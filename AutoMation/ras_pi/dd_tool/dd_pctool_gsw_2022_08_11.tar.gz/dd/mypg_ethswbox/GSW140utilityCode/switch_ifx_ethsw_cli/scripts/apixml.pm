#!/usr/bin/perl -w
use Fcntl;
use Getopt::Std;

################################################################################
# API callback handler to parse the API XML file
my $currentTag = "";
my @tagStack = ();
my $alreadyTagCallbackCalled = 0;
my $XmlHandler;
my $XmlEndHandler;
my %attrHash = ();
my $hashSet = 0;

sub parseAPIfile {
   my $filename = shift;
   $XmlHandler = shift;
   $XmlEndHandler = shift;

   sub default_apixml_pm_handler {
      my ($data) = @_;

      if ($alreadyTagCallbackCalled == 0) {
         if (defined ($XmlHandler)) {
            &{$XmlHandler}($currentTag, $data, %attrHash);
            $alreadyTagCallbackCalled = 1;
         }
      }
   }

   sub start_apixml_pm_handler {
      my ($element) = @_;

      push @tagStack, $currentTag;
      $currentTag .= "/" . $element;
      $alreadyTagCallbackCalled = 0;
   }

   sub end_apixml_pm_handler {
      my ($element) = @_;

      if (defined ($XmlEndHandler)) {
         &{$XmlEndHandler}($currentTag);
      }
      $currentTag = pop @tagStack;
   }

   my $fileData = "";

   sysopen(IN, $filename, O_RDONLY) || die "$filename could not be opened!\n";
   while(<IN>) { $fileData .= $_; }
   close (IN);

   $fileData =~ s/\n+//g;
   $fileData =~ s/\r//g;
   $fileData =~ s/[\ \t]+$//g;

   while (length($fileData)) {
      $fileData =~ s/^[\ \t]+//g;
      if ($fileData =~ /^<\/([^> ]+)>/) {
         #end tag
         my $tag = $1;
         my $pos = index($fileData, $tag);
         substr($fileData, $pos - 2, length( $tag ) + 3, "");
         end_apixml_pm_handler($tag);
      }elsif ($fileData =~ /^<([^>]+)>/) {
         #beginning tag
         my $tag = $1;
         my $pos = index($fileData, $tag);
         substr($fileData, $pos - 1, length( $tag ) + 2, "");

         if ($tag =~ /xml version="1.0"/) {next;}

         my @attriblist = split / /, $tag;
         $hashSet = 0;
         my $clearedHash = 0;
         for (my $i = 1; $i < @attriblist; $i++) {
            if ($attriblist[$i] =~ /([0-9a-zA-Z_]+)="*([0-9a-zA-Z_]+)"*/) {
               my $att = $1;
               my $val = $2;
               if (!$clearedHash) {
                  $clearedHash = 1;
                  %attrHash = ();
               }
               $attrHash{$att} = $val;
               $hashSet = 1;
            }
         }

         start_apixml_pm_handler($attriblist[0]);

         #call the default handler in case the tag does not carry any additional data
         if ($fileData =~ /^[\ \t]+</) {
            default_apixml_pm_handler("");
         }

         #if ($tag = /^\//) {
            #beginning tag is also end tag
         #}

      } elsif ($fileData =~ /^([^<]+)/) {
         #tag data
         my $data = $1;
         my $pos = index($fileData, $data);
         substr($fileData, $pos, length( $data ), "");

         default_apixml_pm_handler($data);

      } else {print $fileData; last;}
   }
}

1;