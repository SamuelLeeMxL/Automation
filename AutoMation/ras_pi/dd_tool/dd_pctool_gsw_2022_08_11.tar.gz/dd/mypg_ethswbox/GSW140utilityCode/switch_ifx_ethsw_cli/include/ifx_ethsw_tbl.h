/****************************************************************************

                               Copyright 2010
                          Lantiq Deutschland GmbH
                   Am Campeon 3; 85579 Neubiberg, Germany

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

*****************************************************************************/
#ifndef _INCLUDE_IFX_ETHSW_TBL_H
#define _INCLUDE_IFX_ETHSW_TBL_H

#include <stdio.h>
#include "ifx_cli_lib.h"


#include "switch_cli_config.h"

extern const IFX_ETHSW_CommandTable_t cmdTable[];

#ifdef SWITCHAPI_HELP_TEXT
extern const char *HelpText[];
#endif /* SWITCHAPI_HELP_TEXT */

#endif /* _INCLUDE_IFX_ETHSW_TBL_H */
