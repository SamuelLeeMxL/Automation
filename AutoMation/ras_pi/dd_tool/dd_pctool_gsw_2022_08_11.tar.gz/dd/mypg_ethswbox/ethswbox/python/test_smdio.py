from pyrpio.mdio import MDIO

val = -1
phy_adr = 4;

mdio_bus = MDIO(clk_pin=27, data_pin=22, path='/dev/gpiochip0')
mdio_bus.open()

#while phy_adr < 32: 
val = mdio_bus.write_c22_register(phy_adr, 31, 0xf70f)
val = mdio_bus.read_c22_register(phy_adr, 0)
print ("addr= ",phy_adr, "value =", hex(val))

val = mdio_bus.write_c22_register(phy_adr, 31, 0xf71f)
val = mdio_bus.read_c22_register(phy_adr, 0)
print ("addr= ",phy_adr, "value =", hex(val))

val = mdio_bus.write_c22_register(phy_adr, 31, 0xf72f)
val = mdio_bus.read_c22_register(phy_adr, 0)
print ("addr= ",phy_adr, "value =", hex(val))

val = mdio_bus.write_c22_register(phy_adr, 31, 0xf73f)
val = mdio_bus.read_c22_register(phy_adr, 0)
print ("addr= ",phy_adr, "value =", hex(val))

val = mdio_bus.write_c22_register(phy_adr, 31, 0xfa80)
val = mdio_bus.read_c22_register(phy_adr, 0)
print ("addr= ",phy_adr, "value =", hex(val))

val = mdio_bus.write_c22_register(phy_adr, 31, 0xfa81)
val = mdio_bus.read_c22_register(phy_adr, 0)
print ("addr= ",phy_adr, "value =", hex(val))
#phy_adr = phy_adr + 1

#
# read MDIO register
#

val = mdio_bus.write_c22_register(phy_adr, 31, 0xf408)
val = mdio_bus.write_c22_register(phy_adr, 0, 0x001e)

val = mdio_bus.write_c22_register(phy_adr, 31, 0xf409)
val = mdio_bus.read_c22_register(phy_adr, 0)

print ("addr= ",phy_adr, "value =", hex(val))

val = mdio_bus.write_c22_register(phy_adr, 31, 0xf408)
val = mdio_bus.write_c22_register(phy_adr, 0, 0x0002)

val = mdio_bus.write_c22_register(phy_adr, 31, 0xf409)
val = mdio_bus.read_c22_register(phy_adr, 0)

print ("addr= ",phy_adr, "value =", hex(val))

val = mdio_bus.write_c22_register(phy_adr, 31, 0xf408)
val = mdio_bus.write_c22_register(phy_adr, 0, 0x0003)





val = mdio_bus.write_c22_register(phy_adr, 31, 0xf409)
val = mdio_bus.read_c22_register(phy_adr, 0)

print ("addr= ",phy_adr, "value =", hex(val))


mdio_bus.close()
