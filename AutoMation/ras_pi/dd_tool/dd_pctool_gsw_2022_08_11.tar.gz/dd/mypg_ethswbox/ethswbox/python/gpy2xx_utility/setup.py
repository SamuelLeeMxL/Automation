#File: setup.py

from distutils.core import setup, Extension

PyGPY21xUtility_module = Extension('_PyGPY2xxUtility', #????,??????? 
                        sources=[   'PyGPY2xx_wrap.c',
                                    'gpy2xx_py_interface.c',
                        			'../../src/api/api_gpy.c',
                        			'../../src/api/gpy/src/api/phy/gpy211_chip.c',
                        			'../../src/api/gpy/src/api/phy/gpy211_phy.c',
                        			'../../src/api/gpy/src/api/macsec/gpy211_macsec.c',
                                    '../../src/fapi/mdio/fapi_mdio.c',
                                    '../../src/phy/mdio/lib/bcm2835.c',
                                    '../../src/phy/mdio/lib/mdio.c',
                                    '../../src/os/os_linux.c',
                                    '../../src/api/gpy/example/pc/wip/user_mdio_interface.c',
                                    '../../src/api/gpy/example/pc/wip/gpy211_utility_gpy2xx.c',
                                    '../../src/api/gpy/example/pc/wip/gpy211_utility_common.c',
                                    '../../src/api/gpy/example/pc/wip/gpy211_utility_f24s.c',
                                    '../../src/api/gpy/example/pc/wip/gpy211_utility_pg31.c',
                                    '../../src/api/gpy/example/pc/wip/gpy211_utility_uart.c',
                                    '../../src/api/gpy/example/pc/wip/gpy211_utility_cmdprocessor.c',
                                    '../../src/api/gpy/example/pc/wip/gpy211_utility_gpy211_menu.c',
                                    '../../src/api/gpy/example/pc/wip/gpy211_utility_main.c',
                                ],
                      )

setup(name = 'PyGPY2xxUtility',	#??????
        version = '0.1',
        author = 'SWIG Docs',
        description = 'Simple swig pht from docs',
        include_dirs=['../../src',
                     '../../src/conf',
                     '../../src/os',
		             '../../src/phy/mdio/lib',
                     '../../src/api/gsw/src/include',
                     '../../src/api',
                     '../../src/api/gpy/src/inc',
                     '../../src/api/gpy/src/api/phy',
                     '../../src/api/gpy/src/os/linux',
                     '../../src/api/gpy/example/pc/wip',
                     '../../src/fapi/mdio',
                     '../../src/fapi/ffu',
                     '../../src/cli',
                     '../../src/cli/cmds',
                     '../../src/apps'],
        ext_modules = [PyGPY21xUtility_module], 
        py_modules = ['_PyGPY2xxUtility'], #?????????
    )
