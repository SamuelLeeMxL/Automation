/******************************************************************************
  Copyright 2020 MaxLinear, Inc.

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

******************************************************************************/
README FILE (Under Construction)

0/ Preriquisite: Cmake, readline 
---------------------------------
       sudo snap install cmake --classic
       apt-get install libreadline-dev

1/ Untar the SW package:
-----------------------
pi@rpi4:~/test $ tar xvfz ../mypg_ethswbox-0.0.2.tar.gz
 
pi@rpi4:~/test/mypg_ethswbox/ethswbox $ ls -l
total 44
-rw-r--r--  1 pi pi   633 Jun 23 11:25 ChangeLog.txt
-rw-r--r--  1 pi pi  3422 Jun 23 11:25 CMakeLists.txt
-rw-r--r--  1 pi pi 19457 Jun 23 11:25 LICENSE
drwxr-xr-x  2 pi pi  4096 Jun 23 11:25 python
-rw-r--r--  1 pi pi   299 Jun 23 11:25 README.txt
-rwxr-xr-x  1 pi pi    56 Jun 23 11:25 set_build.sh
drwxr-xr-x 10 pi pi  4096 Jun 23 11:25 src


2/ configure the toolbox:
------------------------ 
pi@rpi4:~/test/mypg_ethswbox/ethswbox $ . set_build.sh 
-- The C compiler identification is GNU 8.3.0
-- Detecting C compiler ABI info
-- Detecting C compiler ABI info - done
-- Check for working C compiler: /usr/bin/cc - skipped
-- Detecting C compile features
-- Detecting C compile features - done
-- Configuring done
-- Generating done
-- Build files have been written to: /home/pi/test/mypg_ethswbox/ethswbox/build

3/ Build the toolbox:
--------------------
pi@rpi4:~/test/mypg_ethswbox/ethswbox/build $ make
[  4%] Building C object CMakeFiles/fapi_mdio.dir/src/fapi/mdio/fapi_mdio.c.o
[  9%] Linking C static library libfapi_mdio.a
[  9%] Built target fapi_mdio
[ 14%] Building C object CMakeFiles/os.dir/src/os/os_linux.c.o
[ 19%] Linking C static library libos.a
[ 19%] Built target os
[ 23%] Building C object CMakeFiles/api_gpy.dir/src/api/api_gpy.c.o
[ 28%] Building C object CMakeFiles/api_gpy.dir/src/api/gpy/src/api/phy/gpy211_phy.c.o
[ 33%] Building C object CMakeFiles/api_gpy.dir/src/api/gpy/src/api/phy/gpy211_chip.c.o
[ 38%] Linking C static library libapi_gpy.a
[ 38%] Built target api_gpy
[ 42%] Building C object CMakeFiles/phy_mdio.dir/src/phy/mdio/lib/bcm2835.c.o
[ 47%] Building C object CMakeFiles/phy_mdio.dir/src/phy/mdio/lib/mdio.c.o
[ 52%] Linking C static library libphy_mdio.a
[ 52%] Built target phy_mdio
[ 57%] Building C object CMakeFiles/cli.dir/src/cli/cmds/cmds.c.o
[ 61%] Building C object CMakeFiles/cli.dir/src/cli/cmds/cmds_apps.c.o
[ 66%] Building C object CMakeFiles/cli.dir/src/cli/cmds/cmds_fapi.c.o
[ 71%] Linking C static library libcli.a
[ 71%] Built target cli
[ 76%] Building C object CMakeFiles/apps.dir/src/apps/apps_tools_gpy.c.o
[ 80%] Linking C static library libapps.a
[ 80%] Built target apps
[ 85%] Building C object CMakeFiles/fapi_ffu.dir/src/fapi/ffu/fapi_gpy_ffu.c.o
[ 90%] Linking C static library libfapi_ffu.a
[ 90%] Built target fapi_ffu
[ 95%] Building C object CMakeFiles/ethswbox.dir/src/cli/ethswbox.c.o
[100%] Linking C executable ethswbox
[100%] Built target ethswbox
pi@rpi4:~/test/mypg_ethswbox/ethswbox/build $


4/ Create symbolic links for ethswbox application (only once after new build folder):
------------------------------------------------------------------------------------
pi@rpi4:~/test/mypg_ethswbox/ethswbox/build $ ./ethswbox 
Ethernet SW Toolbox version 0.0.2 ... Updating symbolic links!
pi@rpi4:~/test/mypg_ethswbox/ethswbox/build $


5/ Check available commands (type "./" and TAB completion):
---------------------------------------------------------- 
pi@rpi4:~/test/mypg_ethswbox/ethswbox/build $ ./
apps-tools-gpy-recover-lbb-uart  ethswbox                         fapi-ffu-upgrade                 fapi-mdio-c22-write              fapi-mdio-c45-write              
CMakeFiles/                      fapi-ffu-erase                   fapi-mdio-c22-read               fapi-mdio-c45-read               
pi@rpi4:~/test/mypg_ethswbox/ethswbox/build $ ./



5/ Command Help (issue command without parameters for example (type "./" and TAB completion to select the command):
------------------------------------------------------------------------------------------------------------------
pi@rpi4:~/test/mypg_ethswbox/ethswbox/build $ ./fapi-mdio-c22-read
  Usage: fapi-mdio-c22-read ifid port reg
   ifid: Interface Id
   port: PHY port address
    reg: PHY register to read
  (hexadecimal value prefixed with 0x)
pi@rpi4:~/test/mypg_ethswbox/ethswbox/build $ 

6/ Example valid commands (type "./" and TAB completion to select the command):
------------------------------------------------------------------------------
pi@rpi4:~/test/mypg_ethswbox/ethswbox/build $ ./fapi-mdio-c22-read 99 0 0x1e
 read: port=0 reg=0x1e value=0x645
pi@rpi4:~/test/mypg_ethswbox/ethswbox/build $

pi@rpi4:~/test/mypg_ethswbox/ethswbox/build $ ./fapi-mdio-c22-read 99 0 30
 read: port=0 reg=0x1e value=0x645
pi@rpi4:~/test/mypg_ethswbox/ethswbox/build $ 

7/ pctool ( the parameter is PHY address)
-----------------------------------------
pi@rpi4:~/aa_pctool/mypg_ethswbox/ethswbox/build $ ./pctool 0
