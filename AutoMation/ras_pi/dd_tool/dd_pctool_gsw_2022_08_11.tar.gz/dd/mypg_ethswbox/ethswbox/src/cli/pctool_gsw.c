/******************************************************************************

  Copyright (c) 2014 Lantiq Deutschland GmbH
  Copyright 2016, Intel Corporation.

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

******************************************************************************/

/**
   \file pctool_gsw.c
   
*/
#include "os_linux.h"

#include "conf_if.h" 
#include "plm_mdio.h"

#include "f2x_swapi_types.h"
#include "f2x_swapi_flow.h"
#include "gsw_sw_init.h"

#include"pctool_gsw_check.h"

int main_GSW_UTILITY(int argc, char **argv);

extern int gsw_swcli_cmdProcessor(int argc, char *argv[]);
extern int ethsw_swapi_register(void);
extern int ethsw_swapi_unregister(void);
extern GSW_API_HANDLE sdev;


u16 my_fapi_gsw_mdio_get_registers (GSW_API_HANDLE handle)
{
    GSW_MDIO_data_t prm;
    u16 i;
    u16 j;
    u16 ret;
	
    memset(&prm , 0, sizeof(GSW_MDIO_data_t));
	
    for (i = 0; i <96;i++)
    {
        printf ("0x%02X: ", i);
        for (j = 0; j <4;j++)
        {
			prm.nAddressDev = j;
			prm.nAddressReg = i;
		
			ret = gsw_api_kioctl(handle, GSW_MDIO_DATA_READ, (u32)&prm);
			if (ret != GSW_statusOk)
				printf ("error");		
            printf ("0x%04X ",prm.nData);
        }
        printf ("\n");         
    }
    return 0;
}


 
typedef struct mmd_register_t {
    const char  *name;
    u16          dev;
    u16          reg;        
} mmd_register_t;


mmd_register_t T_mmd_register [] =
{
    {"TIMESYNC_CAP:",   1, 0x1800},

    {"EEE_CTRL1 :",     3, 0},
    {"EEE_STAT1 :",     3, 1},
    {"EEE_CAP   :",     3, 0x0014},
    {"EEE_WAKERR:",     3, 0x0016},

    {"  EEE_AN_ADV:",   7, 0x003c},
    {"EEE_AN_LPADV:",   7, 0x003d},

    {"LEDCH:",          0x1f, 0x01e0},
    {"LEDCL:",          0x1f, 0x01e1},
    {"LED0H:",          0x1f, 0x01e2},
    {"LED1H:",          0x1f, 0x01e4},
    {"LED2H:",          0x1f, 0x01e6},
    {"LED3H:",          0x1f, 0x01e8},
    {"LED0L:",          0x1f, 0x01e3},
    {"LED1L:",          0x1f, 0x01e5},
    {"LED2L:",          0x1f, 0x01e7},
    {"LED3L:",          0x1f, 0x01e9},

    {"EEE_RXERR_LINK_FAIL_H:",       0x1f, 0x01ea},
    {"EEE_RXERR_LINK_FAIL_L:",       0x1f, 0x01eb},

    {"WOLCTRL:",        0x1f, 0x0781},
    {"WOLAD0 :",        0x1f, 0x0783},
    {"WOLAD1 :",        0x1f, 0x0784},
    {"WOLAD2 :",        0x1f, 0x0785},
    {"WOLAD3 :",        0x1f, 0x0786},
    {"WOLAD4 :",        0x1f, 0x0787},
    {"WOLAD5 :",        0x1f, 0x0788},
    {"WOLPW0 :",        0x1f, 0x0789},
    {"WOLPW1 :",        0x1f, 0x078a},
    {"WOLPW2 :",        0x1f, 0x078b},
    {"WOLPW3 :",        0x1f, 0x078c},
    {"WOLPW4 :",        0x1f, 0x078d},
    {"WOLPW5 :",        0x1f, 0x078e},

    {"PD_CTL :",        0x1f, 0x07fe},
    {"",                0, 0}
};

u16 my_fapi_gsw_mmd_get_registers (GSW_API_HANDLE handle)
{
    GSW_MMD_data_t prm;
    u16 i;
    u16 j;
    u16 ret;
    u32 addr;
	
    memset(&prm , 0, sizeof(GSW_MmdDataRead));
	
    i = 0;
    do
    {
 

        addr = T_mmd_register[i].dev;
        addr = addr << 16;
        addr |= T_mmd_register[i].reg;
        printf ("[0x%02X] %s : ", addr, T_mmd_register[i].name);
        fflush(stdout);

        for (j = 0; j <4;j++)
        {
			prm.nAddressDev = j;
			prm.nAddressReg = addr;
		
			ret = gsw_api_kioctl(handle, GSW_MMD_DATA_READ, (u32)&prm);
			if (ret != GSW_statusOk)
				printf ("error\n");	
                
            printf ("0x%04X ",prm.nAddressReg);
            printf ("0x%04X ",prm.nData);
            fflush(stdout);
        };
        printf ("\n");
        i++;         
    } while (T_mmd_register[i].name != "");
    return 0;
}



GSW_API_HANDLE MY_GSW_handle; // EMILIO
extern GSW_API_HANDLE sdev; // EMILIO
int main(int argc, char *argv[])
{
    int ret;
    GSW_API_HANDLE handle;
    GSW_HW_Init_t param;
    GSW_MDIO_data_t prm;

    /* Initialized Switch API */
    ret = ethsw_swapi_register();
    if (ret != 0) {
    printf("Failed in switch API initialization.\n");
    return 1;
    }

    /* Open switch device 0 */
    /* The namespace is defined by switch API. */
    /* There may not be device node /dev/switch/0, */
    /* unless Switch API is compiled as driver. */
    handle = gsw_api_kopen("/dev/switch/0");
    if (handle == (GSW_API_HANDLE)NULL) {
    ethsw_swapi_unregister();
    printf("Failed in openning switch device (/dev/switch/0).\n");
    return 1;
    }

    MY_GSW_handle = handle; // EMILIO
    sdev = handle;
    /* open underlying platform mdio link */
    ret = plm_mdio_open (GSW_IFID);
    plm_mdio_trace_off ();

 
#if 0
    ret = my_fapi_gsw_mmd_get_registers (handle);

 //   ret = my_fapi_gsw_mdio_get_registers (handle);


    /* Read MDIO registers */

    memset(&prm , 0, sizeof(GSW_MDIO_data_t));
    prm.nAddressDev = 0;
    prm.nAddressReg = 0x1e;
 
    ret = gsw_api_kioctl(handle, GSW_MDIO_DATA_READ, (u32)&prm);
    if (ret != GSW_statusOk) {
    printf("GSW_MDIO_DATA_READ error!");
    ret = 1;
    } else {
    printf("GSW_HW_INIT_NO ok!: nAddressDev = 0x%x  nAddressReg = 0x%x, nData = 0x%x", 
                prm.nAddressDev, prm.nAddressReg, prm.nData);
    ret = 0;
    }

#else
//   ret = gsw_swcli_cmdProcessor(argc, argv);
  ret = main_GSW_UTILITY(argc, argv);
#endif

    /* close underlying platform mdio link */
    ret = plm_mdio_close (GSW_IFID);

   return ret;         
}

#ifndef EMILIO
#define TOOL_VERSION		"1.0.1"

#define TEMP_BUFFRE_SIZE	16
#define SYS_BUFFER_SIZE		100
#define SERIAL_BUFFER_SIZE	256
#define CMD_LINE_BUFFER_SIZE	1000
#define MAX_PARAM		500

char *param_list1[MAX_PARAM];

#include<readline/readline.h>
#include<readline/history.h>


void system_readl (char* buffer, size_t sbuffer)
{
    char* pbuf;

    pbuf = readline (NULL);
    if (strlen(pbuf) > 0) {
        memcpy(buffer, pbuf, strlen(pbuf));
        add_history(pbuf);
        free(pbuf);
    }
}

 void remove_leading_whitespace(char **p, int *len)
{
	while (*len && ((**p == ' ') || (**p == '\r') || (**p == '\r'))) {
		(*p)++;
		(*len)--;
	}
}
int split_buffer(char *buffer, char *array[], int max_param_num)
{
	int i, set_copy = 0;
	int res = 0;
	int len;

	for (i = 0; i < max_param_num; i++)
		array[i] = NULL;

	if (!buffer)
		return 0;

	len = strlen(buffer);

	for (i = 0; i < max_param_num;) {
		remove_leading_whitespace(&buffer, &len);

		for (;
		     *buffer != ' ' && *buffer != '\0' && *buffer != '\r'
		     && *buffer != '\n' && *buffer != '\t'; buffer++, len--) {
			/*Find first valid charactor */
			set_copy = 1;

			if (!array[i])
				array[i] = buffer;
		}

		if (set_copy == 1) {
			i++;

			if (*buffer == '\0' || *buffer == '\r'
			    || *buffer == '\n') {
				*buffer = 0;
				break;
			}

			*buffer = 0;
			buffer++;
			len--;
			set_copy = 0;

		} else {
			if (*buffer == '\0' || *buffer == '\r'
			    || *buffer == '\n')
				break;

			buffer++;
			len--;
		}
	}

	res = i;

	return res;
}


char ReadLineBuffer[CMD_LINE_BUFFER_SIZE];
char *ArgvBuffer[2*MAX_PARAM];

typedef struct {
	char *name_pctool;
	char *name_gsw;
	char *description;
} PCTOOL_TranscodeCommandTable_t;

PCTOOL_TranscodeCommandTable_t TransCmdTable[];
PCTOOL_TranscodeCommandTable_t TransCmdTable1[];

void print_transcode (void)
{
    PCTOOL_TranscodeCommandTable_t* p;
   p =  TransCmdTable;
    do
    {
       printf ("%s %s %s\n", p->name_pctool, p->name_gsw, p->description);
       p++; 
    }
    while (strcmp(p->name_pctool, "END") !=0);
}

char* transcode (char* str)
{
    PCTOOL_TranscodeCommandTable_t* p;
    p =  TransCmdTable;

    if (str != NULL)
    {
        p =  TransCmdTable;
        do
        {
        if (strcmp(str, p->name_pctool) ==0)
            return p->name_gsw;  
        p++; 
        }
        while (strcmp(p->name_pctool, "END") !=0);
 
 
        p =  TransCmdTable1;
        do
        {
        if (strcmp(str, p->name_pctool) ==0)
            return p->name_gsw;  
        p++; 
        }
        while (strcmp(p->name_pctool, "END") !=0);
    }
   
    return "";
}

void gsw_help (void);
void gsw_help1 (void);


int main_GSW_UTILITY(int argc, char **argv)
{
	int i = 0;
    int ret;

    printf("\n\n####################################################################");
    printf("\n###############  SWITCH UTILITY TOOL (Version: %s)  #############", TOOL_VERSION);
    printf("\n####################################################################\n\n");


	printf("\n\n####################################################################");
	printf("\n##################  ETC SWITCH UTILITY SHELL  ######################");
	printf("\n####################################################################\n\n");

	i = 0;
	while (1) {

		printf("\n\nShell : ");

        /* get the command with readline */
		memset(ReadLineBuffer, 0, sizeof(ReadLineBuffer));
        system_readl (ReadLineBuffer, sizeof(ReadLineBuffer));

        /* Split the command line string into argv */
        argc = split_buffer(ReadLineBuffer, &ArgvBuffer[1] , MAX_PARAM);

        /* prepare for the switch api handling */
        ArgvBuffer[0] = "pctool_gsw";
        ArgvBuffer[1] = transcode(ArgvBuffer[1]);
        argc++;

        /* let's go */
        if ((strcmp(ArgvBuffer[1], "exit") == 0))
        {
            return 1;
        }
        else if ((strcmp(ArgvBuffer[1], "--help") == 0))
        {
            gsw_help();
        }
        else if ((strcmp(ArgvBuffer[1], "--help1") == 0))
        {
            gsw_help1();
        }
#ifdef VALIDATION            
        else if ((strcmp(ArgvBuffer[1], "check") == 0))
        {
            pctool_gsw_check(ArgvBuffer[2]);
        }
#endif            
        else
        {   
            /* invoke the switch cli */    
            if (argc > 1)
                ret = gsw_swcli_cmdProcessor(argc, ArgvBuffer);
        }
   
	}/* End of while (1) loop */
}


/*
*
*
*/



 PCTOOL_TranscodeCommandTable_t TransCmdTable[] = {
		{"HW_Init"                       ,"GSW_HW_INIT", 						": Init Switch Hardware"},
        {"Switch_PortEnable"             ,"", 									": Enable Switch Ports"},
        {"RMON_Clear"                    ,"GSW_RMON_CLEAR", 						": Clear RMON counters per Port"},
        {"RMON_Get"                      ,"GSW_RMON_PORT_GET", 					": Get RMON counters per Port"},
        {"RMON_ExtendGet"                ,"GSW_RMON_EXTEND_GET",					": Get RMON extended counters per Port"},
        {"MAC_TableClear"                ,"GSW_MAC_TABLE_CLEAR",					": Clear MAC Table Entries"},
        {"MAC_TableEntryAdd"             ,"GSW_MAC_TABLE_ENTRY_ADD",				": Set MAC Table Entry"},
        {"MAC_TableEntryQuery"           ,"GSW_MAC_TABLE_ENTRY_QUERY",			": Get MAC Table Entry"},
        {"MAC_TableEntryRead"            ,"GSW_MAC_TABLE_ENTRY_READ",			": Read MAC Table Entries"},
        {"CapGet"                        ,"GSW_CAP_GET",							": Get capability"},        
        {"CfgGet"                        ,"GSW_CFG_GET",							": Get Global Configuration"},
        {"CfgSet"                        ,"GSW_CFG_SET",							": Set Global Configuration"},
        {"PortCfgGet"                    ,"GSW_PORT_CFG_GET",				": Get Port Configuration"},
        {"PortCfgSet"                    ,"GSW_PORT_CFG_SET",				": Set Port Configuration"},
        {"PortRedirectGet"               ,"GSW_PORT_REDIRECT_GET",				": Get Port Redirect Configuration"},
        {"PortRedirectSet"               ,"GSW_PORT_REDIRECT_SET",				": Set Port Redirect Configuration"},
        {"MonitorPortCfgGet"             ,"GSW_MONITOR_PORT_CFG_GET",			": Get Monitor Port Configuration"},
        {"MonitorPortCfgSet"             ,"GSW_MONITOR_PORT_CFG_SET",			": Set Monitor Port Configuration"},
        {"CPU_PortCfgGet"                ,"GSW_CPU_PORT_CFG_GET",				": Get CPU Port Configuration"},
        {"CPU_PortCfgSet"                ,"GSW_CPU_PORT_CFG_SET",				": Set CPU Port Configuration"},
        {"VLAN_IdCreate"                 ,"GSW_VLAN_ID_CREATE",					": Create VLAN ID"},
        {"VLAN_IdDelete"                 ,"GSW_VLAN_ID_DELETE",					": Delete VLAN ID"},
        {"VLAN_IdGet"                    ,"GSW_VLAN_ID_GET",						": Get VLAN ID"},
        {"VLAN_Member_Init"              ,"GSW_VLAN_MEMBER_INIT",				": VLAN Membership Initilization"},
        {"VLAN_PortCfgGet"               ,"GSW_VLAN_PORT_CFG_GET",				": Get VLAN Port Configuration"},
        {"VLAN_PortCfgSet"               ,"GSW_VLAN_PORT_CFG_SET",				": Set VLAN Port Configuration"},
        {"VLAN_PortMemberAdd"            ,"GSW_VLAN_PORT_MEMBER_ADD",			": Add VLAN Port Member Configuration"},
        {"VLAN_PortMemberRemove"         ,"GSW_VLAN_PORT_MEMBER_REMOVE",			": Remove VLAN Port Member Configuration"},
        {"VLAN_PortMemberRead"           ,"GSW_VLAN_PORT_MEMBER_READ",			": Read VLAN Port Member Configuration"},
        {"VLAN_ReservedAdd"              ,"GSW_VLAN_RESERVED_ADD",				": Add VLAN Reserved Configuration"},
        {"VLAN_ReservedRemove"           ,"GSW_VLAN_RESERVED_REMOVE",			": Remove VLAN Reserved Configuration"},
        {"SVLAN_CfgGet"                  ,"GSW_SVLAN_CFG_GET",					": Get SVLAN Configuration"},
        {"SVLAN_CfgSet"                  ,"GSW_SVLAN_CFG_SET",					": Set SVLAN Configuration"},
        {"SVLAN_PortCfgGet"              ,"GSW_SVLAN_PORT_CFG_GET",				": Get SVLAN Port Configuration"},
        {"SVLAN_PortCfgSet"              ,"GSW_SVLAN_PORT_CFG_SET",				": Set SVLAN Port Configuration"},
        {"QoS_MeterCfgGet"               ,"GSW_QOS_METER_CFG_GET",				": Get QoS Meter Configuration"},
        {"QoS_MeterCfgSet"               ,"GSW_QOS_METER_CFG_SET",				": Set QoS Meter Configuration"},
        {"QoS_MeterPortAssign"           ,"GSW_QOS_METER_PORT_ASSIGN",			": Assign Meter Configuration to a Port"},
        {"QoS_MeterPortDeassign"         ,"GSW_QOS_METER_PORT_DEASSIGN",			": Deassign Meter Configuration to a Port"},
        {"QoS_ClassDSCP_Get"             ,"GSW_QOS_CLASS_DSCP_GET",				": Get QoS Class DSCP Mapping Configuration"},
        {"QoS_ClassDSCP_Set"             ,"GSW_QOS_CLASS_DSCP_SET",				": Set QoS Class DSCP Mapping Configuration"},
        {"QoS_ClassPCP_Get"              ,"GSW_QOS_CLASS_PCP_GET",				": Get QoS Class PCP Mapping Configuration"},
        {"QoS_ClassPCP_Set"              ,"GSW_QOS_CLASS_PCP_SET",				": Set QoS Class PCP Mapping Configuration"},
        {"QoS_DSCP_ClassGet"             ,"GSW_QOS_DSCP_CLASS_GET",				": Get QoS DSCP Class Mapping Configuration"},
        {"QoS_DSCP_ClassSet"             ,"GSW_QOS_DSCP_CLASS_SET",				": Set QoS DSCP Class Mapping Configuration"},
        {"QoS_DSCP_DropPrecedenceCfgGet" ,"GSW_QOS_DSCP_DROP_PRECEDENCE_CFG_GET",": Get QoS DSCP Drop Precedence Configuration"},
        {"QoS_DSCP_DropPrecedenceCfgSet" ,"GSW_QOS_DSCP_DROP_PRECEDENCE_CFG_SET",": Set QoS DSCP Drop Precedence Configuration"},
        {"QoS_FlowctrlCfgGet"            ,"GSW_QOS_FLOWCTRL_CFG_GET",			": Get QoS Flow Control Configuration"},
        {"QoS_FlowctrlCfgSet"            ,"GSW_QOS_FLOWCTRL_CFG_SET",			": Set QoS Flow Control Configuration"},
        {"QoS_FlowctrlPortCfgGet"        ,"GSW_QOS_FLOWCTRL_PORT_CFG_GET",		": Get QoS Flow Control Port Configuration"},
        {"QoS_FlowctrlPortCfgSet"        ,"GSW_QOS_FLOWCTRL_PORT_CFG_SET",		": Set QoS Flow Control Port Configuration"},
        {"QoS_PCP_ClassGet"              ,"GSW_QOS_PCP_CLASS_GET",				": Get QoS PCP Class Mapping Configuration"},
        {"QoS_PCP_ClassSet"              ,"GSW_QOS_PCP_CLASS_SET",				": Set QoS PCP Class Mapping Configuration"},
        {"QoS_PortCfgGet"                ,"GSW_QOS_PORT_CFG_GET",					": Get QoS Port Configuration"},
        {"QoS_PortCfgSet"                ,"GSW_QOS_PORT_CFG_SET",					": Set QoS Port Configuration"},
        {"QoS_PortRemarkingCfgGet"       ,"GSW_QOS_PORT_REMARKING_CFG_GET",		": Get QoS Port Remarking Configuration"},
        {"QoS_PortRemarkingCfgSet"       ,"GSW_QOS_PORT_REMARKING_CFG_SET",		": Set QoS Port Remarking Configuration"},
        {"QoS_QueueBufferReserveCfgGet"  ,"GSW_QOS_QUEUE_BUFFER_RESERVE_CFG_GET",": Get QoS Buffer Reservation Configuration"},
        {"QoS_QueueBufferReserveCfgSet"  ,"GSW_QOS_QUEUE_BUFFER_RESERVE_CFG_SET",": Set QoS Buffer Reservation Configuration"},
        {"QoS_QueuePortGet"              ,"GSW_QOS_QUEUE_PORT_GET",				": Get QoS Queue Port Configuration"},
        {"QoS_QueuePortSet"              ,"GSW_QOS_QUEUE_PORT_SET",				": Set QoS Queue Port Configuration"},
        {"QoS_SchedulerCfgGet"           ,"GSW_QOS_SCHEDULER_CFG_GET",			": Get QoS Scheduler Configuration"},
        {"QoS_SchedulerCfgSet"           ,"GSW_QOS_SCHEDULER_CFG_SET",			": Set QoS Scheduler Configuration"},
        {"QoS_ShaperCfgGet"              ,"GSW_QOS_SHAPER_CFG_GET",				": Get QoS Shaper Configuration"},
        {"QoS_ShaperCfgSet"              ,"GSW_QOS_SHAPER_CFG_SET",				": Set QoS Shaper Configuration"},
        {"QoS_ShaperQueueAssign"         ,"GSW_QOS_SHAPER_QUEUE_ASSIGN",			": Assign QoS Shaper Queue"},
        {"QoS_ShaperQueueDeassign"       ,"GSW_QOS_SHAPER_QUEUE_DEASSIGN",		": Deassign QoS Shaper Queue"},
        {"QoS_ShaperQueueGet"            ,"GSW_QOS_SHAPER_QUEUE_GET",			": Get QoS Shaper Queue"},
        {"QoS_StormCfgGet"               ,"GSW_QOS_STORM_CFG_GET",				": Get QoS Storm Configuration"},
        {"QoS_StormCfgSet"               ,"GSW_QOS_STORM_CFG_SET",				": Set QoS Storm Configuration"},
        {"QoS_SVLAN_ClassPCP_PortGet"    ,"GSW_QOS_SVLAN_CLASS_PCP_PORT_GET",	": Get QoS SVLAN Class PCP Port Configuration"},
        {"QoS_SVLAN_ClassPCP_PortSet"    ,"GSW_QOS_SVLAN_CLASS_PCP_PORT_SET",	": Set QoS SVLAN Class PCP Port Configuration"},
        {"QoS_SVLAN_PCP_ClassGet"        ,"GSW_QOS_SVLAN_PCP_CLASS_GET",			": Get QoS SVLAN PCP Class Configuration"},
        {"QoS_SVLAN_PCP_ClassSet"        ,"GSW_QOS_SVLAN_PCP_CLASS_SET",			": Set QoS SVLAN PCP Class Configuration"},
        {"QoS_WredCfgGet"                ,"GSW_QOS_WRED_CFG_GET",				": Get QoS WRED Configuration"},
        {"QoS_WredCfgSet"                ,"GSW_QOS_WRED_CFG_SET",				": Set QoS WRED Configuration"},
        {"QoS_WredPortCfgGet"            ,"GSW_QOS_WRED_PORT_CFG_GET",			": Get QoS WRED Port Configuration"},
        {"QoS_WredPortCfgSet"            ,"GSW_QOS_WRED_PORT_CFG_SET",			": Set QoS WRED Port Configuration"},
        {"QoS_WredQueueCfgGet"           ,"GSW_QOS_WRED_QUEUE_CFG_GET",			": Get QoS WRED Queue Configuration"},
        {"QoS_WredQueueCfgSet"           ,"GSW_QOS_WRED_QUEUE_CFG_SET",			": Set QoS WRED Queue Configuration"},
        {"MDIO_CfgGet"                   ,"GSW_MDIO_CFG_GET",					": Get MDIO Configuration"},
        {"MDIO_CfgSet"                   ,"GSW_MDIO_CFG_SET",					": Set MDIO Configuration"},
        {"MDIO_DataRead"                 ,"GSW_MDIO_DATA_READ",					": Read MDIO Data"},
        {"MDIO_DataWrite"                ,"GSW_MDIO_DATA_WRITE",					": Write MDIO Data"},
        {"MMD_DataRead"                  ,"GSW_MMD_DATA_READ",					": Read MMD Data"},
        {"MMD_DataWrite"                 ,"GSW_MMD_DATA_WRITE",					": Write MMD Data"},
        {"MULTICAST_Router_Port_Add"     ,"GSW_MULTICAST_ROUTER_PORT_ADD",		": Multicast router port add"},
        {"MULTICAST_Router_Port_Read"    ,"GSW_MULTICAST_ROUTER_PORT_READ",		": Multicast router port read"},
        {"MULTICAST_Router_Port_Remove"  ,"GSW_MULTICAST_ROUTER_PORT_REMOVE",	": Multicast router port remove"},
        {"MULTICAST_Snoop_Cfg_Get"       ,"GSW_MULTICAST_SNOOP_CFG_GET",			": Multicast snooping configuration get"},
        {"MULTICAST_Snoop_Cfg_Set"       ,"GSW_MULTICAST_SNOOP_CFG_SET",			": Multicast snooping configuration set"},
        {"MULTICAST_Table_Entry_Add"     ,"GSW_MULTICAST_TABLE_ENTRY_ADD",		": Multicast table entry add"},
        {"MULTICAST_Table_Entry_Read"    ,"GSW_MULTICAST_TABLE_ENTRY_READ",		": Multicast table entry read"},
        {"MULTICAST_Table_Entry_Remove"  ,"GSW_MULTICAST_TABLE_ENTRY_REMOVE",	": Multicast table entry remove"},
        {"PCE_Rule_Write"                ,"GSW_PCE_RULE_WRITE",					": PCE rule write"},
        {"PCE_Rule_Read"                 ,"GSW_PCE_RULE_READ",					": PCE rule read"},
        {"TRUNKING_Cfg_Get"              ,"GSW_TRUNKING_CFG_GET",				": Read out the current port trunking algorithm"},
        {"TRUNKING_Cfg_Set"              ,"GSW_TRUNKING_CFG_SET",				": Configure the current port trunking algorithm"},
        {"TRUNKING_Port_Cfg_Get"         ,"GSW_TRUNKING_PORT_CFG_GET",			": Read out the port trunking state of a given physical Ethernet switch port"},
        {"TRUNKING_Port_Cfg_Set"         ,"GSW_TRUNKING_PORT_CFG_SET",			": Configure the port trunking on two physical Ethernet switch ports"},
        {"PORT_LinkCfgSet"               ,"GSW_PORT_LINK_CFG_SET",				": Configure the port Link"},
        {"PORT_LinkCfgGet"               ,"GSW_PORT_LINK_CFG_GET",				": Read out the port Link status"},
        {"PORT_PhyAddrGet"               ,"GSW_PORT_PHY_ADDR_GET",				": Read out the port phy address"},
        {"PORT_PhyQuery"                 ,"GSW_PORT_PHY_QUERY",				    ": Check the port phy"},
        {"EnableDebug"                   ,"",									": Enable/Disable debug option"},
        {"help"                          ,"--help",									": Exit switch utility tool"},
        {"Exit"                          ,"exit",									": Exit switch utility tool"},
        {"exit"                          ,"exit",									": Exit switch utility tool"},
        {"check"                         ,"check",									": Check switch utility tool"},
        {"END"                          ,"",									": END"}
};



PCTOOL_TranscodeCommandTable_t TransCmdTable1[] = {
        {"RegisterGet"                   ,"GSW_REGISTER_GET",                  ": Read Switch Internal Register"},
        {"RegisterSet"                   ,"GSW_REGISTER_SET",                  ": Write Switch Internal Register"},
        {"8021X_EapolRuleGet"            ,"GSW_8021X_EAPOL_RULE_GET",          ": Read IEEE 802.1x filter configuration"},
        {"8021X_EapolRuleSet"            ,"GSW_8021X_EAPOL_RULE_SET",          ": Set IEEE 802.1x Port filter rule"},
        {"8021X_PortCfgGet"              ,"GSW_8021X_PORT_CFG_GET",            ": Get 802.1x port status"},
        {"8021x_PortCfgSet"               ,"GSW_8021X_PORT_CFG_SET",            ": Set 802.1x port status"},
        {"Reset"                         ,"GSW_RESET",                         ": Switch Hardware Reset"},
        {"Disable"                       ,"GSW_DISABLE",                       ": Switch Disable"},
        {"Enable"                        ,"GSW_ENABLE",                        ": Switch Enable"},
        {"PORT_RgmiiClkCfgGet"           ,"GSW_PORT_RGMII_CLK_CFG_GET",        ": Read RGMII clocking parameter (when Port configured in RGMII mode"},
        {"PORT_RgmiiClkCfgSet"           ,"GSW_PORT_RGMII_CLK_CFG_SET",        ": Configure RGMII clocking parameter RGMII (when Port configured in RGMII mode"},
        {"STP_BpduRuleGet"               ,"GSW_STP_BPDU_RULE_GET",             ": Get Spanning Tree configuration"},
        {"STP_BpduRuleSet"               ,"GSW_STP_BPDU_RULE_SET",             ": Set Spanning Tree Configuration"},
        {"STP_PortCfgSet"                ,"GSW_STP_PORT_CFG_GET",              ": Get Configuration Spanning Tree Ethernet Port"},
        {"STP_PortCfgGet"                ,"GSW_STP_PORT_CFG_SET",              ": Set Configuration Spanning Tree Ethernet Port"},
        {"VersionGet"                    ,"GSW_VERSION_GET",                   ": Retrieve the version string of the currently version index"},
        {"WOL_CfgGet"                    ,"GSW_WOL_CFG_GET",                   ": Get the Wake-on-LAN configuration"},
        {"Wol_CfgGSet"                   ,"GSW_WOL_CFG_SET",                   ": Set the Wake-on-LAN configuration"},
        {"WOL_PortCfgGet"                ,"GSW_WOL_PORT_CFG_GET",              ": Get current status of the Wake-On-LAN feature on a dedicated port"},
        {"WOL_PortCfgSet"                ,"GSW_WOL_PORT_CFG_SET",              ": Set the current Wake-On-LAN status for a dedicated port"},
        {"Irq_Get"                       ,"GSW_IRQ_GET",                       ": Get the interrupt status"},
        {"Irq_MaskSet"                   ,"GSW_IRQ_MASK_SET",                  ": Set the interrupt enable configuration"},
        {"Irq_StatusClear"               ,"GSW_IRQ_STATUS_CLEAR",              ": Clear individual interrupt status bits"},
        {"TIMESTAMP_TimerGet"            ,"GSW_TIMESTAMP_TIMER_GET",           ": Get the global packet timestamp reference counter"},
        {"TIMESTAMP_TimerSet"            ,"GSW_TIMESTAMP_TIMER_SET",           ": Set the global packet timestamp reference counter"},
        {"TIMESTAMP_PortRead"           ,"GSW_TIMESTAMP_PORT_READ",           ": Get Port related timestamp values"},
        {"help1"                         ,"--help1",	   					   ": Exit switch utility tool"},
        {"END"                           ,"",                                  ": END"}
};


void gsw_help (void)
{
		printf("\n\n\n\tSwitch Utility Tool Version   : %s", TOOL_VERSION);
		printf("\n\t*************************************\n\n");

printf (
"        ""HW_Init                       : Init Switch Hardware\n"
"        ""Switch_PortEnable             : Enable Switch Ports\n"
"        ""RMON_Clear                    : Clear RMON counters per Port\n"
"        ""RMON_Get                      : Get RMON counters per Port\n"
"        ""RMON_ExtendGet                : Get RMON extended counters per Port\n"
"        ""MAC_TableClear                : Clear MAC Table Entries\n"
"        ""MAC_TableEntryAdd             : Set MAC Table Entry\n"
"        ""MAC_TableEntryQuery           : Get MAC Table Entry\n"
"        ""MAC_TableEntryRead            : Read MAC Table Entries\n"
"        ""CapGet                        : Get Capabilities\n"
"        ""CfgGet                        : Get Global Configuration\n"
"        ""CfgSet                        : Set Global Configuration\n"
"        ""PortCfgGet                    : Get Port Configuration\n"
"        ""PortCfgSet                    : Set Port Configuration\n"
"        ""PortRedirectGet               : Get Port Redirect Configuration\n"
"        ""PortRedirectSet               : Set Port Redirect Configuration\n"
"        ""MonitorPortCfgGet             : Get Monitor Port Configuration\n"
"        ""MonitorPortCfgSet             : Set Monitor Port Configuration\n"
"        ""CPU_PortCfgGet                : Get CPU Port Configuration\n"
"        ""CPU_PortCfgSet                : Set CPU Port Configuration\n"
"        ""VLAN_IdCreate                 : Create VLAN ID\n"
"        ""VLAN_IdDelete                 : Delete VLAN ID\n"
"        ""VLAN_IdGet                    : Get VLAN ID\n"
"        ""VLAN_Member_Init              : VLAN Membership Initilization\n"
"        ""VLAN_PortCfgGet               : Get VLAN Port Configuration\n"
"        ""VLAN_PortCfgSet               : Set VLAN Port Configuration\n"
"        ""VLAN_PortMemberAdd            : Add VLAN Port Member Configuration\n"
"        ""VLAN_PortMemberRemove         : Remove VLAN Port Member Configuration\n"
"        ""VLAN_PortMemberRead           : Read VLAN Port Member Configuration\n"
"        ""VLAN_ReservedAdd              : Add VLAN Reserved Configuration\n"
"        ""VLAN_ReservedRemove           : Remove VLAN Reserved Configuration\n"
"        ""SVLAN_CfgGet                  : Get SVLAN Configuration\n"
"        ""SVLAN_CfgSet                  : Set SVLAN Configuration\n"
"        ""SVLAN_PortCfgGet              : Get SVLAN Port Configuration\n"
"        ""SVLAN_PortCfgSet              : Set SVLAN Port Configuration\n"
"        ""QoS_MeterCfgGet               : Get QoS Meter Configuration\n"
"        ""QoS_MeterCfgSet               : Set QoS Meter Configuration\n"
"        ""QoS_MeterPortAssign           : Assign Meter Configuration to a Port\n"
"        ""QoS_MeterPortDeassign         : Deassign Meter Configuration to a Port\n"
"        ""QoS_ClassDSCP_Get             : Get QoS Class DSCP Mapping Configuration\n"
"        ""QoS_ClassDSCP_Set             : Set QoS Class DSCP Mapping Configuration\n"
"        ""QoS_ClassPCP_Get              : Get QoS Class PCP Mapping Configuration\n"
"        ""QoS_ClassPCP_Set              : Set QoS Class PCP Mapping Configuration\n"
"        ""QoS_DSCP_ClassGet             : Get QoS DSCP Class Mapping Configuration\n"
"        ""QoS_DSCP_ClassSet             : Set QoS DSCP Class Mapping Configuration\n"
"        ""QoS_DSCP_DropPrecedenceCfgGet : Get QoS DSCP Drop Precedence Configuration\n"
"        ""QoS_DSCP_DropPrecedenceCfgSet : Set QoS DSCP Drop Precedence Configuration\n"
"        ""QoS_FlowctrlCfgGet            : Get QoS Flow Control Configuration\n"
"        ""QoS_FlowctrlCfgSet            : Set QoS Flow Control Configuration\n"
"        ""QoS_FlowctrlPortCfgGet        : Get QoS Flow Control Port Configuration\n"
"        ""QoS_FlowctrlPortCfgSet        : Set QoS Flow Control Port Configuration\n"
"        ""QoS_PCP_ClassGet              : Get QoS PCP Class Mapping Configuration\n"
"        ""QoS_PCP_ClassSet              : Set QoS PCP Class Mapping Configuration\n"
"        ""QoS_PortCfgGet                : Get QoS Port Configuration\n"
"        ""QoS_PortCfgSet                : Set QoS Port Configuration\n"
"        ""QoS_PortRemarkingCfgGet       : Get QoS Port Remarking Configuration\n"
"        ""QoS_PortRemarkingCfgSet       : Set QoS Port Remarking Configuration\n"
"        ""QoS_QueueBufferReserveCfgGet  : Get QoS Buffer Reservation Configuration\n"
"        ""QoS_QueueBufferReserveCfgSet  : Set QoS Buffer Reservation Configuration\n"
"        ""QoS_QueuePortGet              : Get QoS Queue Port Configuration\n"
"        ""QoS_QueuePortSet              : Set QoS Queue Port Configuration\n"
"        ""QoS_SchedulerCfgGet           : Get QoS Scheduler Configuration\n"
"        ""QoS_SchedulerCfgSet           : Set QoS Scheduler Configuration\n"
"        ""QoS_ShaperCfgGet              : Get QoS Shaper Configuration\n"
"        ""QoS_ShaperCfgSet              : Set QoS Shaper Configuration\n"
"        ""QoS_ShaperQueueAssign         : Assign QoS Shaper Queue\n"
"        ""QoS_ShaperQueueDeassign       : Deassign QoS Shaper Queue\n"
"        ""QoS_ShaperQueueGet            : Get QoS Shaper Queue\n"
"        ""QoS_StormCfgGet               : Get QoS Storm Configuration\n"
"        ""QoS_StormCfgSet               : Set QoS Storm Configuration\n"
"        ""QoS_SVLAN_ClassPCP_PortGet    : Get QoS SVLAN Class PCP Port Configuration\n"
"        ""QoS_SVLAN_ClassPCP_PortSet    : Set QoS SVLAN Class PCP Port Configuration\n"
"        ""QoS_SVLAN_PCP_ClassGet        : Get QoS SVLAN PCP Class Configuration\n"
"        ""QoS_SVLAN_PCP_ClassSet        : Set QoS SVLAN PCP Class Configuration\n"
"        ""QoS_WredCfgGet                : Get QoS WRED Configuration\n"
"        ""QoS_WredCfgSet                : Set QoS WRED Configuration\n"
"        ""QoS_WredPortCfgGet            : Get QoS WRED Port Configuration\n"
"        ""QoS_WredPortCfgSet            : Set QoS WRED Port Configuration\n"
"        ""QoS_WredQueueCfgGet           : Get QoS WRED Queue Configuration\n"
"        ""QoS_WredQueueCfgSet           : Set QoS WRED Queue Configuration\n"
"        ""MDIO_CfgGet                   : Get MDIO Configuration\n"
"        ""MDIO_CfgSet                   : Set MDIO Configuration\n"
"        ""MDIO_DataRead                 : Read MDIO Data\n"
"        ""MDIO_DataWrite                : Write MDIO Data\n"
"        ""MMD_DataRead                  : Read MMD Data\n"
"        ""MMD_DataWrite                 : Write MMD Data\n"
"        ""MULTICAST_Router_Port_Add     : Multicast router port add\n"
"        ""MULTICAST_Router_Port_Read    : Multicast router port read\n"
"        ""MULTICAST_Router_Port_Remove  : Multicast router port remove\n"
"        ""MULTICAST_Snoop_Cfg_Get       : Multicast snooping configuration get\n"
"        ""MULTICAST_Snoop_Cfg_Set       : Multicast snooping configuration set\n"
"        ""MULTICAST_Table_Entry_Add     : Multicast table entry add\n"
"        ""MULTICAST_Table_Entry_Read    : Multicast table entry read\n"
"        ""MULTICAST_Table_Entry_Remove  : Multicast table entry remove\n"
"        ""PCE_Rule_Write                : PCE rule write\n"
"        ""PCE_Rule_Read                 : PCE rule read\n"
"        ""TRUNKING_Cfg_Get              : Read out the current port trunking algorithm\n"
"        ""TRUNKING_Cfg_Set              : Configure the current port trunking algorithm\n"
"        ""TRUNKING_Port_Cfg_Get         : Read out the port trunking state of a given physical Ethernet switch port\n"
"        ""TRUNKING_Port_Cfg_Set         : Configure the port trunking on two physical Ethernet switch ports\n"
"        ""PORT_LinkCfgSet               : Configure the port Link\n"
"        ""PORT_LinkCfgGet               : Read out the port Link status\n"
"        ""EnableDebug                   : Enable/Disable debug option\n"
"        ""Exit                          : Exit switch utility tool\n"
"\n"
"IMPORTANT NOTE:\n"
"\n"

"For hex decimal input param please add 0x before the hex decimal number or just give decimal number\n"
"Perfix hex decimal value with 0x or  Switch command execution will lead to wrong setting or malfunction\n"
    );
}


void gsw_help1 (void)
{

printf (
"        ""RegisterGet                    : Read Switch Internal Register\n"
"        ""RegisterSet                    : Write Switch Internal Register\n"
"        ""8021X_EapolRuleGet             : Read IEEE 802.1x filter configuration\n"
"        ""8021X_EapolRuleSet             : Set IEEE 802.1x Port filter rule\n"
"        ""8021X_PortCfgGet               : Get 802.1x port status\n"
"        ""8021xPortCfgSet                : Set 802.1x port status\n"
"        ""Reset                          : Switch Hardware Reset\n"
"        ""Disable                        : Switch Disable\n"
"        ""Enable                         : Switch Enable\n"
"        ""PORT_RgmiiClkCfgGet            : Read RGMII clocking parameter (when Port configured in RGMII mode\n"
"        ""PORT_RgmiiClkCfgSet            : Configure RGMII clocking parameter RGMII (when Port configured in RGMII mode\n"
"        ""STP_BpduRuleGet                : Get Spanning Tree configuration\n"
"        ""STP_BpduRuleSet                : Set Spanning Tree Configuration\n"
"        ""STP_PortCfgSet                 : Get Configuration Spanning Tree Ethernet Port\n"
"        ""STP_PortCfgGet                 : Set Configuration Spanning Tree Ethernet Port\n"
"        ""VersionGet                     : Retrieve the version string of the currently version index\n"
"        ""WOL_CfgGet                     : Get the Wake-on-LAN configuration\n"
"        ""Wol_CfgGSet                    : Set the Wake-on-LAN configuration\n"
"        ""WOL_PortCfgGGet                : Get current status of the Wake-On-LAN feature on a dedicated port\n"
"        ""WOL_PortCfgGSet                : Set the current Wake-On-LAN status for a dedicated port\n"
"        ""Irq_Set                        : Get the interrupt status\n"
"        ""Irq_Get                        : Get the interrupt enable configuration\n"
"        ""Irq_MaskSet                    : Set the interrupt enable configuration\n"
"        ""Irq_StatusClear                : Clear individual interrupt status bits\n"
"        ""TIMESTAMP_TimerGet             : Get the global packet timestamp reference counter\n"
"        ""TIMESTAMP_TimerSet             : Set the global packet timestamp reference counter\n"
"        ""TIMESTAMP_TimerRead            : Get Port related timestamp values\n"
    );
};

#endif
