#ifndef _CONF_IF_H
#define _CONF_IF_H
/******************************************************************************

  Copyright (c) 2014 Lantiq Deutschland GmbH
  Copyright 2016, Intel Corporation.

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

******************************************************************************/
/**
   \file conf_if.h
   
    PHY Interface configuration.

    /* TO DO, THINK: Phy Interface Id not yet implemented
    we have only type of interface: RPI, MDIO BITBANG....
    */
   
 

#ifdef __cplusplus
   extern "C" {
#endif

/* ============================= */
/* Includes                      */
/* ============================= */



/* ============================= */
/* Definition                    */
/* ============================= */
#ifndef SMDIO_ADDR
#define SMDIO_ADDR 0x1f  
#endif

/* Definition PHY interface:
   RPI4 GPIO MDIO BITBANG  */
#define GPY_IFID                  0x10                     
#define RPI4B_GPIO_MDIO_CLK_PIN   23
#define RPI4B_GPIO_MDIO_DATA_PIN  24
#define RPI4B_GPIO_MEM 1


/* Definition PHY interface:
   RPI4 GPIO GSW MDIO BITBANG  */
#define GSW_IFID                     0x20
#define RPI4B_GPIO_GSW_MDIO_CLK_PIN  3
#define RPI4B_GPIO_GSW_MDIO_DATA_PIN 2 

#define GSW_SMDIO_ADDR          0x1F
#define GSW_SMDIO_TARGET_BASE   0x1F
#define GSW_SMDIO_TARGET_OFFSET 0x00



#ifdef __cplusplus
}
#endif

#endif /* _CONF_IF_H */
