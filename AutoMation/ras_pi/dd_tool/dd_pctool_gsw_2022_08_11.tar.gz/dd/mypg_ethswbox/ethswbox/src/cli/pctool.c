/******************************************************************************

  Copyright (c) 2014 Lantiq Deutschland GmbH
  Copyright 2016, Intel Corporation.

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

******************************************************************************/

/**
   \file ethswbox.c
   
*/
#include "os_linux.h"
 
#include "gpy211_utility_main.h"

int main(int argc, char *argv[])
{
   int ret;

   ret = main_GPY211_UTILITY(argc, argv);

   return ret;         
}
