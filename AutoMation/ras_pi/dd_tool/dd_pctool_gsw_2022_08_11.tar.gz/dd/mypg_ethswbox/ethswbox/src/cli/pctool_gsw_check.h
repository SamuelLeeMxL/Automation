#ifndef _PCTOOL_GSW_CHECK_H
#define _PCTOOL_GSW_CHECK_H
/******************************************************************************

  Copyright (c) 2014 Lantiq Deutschland GmbH
  Copyright 2016, Intel Corporation.

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

******************************************************************************/

/**
   \file pctool_check.h
   
*/

#ifdef __cplusplus
   extern "C" {
#endif
#define VALIDATION
int pctool_gsw_check (char* name);

int Cmds_Check_rmon (void);
int Cmds_Check_mac (void);
int Cmds_Check_cfg (void);
int Cmds_Check_port (void);
int Cmds_Check_mon (void);
int Cmds_Check_cpu (void);
int Cmds_Check_vlan (void);
int Cmds_Check_svlan (void);
int Cmds_Check_qos (void);
int Cmds_Check_mcast (void);
int Cmds_Check_pce (void);
int Cmds_Check_trunk (void);
int Cmds_Check_portlk (void);


#ifdef __cplusplus
}
#endif


#endif /* _PCTOOL_GSW_CHECK_H */
