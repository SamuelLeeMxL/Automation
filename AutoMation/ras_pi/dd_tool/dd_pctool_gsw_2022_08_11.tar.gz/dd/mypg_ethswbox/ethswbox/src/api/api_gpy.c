/******************************************************************************

    Copyright 2021 Maxlinear

    SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only)

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.
******************************************************************************/

/**
   \file api_gpy.c
   This files implements the functions for accessing the PHY thru the GPYAPI driver.


*/

/* ============================= */
/* Includes                      */
/* ============================= */
#include "os.h"
#include "types.h"

/* GPYAPI access */
#include "gpy211_common.h"
#include "gpy211_phy.h"
#include "gpy211_regs.h"

#include "api_gpy.h"

/* Phy interface configuration */
#include "conf_if.h"

/*********************************************
* local Prototypes                           *
*********************************************/
#if 0 /* TEMPORARY PCTOOL intergration */
static int api_gpy_read(void *mdiobus_data, u16 addr, u32 regnum);
static int api_gpy_write(void *mdiobus_data, u16 addr, u32 regnum, u16 val);
#endif

/*********************************************
*   VARIABLES                                *
*********************************************/
/*
    For communicating with GPHY APIs, the user application
    uses gpy211_device structure when invoking the API. this
    file implements the user application for accessing the
    PHY devices through the GPYAPI.
        - GpyEthPhyDevice: GPY PHY device structure
        - GpyEthPhyData:   GPY PHY device data
*/
static struct gpy211_device GpyEthPhyDevice;

/* .lock, .unlock, .lock_data */
static u16 GpyEthPhyData;


/* structure for holding pins, PHY port and device */
struct phy_if  {
    u8 clk_pin;
    u8 data_pin;
	u16 port;
	u16 dev; 
};
static struct phy_if phyif;


/*********************************************
* Local Functions                            *
*********************************************/

/**
   Dummy function for GpyEthPhyDevice context.

   \param
      void*  data


   \return
      none
*/
static void GpyEthPhyDummy(void *data)
{
	(void)data;
}


/**
   PHY Register Read function through PCI MMIO MDIO interface according to
   the Clause 22 or 45.
   This function is invoked by the underlying GPYAPI driver for accessing
   the PHY thru MDIO.    

   \param
      void* mdiobus_data
      u16   addr
      u32   regnum

   \return
      >=0:  register value
      <0:   error
*/
int api_gpy_read(void *mdiobus_data, u16 addr, u32 regnum)
{
   u16 val;
   u32 devad; 
 
   if(regnum & MII_ADDR_C45) 
   {
      devad = ((regnum >> 16) & 0x1f);
      regnum = regnum & 0xFFFF ;

	  val =  mdio_c45_read (phyif.clk_pin, phyif.data_pin, addr, devad, regnum);
 #if 0 
      printf ("api_gpy_read: mdio_c45_read: clk_pin = %d, data_pin = %d, addr = %d, devad = 0x%x, regnum = 0x%x val = 0x%x\n",
      phyif.clk_pin, phyif.data_pin, addr, devad, regnum, val); 
 #endif
   }
   else 
   {
	  val =  mdio_c22_read (phyif.clk_pin, phyif.data_pin,  addr, regnum);
   
#if 0
      printf ("api_gpy_read: mdio_c22_read: clk_pin = %d, data_pin = %d, addr = %d, regnum = 0x%x val = 0x%x\n",  
      phyif.clk_pin, phyif.data_pin, addr, regnum, val); 
#endif
   } 
   return val;
}

/**
   PHY Register Write function through PCI MMIO MDIO interface according to
   the Clause 22 or 45.
   This function is invoked by the underlying GPYAPI driver for accessing
   the PHY thru MDIO.    

   \param
      void* mdiobus_data
      u16   addr
      u32   regnum
      u16   val

   \return
      >=0:  success
      <0:   error

*/
int api_gpy_write(void *mdiobus_data, u16 addr, u32 regnum, u16 val)
{
   int ret;
   u32 devad; 
   
   if(regnum & MII_ADDR_C45) 
   {
      devad = ((regnum >> 16) & 0x1f);
      regnum = regnum & 0xFFFF ; 
   	  ret =  mdio_c45_write(phyif.clk_pin, phyif.data_pin,  addr, devad, regnum, val);

#if 0
      printf ("api_gpy_write: mdio_c45_write: clk_pin = %d, data_pin = %d, addr = %d, devad = 0x%x, regnum = 0x%x val = 0x%x\n",
      phyif.clk_pin, phyif.data_pin, addr, devad, regnum, val);
#endif	  
   }
   else
   {
   	   ret = mdio_c22_write(phyif.clk_pin, phyif.data_pin,  addr, regnum, val);

#if 0
	   printf ("api_gpy_write: mdio_c22_write: clk_pin = %d, data_pin = %d, addr = %d, regnum = 0x%x val = 0x%x\n",
       phyif.clk_pin, phyif.data_pin, addr, regnum, val);
#endif	   
   }
   return ret; 
}



/*********************************************
* Global Functions                           *
*********************************************/

/**
   This function open the API and returns the PHY device context 
   according to the provided phy interface id.
   (TO DO, THINK: under construction)

   \param
      u16 if_id     phy Interface id
      u16 port      phy port addr
      u16 dev       phy dev addr

   \return
      void*        PHY device context
      >< NULL      Valid context
      == NULL      Error     
*/
void* api_gpy_open (u16 if_id, u16 port, u16 dev)
{
 
  int ret;  
   memset(&GpyEthPhyDevice, 0, sizeof(GpyEthPhyDevice));

   GpyEthPhyDevice.lock              = GpyEthPhyDummy;
   GpyEthPhyDevice.unlock            = GpyEthPhyDummy;
   GpyEthPhyDevice.lock_data         = &GpyEthPhyData;
   GpyEthPhyDevice.mdiobus_read      = api_gpy_read;
   GpyEthPhyDevice.mdiobus_write     = api_gpy_write;
   GpyEthPhyDevice.mdiobus_data      = NULL;
   GpyEthPhyDevice.smdio_addr        = SMDIO_ADDR;
   GpyEthPhyDevice.phy_addr          = port;
   GpyEthPhyDevice.priv_data         = NULL;
   GpyEthPhyDevice.shared_data       = NULL;

   GpyEthPhyDevice.wol_supported     = 0x60;
   GpyEthPhyDevice.macsec_supported  = 1;
   GpyEthPhyDevice.nr_of_sas         = 0;
   GpyEthPhyDevice.gmac_data         = NULL;
   GpyEthPhyDevice.macsec_data       = NULL;
   GpyEthPhyDevice.ptp_clock         = 0x320;
   GpyEthPhyDevice.def_addend        = 0xaabbccdd;

    /* TO DO, THINK: Phy Interface Id not yet implemented
    we have only type of interface: RPI, MDIO BITBANG....
    */

   phyif.clk_pin  = RPI4B_GPIO_MDIO_CLK_PIN;
   phyif.data_pin = RPI4B_GPIO_MDIO_DATA_PIN;
   phyif.port     = port;
   phyif.dev      = dev;          

   /* Initialize the BCM mdio library
      Open the mdio
    */  
   bcm2835_init (RPI4B_GPIO_MEM);
   ret = mdio_open(phyif.clk_pin, phyif.data_pin);

   return  (void*)&GpyEthPhyDevice; 
}


/**
   This function close the API.
   (TO DO, THINK: under construction)

   \param
      u16 if_id     phy Interface id
      u16 port      phy port addr
      u16 dev       phy dev addr

   \return
      none
*/
void api_gpy_close (u16 if_id, u16 port, u16 dev)
{
 
    /* TO DO, THINK: Phy Interface Id not yet implemented
    we have only type of interface: RPI, MDIO BITBANG....
    */


   /* Close the mdio 
    */  
   (void)mdio_close(phyif.clk_pin, phyif.data_pin);
}


/**
   This function returns the GPIO clk pin number.
   (TO DO, THINK: under construction)

   \param
      u16 if_id     phy Interface id
 

   \return
      u8    clk_pin number
*/
u8 api_gpy_if_clk_pin (u16 if_id)
{

    /* TO DO, THINK: Phy Interface Id not yet implemented
    we have only type of interface: RPI, MDIO BITBANG....
    */

   return  phyif.clk_pin; 
}


/**
   This function returns the GPIO data pin number.
   (TO DO, THINK: under construction)

   \param
      u16 if_id     phy Interface id
 

   \return
      u8    data_pin number
*/
u8 api_gpy_if_data_pin (u16 if_id)
{

    /* TO DO, THINK: Phy Interface Id not yet implemented
    we have only type of interface: RPI, MDIO BITBANG....
    */

   return  phyif.data_pin; 
}
