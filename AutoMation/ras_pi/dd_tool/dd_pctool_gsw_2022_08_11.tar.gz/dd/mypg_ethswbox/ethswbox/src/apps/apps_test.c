/******************************************************************************

    Copyright 2021 Maxlinear

    SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only)

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.
******************************************************************************/

/**
   \file apps_test.c
    Just to see how it looks like an apps

*/

/* ============================= */
/* Includes                      */
/* ============================= */

/* Access to GPYAPI driver  */
#include "os_linux.h"
#include "types.h"

 
#include "apps_test.h"
#include "fapi_gpy_ffu.h"
#include "fapi_mdio.h"

 

/**
    Implements MDIO Register Read function Clause 45


   \param
      u16	if_id           phy Interface id
      u16   port            phy port addr        
      u16   dev             phy dev addr        
	  u16 	reg             phy register

   \return
    >=0:  register value
    -1:   access error
    -2:   parameter error
*/

s32 apps_test (u16 if_id)
{
    printf ("apps: under construction: if_id = %d\n",if_id);
    return OS_SUCCESS;
}
