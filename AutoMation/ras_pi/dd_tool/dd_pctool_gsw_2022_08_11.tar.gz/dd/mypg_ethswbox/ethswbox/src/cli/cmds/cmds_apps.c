/******************************************************************************

  Copyright (c) 2014 Lantiq Deutschland GmbH
  Copyright 2016, Intel Corporation.

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

******************************************************************************/

/**
   \file cmds_apps.c
    Implements CLI commands for APPS
        - 
        -  
*/
#include "os_linux.h"

#include "cmds.h"
#include "cmds_apps.h"

#include "apps_tools_gpy.h"
#include "gpy211_utility_main.h"



/* ========================================================================== */
/*                           Function prototypes                              */
/* ========================================================================== */
static void cmds_apps_help (void);




OS_boolean_t cmds_apps (CmdArgs_t* pArgs, int *err)
{
    OS_boolean_t  api_executed; 
    int ret;
 
    if (pArgs == NULL)
    {
        *err = OS_ERROR;
        return OS_TRUE; 
    }

    ret = OS_SUCCESS;        
    api_executed = OS_TRUE;
   
   /******************************************
   *  apps CLI cmds                          *
   ******************************************/   
      
   if ((strcmp(pArgs->name, "cmds-apps-help")  == 0 ) || (strcmp(pArgs->name, "cmds-apps-?")  == 0))
   {
     cmds_apps_help ();
   }


   /*****************************************
    * APPS:                                 *
    * ***************************************/
   else if (strcmp(pArgs->name, "apps-tools-gpy-recover-lbb-uart") == 0)
   {
      u16 ifid;
      u16 port;

      int val;

      if (pArgs->prmc < 1)
      { 
         printf ("  Usage: apps-tools-gpy-recover-lbb-uart ifid\n");
         printf ("   ifid: Interface Id\n");
         printf ("   (hexadecimal value prefixed with 0x)\n");
         goto goto_end_help;
      }

      ifid    = pArgs->prmvi [0];

      ret = apps_tools_gpy_recover_lbb_uart (ifid);

   }

   else if (strcmp(pArgs->name, "apps-p31g-util") == 0)
   {
      u16 ifid;
      u16 port;
      char *argv[200];
      int val;
      char str[100];

      if (pArgs->prmc < 2)
      { 
         printf ("  Usage: apps-p31g-util ifid port\n");
         printf ("   ifid: Interface Id\n");         
         printf ("   port: PHY port address\n");
         printf ("   (hexadecimal value prefixed with 0x)\n");
         goto goto_end_help;
      }

      ifid    = pArgs->prmvi [0];
      port    = pArgs->prmvi [1];

    
      sprintf(str, "%d", port);
      argv[1] = str;

      ret = main_GPY211_UTILITY(pArgs->prmc , argv);

   }


   /***************
   *  No command  *
   ***************/
   else 
   {
      api_executed = OS_FALSE;
   }

goto_end_help:
   *err = ret;
   return api_executed;   
}


int cmds_apps_symlink_set (void)
{  
   os_system ("ln -sf ./ethswbox apps-tools-gpy-recover-lbb-uart");    
   os_system ("ln -sf ./ethswbox apps-p31g-util");    

   return OS_SUCCESS;
}


static void cmds_apps_help (void)
{
   printf ("+------------------------------------------------------------------+\n");
   printf ("|                           HELP !                                 |\n");
   printf ("|                        CMDS - APPS                               |\n");
   printf ("|                                                                  |\n");
   printf ("+------------------------------------------------------------------+\n");
   printf ("|                                                                  |\n");
   printf ("+------------------------------------------------------------------+\n");
   printf ("\n");

}
