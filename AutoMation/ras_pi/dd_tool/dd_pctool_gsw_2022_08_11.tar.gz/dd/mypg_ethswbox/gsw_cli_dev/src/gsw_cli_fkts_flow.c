/******************************************************************************

                         Copyright (c) 2012, 2014, 2015
                            Lantiq Deutschland GmbH

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

******************************************************************************/

#include "ltq_cli_lib.h"


#ifndef IOCTL_PCTOOL
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <ctype.h>
#endif

#define NUM_TC 16

int gsw_pce_rule_read(int argc, char *argv[], void *fd, int numPar)
{
    GSW_PCE_rule_t pce_rule;
    int cnt, i;

    memset(&pce_rule, 0x00, sizeof(pce_rule));

    cnt = scanParamArg(argc, argv, "pattern.nIndex", sizeof(pce_rule.pattern.nIndex), &pce_rule.pattern.nIndex);

    if (cnt == 0)
        return (-2);

    if (cli_ioctl((GSW_API_HANDLE)fd, GSW_PCE_RULE_READ, &pce_rule) != 0)
        return (-3);

    if (pce_rule.pattern.bEnable) {
        printf("\n\tp.nIndex                    = %u", pce_rule.pattern.nIndex);
 
        if (pce_rule.pattern.bMAC_DstEnable) {
            printf("\n\tp.bMAC_DstEnable            = %u", pce_rule.pattern.bMAC_DstEnable);
            printf("\n\tp.nMAC_Dst                  = ");

            for (i = 0; i < 6; i++) {
                printf("%2.2x", pce_rule.pattern.nMAC_Dst[i]);
            }

            printf("\n\tp.nMAC_DstMask              = 0x%x", pce_rule.pattern.nMAC_DstMask);
        }

        if (pce_rule.pattern.bMAC_SrcEnable) {
            printf("\n\tp.bMAC_SrcEnable            = %u", pce_rule.pattern.bMAC_SrcEnable);
            printf("\n\tp.nMAC_Src                  = ");

            for (i = 0; i < 6; i++) {
                printf("%2.2x", pce_rule.pattern.nMAC_Src[i]);
            }

            printf("\n\tp.nMAC_SrcMask              = 0x%x", pce_rule.pattern.nMAC_SrcMask);
        }

        if (pce_rule.pattern.eDstIP_Select) {
            printf("\n\tp.eDstIP_Select             = %u", pce_rule.pattern.eDstIP_Select);

            if (pce_rule.pattern.eDstIP_Select == GSW_PCE_IP_V4) {
                printf("\n\tp.nDstIP                    = 0x%x", pce_rule.pattern.nDstIP.nIPv4);
                printf("\n\tp.nDstIP_Mask               = 0x%x", pce_rule.pattern.nDstIP_Mask);
            } else if (pce_rule.pattern.eDstIP_Select == GSW_PCE_IP_V6) {
                printf("\n\tp.nDstIP                    = ");

                for (i = 0; i < 8; i++) {
                    if (i == 7)
                        printf("%x", pce_rule.pattern.nDstIP.nIPv6[i]);
                    else
                        printf("%x:", pce_rule.pattern.nDstIP.nIPv6[i]);
                }
                                                        
                printf("\n\tp.nDstIP_Mask                = 0x%x", pce_rule.pattern.nDstIP_Mask);
            }
        }

        if (pce_rule.pattern.eSrcIP_Select) {
            printf("\n\tp.eSrcIP_Select             = %u", pce_rule.pattern.eSrcIP_Select);

            if (pce_rule.pattern.eSrcIP_Select == GSW_PCE_IP_V4) {
                printf("\n\tp.nSrcIP                    = 0x%x", pce_rule.pattern.nSrcIP.nIPv4);
                printf("\n\tp.nSrcIP_Mask               = 0x%x", pce_rule.pattern.nSrcIP_Mask);
            } else if (pce_rule.pattern.eSrcIP_Select == GSW_PCE_IP_V6) {
                printf("\n\tp.nSrcIP                    = ");

                for (i = 0; i < 8; i++) {
                    if (i == 7)
                        printf("%x", pce_rule.pattern.nSrcIP.nIPv6[i]);
                    else
                        printf("%x:", pce_rule.pattern.nSrcIP.nIPv6[i]);
                }

                printf("\n\tp.nSrcIP_Mask               = 0x%x", pce_rule.pattern.nSrcIP_Mask);
            }
        }

        if (pce_rule.pattern.bVid) {
            printf("\n\tp.bVid                      = %u", pce_rule.pattern.bVid);
            printf("\n\tp.nVid                      = %u", pce_rule.pattern.nVid);

            if (pce_rule.pattern.bVidRange_Select)
                printf("\n\tp.bVidRange_Select          = %u (Range Key)", pce_rule.pattern.bVidRange_Select);
            else
                printf("\n\tp.bVidRange_Select          = %u (Mask Key)", pce_rule.pattern.bVidRange_Select);
                printf("\n\tp.nVidRange                 = %u", pce_rule.pattern.nVidRange);
        }

        if (pce_rule.pattern.bSLAN_Vid) {
            printf("\n\tp.bSLAN_Vid                 = %u", pce_rule.pattern.bSLAN_Vid);
            printf("\n\tp.nSLAN_Vid                 = %u", pce_rule.pattern.nSLAN_Vid);
        }

        if (pce_rule.pattern.bPortIdEnable) {
            printf("\n\tp.bPortIdEnable             = %u", pce_rule.pattern.bPortIdEnable);
            printf("\n\tp.nPortId                   = %u", pce_rule.pattern.nPortId);
        }

        if (pce_rule.pattern.bPktLngEnable) {
            printf("\n\tp.bPktLngEnable             = %u", pce_rule.pattern.bPktLngEnable);
            printf("\n\tp.nPktLng                   = %u", pce_rule.pattern.nPktLng);
            printf("\n\tp.nPktLngRange              = %u", pce_rule.pattern.nPktLngRange);
        }

        if (pce_rule.action.eLearningAction)
            printf("\n\ta.eLearningAction           = %u", pce_rule.action.eLearningAction);

        if (pce_rule.action.eSnoopingTypeAction)
            printf("\n\ta.eSnoopingTypeAction       = %u", pce_rule.action.eSnoopingTypeAction);

        if (pce_rule.pattern.bEtherTypeEnable) {
            printf("\n\tp.nEtherType                = 0x%x", pce_rule.pattern.nEtherType);
            printf("\n\tp.nEtherTypeMask            = 0x%x", pce_rule.pattern.nEtherTypeMask);
        }

        if (pce_rule.pattern.bProtocolEnable) {
            printf("\n\tp.nProtocol                 = 0x%x", pce_rule.pattern.nProtocol);
            printf("\n\tp.nProtocolMask             = 0x%x", pce_rule.pattern.nProtocolMask);
        }

        if (pce_rule.pattern.bSessionIdEnable) {
            printf("\n\tp.bSessionIdEnable          = 0x%x", pce_rule.pattern.bSessionIdEnable);
            printf("\n\tp.nSessionId                = 0x%x", pce_rule.pattern.nSessionId);
        }

        if (pce_rule.pattern.bAppDataMSB_Enable) {
            printf("\n\tp.nAppDataMSB               = 0x%x", pce_rule.pattern.nAppDataMSB);
            printf("\n\tp.bAppMaskRangeMSB_Select   = %u", pce_rule.pattern.bAppMaskRangeMSB_Select);
            printf("\n\tp.nAppMaskRangeMSB          = 0x%x", pce_rule.pattern.nAppMaskRangeMSB);
        }

        if (pce_rule.pattern.bAppDataLSB_Enable) {
            printf("\n\tp.nAppDataLSB               = 0x%x", pce_rule.pattern.nAppDataLSB);
            printf("\n\tp.bAppMaskRangeLSB_Select   = %u", pce_rule.pattern.bAppMaskRangeLSB_Select);
            printf("\n\tp.nAppMaskRangeLSB          = 0x%x", pce_rule.pattern.nAppMaskRangeLSB);
        }
  

        if (pce_rule.pattern.bDSCP_Enable)
            printf("\n\tp.nDSCP                     = %u", pce_rule.pattern.nDSCP);

        if (pce_rule.action.bRemarkAction)
            printf("\n\ta.bRemarkAction             = Enabled  val = %u", pce_rule.action.bRemarkAction);

        if (pce_rule.action.bRemarkPCP)
            printf("\n\ta.bRemarkPCP                = Disabled val = %u", pce_rule.action.bRemarkPCP);

        if (pce_rule.action.bRemarkDSCP)
            printf("\n\ta.bRemarkDSCP               = Disabled val = %u", pce_rule.action.bRemarkDSCP);

        if (pce_rule.action.bRemarkClass)
            printf("\n\ta.bRemarkClass              = Disabled val = %u", pce_rule.action.bRemarkClass);

        if (pce_rule.action.bRemarkSTAG_PCP)
            printf("\n\ta.bRemarkSTAG_PCP           = Disabled val = %u", pce_rule.action.bRemarkSTAG_PCP);

        if (pce_rule.action.bRemarkSTAG_DEI)
            printf("\n\ta.bRemarkSTAG_DEI           = Disabled val = %u", pce_rule.action.bRemarkSTAG_DEI);

        if ((pce_rule.action.bRMON_Action) || (pce_rule.action.bFlowID_Action)) {
            printf("\n\ta.nFlowID/nRmon_ID          = %u", pce_rule.action.nFlowID);
        }

        if (pce_rule.pattern.bPCP_Enable) {
            printf("\n\tp.bPCP_Enable               = %u", pce_rule.pattern.bPCP_Enable);
            printf("\n\tp.nPCP                      = %u", pce_rule.pattern.nPCP);
        }

        if (pce_rule.pattern.bSTAG_PCP_DEI_Enable) {
            printf("\n\tp.bSTAG_PCP_DEI_Enable      = %u", pce_rule.pattern.bSTAG_PCP_DEI_Enable);
            printf("\n\tp.nSTAG_PCP_DEI             = %u", pce_rule.pattern.nSTAG_PCP_DEI);
        }

        if (pce_rule.action.ePortMapAction) {
            printf("\n\ta.ePortMapAction            = 0x%x", pce_rule.action.ePortMapAction);
            printf("\n\ta.nForwardPortMa            = 0x%x", i, pce_rule.action.nForwardPortMap);
        }

        if (pce_rule.action.eTrafficClassAction) {
            printf("\n\ta.eTrafficClassAction       = %u", pce_rule.action.eTrafficClassAction);
            printf("\n\ta.nTrafficClassAlternate    = %u", pce_rule.action.nTrafficClassAlternate);
        }

        if (pce_rule.action.bPortTrunkAction) {
            printf("\n\ta.bPortTrunkAction          = Enabled");
            printf("\n\ta.bPortLinkSelection        = %u", pce_rule.action.bPortLinkSelection);
        }

        if (pce_rule.action.eMeterAction)
            printf("\n\ta.nMeterId                  = %u", pce_rule.action.nMeterId);

    } else {
        printf("\n\tp.nIndex rule not set at    = %u", pce_rule.pattern.nIndex);
    }

    return 0;
}


int gsw_pce_rule_write(int argc, char *argv[], void *fd, int numPar)
{
	GSW_PCE_rule_t pce_rule;
	int cnt = 0;

	memset(&pce_rule, 0, sizeof(pce_rule));

	cnt += scanParamArg(argc, argv, "pattern.nIndex", sizeof(pce_rule.pattern.nIndex), &pce_rule.pattern.nIndex);
	cnt += scanParamArg(argc, argv, "pattern.bEnable", sizeof(pce_rule.pattern.bEnable), &pce_rule.pattern.bEnable);
	cnt += scanParamArg(argc, argv, "pattern.bPortIdEnable", sizeof(pce_rule.pattern.bPortIdEnable), &pce_rule.pattern.bPortIdEnable);
	cnt += scanParamArg(argc, argv, "pattern.nPortId", sizeof(pce_rule.pattern.nPortId), &pce_rule.pattern.nPortId);
	cnt += scanParamArg(argc, argv, "pattern.bDSCP_Enable", sizeof(pce_rule.pattern.bDSCP_Enable), &pce_rule.pattern.bDSCP_Enable);
	cnt += scanParamArg(argc, argv, "pattern.nDSCP", sizeof(pce_rule.pattern.nDSCP), &pce_rule.pattern.nDSCP);
	cnt += scanParamArg(argc, argv, "pattern.bPCP_Enable", sizeof(pce_rule.pattern.bPCP_Enable), &pce_rule.pattern.bPCP_Enable);
	cnt += scanParamArg(argc, argv, "pattern.nPCP", sizeof(pce_rule.pattern.nPCP), &pce_rule.pattern.nPCP);
	cnt += scanParamArg(argc, argv, "pattern.bSTAG_PCP_DEI_Enable", sizeof(pce_rule.pattern.bSTAG_PCP_DEI_Enable), &pce_rule.pattern.bSTAG_PCP_DEI_Enable);
	cnt += scanParamArg(argc, argv, "pattern.nSTAG_PCP_DEI", sizeof(pce_rule.pattern.nSTAG_PCP_DEI), &pce_rule.pattern.nSTAG_PCP_DEI);
	cnt += scanParamArg(argc, argv, "pattern.bPktLngEnable", sizeof(pce_rule.pattern.bPktLngEnable), &pce_rule.pattern.bPktLngEnable);
	cnt += scanParamArg(argc, argv, "pattern.nPktLng", sizeof(pce_rule.pattern.nPktLng), &pce_rule.pattern.nPktLng);
	cnt += scanParamArg(argc, argv, "pattern.nPktLngRange", sizeof(pce_rule.pattern.nPktLngRange), &pce_rule.pattern.nPktLngRange);
	cnt += scanMAC_Arg(argc, argv, "pattern.nMAC_Dst", pce_rule.pattern.nMAC_Dst);
	cnt += scanParamArg(argc, argv, "pattern.nMAC_DstMask", sizeof(pce_rule.pattern.nMAC_DstMask), &pce_rule.pattern.nMAC_DstMask);
	cnt += scanParamArg(argc, argv, "pattern.bMAC_SrcEnable", sizeof(pce_rule.pattern.bMAC_SrcEnable), &pce_rule.pattern.bMAC_SrcEnable);
	cnt += scanMAC_Arg(argc, argv, "pattern.nMAC_Src", pce_rule.pattern.nMAC_Src);
	cnt += scanParamArg(argc, argv, "pattern.nMAC_SrcMask", sizeof(pce_rule.pattern.nMAC_SrcMask), &pce_rule.pattern.nMAC_SrcMask);
	cnt += scanParamArg(argc, argv, "pattern.bAppDataMSB_Enable", sizeof(pce_rule.pattern.bAppDataMSB_Enable), &pce_rule.pattern.bAppDataMSB_Enable);
	cnt += scanParamArg(argc, argv, "pattern.nAppDataMSB", sizeof(pce_rule.pattern.nAppDataMSB), &pce_rule.pattern.nAppDataMSB);
	cnt += scanParamArg(argc, argv, "pattern.bAppMaskRangeMSB_Select", sizeof(pce_rule.pattern.bAppMaskRangeMSB_Select), &pce_rule.pattern.bAppMaskRangeMSB_Select);
	cnt += scanParamArg(argc, argv, "pattern.nAppMaskRangeMSB", sizeof(pce_rule.pattern.nAppMaskRangeMSB), &pce_rule.pattern.nAppMaskRangeMSB);
	cnt += scanParamArg(argc, argv, "pattern.bAppDataLSB_Enable", sizeof(pce_rule.pattern.bAppDataLSB_Enable), &pce_rule.pattern.bAppDataLSB_Enable);
	cnt += scanParamArg(argc, argv, "pattern.nAppDataLSB", sizeof(pce_rule.pattern.nAppDataLSB), &pce_rule.pattern.nAppDataLSB);
	cnt += scanParamArg(argc, argv, "pattern.bAppMaskRangeLSB_Select", sizeof(pce_rule.pattern.bAppMaskRangeLSB_Select), &pce_rule.pattern.bAppMaskRangeLSB_Select);
	cnt += scanParamArg(argc, argv, "pattern.nAppMaskRangeLSB", sizeof(pce_rule.pattern.nAppMaskRangeLSB), &pce_rule.pattern.nAppMaskRangeLSB);
	cnt += scanParamArg(argc, argv, "pattern.eDstIP_Select", sizeof(pce_rule.pattern.eDstIP_Select), &pce_rule.pattern.eDstIP_Select);

	if (pce_rule.pattern.eDstIP_Select == GSW_PCE_IP_V4)
		cnt += scanIPv4_Arg(argc, argv, "pattern.nDstIP", &pce_rule.pattern.nDstIP.nIPv4);
	else if (pce_rule.pattern.eDstIP_Select == GSW_PCE_IP_V6)
		cnt += scanIPv6_Arg(argc, argv, "pattern.nDstIP", pce_rule.pattern.nDstIP.nIPv6);

	cnt += scanParamArg(argc, argv, "pattern.nDstIP_Mask", sizeof(pce_rule.pattern.nDstIP_Mask), &pce_rule.pattern.nDstIP_Mask);
	cnt += scanParamArg(argc, argv, "pattern.eSrcIP_Select", sizeof(pce_rule.pattern.eSrcIP_Select), &pce_rule.pattern.eSrcIP_Select);

	if (pce_rule.pattern.eSrcIP_Select == GSW_PCE_IP_V4)
		cnt += scanIPv4_Arg(argc, argv, "pattern.nSrcIP", &pce_rule.pattern.nSrcIP.nIPv4);
	else if (pce_rule.pattern.eSrcIP_Select == GSW_PCE_IP_V6)
		cnt += scanIPv6_Arg(argc, argv, "pattern.nSrcIP", pce_rule.pattern.nSrcIP.nIPv6);

	cnt += scanParamArg(argc, argv, "pattern.nSrcIP_Mask", sizeof(pce_rule.pattern.nSrcIP_Mask), &pce_rule.pattern.nSrcIP_Mask);

	cnt += scanParamArg(argc, argv, "pattern.bEtherTypeEnable", sizeof(pce_rule.pattern.bEtherTypeEnable), &pce_rule.pattern.bEtherTypeEnable);
	cnt += scanParamArg(argc, argv, "pattern.nEtherType", sizeof(pce_rule.pattern.nEtherType), &pce_rule.pattern.nEtherType);
	cnt += scanParamArg(argc, argv, "pattern.nEtherTypeMask", sizeof(pce_rule.pattern.nEtherTypeMask), &pce_rule.pattern.nEtherTypeMask);

	cnt += scanParamArg(argc, argv, "pattern.bProtocolEnable", sizeof(pce_rule.pattern.bProtocolEnable), &pce_rule.pattern.bProtocolEnable);
	cnt += scanParamArg(argc, argv, "pattern.nProtocol", sizeof(pce_rule.pattern.nProtocol), &pce_rule.pattern.nProtocol);
	cnt += scanParamArg(argc, argv, "pattern.nProtocolMask", sizeof(pce_rule.pattern.nProtocolMask), &pce_rule.pattern.nProtocolMask);

	cnt += scanParamArg(argc, argv, "pattern.bSessionIdEnable", sizeof(pce_rule.pattern.bSessionIdEnable), &pce_rule.pattern.bSessionIdEnable);
	cnt += scanParamArg(argc, argv, "pattern.nSessionId", sizeof(pce_rule.pattern.nSessionId), &pce_rule.pattern.nSessionId);

	cnt += scanParamArg(argc, argv, "pattern.bVid", sizeof(pce_rule.pattern.bVid), &pce_rule.pattern.bVid);
	cnt += scanParamArg(argc, argv, "pattern.nVid", sizeof(pce_rule.pattern.nVid), &pce_rule.pattern.nVid);
	cnt += scanParamArg(argc, argv, "pattern.bVidRange_Select", sizeof(pce_rule.pattern.bVidRange_Select), &pce_rule.pattern.bVidRange_Select);
	cnt += scanParamArg(argc, argv, "pattern.nVidRange", sizeof(pce_rule.pattern.nVidRange), &pce_rule.pattern.nVidRange);

	cnt += scanParamArg(argc, argv, "pattern.bSLAN_Vid", sizeof(pce_rule.pattern.bSLAN_Vid), &pce_rule.pattern.bSLAN_Vid);
	cnt += scanParamArg(argc, argv, "pattern.nSLAN_Vid", sizeof(pce_rule.pattern.nSLAN_Vid), &pce_rule.pattern.nSLAN_Vid);

	cnt += scanParamArg(argc, argv, "action.eTrafficClassAction", sizeof(pce_rule.action.eTrafficClassAction), &pce_rule.action.eTrafficClassAction);
	cnt += scanParamArg(argc, argv, "action.nTrafficClassAlternate", sizeof(pce_rule.action.nTrafficClassAlternate), &pce_rule.action.nTrafficClassAlternate);
	cnt += scanParamArg(argc, argv, "action.eSnoopingTypeAction", sizeof(pce_rule.action.eSnoopingTypeAction), &pce_rule.action.eSnoopingTypeAction);
	cnt += scanParamArg(argc, argv, "action.eLearningAction", sizeof(pce_rule.action.eLearningAction), &pce_rule.action.eLearningAction);
	cnt += scanParamArg(argc, argv, "action.eIrqAction", sizeof(pce_rule.action.eIrqAction), &pce_rule.action.eIrqAction);
	cnt += scanParamArg(argc, argv, "action.eCrossStateAction", sizeof(pce_rule.action.eCrossStateAction), &pce_rule.action.eCrossStateAction);
	cnt += scanParamArg(argc, argv, "action.eCritFrameAction", sizeof(pce_rule.action.eCritFrameAction), &pce_rule.action.eCritFrameAction);
	cnt += scanParamArg(argc, argv, "action.eTimestampAction", sizeof(pce_rule.action.eTimestampAction), &pce_rule.action.eTimestampAction);
	cnt += scanParamArg(argc, argv, "action.ePortMapAction", sizeof(pce_rule.action.ePortMapAction), &pce_rule.action.ePortMapAction);
	cnt += scanParamArg(argc, argv, "action.nForwardPortMap", sizeof(pce_rule.action.nForwardPortMap), &pce_rule.action.nForwardPortMap);

	cnt += scanParamArg(argc, argv, "action.bRemarkAction", sizeof(pce_rule.action.bRemarkAction), &pce_rule.action.bRemarkAction);
	cnt += scanParamArg(argc, argv, "action.bRemarkPCP", sizeof(pce_rule.action.bRemarkAction), &pce_rule.action.bRemarkPCP);
	cnt += scanParamArg(argc, argv, "action.bRemarkSTAG_PCP", sizeof(pce_rule.action.bRemarkSTAG_PCP), &pce_rule.action.bRemarkSTAG_PCP);
	cnt += scanParamArg(argc, argv, "action.bRemarkSTAG_DEI", sizeof(pce_rule.action.bRemarkSTAG_DEI), &pce_rule.action.bRemarkSTAG_DEI);
	cnt += scanParamArg(argc, argv, "action.bRemarkDSCP", sizeof(pce_rule.action.bRemarkDSCP), &pce_rule.action.bRemarkDSCP);
	cnt += scanParamArg(argc, argv, "action.bRemarkClass", sizeof(pce_rule.action.bRemarkClass), &pce_rule.action.bRemarkClass);
	cnt += scanParamArg(argc, argv, "action.eMeterAction", sizeof(pce_rule.action.eMeterAction), &pce_rule.action.eMeterAction);
	cnt += scanParamArg(argc, argv, "action.nMeterId", sizeof(pce_rule.action.nMeterId), &pce_rule.action.nMeterId);
	cnt += scanParamArg(argc, argv, "action.bRMON_Action", sizeof(pce_rule.action.bRMON_Action), &pce_rule.action.bRMON_Action);
	cnt += scanParamArg(argc, argv, "action.nRMON_Id", sizeof(pce_rule.action.nRMON_Id), &pce_rule.action.nRMON_Id);
	cnt += scanParamArg(argc, argv, "action.eVLAN_Action", sizeof(pce_rule.action.eVLAN_Action), &pce_rule.action.eVLAN_Action);
	cnt += scanParamArg(argc, argv, "action.nVLAN_Id", sizeof(pce_rule.action.nVLAN_Id), &pce_rule.action.nVLAN_Id);
	cnt += scanParamArg(argc, argv, "action.nFId", sizeof(pce_rule.action.nFId), &pce_rule.action.nFId);

	cnt += scanParamArg(argc, argv, "action.eSVLAN_Action", sizeof(pce_rule.action.eSVLAN_Action), &pce_rule.action.eSVLAN_Action);
	cnt += scanParamArg(argc, argv, "action.nSVLAN_Id", sizeof(pce_rule.action.nSVLAN_Id), &pce_rule.action.nSVLAN_Id);
	cnt += scanParamArg(argc, argv, "action.eVLAN_CrossAction", sizeof(pce_rule.action.eVLAN_CrossAction), &pce_rule.action.eVLAN_CrossAction);
	cnt += scanParamArg(argc, argv, "action.bPortBitMapMuxControl", sizeof(pce_rule.action.bPortBitMapMuxControl), &pce_rule.action.bPortBitMapMuxControl);
	cnt += scanParamArg(argc, argv, "action.bCVLAN_Ignore_Control", sizeof(pce_rule.action.bCVLAN_Ignore_Control), &pce_rule.action.bCVLAN_Ignore_Control);
	cnt += scanParamArg(argc, argv, "action.bPortLinkSelection", sizeof(pce_rule.action.bPortLinkSelection), &pce_rule.action.bPortLinkSelection);
	cnt += scanParamArg(argc, argv, "action.bPortTrunkAction", sizeof(pce_rule.action.bPortTrunkAction), &pce_rule.action.bPortTrunkAction);

	cnt += scanParamArg(argc, argv, "action.bFlowID_Action", sizeof(pce_rule.action.bFlowID_Action), &pce_rule.action.bFlowID_Action);
	cnt += scanParamArg(argc, argv, "action.nFlowID", sizeof(pce_rule.action.nFlowID), &pce_rule.action.nFlowID);


	if (cnt != numPar) return (-2);

	if (cnt == 0) return (-3);

	return cli_ioctl((GSW_API_HANDLE)fd, GSW_PCE_RULE_WRITE, &pce_rule);
}

int gsw_rmon_extend_get(int argc, char *argv[], void *fd, int numPar)
{
	GSW_RMON_extendGet_t param;
	int cnt, i;
	memset(&param, 0, sizeof(GSW_RMON_extendGet_t));

	cnt = scanParamArg(argc, argv, "nPortId", sizeof(param.nPortId), &param.nPortId);

	if (cnt != 1)
		return (-2);

	if (cli_ioctl((GSW_API_HANDLE)fd, GSW_RMON_EXTEND_GET, &param)) {
		printf("ioctl returned with ERROR!\n");
		return (-3);
	}

	for (i = 0; i < GSW_RMON_EXTEND_NUM; i++) {
		printf("RMON Counter [%2d] = %d\n", i, param.nTrafficFlowCnt[i]);
	}

	return 0;
}

int gsw_rmon_extend_set(int argc, char *argv[], void *fd, int numPar)
{
	return -1;
}

int gsw_timestamp_timer_get(int argc, char *argv[], void *fd, int numPar)
{
	GSW_TIMESTAMP_Timer_t param;
	memset(&param, 0, sizeof(GSW_TIMESTAMP_Timer_t));

	if (cli_ioctl((GSW_API_HANDLE)fd, GSW_TIMESTAMP_TIMER_GET, &param)) {
		printf("ioctl returned with ERROR!\n");
		return (-3);
	}

	printHex32Value("nSec", param.nSec, 0);
	printHex32Value("nNanoSec", param.nNanoSec, 0);
	printHex32Value("nFractionalNanoSec", param.nFractionalNanoSec, 0);
	return 0;
}

int gsw_timestamp_timer_set(int argc, char *argv[], void *fd, int numPar)
{
	GSW_TIMESTAMP_Timer_t param;
	int cnt = 0;
	memset(&param, 0, sizeof(GSW_TIMESTAMP_Timer_t));

	if (cli_ioctl((GSW_API_HANDLE)fd, GSW_TIMESTAMP_TIMER_GET, &param)) {
		printf("ioctl returned with ERROR!\n");
		return (-3);
	}

	cnt += scanParamArg(argc, argv, "nSec", sizeof(param.nSec), &param.nSec);
	cnt += scanParamArg(argc, argv, "nNanoSec", sizeof(param.nNanoSec), &param.nNanoSec);
	cnt += scanParamArg(argc, argv, "nFractionalNanoSec", sizeof(param.nFractionalNanoSec), &param.nFractionalNanoSec);

	if (cnt != numPar)
		return (-2);

	if (cli_ioctl((GSW_API_HANDLE)fd, GSW_TIMESTAMP_TIMER_SET, &param)) {
		printf("ioctl returned with ERROR!\n");
		return (-3);
	}

	return 0;
}

int gsw_timestamp_port_read(int argc, char *argv[], void *fd, int numPar)
{
	GSW_TIMESTAMP_PortRead_t param;
	int cnt;
	memset(&param, 0, sizeof(GSW_TIMESTAMP_PortRead_t));
	cnt = scanParamArg(argc, argv, "nPortId", sizeof(param.nPortId), &param.nPortId);

	if (cnt != numPar)
		return (-2);

	if (cli_ioctl((GSW_API_HANDLE)fd, GSW_TIMESTAMP_PORT_READ, &param)) {
		printf("ioctl returned with ERROR!\n");
		return (-3);
	}

	printHex32Value("nPortId", param.nPortId, 0);
	printHex32Value("nIngressSec", param.nIngressSec, 0);
	printHex32Value("nIngressNanoSec", param.nIngressNanoSec, 0);
	printHex32Value("nEgressSec", param.nEgressSec, 0);
	printHex32Value("nEgressNanoSec", param.nEgressNanoSec, 0);
	return 0;
}
int gsw_boot_get(int argc, char *argv[], void *fd, int numPar)
{
	return -1;
}

int gsw_boot_set(int argc, char *argv[], void *fd, int numPar)
{
	return -1;
}

int gsw_rmon_extend_clear(int argc, char *argv[], void *fd, int numPar)
{
	return -1;
}

int gsw_register_set(int argc, char *argv[], void *fd, int numPar)
{
	GSW_register_t param;
	u16 nSetBits = 0, nClearBits = 0;
	int bitmask_used = 0;

	memset(&param, 0, sizeof(GSW_register_t));

	if (scanParamArg(argc, argv, "nRegAddr", sizeof(param.nRegAddr), &param.nRegAddr) == 0)
		return (-2);


	if (scanParamArg(argc, argv, "nSetBits", sizeof(nSetBits), &nSetBits) != 0)
		bitmask_used = 1;

	if (scanParamArg(argc, argv, "nClearBits", sizeof(nClearBits), &nClearBits) != 0)
		bitmask_used = 1;

	if (bitmask_used == 0) {
		/* Scan 'nData' and write the hardware register. */
		if (scanParamArg(argc, argv, "nData", sizeof(param.nData), &param.nData) == 0)
			return (-3);

	} else {
		/* Read the register, set 'nSetBits', clear 'nCleartBits' and
		   write hardware register. */
		if (cli_ioctl((GSW_API_HANDLE)fd, GSW_REGISTER_GET, &param) != 0)
			return (-4);

		param.nData = param.nData & ~nClearBits;
		param.nData = param.nData | nSetBits;
	}

	return cli_ioctl((GSW_API_HANDLE)fd, GSW_REGISTER_SET, &param);
}



int gsw_qos_queue_port_get(int argc, char *argv[], void *fd, int numPar)
{

   
	GSW_QoS_queuePort_t queuePortParam;
	int tc;

	if (findStringParam(argc, argv, "listunused")) {
		/* printout the unused Queues of the whole switch.
		   First read out the capability retreaving the total amount of queues.
		   Then read the queue assignment of all traffic classes of all ports.
		   Then printout the list of all unused queues. */
		GSW_cap_t capParam;
		int numQueues, numPorts, port, i;
		char *ptrQueues;

		memset(&capParam, 0, sizeof(GSW_cap_t));
		capParam.nCapType = GSW_CAP_TYPE_PRIORITY_QUEUE;

		if (cli_ioctl((GSW_API_HANDLE)fd, GSW_CAP_GET, &capParam) != 0) {
			printf("ioctl returned with ERROR!\n");
			return (-1);
		}

		numQueues = capParam.nCap;

		memset(&capParam, 0, sizeof(GSW_cap_t));
		capParam.nCapType = GSW_CAP_TYPE_PORT;

		if (cli_ioctl((GSW_API_HANDLE)fd, GSW_CAP_GET, &capParam) != 0) {
			printf("ioctl returned with ERROR!\n");
			return (-1);
		}

		numPorts = capParam.nCap;

		/* allocate temporary buffer which will be freed later again */
		ptrQueues = malloc(numQueues);

		if (ptrQueues == NULL) {
			printf("Could not allocate memory!\n");
			return (-1);
		}

		memset(ptrQueues, 0, numQueues);

		for (port = 0; port < numPorts; port++) {
			for (tc = 0; tc < NUM_TC; tc++) {
				memset(&queuePortParam, 0, sizeof(GSW_QoS_queuePort_t));
				queuePortParam.nPortId = port;
				queuePortParam.nTrafficClassId = tc;

				if (cli_ioctl((GSW_API_HANDLE)fd, GSW_QOS_QUEUE_PORT_GET, &queuePortParam) != 0) {
					printf("ioctl returned with ERROR!\n");
					/* free temporary buffer */
					free(ptrQueues);
					return (-1);
				}

				if (queuePortParam.nQueueId < numQueues) {
					/* mark the queue as used */
					ptrQueues[queuePortParam.nQueueId] = 1;
				}
			}
		}

		printf("\nList of unused Egress Traffic Class Queue Indices:\n"
		       "--------------------------------------------------\n");

		for (i = 0; i < numQueues; i++) {
			if (ptrQueues[i] == 0) {
				printf("Queue %2d unused\n", i);
			}
		}

		printf("\n");

		/* free temporary buffer */
		free(ptrQueues);
		return 0;
	}

	memset(&queuePortParam, 0, sizeof(GSW_QoS_queuePort_t));

	if (scanParamArg(argc, argv, "nPortId", sizeof(queuePortParam.nPortId), &queuePortParam.nPortId)) {
		if (scanParamArg(argc, argv, "nTrafficClassId", sizeof(queuePortParam.nTrafficClassId), &queuePortParam.nTrafficClassId)) {

			if (cli_ioctl((GSW_API_HANDLE)fd, GSW_QOS_QUEUE_PORT_GET, &queuePortParam) != 0) {
				printf("ioctl returned with ERROR!\n");
				return (-1);
			}

			printf("Returned values:\n----------------\n");
			printHex32Value("nPortId", queuePortParam.nPortId, 8);
			printHex32Value("nTrafficClassId", queuePortParam.nTrafficClassId, 0);
			printHex32Value("nQueueId", queuePortParam.nQueueId, 0);
		} else {
			/* printout all queues of that port */
			printf("\n Port | Traffic Class | Egress Queue \n");
			printf("---------------------------------------\n");

			for (tc = 0; tc < NUM_TC; tc++) {
				queuePortParam.nTrafficClassId = tc;

				if (cli_ioctl((GSW_API_HANDLE)fd, GSW_QOS_QUEUE_PORT_GET, &queuePortParam) != 0) {
					printf("ioctl returned with ERROR!\n");
					return (-1);
				}
			}

			printf("---------------------------------------\n");
			/* printout all queues of that port */
			printf("\n Port | Traffic Class | Egress Queue \n");
			printf("---------------------------------------\n");

			for (tc = 0; tc < NUM_TC; tc++) {
				queuePortParam.nTrafficClassId = tc;

				if (cli_ioctl((GSW_API_HANDLE)fd, GSW_QOS_QUEUE_PORT_GET, &queuePortParam) != 0) {
					printf("ioctl returned with ERROR!\n");
					return (-1);
				}
			}

			printf("---------------------------------------\n");
		}
	}
 
	return 0;
}

#if defined(CONFIG_LTQ_TEST) && CONFIG_LTQ_TEST

int gsw_route_entry_add(int argc, char *argv[], void *fd, int numPar)
{
	GSW_ROUTE_Entry_t rt_entry;
	int cnt = 0;

	memset(&rt_entry, 0, sizeof(rt_entry));

	cnt += scanParamArg(argc, argv, "nHashVal", sizeof(rt_entry.nHashVal), &rt_entry.nHashVal);
	cnt += scanParamArg(argc, argv, "nRtIndex", sizeof(rt_entry.nRtIndex), &rt_entry.nRtIndex);
	cnt += scanParamArg(argc, argv, "bPrio", sizeof(rt_entry.bPrio), &rt_entry.bPrio);
	cnt += scanParamArg(argc, argv, "nFlags", sizeof(rt_entry.nFlags), &rt_entry.nFlags);

	cnt += scanParamArg(argc, argv, "routeEntry.pattern.eIpType", sizeof(rt_entry.routeEntry.pattern.eIpType), &rt_entry.routeEntry.pattern.eIpType);

	if (rt_entry.routeEntry.pattern.eIpType == GSW_RT_IP_V4)
		cnt += scanIPv4_Arg(argc, argv, "routeEntry.pattern.nDstIP", &rt_entry.routeEntry.pattern.nDstIP.nIPv4);
	else if (rt_entry.routeEntry.pattern.eIpType == GSW_RT_IP_V6)
		cnt += scanIPv6_Arg(argc, argv, "routeEntry.pattern.nDstIP", rt_entry.routeEntry.pattern.nDstIP.nIPv6);

	if (rt_entry.routeEntry.pattern.eIpType == GSW_RT_IP_V4)
		cnt += scanIPv4_Arg(argc, argv, "routeEntry.pattern.nSrcIP", &rt_entry.routeEntry.pattern.nSrcIP.nIPv4);
	else if (rt_entry.routeEntry.pattern.eIpType == GSW_RT_IP_V6)
		cnt += scanIPv6_Arg(argc, argv, "routeEntry.pattern.nSrcIP", rt_entry.routeEntry.pattern.nSrcIP.nIPv6);

	cnt += scanParamArg(argc, argv, "routeEntry.pattern.nSrcPort", sizeof(rt_entry.routeEntry.pattern.nSrcPort), &rt_entry.routeEntry.pattern.nSrcPort);
	cnt += scanParamArg(argc, argv, "routeEntry.pattern.nDstPort", sizeof(rt_entry.routeEntry.pattern.nDstPort), &rt_entry.routeEntry.pattern.nDstPort);
	cnt += scanParamArg(argc, argv, "routeEntry.pattern.nRoutExtId", sizeof(rt_entry.routeEntry.pattern.nRoutExtId), &rt_entry.routeEntry.pattern.nRoutExtId);
	cnt += scanParamArg(argc, argv, "routeEntry.pattern.bValid", sizeof(rt_entry.routeEntry.pattern.bValid), &rt_entry.routeEntry.pattern.bValid);


	cnt += scanParamArg(argc, argv, "routeEntry.action.nDstPortMap", sizeof(rt_entry.routeEntry.action.nDstPortMap), &rt_entry.routeEntry.action.nDstPortMap);
	cnt += scanParamArg(argc, argv, "routeEntry.action.nDstSubIfId", sizeof(rt_entry.routeEntry.action.nDstSubIfId), &rt_entry.routeEntry.action.nDstSubIfId);
	cnt += scanParamArg(argc, argv, "routeEntry.action.eIpType", sizeof(rt_entry.routeEntry.action.eIpType), &rt_entry.routeEntry.action.eIpType);

	if (rt_entry.routeEntry.action.eIpType == GSW_RT_IP_V4)
		cnt += scanIPv4_Arg(argc, argv, "routeEntry.action.nNATIPaddr", &rt_entry.routeEntry.action.nNATIPaddr.nIPv4);
	else if (rt_entry.routeEntry.action.eIpType == GSW_RT_IP_V6)
		cnt += scanIPv6_Arg(argc, argv, "routeEntry.action.nNATIPaddr", rt_entry.routeEntry.action.nNATIPaddr.nIPv6);

	cnt += scanParamArg(argc, argv, "routeEntry.action.nTcpUdpPort", sizeof(rt_entry.routeEntry.action.nTcpUdpPort), &rt_entry.routeEntry.action.nTcpUdpPort);
	cnt += scanParamArg(argc, argv, "routeEntry.action.nMTUvalue", sizeof(rt_entry.routeEntry.action.nMTUvalue), &rt_entry.routeEntry.action.nMTUvalue);

	cnt += scanParamArg(argc, argv, "routeEntry.action.bMAC_SrcEnable", sizeof(rt_entry.routeEntry.action.bMAC_SrcEnable), &rt_entry.routeEntry.action.bMAC_SrcEnable);
	cnt += scanMAC_Arg(argc, argv, "routeEntry.action.nSrcMAC", rt_entry.routeEntry.action.nSrcMAC);
	cnt += scanParamArg(argc, argv, "routeEntry.action.bMAC_DstEnable", sizeof(rt_entry.routeEntry.action.bMAC_DstEnable), &rt_entry.routeEntry.action.bMAC_DstEnable);
	cnt += scanMAC_Arg(argc, argv, "routeEntry.action.nDstMAC", rt_entry.routeEntry.action.nDstMAC);

	cnt += scanParamArg(argc, argv, "routeEntry.action.bPPPoEmode", sizeof(rt_entry.routeEntry.action.bPPPoEmode), &rt_entry.routeEntry.action.bPPPoEmode);
	cnt += scanParamArg(argc, argv, "routeEntry.action.nPPPoESessId", sizeof(rt_entry.routeEntry.action.nPPPoESessId), &rt_entry.routeEntry.action.nPPPoESessId);

	cnt += scanParamArg(argc, argv, "routeEntry.action.bTunnel_Enable", sizeof(rt_entry.routeEntry.action.bTunnel_Enable), &rt_entry.routeEntry.action.bTunnel_Enable);
	cnt += scanParamArg(argc, argv, "routeEntry.action.eTunType", sizeof(rt_entry.routeEntry.action.eTunType), &rt_entry.routeEntry.action.eTunType);
	cnt += scanParamArg(argc, argv, "routeEntry.action.nTunnelIndex", sizeof(rt_entry.routeEntry.action.nTunnelIndex), &rt_entry.routeEntry.action.nTunnelIndex);

	cnt += scanParamArg(argc, argv, "routeEntry.action.bMeterAssign", sizeof(rt_entry.routeEntry.action.bMeterAssign), &rt_entry.routeEntry.action.bMeterAssign);
	cnt += scanParamArg(argc, argv, "routeEntry.action.nMeterId", sizeof(rt_entry.routeEntry.action.nMeterId), &rt_entry.routeEntry.action.nMeterId);

	cnt += scanParamArg(argc, argv, "routeEntry.action.bRTPMeasEna", sizeof(rt_entry.routeEntry.action.bRTPMeasEna), &rt_entry.routeEntry.action.bRTPMeasEna);
	cnt += scanParamArg(argc, argv, "routeEntry.action.nRTPSeqNumber", sizeof(rt_entry.routeEntry.action.nRTPSeqNumber), &rt_entry.routeEntry.action.nRTPSeqNumber);
	cnt += scanParamArg(argc, argv, "routeEntry.action.nRTPSessionPktCnt", sizeof(rt_entry.routeEntry.action.nRTPSessionPktCnt), &rt_entry.routeEntry.action.nRTPSessionPktCnt);

	cnt += scanParamArg(argc, argv, "routeEntry.action.nFID", sizeof(rt_entry.routeEntry.action.nFID), &rt_entry.routeEntry.action.nFID);
	cnt += scanParamArg(argc, argv, "routeEntry.action.nFlowId", sizeof(rt_entry.routeEntry.action.nFlowId), &rt_entry.routeEntry.action.nFlowId);

	cnt += scanParamArg(argc, argv, "routeEntry.action.eOutDSCPAction", sizeof(rt_entry.routeEntry.action.eOutDSCPAction), &rt_entry.routeEntry.action.eOutDSCPAction);
	cnt += scanParamArg(argc, argv, "routeEntry.action.bInnerDSCPRemark", sizeof(rt_entry.routeEntry.action.bInnerDSCPRemark), &rt_entry.routeEntry.action.bInnerDSCPRemark);
	cnt += scanParamArg(argc, argv, "routeEntry.action.nDSCP", sizeof(rt_entry.routeEntry.action.nDSCP), &rt_entry.routeEntry.action.nDSCP);

	cnt += scanParamArg(argc, argv, "routeEntry.action.bTCremarking", sizeof(rt_entry.routeEntry.action.bTCremarking), &rt_entry.routeEntry.action.bTCremarking);
	cnt += scanParamArg(argc, argv, "routeEntry.action.nTrafficClass", sizeof(rt_entry.routeEntry.action.nTrafficClass), &rt_entry.routeEntry.action.nTrafficClass);

	cnt += scanParamArg(argc, argv, "routeEntry.action.nSessionCtrs", sizeof(rt_entry.routeEntry.action.nSessionCtrs), &rt_entry.routeEntry.action.nSessionCtrs);

	cnt += scanParamArg(argc, argv, "routeEntry.action.eSessDirection", sizeof(rt_entry.routeEntry.action.eSessDirection), &rt_entry.routeEntry.action.eSessDirection);
	cnt += scanParamArg(argc, argv, "routeEntry.action.eSessRoutingMode", sizeof(rt_entry.routeEntry.action.eSessRoutingMode), &rt_entry.routeEntry.action.eSessRoutingMode);

	cnt += scanParamArg(argc, argv, "routeEntry.action.bTTLDecrement", sizeof(rt_entry.routeEntry.action.bTTLDecrement), &rt_entry.routeEntry.action.bTTLDecrement);
	cnt += scanParamArg(argc, argv, "routeEntry.action.bHitStatus", sizeof(rt_entry.routeEntry.action.bHitStatus), &rt_entry.routeEntry.action.bHitStatus);

	if (cnt != numPar) return (-2);

	if (cnt == 0) return (-2);

	if(cli_ioctl((GSW_API_HANDLE)fd, GSW_ROUTE_ENTRY_ADD, &rt_entry) != 0)
		return (-3);
	cnt = cli_ioctl((GSW_API_HANDLE)fd, GSW_ROUTE_ENTRY_ADD, &rt_entry);
	printf("\treturn:    %d\n", cnt);
	printf("\tnRtIndex:  %d\n", rt_entry.nRtIndex);
	return 0;
}

int gsw_route_entry_read(int argc, char *argv[], void *fd, int numPar)
{
	GSW_ROUTE_Entry_t rt_entry;
	int cnt = 0;

	memset(&rt_entry, 0, sizeof(rt_entry));

	cnt += scanParamArg(argc, argv, "nRtIndex", sizeof(rt_entry.nRtIndex), &rt_entry.nRtIndex);

	if (cnt == 0)
		return (-2);

	if (cli_ioctl((GSW_API_HANDLE)fd, GSW_ROUTE_ENTRY_READ, &rt_entry) != 0)
		return (-3);

	printf("\tnHashVal:              %d\n", rt_entry.nHashVal);
	printf("\tnRtIndex:              %d\n", rt_entry.nRtIndex);
	printf("\tbPrio:                 %d\n", rt_entry.bPrio);
	printf("\tnFlags:                %d\n", rt_entry.nFlags);

	if (rt_entry.routeEntry.pattern.eIpType == GSW_RT_IP_V4) {
		printf("\trouteEntry.pattern.nDstIP: ");
		printIPv4_Address(rt_entry.routeEntry.pattern.nDstIP.nIPv4);
		printf("\n");
		printf("\trouteEntry.pattern.nSrcIP: ");
		printIPv4_Address(rt_entry.routeEntry.pattern.nSrcIP.nIPv4);
		printf("\n");
	} else if (rt_entry.routeEntry.pattern.eIpType == GSW_RT_IP_V6) {
		printf("\trouteEntry.pattern.nDstIP: ");
		printIPv6_Address(rt_entry.routeEntry.pattern.nDstIP.nIPv6);
		printf("\n");
		printf("\trouteEntry.pattern.nSrcIP: ");
		printIPv6_Address(rt_entry.routeEntry.pattern.nSrcIP.nIPv6);
		printf("\n");
	}

	printf("\trouteEntry.pattern.nSrcPort:0x%08x\n", rt_entry.routeEntry.pattern.nSrcPort);
	printf("\trouteEntry.pattern.nDstPort:0x%08x\n", rt_entry.routeEntry.pattern.nDstPort);
	printf("\trouteEntry.pattern.nRoutExtId:%d\n", rt_entry.routeEntry.pattern.nRoutExtId);
	printf("\trouteEntry.pattern.bValid:%d\n", rt_entry.routeEntry.pattern.bValid);


	printf("\trouteEntry.action.nDstPortMap: 0x%08x\n", rt_entry.routeEntry.action.nDstPortMap);
	printf("\trouteEntry.action.nDstSubIfId: 0x%08x\n", rt_entry.routeEntry.action.nDstSubIfId);

	if (rt_entry.routeEntry.action.eIpType == GSW_RT_IP_V4) {
		printf("\trouteEntry.action.nNATIPaddr: ");
		printIPv4_Address(rt_entry.routeEntry.action.nNATIPaddr.nIPv4);
		printf("\n");
	} else if (rt_entry.routeEntry.action.eIpType == GSW_RT_IP_V6) {
		printf("\trouteEntry.action.nNATIPaddr: ");
		printIPv6_Address(rt_entry.routeEntry.action.nNATIPaddr.nIPv6);
		printf("\n");
	}

	printf("\trouteEntry.action.nTcpUdpPort: 0x%08x\n", rt_entry.routeEntry.action.nTcpUdpPort);
	printf("\trouteEntry.action.nMTUvalue: 0x%08x\n", rt_entry.routeEntry.action.nMTUvalue);


	printf("\trouteEntry.action.bMAC_SrcEnable: %d\n", rt_entry.routeEntry.action.bMAC_SrcEnable);
	printf("\trouteEntry.action.nSrcMAC[6]               ");
	printMAC_Address(rt_entry.routeEntry.action.nSrcMAC);
	printf("\n");
	printf("\trouteEntry.action.bMAC_SrcEnable: %d\n", rt_entry.routeEntry.action.bMAC_DstEnable);
	printf("\trouteEntry.action.nDstMAC[6]               ");
	printMAC_Address(rt_entry.routeEntry.action.nDstMAC);
	printf("\n");

	printf("\trouteEntry.action.bPPPoEmode :%d\n", rt_entry.routeEntry.action.bPPPoEmode);
	printf("\trouteEntry.action.nPPPoESessId:%d\n",  rt_entry.routeEntry.action.nPPPoESessId);

	printf("\trouteEntry.action.bTunnel_Enable: %d\n",  rt_entry.routeEntry.action.bTunnel_Enable);
	printf("\trouteEntry.action.eTunType: %d\n", rt_entry.routeEntry.action.eTunType);
	printf("\trouteEntry.action.nTunnelIndex: %d\n", rt_entry.routeEntry.action.nTunnelIndex);

	printf("\trouteEntry.action.bMeterAssign: %d\n", rt_entry.routeEntry.action.bMeterAssign);
	printf("\trouteEntry.action.nMeterId: %d\n", rt_entry.routeEntry.action.nMeterId);

	printf("\trouteEntry.action.bRTPMeasEna:%d\n", rt_entry.routeEntry.action.bRTPMeasEna);
	printf("\trouteEntry.action.nRTPSeqNumber:%d\n",  rt_entry.routeEntry.action.nRTPSeqNumber);
	printf("\trouteEntry.action.nRTPSessionPktCnt: %d\n", rt_entry.routeEntry.action.nRTPSessionPktCnt);

	printf("\trouteEntry.action.nFID: %d\n", rt_entry.routeEntry.action.nFID);
	printf("\trouteEntry.action.nFlowId: %d\n", rt_entry.routeEntry.action.nFlowId);

	printf("\trouteEntry.action.eOutDSCPAction:%d\n", rt_entry.routeEntry.action.eOutDSCPAction);
	printf("\trouteEntry.action.bInnerDSCPRemark:%d\n", rt_entry.routeEntry.action.bInnerDSCPRemark);
	printf("\trouteEntry.action.nDSCP:%d\n", rt_entry.routeEntry.action.nDSCP);

	printf("\trouteEntry.action.bTCremarking:%d\n", rt_entry.routeEntry.action.bTCremarking);
	printf("\trouteEntry.action.nTrafficClass:%d\n", rt_entry.routeEntry.action.nTrafficClass);

	printf("\trouteEntry.action.nSessionCtrs: %d\n", rt_entry.routeEntry.action.nSessionCtrs);

	printf("\trouteEntry.action.eSessDirection: %d\n", rt_entry.routeEntry.action.eSessDirection);
	printf("\trouteEntry.action.eSessRoutingMode: %d\n", rt_entry.routeEntry.action.eSessRoutingMode);

	printf("\trouteEntry.action.bTTLDecrement: %d\n", rt_entry.routeEntry.action.bTTLDecrement);
	printf("\trouteEntry.action.bHitStatus: %d\n", rt_entry.routeEntry.action.bHitStatus);

	return 0;
}

int gsw_route_entry_delete(int argc, char *argv[], void *fd, int numPar)
{
	GSW_ROUTE_Entry_t rt_entry;
	int cnt = 0;

	memset(&rt_entry, 0, sizeof(rt_entry));

	cnt += scanParamArg(argc, argv, "nRtIndex", sizeof(rt_entry.nRtIndex), &rt_entry.nRtIndex);
	cnt += scanParamArg(argc, argv, "nHashVal", sizeof(rt_entry.nHashVal), &rt_entry.nHashVal);

	if (cnt == 0)
		return (-2);

	if (cli_ioctl((GSW_API_HANDLE)fd, GSW_ROUTE_ENTRY_DELETE, &rt_entry) != 0)
		return (-3);

	return 0;
}

int gsw_route_tunnel_entry_add(int argc, char *argv[], void *fd, int numPar)
{
	GSW_ROUTE_Tunnel_Entry_t tn_entry;
	int cnt = 0;

	memset(&tn_entry, 0, sizeof(tn_entry));

	cnt += scanParamArg(argc, argv, "nTunIndex", sizeof(tn_entry.nTunIndex), &tn_entry.nTunIndex);
	cnt += scanParamArg(argc, argv, "tunnelEntry.eTunnelType", sizeof(tn_entry.tunnelEntry.eTunnelType), &tn_entry.tunnelEntry.eTunnelType);

	if (tn_entry.tunnelEntry.eTunnelType == GSW_ROUTE_TUNL_6RD) {
		cnt += scanIPv4_Arg(argc, argv, "tunnelEntry.t.tun6RD.nSrcIP4Addr", &tn_entry.tunnelEntry.t.tun6RD.nSrcIP4Addr.nIPv4);
		cnt += scanIPv4_Arg(argc, argv, "tunnelEntry.t.tun6RD.nDstIP4Addr", &tn_entry.tunnelEntry.t.tun6RD.nDstIP4Addr.nIPv4);
	} else if (tn_entry.tunnelEntry.eTunnelType == GSW_ROUTE_TUNL_L2TP) {
		cnt += scanParamArg(argc, argv, "tunnelEntry.t.nTunL2TP", sizeof(tn_entry.tunnelEntry.t.nTunL2TP), &tn_entry.tunnelEntry.t.nTunL2TP);
	} else if (tn_entry.tunnelEntry.eTunnelType == GSW_ROUTE_TUNL_IPSEC) {
		cnt += scanParamArg(argc, argv, "tunnelEntry.t.nTunIPsec", sizeof(tn_entry.tunnelEntry.t.nTunIPsec), &tn_entry.tunnelEntry.t.nTunIPsec);
	} else if (tn_entry.tunnelEntry.eTunnelType == GSW_ROUTE_TUNL_DSLITE) {
		cnt += scanIPv6_Arg(argc, argv, "tunnelEntry.t.tunDSlite.nSrcIP6Addr", tn_entry.tunnelEntry.t.tunDSlite.nSrcIP6Addr.nIPv6);
		cnt += scanIPv6_Arg(argc, argv, "tunnelEntry.t.tunDSlite.nDstIP6Addr", tn_entry.tunnelEntry.t.tunDSlite.nDstIP6Addr.nIPv6);
	}

	if (cnt != numPar) return (-2);

	if (cnt == 0) return (-2);

	if (cli_ioctl((GSW_API_HANDLE)fd, GSW_ROUTE_TUNNEL_ENTRY_ADD, &tn_entry) != 0)
		return (-3);

	return 0;
}

int gsw_route_tunnel_entry_delete(int argc, char *argv[], void *fd, int numPar)
{
	GSW_ROUTE_Tunnel_Entry_t tn_entry;
	int cnt = 0;

	memset(&tn_entry, 0, sizeof(tn_entry));

	cnt += scanParamArg(argc, argv, "nTunIndex", sizeof(tn_entry.nTunIndex), &tn_entry.nTunIndex);
	cnt += scanParamArg(argc, argv, "tunnelEntry.eTunnelType", sizeof(tn_entry.tunnelEntry.eTunnelType), &tn_entry.tunnelEntry.eTunnelType);

	if (tn_entry.tunnelEntry.eTunnelType == GSW_ROUTE_TUNL_6RD) {
		cnt += scanIPv4_Arg(argc, argv, "tunnelEntry.t.tun6RD.nSrcIP4Addr", &tn_entry.tunnelEntry.t.tun6RD.nSrcIP4Addr.nIPv4);
		cnt += scanIPv4_Arg(argc, argv, "tunnelEntry.t.tun6RD.nDstIP4Addr", &tn_entry.tunnelEntry.t.tun6RD.nDstIP4Addr.nIPv4);
	} else if (tn_entry.tunnelEntry.eTunnelType == GSW_ROUTE_TUNL_L2TP) {
		cnt += scanParamArg(argc, argv, "tunnelEntry.t.nTunL2TP", sizeof(tn_entry.tunnelEntry.t.nTunL2TP), &tn_entry.tunnelEntry.t.nTunL2TP);
	} else if (tn_entry.tunnelEntry.eTunnelType == GSW_ROUTE_TUNL_IPSEC) {
		cnt += scanParamArg(argc, argv, "tunnelEntry.t.nTunIPsec", sizeof(tn_entry.tunnelEntry.t.nTunIPsec), &tn_entry.tunnelEntry.t.nTunIPsec);
	} else if (tn_entry.tunnelEntry.eTunnelType == GSW_ROUTE_TUNL_DSLITE) {
		cnt += scanIPv6_Arg(argc, argv, "tunnelEntry.t.tunDSlite.nSrcIP6Addr", tn_entry.tunnelEntry.t.tunDSlite.nSrcIP6Addr.nIPv6);
		cnt += scanIPv6_Arg(argc, argv, "tunnelEntry.t.tunDSlite.nDstIP6Addr", tn_entry.tunnelEntry.t.tunDSlite.nDstIP6Addr.nIPv6);
	}

	if (cnt != numPar) return (-2);

	if (cnt == 0) return (-2);

	if (cli_ioctl((GSW_API_HANDLE)fd, GSW_ROUTE_TUNNEL_ENTRY_DELETE, &tn_entry) != 0)
		return (-3);

	return 0;
}

int gsw_route_tunnel_entry_read(int argc, char *argv[], void *fd, int numPar)
{
	GSW_ROUTE_Tunnel_Entry_t tn_entry;
	int cnt = 0;

	memset(&tn_entry, 0, sizeof(tn_entry));

	cnt += scanParamArg(argc, argv, "nTunIndex", sizeof(tn_entry.nTunIndex), &tn_entry.nTunIndex);
	cnt += scanParamArg(argc, argv, "tunnelEntry.eTunnelType", sizeof(tn_entry.tunnelEntry.eTunnelType), &tn_entry.tunnelEntry.eTunnelType);

	if (cnt != numPar) return (-2);

	if (cnt != 2) return (-2);

	if (cli_ioctl((GSW_API_HANDLE)fd, GSW_ROUTE_TUNNEL_ENTRY_READ, &tn_entry) != 0)
		return (-3);

	printf("\n\tTunIndex      :          %d\n", tn_entry.nTunIndex);
	printf("\ttunnelEntry.eTunnelType:              %d\n", tn_entry.tunnelEntry.eTunnelType);

	if (tn_entry.tunnelEntry.eTunnelType == GSW_ROUTE_TUNL_6RD) {
		printf("\ttunnelEntry.t.tun6RD.nSrcIP4Addr: ");
		printIPv4_Address(tn_entry.tunnelEntry.t.tun6RD.nSrcIP4Addr.nIPv4);
		printf("\n");
		printf("\ttunnelEntry.t.tun6RD.nDstIP4Addr: ");
		printIPv4_Address(tn_entry.tunnelEntry.t.tun6RD.nDstIP4Addr.nIPv4);
		printf("\n");
	}

	if (tn_entry.tunnelEntry.eTunnelType == GSW_ROUTE_TUNL_L2TP)
		printf("\ttunnelEntry.t.nTunL2TP:0x%08x\n", tn_entry.tunnelEntry.t.nTunL2TP);

	if (tn_entry.tunnelEntry.eTunnelType == GSW_ROUTE_TUNL_IPSEC)
		printf("\ttunnelEntry.t.nTunIPsec:0x%08x\n", tn_entry.tunnelEntry.t.nTunIPsec);

	if (tn_entry.tunnelEntry.eTunnelType == GSW_ROUTE_TUNL_DSLITE) {
		printf("\ttunnelEntry.t.tunDSlite.nSrcIP6Addr: ");
		printIPv6_Address(tn_entry.tunnelEntry.t.tunDSlite.nSrcIP6Addr.nIPv6);
		printf("\n");
		printf("\ttunnelEntry.t.tunDSlite.nDstIP6Addr: ");
		printIPv6_Address(tn_entry.tunnelEntry.t.tunDSlite.nDstIP6Addr.nIPv6);
		printf("\n");
	}

	return 0;
}

int gsw_route_l2nat_cfg_read(int argc, char *argv[], void *fd, int numPar)
{
	GSW_ROUTE_EgPort_L2NAT_Cfg_t l2nat_cfg;
	int cnt = 0;

	memset(&l2nat_cfg, 0, sizeof(l2nat_cfg));

	cnt += scanParamArg(argc, argv, "nEgPortId", sizeof(l2nat_cfg.nEgPortId), &l2nat_cfg.nEgPortId);

	if (cnt != numPar) return (-2);

	if (cli_ioctl((GSW_API_HANDLE)fd, GSW_ROUTE_L2NAT_CFG_READ, &l2nat_cfg) != 0)
		return (-3);

	printf("\n\tbL2NATEna : 0x%08x", l2nat_cfg.bL2NATEna);
	printf("\n\tEgPortId  : 0x%08x", l2nat_cfg.nEgPortId);
	printf("\n\tNatMAC[6] : ");
	printMAC_Address(l2nat_cfg.nNatMAC);
	printf("\n");
	return 0;
}

int gsw_route_l2nat_cfg_write(int argc, char *argv[], void *fd, int numPar)
{
	GSW_ROUTE_EgPort_L2NAT_Cfg_t l2nat_cfg;
	int cnt = 0;

	memset(&l2nat_cfg, 0, sizeof(l2nat_cfg));
	cnt += scanParamArg(argc, argv, "bL2NATEna", sizeof(l2nat_cfg.bL2NATEna), &l2nat_cfg.bL2NATEna);
	cnt += scanParamArg(argc, argv, "nEgPortId", sizeof(l2nat_cfg.nEgPortId), &l2nat_cfg.nEgPortId);
	cnt += scanMAC_Arg(argc, argv, "nNatMAC", l2nat_cfg.nNatMAC);

	if ((cnt != numPar)) return (-2);

	if (cli_ioctl((GSW_API_HANDLE)fd, GSW_ROUTE_L2NAT_CFG_WRITE, &l2nat_cfg) != 0)
		return (-3);

	return 0;
}


int gsw_route_session_hit_op(int argc, char *argv[], void *fd, int numPar)
{
	GSW_ROUTE_Session_Hit_t session_hit;

	int cnt = 0;
	int ret;

	memset(&session_hit, 0, sizeof(session_hit));

	cnt += scanParamArg(argc, argv, "nRtIndex", sizeof(session_hit.nRtIndex), &session_hit.nRtIndex);
	cnt += scanParamArg(argc, argv, "eHitOper", sizeof(session_hit.eHitOper), &session_hit.eHitOper);

	if (cnt != numPar) return (-2);

	if(cli_ioctl((GSW_API_HANDLE)fd, GSW_ROUTE_SESSION_HIT_OP, &session_hit) != 0)
		return (-3);
	ret = cli_ioctl((GSW_API_HANDLE)fd, GSW_ROUTE_SESSION_HIT_OP, &session_hit);

	if (session_hit.eHitOper == GSW_ROUTE_HIT_READ) {
		printf("\n\tnRtIndex   :0x%08x", session_hit.nRtIndex);
		printf("\n\teHitOper   :0x%08x", session_hit.eHitOper);
		printf("\n\tHIt Status : %d", ret);
		printf("\n");
	}

	return 0;
}

int gsw_route_session_dest_mod(int argc, char *argv[], void *fd, int numPar)
{
	GSW_ROUTE_Session_Dest_t dest_mod;
	int cnt = 0;

	memset(&dest_mod, 0, sizeof(dest_mod));

	cnt += scanParamArg(argc, argv, "nRtIdx", sizeof(dest_mod.nRtIdx), &dest_mod.nRtIdx);
	cnt += scanParamArg(argc, argv, "nDstSubIfId", sizeof(dest_mod.nDstSubIfId), &dest_mod.nDstSubIfId);
	cnt += scanParamArg(argc, argv, "nDstPortMap", sizeof(dest_mod.nDstPortMap), &dest_mod.nDstPortMap);

	if (cnt != numPar) return (-2);

	if (cli_ioctl((GSW_API_HANDLE)fd, GSW_ROUTE_SESSION_DEST_MOD, &dest_mod) != 0)
		return (-3);

	printf("\n\t nRtIdx   :0x%08x", dest_mod.nRtIdx);
	printf("\n\t nDstSubIfId   :0x%08x", dest_mod.nDstSubIfId);
	printf("\n\t nDstPortMap   :0x%08x", dest_mod.nDstPortMap);
	return 0;
}
#endif /* CONFIG_LTQ_TEST */
