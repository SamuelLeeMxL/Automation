/******************************************************************************

         Copyright 2016 - 2017 Intel Corporation
         Copyright 2015 - 2016 Lantiq Beteiligungs-GmbH & Co. KG
         Copyright 2012 - 2014 Lantiq Deutschland GmbH

  SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only)

******************************************************************************/

#include <windows_stub.h>
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <gpy211.h>
//#include <gpy211_gmac.h>
#include <gpy211_macsec.h>
#include "gpy211_utility.h"

#include "gpy211_utility_cmdprocessor.h"
#include "gpy211_utility_common.h"
#include "gpy211_utility_pg31.h"
#include "gpy211_utility_f24s.h"
#include "gpy211_utility_gpy2xx.h"
#include "gpy211_utility_gpy211_menu.h"



int cmdProcessor(int num, int counter, char **param_list, FILE *fp)
{
#if LOGM_IN_FILE
	mdio_fp = fp;
#endif

	if (xstrncasecmp(param_list[0], "help", 4) == 0) {
		gpy211_menu(num > 1 ? param_list[1] : NULL);
	} else if (xstrncasecmp(param_list[0], "en_debug", 8) == 0) {
		if (num == 2) {
			debugenable = xstrtoul(param_list[1]);
		} else
			PRINTM(fp, "\n\ten_debug <Option> ( 0-disable 1-enable)");

#if F24S_READ_REGS
	} else if (xstrncasecmp(param_list[0], "print_f24s_regs", strlen("print_f24s_regs")) == 0) {
		/* To print F24S registers */
		print_f24s_regs();
#endif
#if P31G_READ_REGS
	} else if (xstrncasecmp(param_list[0], "print_p31g_regs", strlen("print_p31g_regs")) == 0) {
		if (p_gpyapi_phy->priv_data == 0) {
			printf("\nERROR: GPY2xx init not done, need cll first gpy2xx_init.\n");
			return -1;
		}

		/* To print P31G registers */
		print_p31g_regs();
#endif
	} else if (xstrncasecmp(param_list[0], "gpy2xx_msec", strlen("gpy2xx_msec")) == 0) {
		gpy2xx_msec_main(num, (char **)param_list);
#if ISECURE_MSEC_TEST
	} else if (xstrncasecmp(param_list[0], "gpy211_macsec", strlen("gpy211_macsec")) == 0) {
		mac_sec_main(num, (char **)param_list);
#endif
	} else {
#if (defined(GPY211_PC_TEST) && GPY211_PC_TEST)
		gpy211_main(num, param_list);
#else	/* GPY211_PC_TEST */
		PRINTM(fp, "Command Not Supported\n");
#endif	/* GPY211_PC_TEST */
	}
	return 0;
}
