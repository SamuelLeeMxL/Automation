#ifndef _WINDOWS_H_

#include "os_linux.h"

#define DWORD OS_ulong_t
typedef void *LPVOID;
#define WINAPI
/* STUB for windwows */
#define Sleep os_mssleep

#undef INLINE
#ifdef INLINE
#define INLINE inline
#else
#define INLINE
#endif
#endif

#define system