/******************************************************************************

         Copyright 2016 - 2017 Intel Corporation
         Copyright 2015 - 2016 Lantiq Beteiligungs-GmbH & Co. KG
         Copyright 2012 - 2014 Lantiq Deutschland GmbH

  SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only)

******************************************************************************/

#ifndef _UTILITY_UART_H_
#define _UTILITY_UART_H_

int pc_uart_dataread(u32 Offset, u32 *value);
int pc_uart_datawrite(u32 Offset, u32 value);
int pc_uart_dataread_32(u32 Offset, u32 *value);
int pc_uart_datawrite_32(u32 Offset, u32 *value);

#endif /* _UTILITY_UART_H_ */

