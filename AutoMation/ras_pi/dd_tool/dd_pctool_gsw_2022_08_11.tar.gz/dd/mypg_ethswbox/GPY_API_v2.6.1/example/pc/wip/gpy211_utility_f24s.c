/******************************************************************************

         Copyright 2016 - 2017 Intel Corporation
         Copyright 2015 - 2016 Lantiq Beteiligungs-GmbH & Co. KG
         Copyright 2012 - 2014 Lantiq Deutschland GmbH

  SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only)

******************************************************************************/

#include <windows_stub.h>
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <gpy211.h>
//#include <gpy211_gmac.h>
#include <gpy211_macsec.h>
#include "gpy211_utility.h"

#include "gpy211_utility_f24s.h"
#include "gpy211_utility_uart.h"

#if F24S_READ_REGS
void print_f24s_top()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tSwitch TOP Registers\n");
	base = 0xE000;

	for (i = 0; i < 0xC40; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_f24s_rcu()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tReset Control Unit Registers\n");
	base = 0xFA00;

	for (i = 0; i < 2; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}

	base = 0xFA10;

	for (i = 0; i < 2; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}

	base = 0xFA70;

	for (i = 0; i < 3; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}

	base = 0xFA74;

	for (i = 0; i < 3; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}

	addr = 0xFA78;
	pc_uart_dataread(addr, &value);
	printf("\taddr = 0x%x, value = 0x%x\n", addr, value);

	base = 0xFA80;

	for (i = 0; i < 2; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_f24s_cgu()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tClock Generation Unit Registers\n");
	base = 0xF948;

	for (i = 0; i < 9; i++) {
		addr = base + (i * 4);
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}

	base = 0xF980;

	for (i = 0; i < 5; i++) {
		addr = base + (i * 4);
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_f24s_gphy()
{
	u32 i, j, base = 0, addr = 0, value = 0;

	printf("\n\tGPHY Shell Registers\n");

	for (j = 0; j < 4; j++) {
		printf("\n\tGPHY%d Registers\n", j);
		base = 0xF700 + (j << 4);

		for (i = 0; i < 4; i++) {
			addr = base + i;
			pc_uart_dataread(addr, &value);
			printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
		}

		for (i = 0; i < 2; i++) {
			addr = base + 0x8 + i;
			pc_uart_dataread(addr, &value);
			printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
		}

		addr = base + 0xf;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_f24s_uart()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tUART Registers\n");
	base = 0xF680;

	for (i = 0; i < 5; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_f24s_sspi()
{
	u32 addr = 0, value = 0;

	printf("\n\tSPI Slave Registers\n");
	addr = 0xF580;
	pc_uart_dataread(addr, &value);
	printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
}

void print_f24s_mspi()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tSPI Master Registers\n");
	base = 0xF510;

	for (i = 0; i < 5; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}

	base = 0xF518;

	for (i = 0; i < 8; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_f24s_smdio()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tMDIO Slave Registers\n");
	base = 0xF480;

	for (i = 0; i < 2; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_f24s_mmdio()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tMDIO Master Registers\n");
	addr = 0xF400;
	pc_uart_dataread(addr, &value);
	printf("\taddr = 0x%x, value = 0x%x\n", addr, value);

	base = 0xF408;

	for (i = 0; i < 5; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}

	base = 0xF410;

	for (i = 0; i < 12; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}

	base = 0xF41D;

	for (i = 0; i < 4; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}

	addr = 0xF422;
	pc_uart_dataread(addr, &value);
	printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
}

void print_f24s_led()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tLED Registers\n");
	base = 0xF3E0;

	for (i = 0; i < 3; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_f24s_icu()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tICU Registers\n");
	addr = 0xF3C0;
	pc_uart_dataread(addr, &value);
	printf("\taddr = 0x%x, value = 0x%x\n", addr, value);

	base = 0xF3C2;

	for (i = 0; i < 3; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_f24s_gpio()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tGPIO Registers\n");
	base = 0xF380;

	for (i = 0; i < 8; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}

	base = 0xF390;

	for (i = 0; i < 8; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_f24s_rgmii()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tR(G)MII Registers\n");
	base = 0xF100;

	for (i = 0; i < 2; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}

	addr = 0xF120;
	pc_uart_dataread(addr, &value);
	printf("\taddr = 0x%x, value = 0x%x\n", addr, value);

	addr = 0xF130;
	pc_uart_dataread(addr, &value);
	printf("\taddr = 0x%x, value = 0x%x\n", addr, value);

	base = 0xF140;

	for (i = 0; i < 3; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}

	base = 0xF160;

	for (i = 0; i < 4; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}

	base = 0xF168;

	for (i = 0; i < 4; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_f24s_sgmii()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tSGMII PHY\n");
	base = 0xD000;

	for (i = 0; i < 11; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}

	base = 0xD100;

	for (i = 0; i < 3; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}

	base = 0xD111;

	for (i = 0; i < 2; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}

	printf("\n\tSGMII MACRO\n");
	base = 0xD200;

	for (i = 0; i < 2; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}

	addr = 0xD20F;
	pc_uart_dataread(addr, &value);
	printf("\taddr = 0x%x, value = 0x%x\n", addr, value);

	printf("\n\tSGMII TBI\n");
	base = 0xD300;

	for (i = 0; i < 15; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}

	printf("\n\tSGMII PCS\n");
	base = 0xD400;

	for (i = 0; i < 7; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_f24s_regs()
{
	printf("\nSGMII_Registers\n");
	print_f24s_sgmii();
	printf("\nTop Level PDI Registers\n");
	print_f24s_rgmii();
	print_f24s_gpio();
	print_f24s_icu();
	print_f24s_led();
	print_f24s_mmdio();
	print_f24s_smdio();
	print_f24s_mspi();
	print_f24s_sspi();
	print_f24s_uart();
	print_f24s_gphy();
	print_f24s_cgu();
	print_f24s_rcu();
	print_f24s_top();
}
#endif
