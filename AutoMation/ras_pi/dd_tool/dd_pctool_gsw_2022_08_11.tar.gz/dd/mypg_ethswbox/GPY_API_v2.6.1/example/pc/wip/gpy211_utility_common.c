/******************************************************************************

         Copyright 2016 - 2017 Intel Corporation
         Copyright 2015 - 2016 Lantiq Beteiligungs-GmbH & Co. KG
         Copyright 2012 - 2014 Lantiq Deutschland GmbH

  SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only)

******************************************************************************/

#include <windows_stub.h>
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <gpy211.h>
//#include <gpy211_gmac.h>
#include <gpy211_macsec.h>
#include "gpy211_utility.h"

#if FCON_MSEC_TEST
#include <e160_api.h>
#endif
//#include <eip160_common.h>
#include<time.h>

#define ARRAY_SIZE(x)	(sizeof(x) / sizeof((x)[0]))

/*general purpose*/
 
 unsigned int null_ptr_found = 0;

//! Byte swap unsigned int
u32 swap_uint32(u32 val)
{
	val = ((val << 8) & 0xFF00FF00) | ((val >> 8) & 0xFF00FF);
	return (val << 16) | (val >> 16);
}


 INLINE int xisupper(char c)
{
	return (c >= 'A' && c <= 'Z');
}

 INLINE int xisalpha(char c)
{
	return ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z'));
}

 INLINE int xisspace(char c)
{
	return (c == ' ' || c == '\t' || c == '\n' || c == '\12');
}

 INLINE int xisdigit(char c)
{
	return (c >= '0' && c <= '9');
}

 int xgetBase(const char *sPtr)
{
	const char *curr = sPtr;
	int hex = 0, dec = 0;

	if ((sPtr[0] == '0') && ((sPtr[1] == 'x') || (sPtr[1] == 'X'))) {
		curr = curr + 2;

		while (*curr != '\0') {
			if (('A' <= *curr && *curr <= 'F') || ('a' <= *curr && *curr <= 'f') || ('0' <= *curr && *curr <= '9')) {
				hex = 16;
			} else {
				hex = 0;
				break;
			}

			curr++;
		}

		return hex;
	} else {
		// Check for Decimal Number
		while (*curr != '\0') {
			if ((*curr >= '0') && (*curr <= '9')) {
				dec = 10;
			} else {
				dec = 0;
				break;
			}

			curr++;
		}

		return dec;
	}

	return -1;
}

 unsigned long xstrtoul(char *sPtr)
{
	unsigned long acc = 0;
	int i = 0, base = 0;
	char c;

	if (sPtr == 0) {
		null_ptr_found = 1;
		return 0;
	}

	// Determine whether the input is in Hex or Dec format
	base = xgetBase(sPtr);

	if (base == 0) {
		printf("\nALERT : Error: Invalid input. Provide Hex or Dec\n");
		Sleep(100);
		printf("\n\nIMPORTANT NOTE:\n");
		printf("\nFor hex decimal input param please add 0x before the hex decimal number or just give decimal number");
		printf("\nPerfix hex decimal value with 0x or Switch command execution will lead to wrong setting or malfunction\n");
		null_ptr_found = 1;
		return 0;
	} else if (base == 16) {
		i = 2;
	}

	for (; i < strlen(sPtr); i++) {
		c = sPtr[i];

		if ((c >= '0') && (c <= '9'))
			c -= '0';
		else if ((c >= 'a') && (c <= 'f'))
			c -= 'a' - 10;
		else if ((c >= 'A') && (c <= 'F'))
			c -= 'A' - 10;
		else c = 0;

		acc *= base;
		acc += c;
	}

	return acc;
}

 void printMAC_Address(unsigned char *pMAC)
{
	printf("%02x:%02x:%02x:%02x:%02x:%02x",
	       pMAC[0],
	       pMAC[1],
	       pMAC[2],
	       pMAC[3],
	       pMAC[4],
	       pMAC[5]);
}

 int convert_mac_adr_str(char *mac_adr_str, unsigned char *mac_adr_ptr)
{
	char *str_ptr = mac_adr_str;
	char *endptr;
	int i;
	unsigned long int val;

	if (strlen(mac_adr_str) != (12 + 5)) {
		printf("ERROR: Invalid length of address string!\n");
		return 0;
	}

	for (i = 0; i < 6; i++) {
		val = strtoul(str_ptr, &endptr, 16);

		if ((*endptr != 0) && (*endptr != ':') && (*endptr != '-'))
			return 0;

		*(mac_adr_ptr + i) = (unsigned char)(val & 0xFF);
		str_ptr = endptr + 1;
	}

	return 1;
}

 int copy_key_to_dst(char *key_adr_str, u8 size, char *key_adr_ptr)
{
	int i;
	char buf[20];
	char *pEnd = NULL;
	char *in_key = (char *)key_adr_str;
	unsigned int *out_key = (unsigned int *)key_adr_ptr;

	if (strlen(key_adr_str) != (size * 2)) {
		printf("ERROR: Len mismatch %d != %d!\n", strlen(in_key), (size * 2));
		return 0;
	}

	for (i = 0; i < (size / 4); i++) {
		pEnd = NULL;
		snprintf(buf, sizeof(buf) / sizeof(buf[0]), "%c%c%c%c%c%c%c%c",
			 in_key[6], in_key[7], in_key[4], in_key[5],
			 in_key[2], in_key[3], in_key[0], in_key[1]);

		out_key[i] = (strtoll(buf, &pEnd, 16) & 0xFFFFFFFFu);
		in_key = in_key + 8;
		//printf("\nConverted int %s, %x", buf, out_key[i]);
	}

	return 0;
}

 void remove_leading_whitespace(char **p, int *len)
{
	while (*len && ((**p == ' ') || (**p == '\r') || (**p == '\r'))) {
		(*p)++;
		(*len)--;
	}
}

 int split_buffer(char *buffer, char *array[], int max_param_num)
{
	int i, set_copy = 0;
	int res = 0;
	int len;

	for (i = 0; i < max_param_num; i++)
		array[i] = NULL;

	if (!buffer)
		return 0;

	len = strlen(buffer);

	for (i = 0; i < max_param_num;) {
		remove_leading_whitespace(&buffer, &len);

		for (;
		     *buffer != ' ' && *buffer != '\0' && *buffer != '\r'
		     && *buffer != '\n' && *buffer != '\t'; buffer++, len--) {
			/*Find first valid charactor */
			set_copy = 1;

			if (!array[i])
				array[i] = buffer;
		}

		if (set_copy == 1) {
			i++;

			if (*buffer == '\0' || *buffer == '\r'
			    || *buffer == '\n') {
				*buffer = 0;
				break;
			}

			*buffer = 0;
			buffer++;
			len--;
			set_copy = 0;

		} else {
			if (*buffer == '\0' || *buffer == '\r'
			    || *buffer == '\n')
				break;

			buffer++;
			len--;
		}
	}

	res = i;

	return res;
}


 unsigned int t_olower(u32 ch)
{
	if (ch >= 'A' && ch <= 'Z')
		return ch + 'a' - 'A';

	return ch;
}

 unsigned int xstrncasecmp(const char *s1, const char *s2, unsigned int n)
{
	int c1, c2;

	if (!s1 || !s2) return 1;

	for (; n > 0; s1++, s2++, --n) {
		c1 = t_olower(*s1);
		c2 = t_olower(*s2);

		if (c1 != c2) {
			return (c1 - c2);
		} else if (c1 == '\0') {
			return 0;
		}
	}

	return 0;
}


unsigned int str_to_hex(unsigned char *str)
{
	unsigned int n = 0;
	int i = 0;

	if (!str)
		return 0;

	if (str[0] == 0)
		return 0;

	while (str[i]) {
		n = n * 16;

		if (('0' <= str[i] && str[i] <= '9')) {
			n += str[i] - '0';
		} else if (('A' <= str[i] && str[i] <= 'F')) {
			n += str[i] - 'A' + 10;
			;
		} else if (('a' <= str[i] && str[i] <= 'f')) {
			n += str[i] - 'a' + 10;
			;
		} else
			printf("Wrong value:%u\n", str[i]);

		i++;
	}

	return n;
}

 INLINE unsigned int hex2int(char c)
{
	if (c >= '0' && c <= '9')
		return (unsigned int)(c - '0');
	else
		return (unsigned int)(c - 'a' + 10);
}

 int print_sys_time(u32 sec, u32 nsec)
{
	int hour, minute;

	minute = sec / 60;
	sec = sec % 60;

	hour = minute / 60;
	minute = minute % 60;

	printf("\n\tSystem time in H:M:S:NSec format %d:%d:%d:%d\n", hour, minute, sec, nsec);
	return 0;
}

