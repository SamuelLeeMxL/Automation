#ifndef _OS_LINUX_H
#define _OS_LINUX_H
/******************************************************************************

  Copyright (c) 2014 Lantiq Deutschland GmbH
  Copyright 2016, Intel Corporation.

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

******************************************************************************/
/**
   \file os_linux.h
   
*/

#ifdef __cplusplus
   extern "C" {
#endif

/* ============================= */
/* Includes                      */
/* ============================= */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>

#include <stdarg.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>

#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/select.h>


#include "os_types.h"



/* ============================= */
/* Prototypes                    */
/* ============================= */
int os_open (const char *pDevName);
int os_close(const int devFd);
int os_ioctl(const int devFd, 
             const unsigned int devCmd, 
             OS_uintptr_t param);
                                                                           
void *os_memalloc (OS_size_t memSize_byte);
void os_memfree   (void *pMemBlock);

int os_fileload (char const     *pName, 
                 unsigned char **ppDataBuf, 
                 OS_size_t    *pBufSize_byte);
                             
int os_system  (char const *pCmd);
int os_fprintf (FILE *stream, 
                const char *format, ...);

int os_snprintf (char *pStrBuf, 
                 int bufSize, 
                 const char *format, ...);

void os_mssleep(OS_time_t sleepTime_ms);
                                    

#ifdef __cplusplus
}
#endif

#endif /* _OS_LINUX_H */
