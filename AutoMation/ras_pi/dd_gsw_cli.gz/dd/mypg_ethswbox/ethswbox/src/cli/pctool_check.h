#ifndef _PCTOOL_CHECK_H
#define _PCTOOL_CHECK_H
/******************************************************************************

  Copyright (c) 2014 Lantiq Deutschland GmbH
  Copyright 2016, Intel Corporation.

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

******************************************************************************/

/**
   \file pctool_check.h
   
*/

#ifdef __cplusplus
   extern "C" {
#endif

int pctool_check (void);
#ifdef __cplusplus
}
#endif


#endif /* _PCTOOL_CHECK_H */
