#ifndef _CMDS_FAPI_H
#define _CMDS_FAPI_H
/******************************************************************************

  Copyright (c) 2014 Lantiq Deutschland GmbH
  Copyright 2016, Intel Corporation.

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

******************************************************************************/

/**
   \file cmds_fapi.h
   
*/

#ifdef __cplusplus
   extern "C" {
#endif
 
/* ========================================================================== */
/*                           Function prototypes                              */
/* ========================================================================== */
extern OS_boolean_t cmds_fapi (CmdArgs_t* pArgs, int *err);
extern int cmds_fapi_symlink_set (void);


#ifdef __cplusplus
}
#endif

#endif /* _CMDS_FAPI_H */
