/******************************************************************************

    Copyright 2021 Maxlinear

    SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only)

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.
******************************************************************************/

/**
   \file pctool_check.c
    This file implements:

*/

/* ============================= */
/* Includes                      */
/* ============================= */

#include"os_linux.h"
#include <stdio.h>
#include <string.h>

#include"pctool_check.h"


#include"gpy211_utility_cmdprocessor.h"
#define VALIDATION 1
#ifdef VALIDATION

/*********************************************
* Table definition                           *
*********************************************/

#define VAL_CMDLINE_ARGC_MAX    8    
#define VAL_CMDLINE_LEN_MAX    100   

typedef struct 
{
    int argc;
    char* argv[VAL_CMDLINE_ARGC_MAX];
    char argb[VAL_CMDLINE_ARGC_MAX][VAL_CMDLINE_LEN_MAX];
}Y_S_GpyEthValidation_CmdLine;

Y_S_GpyEthValidation_CmdLine Gval_CmdLine;




/****************************************************
 *  test FFU feature invalid cases.                 *
 *  gpyeth 0 t ffu                                  *
 * *************************************************/
char *cmds[] =
{
	"help",
"en_debug",
"exit",
"gpy2xx_init",
"gpy2xx_uninit",
"gpy2xx_get_phy_id",
"gpy2xx_soft_reset",
"gpy2xx_poll_reset",
""
};

char *cmds_rw[] =
{

"gpy2xx_read",
"gpy2xx_write",
"gpy2xx_read_mmd",
"gpy2xx_write_mmd",
""
};

char *cmds_mbox[] =
{
"gpy2xx_mbox_read16",
"gpy2xx_mbox_write16",
"gpy2xx_mbox_read32",
"gpy2xx_mbox_write32",
""
};

char *cmds_aneg[] =
{
"gpy2xx_config_advert",
"gpy2xx_setup_forced",
"gpy2xx_restart_aneg",
"gpy2xx_config_aneg",
"gpy2xx_aneg_done",
""
};

char *cmds_status[] =
{
"gpy2xx_update_link",
"gpy2xx_read_status",
"gpy2xx_read_fw_info",
""
};

char *cmds_gpio[] =
{
"gpy2xx_gpio_cfg",
"gpy2xx_gpio_get",
"gpy2xx_gpio_output",
"gpy2xx_gpio_input",
""
};

char *cmds_led[] =
{

"gpy2xx_led_br_cfg",
"gpy2xx_led_br_get",
"gpy2xx_led_if_cfg",
"gpy2xx_led_if_get",
""
};         

char *cmds_extin[] =
{
"gpy2xx_extin_mask",
"gpy2xx_extin_get",
""
};

char *cmds_testmode[] =
{

"gpy2xx_test_mode_cfg",
""
};

char *cmds_cdiag[] =
{

"gpy2xx_cdiag_start",
"gpy2xx_cdiag_read",
""
};

char *cmds_abist[] =
{
"gpy2xx_abist_start",
"gpy2xx_abist_read",
""
};

char *cmds_loopback[] =
{

"gpy2xx_loopback_cfg",
""
};

char *cmds_errcnt[] =
{
"gpy2xx_errcnt_cfg",
"gpy2xx_errcnt_read",
""
};

char *cmds_pcs[] =
{
"gpy2xx_pcs_status_read",
""
};

char *cmds_ptp[] =
{
"gpy2xx_ptp_adjfreq",
"gpy2xx_ptp_adjtime",
"gpy2xx_ptp_settime",
"gpy2xx_ptp_set_tsctrl",
"gpy2xx_ptp_set_ppsctrl",
"gpy2xx_ptp_set_ptoctrl",
"gpy2xx_ptp_gettime",
"gpy2xx_ptp_enable",
"gpy2xx_ptp_disable",
"gpy2xx_ptp_getcfg",
"gpy2xx_ptp_fifostat",
"gpy2xx_ptp_resetfifo",
"gpy2xx_ptp_getrxts",
"gpy2xx_ptp_aux_cfg",
"gpy2xx_ptp_gettxts",
"gpy2xx_ptp_getauxts",
"gpy2xx_ptp_auxfifostat",
"gpy2xx_ptp_resetauxfifo",
""
};

char *cmds_synce[] =
{

"gpy2xx_synce_cfg",
"gpy2xx_synce_get",
""
};

char *cmds_wol[] =
{

"gpy2xx_wol_cfg",
"gpy2xx_wol_get",
""
};

char *cmds_ads[] =
{
"gpy2xx_ads_cfg",
"gpy2xx_ads_get",
"gpy2xx_ads_detected",
""   
};

char *cmds_ulp[] =
{
"gpy2xx_ulp_cfg",
""
};

char *cmds_sgmii[] =
{
"gpy2xx_sgmii_restart_aneg",
"gpy2xx_sgmii_config_aneg",
"gpy2xx_sgmii_aneg_done",
"gpy2xx_sgmii_read_status",
"gpy2xx_sgmii_opmode",
""
};

char *cmds_pvt[] =
{
"gpy2xx_pvt_get",
""
};

char *cmds_gmac[] =
{
"gpy2xx_gmacx_pm_pdi_cfg",
"gpy2xx_gmacx_pm_pdi_get",
"gpy2xx_gmacf_pm_cfg",
"gpy2xx_gmacf_pm_get",
"gpy2xx_gmacl_pm_cfg",
"gpy2xx_gmacl_pm_get",
"gpy2xx_gmacx_bm_cfg",
"gpy2xx_gmacx_bm_status_get",
"gpy2xx_gmacx_bm_get",
"gpy2xx_gmacl_pause_cfg",
"gpy2xx_gmacl_pause_get",
"gpy2xx_gmacf_pkt_cfg",
"gpy2xx_gmacf_pkt_get",
"gpy2xx_gmacf_count_ctrl_cfg",
"gpy2xx_gmacf_count_ctrl_get",
"gpy2xx_gmacf_count_get",
""
};

char *cmds_msec[] =
{
"gpy2xx_msec_init_ing_dev",
"gpy2xx_msec_init_egr_dev",
"gpy2xx_msec_config_ing_tr",
"gpy2xx_msec_config_egr_tr",
"gpy2xx_msec_update_egr_sa_cw",
"gpy2xx_msec_get_ing_tr",
"gpy2xx_msec_get_egr_tr",
"gpy2xx_msec_get_ing_pn",
"gpy2xx_msec_get_egr_pn",
"gpy2xx_msec_config_ing_sam_rule",
"gpy2xx_msec_config_egr_sam_rule",
"gpy2xx_msec_get_ing_sam_rule",
"gpy2xx_msec_get_egr_sam_rule",
"gpy2xx_msec_config_ing_sam_fca",
"gpy2xx_msec_config_egr_sam_fca",
"gpy2xx_msec_get_ing_sam_fca",
"gpy2xx_msec_get_egr_sam_fca",
"gpy2xx_msec_clear_ing_tr",
"gpy2xx_msec_clear_egr_tr",
"gpy2xx_msec_clear_ing_sam_rule",
"gpy2xx_msec_clear_egr_sam_rule",
"gpy2xx_msec_clear_ing_sam_fca",
"gpy2xx_msec_clear_egr_sam_fca",
"gpy2xx_msec_config_ing_vlan_parse",
"gpy2xx_msec_config_egr_vlan_parse",
"gpy2xx_msec_config_ing_sam_eex",
"gpy2xx_msec_config_egr_sam_eex",
"gpy2xx_msec_get_ing_sam_eef",
"gpy2xx_msec_get_egr_sam_eef",
"gpy2xx_msec_config_ing_sam_eec",
"gpy2xx_msec_config_egr_sam_eec",
"gpy2xx_msec_config_ing_cc_rule",
"gpy2xx_msec_get_ing_cc_rule",
"gpy2xx_msec_config_ing_cc_eef",
"gpy2xx_msec_get_ing_cc_eef",
"gpy2xx_msec_config_ing_cc_eec",
"gpy2xx_msec_config_ing_cc_ctrl",
"gpy2xx_msec_get_ing_sa_stats",
"gpy2xx_msec_get_egr_sa_stats",
"gpy2xx_msec_get_ing_global_stats",
"gpy2xx_msec_get_egr_global_stats",
"gpy2xx_msec_config_ing_count_ctrl",
"gpy2xx_msec_config_egr_count_ctrl",
"gpy2xx_msec_config_ing_count_incen",
"gpy2xx_msec_config_egr_count_incen",
"gpy2xx_msec_config_ing_count_secfail",
"gpy2xx_msec_config_egr_count_secfail",
"gpy2xx_msec_config_ing_count_thresh",
"gpy2xx_msec_get_ing_count_thresh",
"gpy2xx_msec_config_egr_count_thresh",
"gpy2xx_msec_get_egr_count_thresh",
"gpy2xx_msec_config_ing_misc_ctrl",
"gpy2xx_msec_config_egr_misc_ctrl",
"gpy2xx_msec_config_ing_sa_nm_ctrl",
"gpy2xx_msec_config_egr_sa_nm_ctrl",
"gpy2xx_msec_config_ing_sa_nm_ncp",
"gpy2xx_msec_config_egr_sa_nm_ncp",
"gpy2xx_msec_config_ing_sa_nm_cp",
"gpy2xx_msec_config_egr_sa_nm_cp",
"gpy2xx_msec_clear_ing_stats_summ",
"gpy2xx_msec_clear_egr_stats_summ",
"gpy2xx_msec_get_ing_stats_summ",
"gpy2xx_msec_get_egr_stats_summ",
"gpy2xx_msec_clear_ing_psa_stats_summ",
"gpy2xx_msec_get_ing_psa_stats_summ",
"gpy2xx_msec_clear_egr_psa_stats_summ",
"gpy2xx_msec_get_egr_psa_stats_summ",
"gpy2xx_msec_config_ing_cp_rule",
"gpy2xx_msec_config_egr_cp_rule",
"gpy2xx_msec_clear_sa_pn_thr_summ",
"gpy2xx_msec_get_sa_pn_thr_summ",
"gpy2xx_msec_clear_egr_sa_exp_summ",
"gpy2xx_msec_get_egr_sa_exp_summ",
"gpy2xx_msec_clear_ing_cc_int_stat",
"gpy2xx_msec_get_ing_cc_int_stat",
"gpy2xx_msec_clear_egr_cc_int_stat",
"gpy2xx_msec_get_egr_cc_int_stat",
"gpy2xx_msec_config_ing_sn_thresh",
"gpy2xx_msec_get_ing_sn_thresh",
"gpy2xx_msec_config_egr_sn_thresh",
"gpy2xx_msec_get_egr_sn_thresh",
"gpy2xx_msec_config_ing_aic_csr",
"gpy2xx_msec_get_ing_aic_csr",
"gpy2xx_msec_config_egr_aic_csr",
"gpy2xx_msec_get_egr_aic_csr",
"gpy2xx_msec_get_ing_cap",
"gpy2xx_msec_get_egr_cap",
"gpy2xx_usxgmii_reach_cfg",
"gpy2xx_usxgmii_reach_get",
""
};





/*********************************************
* local Functions                           *
*********************************************/
static int Val_CmdLineToArgs(char *str, Y_S_GpyEthValidation_CmdLine *pCmdLine)
{
    int i;
	int j;	
	int k;	
    char *p;
    int len;

	if (str == NULL || pCmdLine == NULL)
    {
		return -1;
    }

	pCmdLine->argc = 0;
    p   = str;
    i   = 0;
    j   = 0;
    k   = 0;
    len = strlen(str);

    while (len)
    {	
        pCmdLine->argb[i][j] = *(p+k);

        if (pCmdLine->argb[i][j] == ' ')
        {
            pCmdLine->argb[i][j] = '\0';
            j=0;
            i++;
            if (i > VAL_CMDLINE_ARGC_MAX)
            {
               printf("Val_CmdLineToArgs: Too many arguments. Max %d\n", VAL_CMDLINE_ARGC_MAX);
                return -1;
            }        
        }
        else
        {
            j++;
            if (j > VAL_CMDLINE_LEN_MAX)
            {
               printf("Val_CmdLineToArgs: Too long command line. Max %d\n", VAL_CMDLINE_ARGC_MAX);
                return -1;
            } 
        }
        k++;
        len--;
    }

    pCmdLine->argc = i+1;
    pCmdLine->argb[i][j] = '\0';

    for (i = 0; i < pCmdLine->argc ; i++)
    {
       pCmdLine->argv[i] = &pCmdLine->argb[i][0]; 
    }

    return 0;
}


static int Val_CmdLinePrintArgs(Y_S_GpyEthValidation_CmdLine *pCmdLine)
{
    int i;
	if (pCmdLine == NULL)
    {
		return -1;
    }

    for (i = 0; i < pCmdLine->argc ; i++)
    {
       printf("%s",&pCmdLine->argb[i][0]); 
    }
    printf("\n"); 
    return 0;
}


/*********************************************
* Test group  Functions                      *
*********************************************/
int Cmds_Check (char *str,  char *val_addr[], Y_S_GpyEthValidation_CmdLine *val_CmdLine)
{
    int ret;
    int i;

    printf("*** %s ***\n", str); 
    i=0;
    ret=0;
    while (strcmp(val_addr[i],"") != 0)
    {
//        printf("* %d *\n", i); 
        ret |= Val_CmdLineToArgs(val_addr[i], val_CmdLine);
        ret |= Val_CmdLinePrintArgs (val_CmdLine);
    	cmdProcessor(val_CmdLine->argc, val_CmdLine->argc, &val_CmdLine->argv[0], (FILE *)NULL);

        printf("\n"); 
        i++;
    };
    printf("***\n");
    return ret;
}








int Cmds_Check_wol (void){
    return (Cmds_Check("Check wol",  cmds_wol, &Gval_CmdLine));
}
int Cmds_Check_aneg (void){
    return (Cmds_Check("Check cmds_aneg",  cmds_aneg, &Gval_CmdLine));
}


int Cmds_Check_status (void){
    return (Cmds_Check("Check cmds_status",  cmds_status, &Gval_CmdLine));
}

int Cmds_Check_gpio (void){
    return (Cmds_Check("Check cmds_gpio",  cmds_gpio, &Gval_CmdLine));
}

int Cmds_Check_led (void){
    return (Cmds_Check("Check cmds_led",  cmds_led, &Gval_CmdLine));
}

int Cmds_Check_extin (void){
    return (Cmds_Check("Check cmds_extin",  cmds_extin, &Gval_CmdLine));
}

int Cmds_Check_testmode (void){
    return (Cmds_Check("Check cmds_testmode",  cmds_testmode, &Gval_CmdLine));
}

int Cmds_Check_cdiag (void){
    return (Cmds_Check("Check cmds_cdiag",  cmds_cdiag, &Gval_CmdLine));
}

int Cmds_Check_abist (void){
    return (Cmds_Check("Check cmds_abist",  cmds_abist, &Gval_CmdLine));
}

int Cmds_Check_loopback (void){
    return (Cmds_Check("Check cmds_loopback",  cmds_loopback, &Gval_CmdLine));
}



int Cmds_Check_errcnt (void){
    return (Cmds_Check("Check cmds_errcnt",  cmds_errcnt, &Gval_CmdLine));
}


int Cmds_Check_pcs (void){
    return (Cmds_Check("Check cmds_pcs",  cmds_pcs, &Gval_CmdLine));
}




int Cmds_Check_ptp (void){
    return (Cmds_Check("Check cmds_ptp",  cmds_ptp, &Gval_CmdLine));
}


int Cmds_Check_synce (void){
    return (Cmds_Check("Check cmds_synce",  cmds_synce, &Gval_CmdLine));
}


int Cmds_Check_ads (void){
    return (Cmds_Check("Check cmds_ads",  cmds_ads, &Gval_CmdLine));
}


int Cmds_Check_ulp (void){
    return (Cmds_Check("Check cmds_ulp",  cmds_ulp, &Gval_CmdLine));
}


int Cmds_Check_sgmii (void){
    return (Cmds_Check("Check cmds_sgmii",  cmds_sgmii, &Gval_CmdLine));
}


int Cmds_Check_pvt (void){
    return (Cmds_Check("Check cmds_pvt",  cmds_pvt, &Gval_CmdLine));
}


int Cmds_Check_cmds_gmac (void){
    return (Cmds_Check("Check cmds_cmds_gmac",  cmds_gmac, &Gval_CmdLine));
}


int Cmds_Check_cmds_msec (void){
    return (Cmds_Check("Check cmds_msec",  cmds_msec, &Gval_CmdLine));
}


int pctool_check (void)
{
    int ret = 0;
  ret |= Cmds_Check_wol ();
ret |= Cmds_Check_aneg ();
ret |= Cmds_Check_status ();
ret |= Cmds_Check_gpio ();
ret |= Cmds_Check_led ();
ret |= Cmds_Check_extin ();
ret |= Cmds_Check_testmode ();
ret |= Cmds_Check_cdiag ();
ret |= Cmds_Check_abist ();
ret |= Cmds_Check_loopback ();
ret |= Cmds_Check_errcnt ();
ret |= Cmds_Check_pcs ();
ret |= Cmds_Check_ptp ();
ret |= Cmds_Check_synce ();
ret |= Cmds_Check_ads ();
ret |= Cmds_Check_ulp ();
ret |= Cmds_Check_sgmii ();
ret |= Cmds_Check_pvt ();
ret |= Cmds_Check_cmds_gmac ();
ret |= Cmds_Check_cmds_msec ();

return ret;

}

#endif /* VALIDATION */