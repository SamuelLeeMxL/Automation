/******************************************************************************

    Copyright 2021 Maxlinear

    SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only)

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.
******************************************************************************/

/**
   \file pctool_gsw_check.c
    This file implements:

*/

/* ============================= */
/* Includes                      */
/* ============================= */

#include"os_linux.h"
#include <stdio.h>
#include <string.h>

#include "conf_if.h" 
#include "plm_mdio.h"

#include "f2x_swapi_types.h"
#include "f2x_swapi_flow.h"
#include "gsw_sw_init.h"

extern char* transcode (char* str);
extern int gsw_swcli_cmdProcessor(int argc, char *argv[]);

#include"pctool_gsw_check.h"

#ifdef VALIDATION

/*********************************************
* Table definition                           *
*********************************************/

#define VAL_CMDLINE_ARGC_MAX    500    
#define VAL_CMDLINE_LEN_MAX    2000   

typedef struct 
{
    int argc;
    char* argv[VAL_CMDLINE_ARGC_MAX];
    char argb[VAL_CMDLINE_ARGC_MAX][VAL_CMDLINE_LEN_MAX];
}Y_S_GpyEthValidation_CmdLine;

Y_S_GpyEthValidation_CmdLine Gval_CmdLine;




/****************************************************
 *  Sanity check pctool GSW                         *
 * *************************************************/
char *cmds[] =
{
    "pctool_gsw help",
    "pctool_gsw exit",
    "pctool_gsw Switch_PortEnable",
    "pctool_gsw HW_Init"
    ""
};

char *cmds_rmon[] =
{
    "pctool_gsw RMON_Clear",
    "pctool_gsw RMON_Clear nRmonId=1",                      
    "pctool_gsw RMON_Clear nRmonId=1 eRmonType=0",

    "pctool_gsw RMON_Get nPortId=1",                    // emilio check help
    "pctool_gsw RMON_ExtendGet nPortId=1",
    ""
};

char *cmds_mac[] =
{
    "pctool_gsw MAC_TableClear",
    "pctool_gsw MAC_TableEntryAdd "\
                                  "nFId=1 "\
                                  "nPortId=1 "\
                                  "nAgeTimer=897 "\
                                  "bStaticEntry=1 "\
                                  "nTrafficClass=1 "\
                                  "nMAC=12:34:45:67:89:0A",

    "pctool_gsw MAC_TableEntryQuery "\
                                  "nFId=1 "\
                                  "nMAC=12:34:45:67:89:0A", 
    "pctool_gsw MAC_TableEntryRead",                            
    ""
};

char *cmds_cfg[] =
{
    "pctool_gsw CapGet",
    
    "pctool_gsw CfgGet",

    "pctool_gsw CfgSet "\
                       "eMAC_TableAgeTimer=5 "\
                       "bVLAN_Aware=1 "\
                       "nMaxPacketLen=1024 "\
                       "bLearningLimitAction=1 "\
                       "bMAC_SpoofingAction=1 "\
                       "bPauseMAC_ModeSrc=0 "\
                       "nPauseMAC_Src=ac:9a:96:00:00:00",

    "pctool_gsw CfgGet",
    ""
};

char *cmds_port[] =
{
    "pctool_gsw PortCfgSet "\
    "nPortId=1 "\
    "eEnable=1 "\
    "bUnicastUnknownDrop=0 "\
    "bMulticastUnknownDrop=0 "\
    "bReservedPacketDrop=0 "\
    "bBroadcastDrop=0 "\
    "bAging=0 bLearning=0 "\
    "bLearningMAC_PortLock=0 "\
    "nLearningLimit=0 "\
    "bMAC_SpoofingDetection=0 eFlowCtrl=0 ePortMonitor=0",
    
    "pctool_gsw PortCfgGet nPortId=1",

    "pctool_gsw PortCfgSet "\
    "nPortId=1 "\
    "eEnable=0 "\
    "bUnicastUnknownDrop=1 "\
    "bMulticastUnknownDrop=1 "\
    "bReservedPacketDrop=1 "\
    "bBroadcastDrop=1 "\
    "bAging=0 bLearning=1 "\
    "bLearningMAC_PortLock=1 "\
    "nLearningLimit=1 "\
    "bMAC_SpoofingDetection=0 eFlowCtrl=0 ePortMonitor=1",
    
    "pctool_gsw PortCfgGet nPortId=1",

    "pctool_gsw PortRedirectSet nPortId=1 bRedirectEgress=1 bRedirectIngress=1",
    "pctool_gsw PortRedirectGet nPortId=1",

    "pctool_gsw PortRedirectSet nPortId=1 bRedirectEgress=0 bRedirectIngress=0",
    "pctool_gsw PortRedirectGet nPortId=1",
    ""
};

char *cmds_mon[] =
{
    "pctool_gsw MonitorPortCfgGet nPortId=1", 
    "pctool_gsw MonitorPortCfgSet nPortId=1 bMonitorPort=1",
    "pctool_gsw MonitorPortCfgGet nPortId=1", 
    ""
};

char *cmds_cpu[] =
{
    "pctool_gsw CPU_PortCfgGet nPortId=1",
    "pctool_gsw CPU_PortCfgSet nPortId=1 bCPU_PortValid=0 bSpecialTagIngress=1 bSpecialTagEgress=1 bFcsCheck=1 bFcsGenerate=0 bSpecialTagEthType=1",
    "pctool_gsw CPU_PortCfgGet nPortId=1",
    "pctool_gsw CPU_PortCfgSet nPortId=1 bCPU_PortValid=1 bSpecialTagIngress=0 bSpecialTagEgress=0 bFcsCheck=0 bFcsGenerate=1 bSpecialTagEthType=0",
    "pctool_gsw CPU_PortCfgGet nPortId=1",
    ""
};

char *cmds_vlan[] =
{
    "pctool_gsw VLAN_IdCreate nVId=1 nFId=2",        
    "pctool_gsw VLAN_IdDelete nVId=1",       
    "pctool_gsw VLAN_IdGet nVId=1",
 //    "pctool_gsw VLAN_Member_Init nPortMemberMap=1 nEgressTagMap=8",
    
    "pctool_gsw VLAN_PortCfgSet "\
                                "nPortId=1 "\
                                "nPortVId=2 "\
                                "bVLAN_UnknownDrop=0 "\
                                "bVLAN_ReAssign=0 "\
                                "eVLAN_MemberViolation=0 "\
                                "eAdmitMode=0 "\
                                "bTVM=0",

    "pctool_gsw VLAN_PortCfgGet nPortId=1",    

    "pctool_gsw VLAN_PortMemberAdd "\
                                   "nPortId=1 "\
                                   "nVId=3 "\
                                   "bVLAN_TagEgress=0",

    "pctool_gsw VLAN_PortMemberRemove "\
                                      "nPortId=1 "\
                                      "nVId=3",

    "pctool_gsw VLAN_ReservedAdd "\
                                 "nVId=3",

// too long    "pctool_gsw VLAN_PortMemberRead",
    ""
};

char *cmds_svlan[] =
{
    "pctool_gsw SVLAN_CfgSet nEthertype=0x8101",
    "pctool_gsw SVLAN_CfgGet",
    "pctool_gsw SVLAN_CfgSet nEthertype=0x8102",
    "pctool_gsw SVLAN_CfgGet",

    "pctool_gsw SVLAN_PortCfgGet nPortId=1",
    ""
};

char *cmds_qos[] =
{
    "pctool_gsw QoS_MeterCfgSet nMeterId=1 bEnable=1 nCbs=100 nEbs=200 nRate=300",
    "pctool_gsw QoS_MeterCfgGet nMeterId=1",
 
    "pctool_gsw QoS_MeterPortAssign nMeterId=1 eDir=3 nPortIngressId=0 nPortEgressId=0",
    "pctool_gsw QoS_MeterPortDeassign nMeterId=1 eDir=3 nPortIngressId=0 nPortEgressId=0",

    "pctool_gsw QoS_ClassDSCP_Set nTrafficClass=1 nDSCP=1",
    "pctool_gsw QoS_ClassDSCP_Get",

    "pctool_gsw QoS_ClassPCP_Set nTrafficClass=1 nPCP=1",
    "pctool_gsw QoS_ClassPCP_Get",
 
    "pctool_gsw QoS_DSCP_ClassSet nTrafficClass=1 nDSCP=63",
    "pctool_gsw QoS_DSCP_ClassGet",

    "pctool_gsw QoS_DSCP_DropPrecedenceCfgSet nDSCP_DropPrecedence=0 nDSCP=1",
    "pctool_gsw QoS_DSCP_DropPrecedenceCfgGet",
    "pctool_gsw QoS_DSCP_DropPrecedenceCfgSet nDSCP_DropPrecedence=0 nDSCP=3",
    "pctool_gsw QoS_DSCP_DropPrecedenceCfgGet",
 
    "pctool_gsw QoS_FlowctrlCfgSet nFlowCtrlNonConform_Min=2 nFlowCtrlNonConform_Max=3 nFlowCtrlConform_Min=4 nFlowCtrlConform_Max=5",
    "pctool_gsw QoS_FlowctrlCfgGet",

    "pctool_gsw QoS_FlowctrlPortCfgSet nPortId=1 nFlowCtrl_Min=2 nFlowCtrl_Max=3",
    "pctool_gsw QoS_FlowctrlPortCfgGet nPortId=1",

    "pctool_gsw QoS_PCP_ClassSet nTrafficClass=3 nPCP=7",
    "pctool_gsw QoS_PCP_ClassGet",
 
    "pctool_gsw QoS_PortCfgSet nPortId=1 eClassMode=10 nTrafficClass=0",
    "pctool_gsw QoS_PortCfgGet nPortId=1",


    "pctool_gsw QoS_PortRemarkingCfgSet nPortId=1 "\
                                        "eDSCP_IngressRemarkingEnable=1 "\
                                        "bDSCP_EgressRemarkingEnable=1 "\
                                        "bPCP_IngressRemarkingEnable=1 "\
                                        "bPCP_EgressRemarkingEnable=1 "\
                                        "bSTAG_PCP_IngressRemarkingEnable=1 "\
                                        "bSTAG_DEI_IngressRemarkingEnable=1 "\
                                        "bSTAG_PCP_DEI_EgressRemarkingEnable=1",
    "pctool_gsw QoS_PortRemarkingCfgGet nPortId=1",

    "pctool_gsw QoS_QueueBufferReserveCfgSet nQueueId=1 nBufferReserved=10",
    "pctool_gsw QoS_QueueBufferReserveCfgGet nQueueId=1",
    
    "pctool_gsw QoS_QueuePortSet nPortId=1 nTrafficClassId=5 nQueueId=6",
    "pctool_gsw QoS_QueuePortGet nQueueId=1",
    
    "pctool_gsw QoS_SchedulerCfgSet nQueueId=1 eType=1 nWeight=0x1801",
    "pctool_gsw QoS_SchedulerCfgGet nQueueId=1",
    
    "pctool_gsw QoS_ShaperCfgSet nRateShaperId=1 bEnable=1 nCbs=125 nRate=345",
    "pctool_gsw QoS_ShaperCfgGet nRateShaperId=1",

    "pctool_gsw QoS_ShaperQueueAssign nRateShaperId=1 nQueueId=1",
    "pctool_gsw QoS_ShaperQueueDeassign nRateShaperId=1 nQueueId=1",
    "pctool_gsw QoS_ShaperQueueGet nQueueId=1",
    
    "pctool_gsw QoS_StormCfgSet nMeterId=1 bBroadcast=1 bMulticast=1 bUnknownUnicast=1",
    "pctool_gsw QoS_StormCfgGet",
    "pctool_gsw QoS_StormCfgSet nMeterId=1 bBroadcast=1 bMulticast=0 bUnknownUnicast=1",
    "pctool_gsw QoS_StormCfgGet",
    
    "pctool_gsw QoS_SVLAN_ClassPCP_PortSet nPortId=1 nTrafficClass=15 nCPCP=1 nSPCP=2 nDSCP=8",
    "pctool_gsw QoS_SVLAN_ClassPCP_PortGet nPortId=1",

    "pctool_gsw QoS_SVLAN_PCP_ClassSet nPCP=15 nTrafficClass=5 nTrafficColor=6 nPCP_Remark_Enable=1 nDEI_Remark_Enable=1",
    "pctool_gsw QoS_SVLAN_PCP_ClassGet",

    "pctool_gsw QoS_WredCfgSet eProfile=2 eThreshMode=1 nRed_Min=2 nRed_Max=4 nYellow_Min=5 nYellow_Max=7 nGreen_Min=9 nGreen_Max=10",
    "pctool_gsw QoS_WredCfgGet",    
    
    "pctool_gsw QoS_WredPortCfgSet nPortId=1 nRed_Min=3 nRed_Max=6 nYellow_Min=7 nYellow_Max=9 nGreen_Min=12 nGreen_Max=15",
    "pctool_gsw QoS_WredPortCfgGet nPortId=1",
    "pctool_gsw QoS_WredQueueCfgSet nQueueId=1 nRed_Min=3 nRed_Max=6 nYellow_Min=7 nYellow_Max=9 nGreen_Min=12 nGreen_Max=15",
    "pctool_gsw QoS_WredQueueCfgGet nQueueId=1",
    ""
};

char *cmds_mcast[] =
{
    "pctool_gsw MULTICAST_Router_Port_Add nPortId=1",
    "pctool_gsw MULTICAST_Router_Port_Read bInitial=1 bLast=1 nPortId=1",
    "pctool_gsw MULTICAST_Router_Port_Remove nPortId=1",
    
    "pctool_gsw MULTICAST_Snoop_Cfg_Set "\
                                        "eIGMP_Mode=0 "\
                                        "bIGMPv3=0 "\
                                        "bCrossVLAN=0 "\
                                        "eForwardPort=0 "\
                                        "nForwardPortId=0 "\
                                        "nClassOfService=1 "\
                                        "nRobust=2 "\
                                        "nQueryInterval=200 "\
                                        "eSuppressionAggregation=0 "\
                                        "bFastLeave=0 "\
                                        "bLearningRouter=0",
    "pctool_gsw MULTICAST_Snoop_Cfg_Get",


    "pctool_gsw MULTICAST_Table_Entry_Add nPortId=1 eIPVersion=1 eModeMember=2 uIP_Gda=10.1.1.1  uIP_Gsa=10.1.1.1",
    "pctool_gsw MULTICAST_Table_Entry_Read nPortId=1",
    "pctool_gsw MULTICAST_Table_Entry_Remove nPortId=1",
""
};

char *cmds_pce[] =
{
    "pctool_gsw PCE_Rule_Write "\
                               "pattern.nIndex=1 "\
                               "pattern.bEnable=1 "\
                               "pattern.bPortIdEnable=1 "\
                               "pattern.nPortId=1 "\
                               "pattern.bDSCP_Enable=0 "\
                               "pattern.nDSCP=0 "\
                               "pattern.bPCP_Enable=0 "\
                               "pattern.nPCP=0 "\
                               "pattern.bSTAG_PCP_DEI_Enable=0 "\
                               "pattern.nSTAG_PCP_DEI=0 "\
                               "pattern.bPktLngEnable=0 "\
                               "pattern.nPktLng=0 "\
                               "pattern.nPktLngRange=0 "\
                               "pattern.nMAC_Dst=12:34:45:67:89:0A "\
                               "pattern.nMAC_DstMask=1111 "\
                               "pattern.bMAC_SrcEnable=0 "\
                               "pattern.nMAC_Src=12:34:45:67:89:0B "\
                               "pattern.nMAC_SrcMask=1010 "\
                               "pattern.bAppDataMSB_Enable=0 "\
                               "pattern.nAppDataMSB=45 "\
                               "pattern.bAppMaskRangeMSB_Select=0 "\
                               "pattern.nAppMaskRangeMSB=0 "\

                               "pattern.bAppDataLSB_Enable=0 "\
                               "pattern.nAppDataLSB=56 "\
                               "pattern.bAppMaskRangeLSB_Select=0 "\
                               "pattern.nAppMaskRangeLSB=0 "\

                               "pattern.eDstIP_Select=1 "\
                               "pattern.nDstIP=10.1.1.2 "\
                               "pattern.nDstIP_Mask=0101 "\
                               "pattern.eSrcIP_Select=1 "\
                               "pattern.nSrcIP=10.1.1.3 "\
                               "pattern.nSrcIP_Mask=0011 "\

                               "pattern.bEtherTypeEnable=0 "\
                               "pattern.nEtherType=0 "\
                               "pattern.nEtherTypeMask=0 "\

                               "pattern.bProtocolEnable=0 "\
                               "pattern.nProtocol=0 "\
                               "pattern.nProtocolMask=0 "\

                               "pattern.bSessionIdEnable=0 "\
                               "pattern.nSessionId=0 "\

                               "pattern.bVid=0 "\
                               "pattern.nVid=0 "\
                               "pattern.bVidRange_Select=0 "\
                               "pattern.nVidRange=0 "\

                               "pattern.bSLAN_Vid=0 "\
                               "pattern.nSLAN_Vid=0 "\

                               "action.eTrafficClassAction=0 "\
                               "action.nTrafficClassAlternate=0 "\
                               "action.eSnoopingTypeAction=0 "\
                               "action.eLearningAction=0 "\
                               "action.eIrqAction=0 "\
                               "action.eCrossStateAction=0 "\
                               "action.eCritFrameAction=0 "\
                               "action.eTimestampAction=0 "\
                               "action.ePortMapAction=0 "\
                               "action.nForwardPortMap=0 "\

                               "action.bRemarkAction=0 "\
                               "action.bRemarkPCP=0 "\
                               "action.bRemarkSTAG_PCP=0 "\
                               "action.bRemarkSTAG_DEI=0 "\
                               "action.bRemarkDSCP=0 "\
                               "action.bRemarkClass=0 "\

                               "action.eMeterAction=0 "\
                               "action.nMeterId=0 "\

                               "action.bRMON_Action=0 "\
                               "action.nRMON_Id=0 "\

                               "action.eVLAN_Action=0 "\
                               "action.nVLAN_Id=0 "\
                               "action.nFId=0 "\

                               "action.eSVLAN_Action=0 "\
                               "action.nSVLAN_Id=0 "\
                               "action.eVLAN_CrossAction=0 "\
                               "action.bPortBitMapMuxControl=0 "\
                               "action.bCVLAN_Ignore_Control=0 "\
                               "action.bPortLinkSelection=0 "\
                               "action.bPortTrunkAction=0 "\

                               "action.bFlowID_Action=0 "\
                               "action.nFlowID=0",

   "pctool_gsw PCE_Rule_Read pattern.nIndex=1",
    ""
};

char *cmds_trunk[] =
{
    "pctool_gsw TRUNKING_Cfg_Set bIP_Src=1 bIP_Dst=1 bMAC_Src=1 bMAC_Dst=1",
    "pctool_gsw TRUNKING_Port_Cfg_Get nPortId=1",
    
    "pctool_gsw TRUNKING_Port_Cfg_Set nPortId=1 bAggregateEnable=0 nAggrPortId=2",
    "pctool_gsw TRUNKING_Port_Cfg_Get nPortId=1",

    "pctool_gsw TRUNKING_Port_Cfg_Set nPortId=1 bAggregateEnable=1 nAggrPortId=3",
    "pctool_gsw TRUNKING_Port_Cfg_Get nPortId=1",
    ""
};


char *cmds_portlk[] =
{
    "pctool_gsw PORT_LinkCfgSet "\
                                "nPortId=1 "\
                                "bDuplexForce=0 "\
                                "eDuplex=1 "\
                                "bSpeedForce=1 "\
                                "eSpeed=1000 "\
                                "bLinkForce=0 "\
                                "eLink=0 "\
                                "eMII_Mode=0 "\
                                "eMII_Type=0 "\
                                "eClkMode=0 "\
                                "bLPI=1",    

    "pctool_gsw PORT_LinkCfgGet "\
                                "nPortId=1",
    ""
};


char *cmds_mdio[] =
{
    "pctool_gsw MDIO_CfgGet ",
    "pctool_gsw MDIO_CfgSet "\
                            "nMDIO_Speed=10 "\
                            "bMDIO_Enable=1",
    "pctool_gsw MDIO_CfgGet " ,

    "pctool_gsw MDIO_DataRead nAddressDev=0 nAddressReg=0",
    "pctool_gsw MDIO_DataRead nAddressDev=0 nAddressReg=30",
    "pctool_gsw MDIO_DataRead nAddressDev=1 nAddressReg=30",
    "pctool_gsw MDIO_DataRead nAddressDev=2 nAddressReg=30",
    "pctool_gsw MDIO_DataRead nAddressDev=3 nAddressReg=30",
    "pctool_gsw MDIO_DataRead nAddressDev=4 nAddressReg=30",
    "pctool_gsw MDIO_DataRead nAddressDev=5 nAddressReg=30",
    "pctool_gsw MDIO_DataRead nAddressDev=6 nAddressReg=30",
    "pctool_gsw MDIO_DataRead nAddressDev=7 nAddressReg=30",
    "pctool_gsw MDIO_DataRead nAddressDev=8 nAddressReg=30",

    "pctool_gsw MDIO_DataRead nAddressDev=4 nAddressReg=9",
    "pctool_gsw MDIO_DataWrite nAddressDev=4 nAddressReg=9 nData=0x8300",
    "pctool_gsw MDIO_DataRead nAddressDev=4 nAddressReg=9",

    ""
};


char *cmds_mmd[] =
{
    "pctool_gsw MMD_DataRead nAddressDev=4 nAddressReg=0x00030014",
    "pctool_gsw MMD_DataRead nAddressDev=4 nAddressReg=0x001f01e0",
    "pctool_gsw MMD_DataRead nAddressDev=4 nAddressReg=0x001f01e8",
    "pctool_gsw MMD_DataWrite nAddressDev=4 nAddressReg=0x001f01e8 nData=0x0041",
    "pctool_gsw MMD_DataRead nAddressDev=4 nAddressReg=0x001f01e8",

    ""
};



char *cmds_portphy[] =
{
    "pctool_gsw PORT_PhyAddrGet nPortId=0",
    "pctool_gsw PORT_PhyQuery nPortId=0",
    "pctool_gsw PORT_LinkCfgGet nPortId=0",

    "pctool_gsw PORT_PhyAddrGet nPortId=4",
    "pctool_gsw PORT_PhyQuery nPortId=4",
    "pctool_gsw PORT_LinkCfgGet nPortId=4",

    "pctool_gsw PORT_PhyAddrGet nPortId=5",
    "pctool_gsw PORT_PhyQuery nPortId=5",
    "pctool_gsw PORT_LinkCfgGet nPortId=5",
    ""
};



char *cmds_gsw[] =
{
    "pctool_gsw VersionGet",
    "pctool_gsw Reset eReset=0",
    "pctool_gsw Reset eReset=1",
    "pctool_gsw Disable",
    "pctool_gsw Enable",

    "pctool_gsw RegisterSet nRegAddr=0xf708 nData=0x00FE",
    "pctool_gsw RegisterGet nRegAddr=0xf708",
    ""
};


char *cmds_irq[] =  /* no support */
{
    "pctool_gsw Irq_Get nPortId=1",
    "pctool_gsw Irq_MaskSet nPortId=1 eIrqSrc=2",
    "pctool_gsw Irq_StatusClear nPortId=1 eIrqSrc=2",
    ""
};


char *cmds_rgmii[] =
{
    "pctool_gsw PORT_RgmiiClkCfgSet nPortId=1 nDelayRx=1 nDelayTx=2",
    "pctool_gsw PORT_RgmiiClkCfgGet nPortId=1",
    ""
};

char *cmds_wol[] =
{
    "pctool_gsw Wol_CfgGSet nWolMAC=12:34:45:67:89:0A nWolPassword=12:34:45:67:89:EC bWolPasswordEnable=0",
    "pctool_gsw WOL_CfgGet",

    "pctool_gsw WOL_PortCfgSet nPortId=1 bWakeOnLAN_Enable=1",
    "pctool_gsw WOL_PortCfgGet nPortId=1",
    ""
};

char *cmds_ts[] =
{
    "pctool_gsw TIMESTAMP_TimerSet nSec=256 nNanoSec=439009703470 nFractionalNanoSec=87",
    "pctool_gsw TIMESTAMP_TimerGet",
    "pctool_gsw TIMESTAMP_PortRead nPortId=1",
    ""
};

char *cmds_stp[] =
{
    "pctool_gsw STP_BpduRuleSet eForwardPort=2 nForwardPortId=1",
    "pctool_gsw STP_BpduRuleGet",
    "pctool_gsw STP_PortCfgSet nPortId=1",
    ""
};

char *cmds_8021x[] =
{
    "pctool_gsw 8021X_EapolRuleSet eForwardPort=2 nForwardPortId=1",
    "pctool_gsw 8021X_EapolRuleGet",
    "pctool_gsw 8021X_PortCfgGet nPortId=1",
    "pctool_gsw 8021x_PortCfgSet nPortId=1 eState=0",
    ""
};

/*********************************************
* local Functions                           *
*********************************************/
static int Val_CmdLineToArgs(char *str, Y_S_GpyEthValidation_CmdLine *pCmdLine)
{
    int i;
	int j;	
	int k;	
    char *p;
    int len;

	if (str == NULL || pCmdLine == NULL)
    {
		return -1;
    }

	pCmdLine->argc = 0;
    p   = str;
    i   = 0;
    j   = 0;
    k   = 0;
    len = strlen(str);
//    printf("*+ %d %s +*\n", len, str); 
    while (len)
    {	
        pCmdLine->argb[i][j] = *(p+k);

        if (pCmdLine->argb[i][j] == ' ')
        {
            pCmdLine->argb[i][j] = '\0';
            j=0;
            i++;
            if (i > VAL_CMDLINE_ARGC_MAX)
            {
               printf("Val_CmdLineToArgs: Too many arguments. Max %d\n", VAL_CMDLINE_ARGC_MAX);
                return -1;
            }        
        }
        else
        {
            j++;
            if (j > VAL_CMDLINE_LEN_MAX)
            {
               printf("Val_CmdLineToArgs: Too long command line. Max %d\n", VAL_CMDLINE_LEN_MAX);
                return -1;
            } 
        }
        k++;
        len--;
    }

    pCmdLine->argc = i+1;
    pCmdLine->argb[i][j] = '\0';

    for (i = 0; i < pCmdLine->argc ; i++)
    {
       pCmdLine->argv[i] = &pCmdLine->argb[i][0]; 
    }

    return 0;
}


static int Val_CmdLinePrintArgs(Y_S_GpyEthValidation_CmdLine *pCmdLine)
{
    int i;
	if (pCmdLine == NULL)
    {
		return -1;
    }

    for (i = 0; i < pCmdLine->argc ; i++)
    {
       printf("%s ",&pCmdLine->argb[i][0]); 
    }
    printf("\n"); 
    return 0;
}


/*********************************************
* Test group  Functions                      *
*********************************************/
int Cmds_Check (char *str,  char *val_addr[], Y_S_GpyEthValidation_CmdLine *val_CmdLine)
{
    int ret;
    int i;

    if (str == NULL || val_addr ==  NULL ||val_CmdLine == NULL)
        return 0;


    printf("*** %s ***\n", str); 
    i=0;
    ret=0;
    while (strcmp(val_addr[i],"") != 0)
    {
//        printf("*- %d %s -*\n", i, val_addr[i]); 
        ret |= Val_CmdLineToArgs(val_addr[i], val_CmdLine);
        ret |= Val_CmdLinePrintArgs (val_CmdLine);
 
        val_CmdLine->argv[1] = transcode(val_CmdLine->argv[1]);
        ret = gsw_swcli_cmdProcessor(val_CmdLine->argc, val_CmdLine->argv);
 
        printf("\n"); 
        i++;
    };
    printf("***\n");
    return ret;
}


int Cmds_Check_rmon (void){
    return (Cmds_Check("Check rmon",  cmds_rmon, &Gval_CmdLine));
}

int Cmds_Check_mac (void){
    return (Cmds_Check("Check cmds_mac",  cmds_mac, &Gval_CmdLine));
}

int Cmds_Check_cfg (void){
    return (Cmds_Check("Check cmds_cfg",  cmds_cfg, &Gval_CmdLine));
}

int Cmds_Check_port (void){
    return (Cmds_Check("Check cmds_port",  cmds_port, &Gval_CmdLine));
}

int Cmds_Check_mon (void){
    return (Cmds_Check("Check cmds_mon",  cmds_mon, &Gval_CmdLine));
}

int Cmds_Check_cpu (void){
    return (Cmds_Check("Check cmds_cpu",  cmds_cpu, &Gval_CmdLine));
}

int Cmds_Check_vlan (void){
    return (Cmds_Check("Check cmds_vlan",  cmds_vlan, &Gval_CmdLine));
}

int Cmds_Check_svlan (void){
    return (Cmds_Check("Check cmds_svlan",  cmds_svlan, &Gval_CmdLine));
}

int Cmds_Check_qos (void){
    return (Cmds_Check("Check cmds_qos",  cmds_qos, &Gval_CmdLine));
}

int Cmds_Check_mcast (void){
    return (Cmds_Check("Check cmds_mcast",  cmds_mcast, &Gval_CmdLine));
}

int Cmds_Check_pce (void){
    return (Cmds_Check("Check cmds_pce",  cmds_pce, &Gval_CmdLine));
}

int Cmds_Check_trunk (void){
    return (Cmds_Check("Check cmds_trunk",  cmds_trunk, &Gval_CmdLine));
}

int Cmds_Check_portlk (void){
    return (Cmds_Check("Check cmds_portlk",  cmds_portlk, &Gval_CmdLine));
}

int Cmds_Check_mdio (void){
    return (Cmds_Check("Check cmds_mdio",  cmds_mdio, &Gval_CmdLine));
}

int Cmds_Check_portphy (void){
    return (Cmds_Check("Check cmds_portphy",  cmds_portphy, &Gval_CmdLine));
}

int Cmds_Check_mmd (void){
    return (Cmds_Check("Check cmds_mmd",  cmds_mmd, &Gval_CmdLine));
}

int Cmds_Check_gsw (void){
    return (Cmds_Check("Check cmds_gsw",  cmds_gsw, &Gval_CmdLine));
}

int Cmds_Check_irq (void){
    return (Cmds_Check("Check cmds_irq",  cmds_irq, &Gval_CmdLine));
}

int Cmds_Check_wol (void){
    return (Cmds_Check("Check cmds_wol",  cmds_wol, &Gval_CmdLine));
}

int Cmds_Check_stp (void){
    return (Cmds_Check("Check cmds_stp",  cmds_stp, &Gval_CmdLine));
}

int Cmds_Check_8021x (void){
    return (Cmds_Check("Check cmds_8021x",  cmds_8021x, &Gval_CmdLine));
}


int pctool_gsw_check (char* name)
{
    int ret = 0;

    if (name != NULL)
    {
        if (strcmp(name, "rmon") == 0){
            ret |= Cmds_Check_rmon ();
        }
        else if (strcmp(name, "mac") == 0){
            ret |= Cmds_Check_mac ();
        }
        else if (strcmp(name, "cfg") == 0){
            ret |= Cmds_Check_cfg ();
        }
        else if (strcmp(name, "port") == 0){
            ret |= Cmds_Check_port ();
        }
        else if (strcmp(name, "mon") == 0){
            ret |= Cmds_Check_mon ();
        }
        else if (strcmp(name, "cpu") == 0){
            ret |= Cmds_Check_cpu ();
        }
        else if (strcmp(name, "vlan") == 0){
            ret |= Cmds_Check_vlan ();
        }
        else if (strcmp(name, "svlan") == 0){
            ret |= Cmds_Check_svlan ();
        }
        else if (strcmp(name, "qos") == 0){
            ret |= Cmds_Check_qos ();
        }
        else if (strcmp(name, "mcast") == 0){
            ret |= Cmds_Check_mcast ();
        }
        else if (strcmp(name, "pce") == 0){
            ret |= Cmds_Check_pce ();
        }
        else if (strcmp(name, "trunk") == 0){
            ret |= Cmds_Check_trunk ();
        }
        else if (strcmp(name, "portlk") == 0){
            ret |= Cmds_Check_portlk ();
        }
        else if (strcmp(name, "mdio") == 0){
            ret |= Cmds_Check_mdio ();
        }
        else if (strcmp(name, "mmd") == 0){
            ret |= Cmds_Check_mmd ();
        }
        else if (strcmp(name, "portphy") == 0){
            ret |= Cmds_Check_portphy ();
        }
        else if (strcmp(name, "gsw") == 0){
            ret |= Cmds_Check_gsw ();
        }
        else if (strcmp(name, "irq") == 0){
            ret |= Cmds_Check_irq ();
        }
        else if (strcmp(name, "wol") == 0){
            ret |= Cmds_Check_wol ();
        }
        else if (strcmp(name, "stp") == 0){
            ret |= Cmds_Check_stp ();
        }
        else if (strcmp(name, "8021x") == 0){
            ret |= Cmds_Check_8021x ();
        }
        else if (strcmp(name, "all") == 0){
            ret |= Cmds_Check_rmon ();
            ret |= Cmds_Check_mac ();
            ret |= Cmds_Check_cfg ();
            ret |= Cmds_Check_port ();
            ret |= Cmds_Check_mon ();
            ret |= Cmds_Check_cpu ();
            ret |= Cmds_Check_vlan ();
            ret |= Cmds_Check_svlan ();
            ret |= Cmds_Check_qos ();
            ret |= Cmds_Check_mcast ();
            ret |= Cmds_Check_pce ();
            ret |= Cmds_Check_trunk ();
            ret |= Cmds_Check_portlk ();
            ret |= Cmds_Check_mdio ();
            ret |= Cmds_Check_mmd ();
            ret |= Cmds_Check_portphy ();
            ret |= Cmds_Check_gsw ();
// no support            ret |= Cmds_Check_irq ();
            ret |= Cmds_Check_wol ();
            ret |= Cmds_Check_stp ();
            ret |= Cmds_Check_8021x ();
        }

    }

    printf ("names: rmon mac cfg port mon cpu vlan svlan qos mcast pce trunk portlk mdio mmd portphy gsw irq wol stp 8021x all");
    return ret;
}

#endif /* VALIDATION */