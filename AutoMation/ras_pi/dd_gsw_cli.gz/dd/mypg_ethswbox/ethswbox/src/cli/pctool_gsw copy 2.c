/******************************************************************************

  Copyright (c) 2014 Lantiq Deutschland GmbH
  Copyright 2016, Intel Corporation.

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

******************************************************************************/

/**
   \file pctool_gsw.c
   
*/
#include "os_linux.h"

#include "conf_if.h" 
#include "plm_mdio.h"

#include "f2x_swapi_types.h"
#include "f2x_swapi_flow.h"
#include "gsw_sw_init.h"


int main_GSW_UTILITY(int argc, char **argv);

extern int gsw_swcli_cmdProcessor(int argc, char *argv[]);
extern int ethsw_swapi_register(void);
extern int ethsw_swapi_unregister(void);
extern GSW_API_HANDLE sdev;


u16 my_fapi_gsw_mdio_get_registers (GSW_API_HANDLE handle)
{
    GSW_MDIO_data_t prm;
    u16 i;
    u16 j;
    u16 ret;
	
    memset(&prm , 0, sizeof(GSW_MDIO_data_t));
	
    for (i = 0; i <96;i++)
    {
        printf ("0x%02X: ", i);
        for (j = 0; j <6;j++)
        {
			prm.nAddressDev = j;
			prm.nAddressReg = i;
		
			ret = gsw_api_kioctl(handle, GSW_MDIO_DATA_READ, (u32)&prm);
			if (ret != GSW_statusOk)
				printf ("error");		
            printf ("0x%04X ",prm.nData);
        }
        printf ("\n");         
    }
    return 0;
}


 
typedef struct mmd_register_t {
    const char  *name;
    u16          dev;
    u16          reg;        
} mmd_register_t;


mmd_register_t T_mmd_register [] =
{
    {"TIMESYNC_CAP:",   1, 0x1800},

    {"EEE_CTRL1 :",     3, 0},
    {"EEE_STAT1 :",     3, 1},
    {"EEE_CAP   :",     3, 0x0014},
    {"EEE_WAKERR:",     3, 0x0016},

    {"  EEE_AN_ADV:",   7, 0x003c},
    {"EEE_AN_LPADV:",   7, 0x003d},

    {"LEDCH:",          0x1f, 0x01e0},
    {"LEDCL:",          0x1f, 0x01e1},
    {"LED0H:",          0x1f, 0x01e2},
    {"LED1H:",          0x1f, 0x01e4},
    {"LED2H:",          0x1f, 0x01e6},
    {"LED3H:",          0x1f, 0x01e8},
    {"LED0L:",          0x1f, 0x01e3},
    {"LED1L:",          0x1f, 0x01e5},
    {"LED2L:",          0x1f, 0x01e7},
    {"LED3L:",          0x1f, 0x01e9},

    {"EEE_RXERR_LINK_FAIL_H:",       0x1f, 0x01ea},
    {"EEE_RXERR_LINK_FAIL_L:",       0x1f, 0x01eb},

    {"WOLCTRL:",        0x1f, 0x0781},
    {"WOLAD0 :",        0x1f, 0x0783},
    {"WOLAD1 :",        0x1f, 0x0784},
    {"WOLAD2 :",        0x1f, 0x0785},
    {"WOLAD3 :",        0x1f, 0x0786},
    {"WOLAD4 :",        0x1f, 0x0787},
    {"WOLAD5 :",        0x1f, 0x0788},
    {"WOLPW0 :",        0x1f, 0x0789},
    {"WOLPW1 :",        0x1f, 0x078a},
    {"WOLPW2 :",        0x1f, 0x078b},
    {"WOLPW3 :",        0x1f, 0x078c},
    {"WOLPW4 :",        0x1f, 0x078d},
    {"WOLPW5 :",        0x1f, 0x078e},

    {"PD_CTL :",        0x1f, 0x07fe},
    {"",                0, 0}
};

u16 my_fapi_gsw_mmd_get_registers (GSW_API_HANDLE handle)
{
    GSW_MMD_data_t prm;
    u16 i;
    u16 j;
    u16 ret;
    u32 addr;
	
    memset(&prm , 0, sizeof(GSW_MmdDataRead));
	
    i = 0;
    do
    {
 

        addr = T_mmd_register[i].dev;
        addr = addr << 16;
        addr |= T_mmd_register[i].reg;
        printf ("[0x%02X] %s : ", addr, T_mmd_register[i].name);
        fflush(stdout);

        for (j = 0; j <4;j++)
        {
			prm.nAddressDev = j;
			prm.nAddressReg = addr;
		
			ret = gsw_api_kioctl(handle, GSW_MMD_DATA_READ, (u32)&prm);
			if (ret != GSW_statusOk)
				printf ("error\n");	
                
            printf ("0x%04X ",prm.nAddressReg);
            printf ("0x%04X ",prm.nData);
            fflush(stdout);
        };
        printf ("\n");
        i++;         
    } while (T_mmd_register[i].name != "");
    return 0;
}



GSW_API_HANDLE MY_GSW_handle; // EMILIO
extern GSW_API_HANDLE sdev; // EMILIO
int main(int argc, char *argv[])
{
    int ret;
    GSW_API_HANDLE handle;
    GSW_HW_Init_t param;
    GSW_MDIO_data_t prm;

    /* Initialized Switch API */
    ret = ethsw_swapi_register();
    if (ret != 0) {
    printf("Failed in switch API initialization.\n");
    return 1;
    }

    /* Open switch device 0 */
    /* The namespace is defined by switch API. */
    /* There may not be device node /dev/switch/0, */
    /* unless Switch API is compiled as driver. */
    handle = gsw_api_kopen("/dev/switch/0");
    if (handle == (GSW_API_HANDLE)NULL) {
    ethsw_swapi_unregister();
    printf("Failed in openning switch device (/dev/switch/0).\n");
    return 1;
    }

    MY_GSW_handle = handle; // EMILIO
    sdev = handle;
    /* open underlying platform mdio link */
    ret = plm_mdio_open (GSW_IFID);
    plm_mdio_trace_off ();

 
#if 0
    ret = my_fapi_gsw_mmd_get_registers (handle);

 //   ret = my_fapi_gsw_mdio_get_registers (handle);


    /* Read MDIO registers */

    memset(&prm , 0, sizeof(GSW_MDIO_data_t));
    prm.nAddressDev = 0;
    prm.nAddressReg = 0x1e;
 
    ret = gsw_api_kioctl(handle, GSW_MDIO_DATA_READ, (u32)&prm);
    if (ret != GSW_statusOk) {
    printf("GSW_MDIO_DATA_READ error!");
    ret = 1;
    } else {
    printf("GSW_HW_INIT_NO ok!: nAddressDev = 0x%x  nAddressReg = 0x%x, nData = 0x%x", 
                prm.nAddressDev, prm.nAddressReg, prm.nData);
    ret = 0;
    }

#else
//   ret = gsw_swcli_cmdProcessor(argc, argv);

  ret = main_GSW_UTILITY(argc, argv);
#endif

    /* close underlying platform mdio link */
    ret = plm_mdio_close (GSW_IFID);

   return ret;         
}

#ifndef EMILIO
#define TOOL_VERSION		"1.0.1"

#define TEMP_BUFFRE_SIZE	16
#define SYS_BUFFER_SIZE		100
#define SERIAL_BUFFER_SIZE	256
#define CMD_LINE_BUFFER_SIZE	1000
#define MAX_PARAM		10

char *param_list1[MAX_PARAM];

#include<readline/readline.h>
#include<readline/history.h>


void system_readl (char* buffer, size_t sbuffer)
{
    char* pbuf;

    pbuf = readline (NULL);
    if (strlen(pbuf) > 0) {
        memcpy(buffer, pbuf, strlen(pbuf));
        add_history(pbuf);
        free(pbuf);
    }
}

 void remove_leading_whitespace(char **p, int *len)
{
	while (*len && ((**p == ' ') || (**p == '\r') || (**p == '\r'))) {
		(*p)++;
		(*len)--;
	}
}
int split_buffer(char *buffer, char *array[], int max_param_num)
{
	int i, set_copy = 0;
	int res = 0;
	int len;

	for (i = 0; i < max_param_num; i++)
		array[i] = NULL;

	if (!buffer)
		return 0;

	len = strlen(buffer);

	for (i = 0; i < max_param_num;) {
		remove_leading_whitespace(&buffer, &len);

		for (;
		     *buffer != ' ' && *buffer != '\0' && *buffer != '\r'
		     && *buffer != '\n' && *buffer != '\t'; buffer++, len--) {
			/*Find first valid charactor */
			set_copy = 1;

			if (!array[i])
				array[i] = buffer;
		}

		if (set_copy == 1) {
			i++;

			if (*buffer == '\0' || *buffer == '\r'
			    || *buffer == '\n') {
				*buffer = 0;
				break;
			}

			*buffer = 0;
			buffer++;
			len--;
			set_copy = 0;

		} else {
			if (*buffer == '\0' || *buffer == '\r'
			    || *buffer == '\n')
				break;

			buffer++;
			len--;
		}
	}

	res = i;

	return res;
}


char ReadLineBuffer[CMD_LINE_BUFFER_SIZE];
char *ArgvBuffer[2*MAX_PARAM];

typedef struct {
	char *name_pctool;
	char *name_gsw;
	char *description;
} PCTOOL_TranscodeCommandTable_t;

 PCTOOL_TranscodeCommandTable_t TransCmdTable[];

void print_transcode (void)
{
    PCTOOL_TranscodeCommandTable_t* p;
   p =  TransCmdTable;
    do
    {
       printf ("%s %s %s\n", p->name_pctool, p->name_gsw, p->description);
       p++; 
    }
    while (strcmp(p->name_pctool, "END") !=0);
}

char* transcode (char* str)
{
    PCTOOL_TranscodeCommandTable_t* p;
   p =  TransCmdTable;

    if (str != NULL)
    {
        do
        {
        if (strcmp(str, p->name_pctool) ==0)
            return p->name_gsw;  
        p++; 
        }
        while (strcmp(p->name_pctool, "END") !=0);
    }    
    return "";
}



int main_GSW_UTILITY(int argc, char **argv)
{
	int i = 0;
    int ret;

    printf("\n\n####################################################################");
    printf("\n###############  SWITCH UTILITY TOOL (Version: %s)  #############", TOOL_VERSION);
    printf("\n####################################################################\n\n");


	printf("\n\n####################################################################");
	printf("\n##################  ETC SWITCH UTILITY SHELL  ######################");
	printf("\n####################################################################\n\n");

	i = 0;
	while (1) {

		printf("\n\nShell : ");
		memset(ReadLineBuffer, 0, 1000);

        /* get the command with readline */
        system_readl (ReadLineBuffer, sizeof(ReadLineBuffer));
#if 0        
        ReadLineBuffer[0] = 'Q';
        ReadLineBuffer[1] = ' ';
        ReadLineBuffer[2] = '1';
        ReadLineBuffer[3] = ' ';
        ReadLineBuffer[4] = '2';
        ReadLineBuffer[5] = '\0';
#endif
//        printf ("readline: %s\n", ReadLineBuffer);
        argc = split_buffer(ReadLineBuffer, &ArgvBuffer[1] , MAX_PARAM);
        printf  ("split- %d:\n",argc);
        ArgvBuffer[0] = "pctool_gsw";
        for (i = 0; i<argc;i++)
        {
            printf  ("split- %d: argv[%d] = %s\n",argc,  i, ArgvBuffer[i]);
        }

 //       printf (" %s %s\n", ReadLineBuffer, ArgvBuffer);
#if 0 
        ArgvBuffer[0] = "pctool_gsw";
        ArgvBuffer[1] = transcode("QoS_ShaperCfgGet");
        ArgvBuffer[2] = "nRateShaperId=0";
        argc = 3;
#else
        ArgvBuffer[1] = transcode(ArgvBuffer[1]);
        ArgvBuffer[0] = "pctool_gsw";
        argc++;
#endif        
        for (i = 0; i<argc;i++)
        {
            printf ("argv[%d] = %s\n", i, ArgvBuffer[i]);
        }
 
  //      printf (" %s %s\n", ArgvBuffer[0], ArgvBuffer[1]);

        if ((strcmp(ArgvBuffer[0], "exit") == 0))
            return 1;
        ret = gsw_swcli_cmdProcessor(argc, ArgvBuffer);
   
	}/* End of while (1) loop */
}


/*
*
*
*/



 PCTOOL_TranscodeCommandTable_t TransCmdTable[] = {
		{"HW_Init"                       ,"GSW_HW_INIT", 						": Init Switch Hardware"},
        {"Switch_PortEnable"             ,"", 									": Enable Switch Ports"},
        {"RMON_Clear"                    ,"GSW_RMON_CLEAR", 						": Clear RMON counters per Port"},
        {"RMON_Get"                      ,"GSW_RMON_PORT_GET", 					": Get RMON counters per Port"},
        {"RMON_ExtendGet"                ,"GSW_RMON_EXTEND_GET",					": Get RMON extended counters per Port"},
        {"MAC_TableClear"                ,"GSW_MAC_TABLE_CLEAR",					": Clear MAC Table Entries"},
        {"MAC_TableEntryAdd"             ,"GSW_MAC_TABLE_ENTRY_ADD",				": Set MAC Table Entry"},
        {"MAC_TableEntryQuery"           ,"GSW_MAC_TABLE_ENTRY_QUERY",			": Get MAC Table Entry"},
        {"MAC_TableEntryRead"            ,"GSW_MAC_TABLE_ENTRY_READ",			": Read MAC Table Entries"},
        {"CfgGet"                        ,"GSW_CFG_GET",							": Get Global Configuration"},
        {"CfgSet"                        ,"GSW_CFG_SET",							": Set Global Configuration"},
        {"PortCfgGet"                    ,"GSW_CPU_PORT_CFG_GET",				": Get Port Configuration"},
        {"PortCfgSet"                    ,"GSW_CPU_PORT_CFG_SET",				": Set Port Configuration"},
        {"PortRedirectGet"               ,"GSW_PORT_REDIRECT_GET",				": Get Port Redirect Configuration"},
        {"PortRedirectSet"               ,"GSW_PORT_LINK_CFG_SET",				": Set Port Redirect Configuration"},
        {"MonitorPortCfgGet"             ,"GSW_MONITOR_PORT_CFG_GET",			": Get Monitor Port Configuration"},
        {"MonitorPortCfgSet"             ,"GSW_MONITOR_PORT_CFG_SET",			": Set Monitor Port Configuration"},
        {"CPU_PortCfgGet"                ,"GSW_CPU_PORT_CFG_GET",				": Get CPU Port Configuration"},
        {"CPU_PortCfgSet"                ,"GSW_CPU_PORT_CFG_SET",				": Set CPU Port Configuration"},
        {"VLAN_IdCreate"                 ,"GSW_VLAN_ID_CREATE",					": Create VLAN ID"},
        {"VLAN_IdDelete"                 ,"GSW_VLAN_ID_DELETE",					": Delete VLAN ID"},
        {"VLAN_IdGet"                    ,"GSW_VLAN_ID_GET",						": Get VLAN ID"},
        {"VLAN_Member_Init"              ,"GSW_VLAN_MEMBER_INIT",				": VLAN Membership Initilization"},
        {"VLAN_PortCfgGet"               ,"GSW_VLAN_PORT_CFG_GET",				": Get VLAN Port Configuration"},
        {"VLAN_PortCfgSet"               ,"GSW_VLAN_PORT_CFG_SET",				": Set VLAN Port Configuration"},
        {"VLAN_PortMemberAdd"            ,"GSW_VLAN_PORT_MEMBER_ADD",			": Add VLAN Port Member Configuration"},
        {"VLAN_PortMemberRemove"         ,"GSW_VLAN_PORT_MEMBER_REMOVE",			": Remove VLAN Port Member Configuration"},
        {"VLAN_PortMemberRead"           ,"GSW_VLAN_PORT_MEMBER_READ",			": Read VLAN Port Member Configuration"},
        {"VLAN_ReservedAdd"              ,"GSW_VLAN_RESERVED_ADD",				": Add VLAN Reserved Configuration"},
        {"VLAN_ReservedRemove"           ,"GSW_VLAN_RESERVED_REMOVE",			": Remove VLAN Reserved Configuration"},
        {"SVLAN_CfgGet"                  ,"GSW_SVLAN_CFG_GET",					": Get SVLAN Configuration"},
        {"SVLAN_CfgSet"                  ,"GSW_SVLAN_CFG_SET",					": Set SVLAN Configuration"},
        {"SVLAN_PortCfgGet"              ,"GSW_SVLAN_PORT_CFG_GET",				": Get SVLAN Port Configuration"},
        {"SVLAN_PortCfgSet"              ,"GSW_SVLAN_PORT_CFG_SET",				": Set SVLAN Port Configuration"},
        {"QoS_MeterCfgGet"               ,"GSW_QOS_METER_CFG_GET",				": Get QoS Meter Configuration"},
        {"QoS_MeterCfgSet"               ,"GSW_QOS_METER_CFG_SET",				": Set QoS Meter Configuration"},
        {"QoS_MeterPortAssign"           ,"GSW_QOS_METER_PORT_ASSIGN",			": Assign Meter Configuration to a Port"},
        {"QoS_MeterPortDeassign"         ,"GSW_QOS_METER_PORT_DEASSIGN",			": Deassign Meter Configuration to a Port"},
        {"QoS_ClassDSCP_Get"             ,"GSW_QOS_CLASS_DSCP_GET",				": Get QoS Class DSCP Mapping Configuration"},
        {"QoS_ClassDSCP_Set"             ,"GSW_QOS_CLASS_DSCP_SET",				": Set QoS Class DSCP Mapping Configuration"},
        {"QoS_ClassPCP_Get"              ,"GSW_QOS_CLASS_PCP_GET",				": Get QoS Class PCP Mapping Configuration"},
        {"QoS_ClassPCP_Set"              ,"GSW_QOS_CLASS_PCP_SET",				": Set QoS Class PCP Mapping Configuration"},
        {"QoS_DSCP_ClassGet"             ,"GSW_QOS_DSCP_CLASS_GET",				": Get QoS DSCP Class Mapping Configuration"},
        {"QoS_DSCP_ClassSet"             ,"GSW_QOS_DSCP_CLASS_SET",				": Set QoS DSCP Class Mapping Configuration"},
        {"QoS_DSCP_DropPrecedenceCfgGet" ,"GSW_QOS_DSCP_DROP_PRECEDENCE_CFG_GET",": Get QoS DSCP Drop Precedence Configuration"},
        {"QoS_DSCP_DropPrecedenceCfgSet" ,"GSW_QOS_DSCP_DROP_PRECEDENCE_CFG_SET",": Set QoS DSCP Drop Precedence Configuration"},
        {"QoS_FlowctrlCfgGet"            ,"GSW_QOS_FLOWCTRL_CFG_GET",			": Get QoS Flow Control Configuration"},
        {"QoS_FlowctrlCfgSet"            ,"GSW_QOS_FLOWCTRL_CFG_SET",			": Set QoS Flow Control Configuration"},
        {"QoS_FlowctrlPortCfgGet"        ,"GSW_QOS_FLOWCTRL_PORT_CFG_GET",		": Get QoS Flow Control Port Configuration"},
        {"QoS_FlowctrlPortCfgSet"        ,"GSW_QOS_FLOWCTRL_PORT_CFG_SET",		": Set QoS Flow Control Port Configuration"},
        {"QoS_PCP_ClassGet"              ,"GSW_QOS_CLASS_PCP_GET",				": Get QoS PCP Class Mapping Configuration"},
        {"QoS_PCP_ClassSet"              ,"GSW_QOS_CLASS_PCP_SET",				": Set QoS PCP Class Mapping Configuration"},
        {"QoS_PortCfgGet"                ,"GSW_PORT_CFG_GET",					": Get QoS Port Configuration"},
        {"QoS_PortCfgSet"                ,"GSW_PORT_CFG_SET",					": Set QoS Port Configuration"},
        {"QoS_PortRemarkingCfgGet"       ,"GSW_QOS_PORT_REMARKING_CFG_GET",		": Get QoS Port Remarking Configuration"},
        {"QoS_PortRemarkingCfgSet"       ,"GSW_QOS_PORT_REMARKING_CFG_SET",		": Set QoS Port Remarking Configuration"},
        {"QoS_QueueBufferReserveCfgGet"  ,"GSW_QOS_QUEUE_BUFFER_RESERVE_CFG_GET",": Get QoS Buffer Reservation Configuration"},
        {"QoS_QueueBufferReserveCfgSet"  ,"GSW_QOS_QUEUE_BUFFER_RESERVE_CFG_SET",": Set QoS Buffer Reservation Configuration"},
        {"QoS_QueuePortGet"              ,"GSW_QOS_QUEUE_PORT_GET",				": Get QoS Queue Port Configuration"},
        {"QoS_QueuePortSet"              ,"GSW_QOS_QUEUE_PORT_SET",				": Set QoS Queue Port Configuration"},
        {"QoS_SchedulerCfgGet"           ,"GSW_QOS_SCHEDULER_CFG_GET",			": Get QoS Scheduler Configuration"},
        {"QoS_SchedulerCfgSet"           ,"GSW_QOS_SCHEDULER_CFG_SET",			": Set QoS Scheduler Configuration"},
        {"QoS_ShaperCfgGet"              ,"GSW_QOS_SHAPER_CFG_GET",				": Get QoS Shaper Configuration"},
        {"QoS_ShaperCfgSet"              ,"GSW_QOS_SHAPER_CFG_SET",				": Set QoS Shaper Configuration"},
        {"QoS_ShaperQueueAssign"         ,"GSW_QOS_SHAPER_QUEUE_ASSIGN",			": Assign QoS Shaper Queue"},
        {"QoS_ShaperQueueDeassign"       ,"GSW_QOS_SHAPER_QUEUE_DEASSIGN",		": Deassign QoS Shaper Queue"},
        {"QoS_ShaperQueueGet"            ,"GSW_QOS_SHAPER_QUEUE_GET",			": Get QoS Shaper Queue"},
        {"QoS_StormCfgGet"               ,"GSW_QOS_STORM_CFG_GET",				": Get QoS Storm Configuration"},
        {"QoS_StormCfgSet"               ,"GSW_QOS_STORM_CFG_SET",				": Set QoS Storm Configuration"},
        {"QoS_SVLAN_ClassPCP_PortGet"    ,"GSW_QOS_SVLAN_CLASS_PCP_PORT_GET",	": Get QoS SVLAN Class PCP Port Configuration"},
        {"QoS_SVLAN_ClassPCP_PortSet"    ,"GSW_QOS_SVLAN_CLASS_PCP_PORT_SET",	": Set QoS SVLAN Class PCP Port Configuration"},
        {"QoS_SVLAN_PCP_ClassGet"        ,"GSW_QOS_SVLAN_PCP_CLASS_GET",			": Get QoS SVLAN PCP Class Configuration"},
        {"QoS_SVLAN_PCP_ClassSet"        ,"GSW_QOS_SVLAN_PCP_CLASS_SET",			": Set QoS SVLAN PCP Class Configuration"},
        {"QoS_WredCfgGet"                ,"GSW_QOS_WRED_CFG_GET",				": Get QoS WRED Configuration"},
        {"QoS_WredCfgSet"                ,"GSW_QOS_WRED_CFG_SET",				": Set QoS WRED Configuration"},
        {"QoS_WredPortCfgGet"            ,"GSW_QOS_WRED_PORT_CFG_GET",			": Get QoS WRED Port Configuration"},
        {"QoS_WredPortCfgSet"            ,"GSW_QOS_WRED_PORT_CFG_SET",			": Set QoS WRED Port Configuration"},
        {"QoS_WredQueueCfgGet"           ,"GSW_QOS_WRED_QUEUE_CFG_GET",			": Get QoS WRED Queue Configuration"},
        {"QoS_WredQueueCfgSet"           ,"GSW_QOS_WRED_QUEUE_CFG_SET",			": Set QoS WRED Queue Configuration"},
        {"MDIO_CfgGet"                   ,"GSW_MDIO_CFG_GET",					": Get MDIO Configuration"},
        {"MDIO_CfgSet"                   ,"GSW_MDIO_CFG_SET",					": Set MDIO Configuration"},
        {"MDIO_DataRead"                 ,"GSW_MDIO_DATA_READ",					": Read MDIO Data"},
        {"MDIO_DataWrite"                ,"GSW_MDIO_DATA_WRITE",					": Write MDIO Data"},
        {"MMD_DataRead"                  ,"GSW_MMD_DATA_READ",					": Read MMD Data"},
        {"MMD_DataWrite"                 ,"GSW_MMD_DATA_WRITE",					": Write MMD Data"},
        {"MULTICAST_Router_Port_Add"     ,"GSW_MULTICAST_ROUTER_PORT_ADD",		": Multicast router port add"},
        {"MULTICAST_Router_Port_Read"    ,"GSW_MULTICAST_ROUTER_PORT_READ",		": Multicast router port read"},
        {"MULTICAST_Router_Port_Remove"  ,"GSW_MULTICAST_ROUTER_PORT_REMOVE",	": Multicast router port remove"},
        {"MULTICAST_Snoop_Cfg_Get"       ,"GSW_MULTICAST_SNOOP_CFG_GET",			": Multicast snooping configuration get"},
        {"MULTICAST_Snoop_Cfg_Set"       ,"GSW_MULTICAST_SNOOP_CFG_SET",			": Multicast snooping configuration set"},
        {"MULTICAST_Table_Entry_Add"     ,"GSW_MULTICAST_TABLE_ENTRY_ADD",		": Multicast table entry add"},
        {"MULTICAST_Table_Entry_Read"    ,"GSW_MULTICAST_TABLE_ENTRY_READ",		": Multicast table entry read"},
        {"MULTICAST_Table_Entry_Remove"  ,"GSW_MULTICAST_TABLE_ENTRY_REMOVE",	": Multicast table entry remove"},
        {"PCE_Rule_Write"                ,"GSW_PCE_RULE_READ",					": PCE rule write"},
        {"PCE_Rule_Read"                 ,"GSW_PCE_RULE_READ",					": PCE rule read"},
        {"TRUNKING_Cfg_Get"              ,"GSW_TRUNKING_CFG_GET",				": Read out the current port trunking algorithm"},
        {"TRUNKING_Cfg_Set"              ,"GSW_TRUNKING_CFG_SET",				": Configure the current port trunking algorithm"},
        {"TRUNKING_Port_Cfg_Get"         ,"GSW_TRUNKING_PORT_CFG_GET",			": Read out the port trunking state of a given physical Ethernet switch port"},
        {"TRUNKING_Port_Cfg_Set"         ,"GSW_TRUNKING_PORT_CFG_SET",			": Configure the port trunking on two physical Ethernet switch ports"},
        {"PORT_LinkCfgSet"               ,"GSW_PORT_LINK_CFG_GET",				": Configure the port Link"},
        {"PORT_LinkCfgGet"               ,"GSW_PORT_LINK_CFG_SET",				": Read out the port Link status"},
        {"EnableDebug"                   ,"",									": Enable/Disable debug option"},
        {"help"                          ,"--help",									": Exit switch utility tool"},
        {"Exit"                          ,"exit",									": Exit switch utility tool"},
        {"END"                          ,"",									": END"}
};


#endif