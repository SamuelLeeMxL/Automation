/******************************************************************************

    Copyright 2021 Maxlinear

    SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only)

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.
******************************************************************************/

/**
   \file apps_tools_gpy.c
    This file implements tools for Easy GPY boards
        - apps_tools_gpy_lbb_recover_uart   

*/

/* ============================= */
/* Includes                      */
/* ============================= */

/* Access to GPYAPI driver  */
#include "os_linux.h"
#include "types.h"

 
#include "apps_tools_gpy.h"
#include "fapi_mdio.h" 

 

/**
    Implements apps_gpy_tool_lbb_recover_uart


   \param
      u16	if_id           phy Interface id
 

   \return
    >=0:  register value
    -1:   access error
    -2:   parameter error
*/

s32 apps_tools_gpy_recover_lbb_uart (u16 if_id)
{
    s32 ret;
    u16 port;
    u16 reg;
    u16 val;

    port = 31;

    printf ("APPS - Tools - EASY GPY211 LBB - recover UART.\n");

    /* Set SMDIO */
    printf ("Set SMDIO:\n");

    reg  = 31;
    val  = 0xf38b;
    ret = fapi_mdio_c22_write (if_id, port, reg, val);
    printf ("  - mdiow: port = %d reg = %d/0x%x val = 0x%x\n", port, reg, reg, val);

    reg = 0;
    val = fapi_mdio_c22_read (if_id, port, 31);
    printf ("  - mdior: port = %d reg = %d/0x%x val = 0x%x\n", port, reg, reg, val);

    printf ("\n");
    reg  = 31;
    val  = 0xf38c;
    ret = fapi_mdio_c22_write (if_id, port, reg, val);
    printf ("  - mdiow: port = %d reg = %d/0x%x val = 0x%x\n", port, reg, reg, val);

    reg = 0;
    val = fapi_mdio_c22_read (if_id, port, 31);
    printf ("  - mdior: port = %d reg = %d/0x%x val = 0x%x\n", port, reg, reg, val);
    printf ("\n");


    /* set GPIO pin MUX to UART  */
    printf ("Set GPIO pin MUX to UART:\n");
    reg  = 31;
    val  = 0xf38b;
    ret = fapi_mdio_c22_write (if_id, port, reg, val);
    printf ("  - mdiow: port = %d reg = %d/0x%x val = 0x%x\n", port, reg, reg, val);

    reg  = 0;
    val  = 3;
    ret = fapi_mdio_c22_write (if_id, port, reg, val);
    printf ("  - mdiow: port = %d reg = %d/0x%x val = 0x%x\n", port, reg, reg, val);
    printf ("\n");

    reg  = 31;
    val  = 0xf38c;
    ret = fapi_mdio_c22_write (if_id, port, reg, val);
    printf ("  - mdiow: port = %d reg = %d/0x%x val = 0x%x\n", port, reg, reg, val);

    reg  = 0;
    val  = 3;
    ret = fapi_mdio_c22_write (if_id, port, reg, val);
    printf ("  - mdiow: port = %d reg = %d/0x%x val = 0x%x\n", port, reg, reg, val);
    printf ("DONE.\n");

    return OS_SUCCESS;
}
