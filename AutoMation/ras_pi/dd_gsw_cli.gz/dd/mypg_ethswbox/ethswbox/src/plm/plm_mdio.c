/******************************************************************************

  Copyright (c) 2014 Lantiq Deutschland GmbH
  Copyright 2016, Intel Corporation.

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

******************************************************************************/
/**
   \file plm_mdio.c
   This file implements the PLM (Platform) MDIO access.
   
   
*/


/* ============================= */
/* Includes                      */
/* ============================= */

#include "os_linux.h"
#include "conf_if.h" 
#include "plm_mdio.h"

#include "bcm2835.h"
#include "mdio.h"



/* ============================= */
/* Global function definition    */
/* ============================= */

int plm_mdio_open(u16 if_id)
{
    u8 clk_pin;
    u8 data_pin;

    switch (if_id)
    {
        case GPY_IFID:
        /* GPY MDIO pins */
        clk_pin  = RPI4B_GPIO_MDIO_CLK_PIN;
        data_pin = RPI4B_GPIO_MDIO_DATA_PIN;
        break;

        case GSW_IFID:
        /* GSW MDIO pins */
        clk_pin  = RPI4B_GPIO_GSW_MDIO_CLK_PIN;
        data_pin = RPI4B_GPIO_GSW_MDIO_DATA_PIN;
        break;

        default:
        return 0;
        break;
    }

    /* Initialize the BCM mdio library
    */  
    bcm2835_init (RPI4B_GPIO_MEM);
    (void)mdio_open(clk_pin, data_pin);
    return 0;
}

int plm_mdio_close( u16 if_id)
{
    u8 clk_pin;
    u8 data_pin;

    switch (if_id)
    {
        case GPY_IFID:
        /* GPY MDIO pins */
        clk_pin  = RPI4B_GPIO_MDIO_CLK_PIN;
        data_pin = RPI4B_GPIO_MDIO_DATA_PIN;
        break;

        case GSW_IFID:
        /* GSW MDIO pins */
        clk_pin  = RPI4B_GPIO_GSW_MDIO_CLK_PIN;
        data_pin = RPI4B_GPIO_GSW_MDIO_DATA_PIN;
        break;

        default:
        return 0;
        break;
    }

    /* Close BRCM mdio library
    */  
    (void)mdio_close(clk_pin, data_pin);
    return 0;
}


s32 plm_mdio_read (u16 if_id, u16 port, u16 reg)
{
    u8 clk_pin;
    u8 data_pin;
    u16 val = 0;

    switch (if_id)
    {
        case GPY_IFID:
        /* GPY MDIO pins */
        clk_pin  = RPI4B_GPIO_MDIO_CLK_PIN;
        data_pin = RPI4B_GPIO_MDIO_DATA_PIN;
        break;

        case GSW_IFID:
        /* GSW MDIO pins */
        clk_pin  = RPI4B_GPIO_GSW_MDIO_CLK_PIN;
        data_pin = RPI4B_GPIO_GSW_MDIO_DATA_PIN;
        break;
    }

    /* read register thru mdio library */
	val =  mdio_c22_read (clk_pin, data_pin, port, reg);

    if (plm_mdio_trace_get ())
    {   
      printf ("plm_mdio_read: clk_pin = %d, data_pin = %d, port = %d, reg = 0x%x val = 0x%x\n",
                                clk_pin, data_pin, port, reg, val); 
    }

    return val;
}

s32 plm_mdio_write (u16 if_id, u16 port, u16 reg, u16 val)
{
    u8 clk_pin;
    u8 data_pin;
    int ret;

    switch (if_id)
    {
        case GPY_IFID:
        /* GPY MDIO pins */
        clk_pin  = RPI4B_GPIO_MDIO_CLK_PIN;
        data_pin = RPI4B_GPIO_MDIO_DATA_PIN;
        break;

        case GSW_IFID:
        /* GSW MDIO pins */
        clk_pin  = RPI4B_GPIO_GSW_MDIO_CLK_PIN;
        data_pin = RPI4B_GPIO_GSW_MDIO_DATA_PIN;
        break;
    }
 
    /* write register thru mdio library */
	ret =  mdio_c22_write (clk_pin, data_pin, port,  reg, val);

    if (plm_mdio_trace_get ())
    {  
        printf ("plm_mdio_write: clk_pin = %d, data_pin = %d, port = %d, reg = 0x%x val = 0x%x\n",
                                clk_pin, data_pin, port, reg, val);
    }                            

    return ret;
}

static u16 Plm_Mdio_Trace_Flag = 0x1234; 
void plm_mdio_trace_on (void)
{
    Plm_Mdio_Trace_Flag = 0x1234;
}

void plm_mdio_trace_off (void)
{
    Plm_Mdio_Trace_Flag = 0;
}

u16 plm_mdio_trace_get (void)
{
    return Plm_Mdio_Trace_Flag;
}
