/******************************************************************************

    Copyright 2021 Maxlinear

    SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only)

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.
******************************************************************************/

/**
   \file fapi_gsw_mdio.c
   This file implements Access to GSWxxx thru MDIO. 

*/

/* ============================= */
/* Includes                      */
/* ============================= */


#include "os_linux.h"
#include "conf_if.h" 
#include "fapi_gsw_mdio.h"

#include "plm_mdio.h"

 

/**
    Implements MDIO Register Read function Clause 22

   \param
      u16	if_id           phy Interface id
      u16   port            phy addr        
	  u16 	reg             phy register

   \return
    >=0:  register value
    -1:   access error
    -2:   parameter error
*/
s32 fapi_gsw_mdio_c22_read (u16 if_id, u16 port, u16 reg)
{
    u16 val = 0;
    
    if ((port > 31) || (reg > 65535))
    {
        return -2;
    }

    /* read the register */
	val =  plm_mdio_read (if_id, port, reg);

	return val;
}



/**
    Implements SMDIO Register Write function Clause 22


   \param
      u16	if_id           phy Interface id
      u16   port            phy addr        
	  u16 	reg             phy register
	  u16 	val             phy value to write

   \return
    >=0:  register value
    -1:   access error
    -2:   parameter error
*/
s32 fapi_gsw_mdio_c22_write (u16 if_id, u16 port,  u16 reg, u16 val)
{
    s32 ret = 0;
    
    if ((port > 31) || (reg > 65535))
    {
        return -2;
    }

    /* write the register value */
	ret =  plm_mdio_write (if_id, port,  reg, val);
 
	return ret;
}


/**
    Implements GSW Register Read Access.


   \param
      u16	if_id           GSW Interface id
	  u16 	gsw_addr        GSW Register Offset Address 

   \return
   	u16 	val             GSW Register Value
    >=0:  register value
    -1:   access error
    -2:   parameter error
*/
u16 fapi_gsw_reg_read (u16 if_id, u16 gsw_addr)
{
    u16 val;

    fapi_gsw_mdio_c22_write (if_id, GSW_SMDIO_ADDR, GSW_SMDIO_TARGET_BASE, gsw_addr);
    val = fapi_gsw_mdio_c22_read (if_id, GSW_SMDIO_ADDR, GSW_SMDIO_TARGET_OFFSET);
    return val;
}


/**
    Implements GSW Register Write Access.


   \param
      u16	if_id           GSW Interface id
	  u16 	gsw_addr        GSW Register Offset Address 
	  u16 	val             GSW Register Value to write

   \return
   	u16 	val             GSW Register Value
    >=0:  register value
    -1:   access error
    -2:   parameter error
*/
u16 fapi_gsw_reg_write (u16 if_id, u16 gsw_addr, u16 val)
{

    fapi_gsw_mdio_c22_write (if_id, GSW_SMDIO_ADDR, GSW_SMDIO_TARGET_BASE, gsw_addr);
    val = fapi_gsw_mdio_c22_write (if_id, GSW_SMDIO_ADDR, GSW_SMDIO_TARGET_OFFSET, val);
    return val;
}

//
//
//  MDIO / MMD
//
//

#include "gsw_sw_init.h"

s32 gsw_rreg_rd(u16 if_id, u16 Offset, u16 Shift, u16 Size)
{
    s32 ret = 0;
	u16 ro, rv = 0, mask;
    u16 val;

	if ((Offset & 0xD000) == 0xD000)
		ro = Offset;
	else
		ro = (Offset | 0xE000);
#if defined(SMDIO_INTERFACE) && SMDIO_INTERFACE
//	s = smdio_reg_wr(pd->mdio_id, pd->mdio_addr, SMDIO_WRADDR, ro); 
//	s = smdio_reg_rd(pd->mdio_id, pd->mdio_addr, SMDIO_RDADDR, &rv);
	    
/*    if (s != GSW_statusOk)
		return s;
*/
     rv = fapi_gsw_reg_read (if_id, ro);

#endif /* SMDIO_INTERFACE */
	mask = (1 << Size) - 1 ;
	rv = (rv >> Shift);
	val  = (rv & mask);
	return val;
}

s32 gsw_rreg_wr(u16 if_id, u16 Offset, u16 Shift, u16 Size, u32 value)
{
    s32 ret = 0;

	u16 ro, rv = 0, mask;

	if ((Offset & 0xD000) == 0xD000)
		ro = Offset;
	else
		ro = (Offset | 0xE000);

	if (Size != 16) {
	
    //   s = smdio_reg_wr(pd->mdio_id, pd->mdio_addr, SMDIO_WRADDR, ro);
    //	s = smdio_reg_rd(pd->mdio_id, pd->mdio_addr, SMDIO_RDADDR, &rv);
	//	if (s != GSW_statusOk)
	//		return s;
        rv = fapi_gsw_reg_read (if_id, ro);

		mask = (1 << Size) - 1;
		mask = (mask << Shift);
		value = ((value << Shift) & mask);
		value = ((rv & ~mask) | value);
 
//		s = smdio_reg_wr(pd->mdio_id, pd->mdio_addr, SMDIO_WRADDR, ro);
//		if (s != GSW_statusOk)
//			return s;
//	    s = smdio_reg_wr(pd->mdio_id, pd->mdio_addr, SMDIO_RDADDR, value);
//	    if (s != GSW_statusOk)
//		    return s;

        ret = fapi_gsw_reg_write (if_id, ro, value);

    }
    else {
//          s = smdio_reg_wr(pd->mdio_id, pd->mdio_addr, SMDIO_WRADDR, ro);
//	        s = smdio_reg_wr(pd->mdio_id, pd->mdio_addr, SMDIO_RDADDR, value);	
            ret = fapi_gsw_reg_write (if_id, ro, value);
    }

	return ret;
}












//
// MDIO access
//

#if 0
GSW_return_t GSW_MDIO_DataRead
#endif

u16 fapi_gsw_mdio_dataread(u16 if_id,u16 port, u16 dev, u16 reg)
{
    u16 ret;
    u16 val;
	ur r;

	r = ((0x2 << 10) | ((dev & 0x1F) << 5)
		| (reg & 0x1F));

    ret = fapi_gsw_reg_write (if_id,  MMDIO_CTRL_MBUSY_OFFSET, r);
    val = fapi_gsw_reg_read (if_id,  MMDIO_READ_RDATA_OFFSET);

	return val;
}


#if 0
GSW_return_t GSW_MDIO_DataWrite
#endif
u16 fapi_gsw_mdio_datawrite(u16 if_id,u16 port, u16 dev, u16 reg, u16 val)
{
    u16 ret;
	ur r;
 
	r = val & 0xFFFF;

     ret = fapi_gsw_reg_write (if_id,  MMDIO_WRITE_WDATA_OFFSET, r);

	r = ((0x1 << 10) | (((u8)dev & 0x1F) << 5)
		| ((u8)reg & 0x1F));

     ret = fapi_gsw_reg_write (if_id,  MMDIO_CTRL_MBUSY_OFFSET, r);

	return ret;
}


//
// MMD access
//

#if 0
GSW_return_t GSW_MmdDataRead(void *pdev,
	GSW_MMD_data_t *parm)
{
	GSW_return_t s;
	GSW_MDIO_data_t md;
	u8 found = 0, dev, pi;
	ur pn, pa, mr;
	ethsw_api_dev_t *pd = (ethsw_api_dev_t *)pdev;
	SWAPI_ASSERT(pd == NULL);
	s = gsw_reg_rd(pdev,
		ETHSW_CAP_1_PPORTS_OFFSET,
		ETHSW_CAP_1_PPORTS_SHIFT,
		ETHSW_CAP_1_PPORTS_SIZE, &pn);
	if (s != GSW_statusOk)
		return s;

	for (pi = 0; pi < (pn - 1); pi++) {
		s = gsw_reg_rd(pdev,
			(PHY_ADDR_0_ADDR_OFFSET - pi),
			PHY_ADDR_0_ADDR_SHIFT,
			PHY_ADDR_0_ADDR_SIZE, &pa);
		if (s != GSW_statusOk)
			return s;
		if (pa == parm->nAddressDev) {
			found = 1;
			break;
		}
	}
	if (found) {
		s = gsw_reg_rd(pdev,
			MMDC_CFG_0_PEN_ALL_OFFSET,
			MMDC_CFG_0_PEN_ALL_SHIFT,
			MMDC_CFG_0_PEN_ALL_SIZE, &mr);
		if (s != GSW_statusOk)
			return s;
		mr &= ~(1 << pi);
		dev = ((parm->nAddressReg >> 16) & 0x1F);
		s = gsw_reg_wr(pdev,
			MMDC_CFG_0_PEN_ALL_OFFSET,
			MMDC_CFG_0_PEN_ALL_SHIFT,
			MMDC_CFG_0_PEN_ALL_SIZE, mr);
		if (s != GSW_statusOk)
			return s;
		md.nAddressDev = parm->nAddressDev;
		md.nAddressReg = 0xd;
		md.nData = dev;
		s = GSW_MDIO_DataWrite(pdev, &md);
		if (s != GSW_statusOk)
			return s;

		md.nAddressDev = parm->nAddressDev;
		md.nAddressReg = 0xe;
		md.nData = parm->nAddressReg & 0xFFFF;
		s = GSW_MDIO_DataWrite(pdev, &md);
		if (s != GSW_statusOk)
			return s;

		md.nAddressDev = parm->nAddressDev;
		md.nAddressReg = 0xd;
		md.nData = ((0x4000) | dev);
		s = GSW_MDIO_DataWrite(pdev, &md);
		if (s != GSW_statusOk)
			return s;

		md.nAddressDev = parm->nAddressDev;
		md.nAddressReg = 0xe;
		s = GSW_MDIO_DataRead(pdev, &md);
		if (s != GSW_statusOk)
			return s;
		parm->nData = md.nData;

		mr |= (1 << pi);
		s = gsw_reg_wr(pdev,
			MMDC_CFG_0_PEN_ALL_OFFSET,
			MMDC_CFG_0_PEN_ALL_SHIFT,
			MMDC_CFG_0_PEN_ALL_SIZE, mr);
		if (s != GSW_statusOk)
			return s;
	} else {
		return GSW_statusNoSupport;
	}
	return GSW_statusOk;
}
#endif

#ifndef EMILIO





u16 fapi_gsw_mmd_dataread(u16 if_id, u16 port, u16 dev, u16 reg)
{
    u16 ret;
    u16 val;
	ur r;

	u8 found = 0, ddev, pi;
	ur pn, pa, mr;

    u8 md_dev, md_reg, md_data;


    md_dev  = dev;
    md_reg  = 0xd;
    md_data = reg;
    printf ("0: port = %d md_dev = 0x%x  md_reg = 0x%x md_data = 0x%x\n", port, md_dev, md_reg, md_data);

    ret =  fapi_gsw_mdio_datawrite(if_id, port, md_dev, md_reg, md_data);


    md_dev = dev;
    md_reg = 0x0e;
    md_data = reg;
    printf ("1: md_dev = 0x%x  md_reg = 0x%x md_data = 0x%x\n", md_dev, md_reg, md_data);

    ret =  fapi_gsw_mdio_datawrite(if_id, port, md_dev, md_reg, md_data);



    md_dev = dev;
    md_reg = 0x0d;
    md_data = ((0x4000) | dev);
    printf ("2: md_dev = 0x%x  md_reg = 0x%x md_data = 0x%x\n", md_dev, md_reg, md_data);

    ret =  fapi_gsw_mdio_datawrite(if_id, port, md_dev, md_reg, md_data);





    md_dev = dev;
    md_reg = 0x0e;
    printf ("3: md_dev = 0x%x  md_reg = 0x%x md_data = 0x%x\n", md_dev, md_reg, md_data);

    val = fapi_gsw_mdio_dataread(if_id, port, md_dev, md_reg);
                

	return val;
}













#else
u16 fapi_gsw_mmd_dataread(u16 if_id, u16 port, u16 dev, u16 reg)
{
    u16 ret;
    u16 val;
	ur r;

	u8 found = 0, ddev, pi;
	ur pn, pa, mr;

    u8 md_dev, md_reg, md_data;

/*
	s = gsw_reg_rd(pdev,
		ETHSW_CAP_1_PPORTS_OFFSET,
		ETHSW_CAP_1_PPORTS_SHIFT,
		ETHSW_CAP_1_PPORTS_SIZE, &pn);
*/

#ifdef EMILIO
    pn = gsw_rreg_rd (if_id,  ETHSW_CAP_1_PPORTS_OFFSET,
		              ETHSW_CAP_1_PPORTS_SHIFT,
		              ETHSW_CAP_1_PPORTS_SIZE);

	for (pi = 0; pi < (pn - 1); pi++) {

/*
		s = gsw_reg_rd(pdev,
			(PHY_ADDR_0_ADDR_OFFSET - pi),
			PHY_ADDR_0_ADDR_SHIFT,
			PHY_ADDR_0_ADDR_SIZE, &pa);
*/
    pa = gsw_rreg_rd (if_id,  (PHY_ADDR_0_ADDR_OFFSET - pi),
			        PHY_ADDR_0_ADDR_SHIFT,
			        PHY_ADDR_0_ADDR_SIZE);            
 
		if (pa == port) {
			found = 1;
			break;
		}
	}
#else
    pa = port;
    found = 1;
#endif


	if (found) {
#if 0
        /*
		s = gsw_reg_rd(pdev,
			MMDC_CFG_0_PEN_ALL_OFFSET,
			MMDC_CFG_0_PEN_ALL_SHIFT,
			MMDC_CFG_0_PEN_ALL_SIZE, &mr);
		if (s != GSW_statusOk)
			return s;
        */
        mr = gsw_rreg_rd (if_id, MMDC_CFG_0_PEN_ALL_OFFSET,
			            MMDC_CFG_0_PEN_ALL_SHIFT,
			            MMDC_CFG_0_PEN_ALL_SIZE);


		mr &= ~(1 << pi);
	//	ddev = ((reg >> 16) & 0x1F);
        ddev = dev;
        /*
		s = gsw_reg_wr(pdev,
			MMDC_CFG_0_PEN_ALL_OFFSET,
			MMDC_CFG_0_PEN_ALL_SHIFT,
			MMDC_CFG_0_PEN_ALL_SIZE, mr);
		if (s != GSW_statusOk)
			return s;
        */
        ret = gsw_rreg_wr (if_id, MMDC_CFG_0_PEN_ALL_OFFSET,
			             MMDC_CFG_0_PEN_ALL_SHIFT,
			             MMDC_CFG_0_PEN_ALL_SIZE, mr);
#endif
		md_dev = dev;
		md_reg = 0xd;
		md_data = ddev;

        /*
		s = GSW_MDIO_DataWrite(pdev, &md);
		if (s != GSW_statusOk)
			return s;
        */ 
        ret =  fapi_gsw_mdio_datawrite(if_id, port, md_dev, md_reg, md_data);

/*
		md.nAddressDev = parm->nAddressDev;
		md.nAddressReg = 0xe;
		md.nData = parm->nAddressReg & 0xFFFF;

		s = GSW_MDIO_DataWrite(pdev, &md);
		if (s != GSW_statusOk)
			return s;
*/

		md_dev = dev;
		md_reg = 0x0e;
		md_data = reg;
        ret =  fapi_gsw_mdio_datawrite(if_id, port, md_dev, md_reg, md_data);

/*
		md.nAddressDev = parm->nAddressDev;
		md.nAddressReg = 0xd;
		md.nData = ((0x4000) | dev);
		s = GSW_MDIO_DataWrite(pdev, &md);
		if (s != GSW_statusOk)
			return s;
*/
		md_dev = dev;
		md_reg = 0x0d;
		md_data = ((0x4000) | ddev);
        ret =  fapi_gsw_mdio_datawrite(if_id, port, md_dev, md_reg, md_data);



/*
		md.nAddressDev = parm->nAddressDev;
		md.nAddressReg = 0xe;
		s = GSW_MDIO_DataRead(pdev, &md);
		if (s != GSW_statusOk)
			return s;
		parm->nData = md.nData;
*/
		md_dev = dev;
		md_reg = 0x0e;
        val = fapi_gsw_mdio_dataread(if_id, port, md_dev, md_reg);


#if 0
		mr |= (1 << pi);
        /*
		s = gsw_reg_wr(pdev,
			MMDC_CFG_0_PEN_ALL_OFFSET,
			MMDC_CFG_0_PEN_ALL_SHIFT,
			MMDC_CFG_0_PEN_ALL_SIZE, mr);
		if (s != GSW_statusOk)
			return s;
        */
        ret = gsw_rreg_wr (if_id, MMDC_CFG_0_PEN_ALL_OFFSET,
                    MMDC_CFG_0_PEN_ALL_SHIFT,
                    MMDC_CFG_0_PEN_ALL_SIZE, mr);
#endif                    
	}

	return val;
}
#endif /* EMILIO */

#if 0
GSW_return_t GSW_MmdDataWrite(void *pdev,
	GSW_MMD_data_t *parm)
{
	GSW_return_t s;
	GSW_MDIO_data_t md;
	u32 found = 0, pn, pa, mr, dev, pi;
	ethsw_api_dev_t *pd = (ethsw_api_dev_t *)pdev;
	SWAPI_ASSERT(pd == NULL);
	s = gsw_reg_rd(pdev,
		ETHSW_CAP_1_PPORTS_OFFSET,
		ETHSW_CAP_1_PPORTS_SHIFT,
		ETHSW_CAP_1_PPORTS_SIZE, &pn);
	if (s != GSW_statusOk)
		return s;
	for (pi = 0; pi < pn; pi++) {
		s = gsw_reg_rd(pdev,
			(PHY_ADDR_0_ADDR_OFFSET - pi),
			PHY_ADDR_0_ADDR_SHIFT,
			PHY_ADDR_0_ADDR_SIZE, &pa);
		if (s != GSW_statusOk)
			return s;
		if (pa == parm->nAddressDev) {
			found = 1;
			break;
		}
	}
	if (found) {
		s = gsw_reg_rd(pdev,
			MMDC_CFG_0_PEN_ALL_OFFSET,
			MMDC_CFG_0_PEN_ALL_SHIFT,
			MMDC_CFG_0_PEN_ALL_SIZE, &mr);
		if (s != GSW_statusOk)
			return s;
		mr &= ~(1 << pi);
		dev = ((parm->nAddressReg >> 16) & 0x1F);
		s = gsw_reg_wr(pdev,
			MMDC_CFG_0_PEN_ALL_OFFSET,
			MMDC_CFG_0_PEN_ALL_SHIFT,
			MMDC_CFG_0_PEN_ALL_SIZE, mr);
		if (s != GSW_statusOk)
			return s;
		md.nAddressDev = parm->nAddressDev;
		md.nAddressReg = 0xd;
		md.nData = dev;
		s = GSW_MDIO_DataWrite(pdev, &md);
		if (s != GSW_statusOk)
			return s;

		md.nAddressDev = parm->nAddressDev;
		md.nAddressReg = 0xe;
		md.nData = parm->nAddressReg & 0xFFFF;
		s = GSW_MDIO_DataWrite(pdev, &md);
		if (s != GSW_statusOk)
			return s;

		md.nAddressDev = parm->nAddressDev;
		md.nAddressReg = 0xd;
		md.nData = ((0x4000) | dev);
		s = GSW_MDIO_DataWrite(pdev, &md);
		if (s != GSW_statusOk)
			return s;

		md.nAddressDev = parm->nAddressDev;
		md.nAddressReg = 0xe;
		md.nData = parm->nData;
		s = GSW_MDIO_DataWrite(pdev, &md);
		if (s != GSW_statusOk)
			return s;
		mr |= (1 << pi);
		s = gsw_reg_wr(pdev,
			MMDC_CFG_0_PEN_ALL_OFFSET,
			MMDC_CFG_0_PEN_ALL_SHIFT,
			MMDC_CFG_0_PEN_ALL_SIZE, mr);
		if (s != GSW_statusOk)
			return s;
	} else {
		return GSW_statusNoSupport;
	}
	return GSW_statusOk;
}
#endif






//
//
//




u16 fapi_gsw_mdio_get_registers (u16 if_id,  u16 port, gsw_mdio_t *p)
{
    plm_mdio_trace_off ();

    if (p)
    {
        u16 i;
        u16 j;

        for (i = 0; i <32;i++)
        {
            printf ("0x%02X: ", i);
            for (j = 0; j <6;j++)
            {
                p->regs[i] = fapi_gsw_mdio_dataread(if_id, 0, j, i);              
                printf ("0x%04X ",p->regs[i]);
            }
            printf ("\n");         
        }
    }

    plm_mdio_trace_on ();
    return 0;
}




#if 0
// dump GSW registers 


typedef struct gsw_register_t {
    const char  *name;
    u16          reg;        
} gsw_register_t;


gsw_register_t T_gsw_register_gphy [] =
{
    {"GPY0_FCR:", 			0},
    {"GPY0_CFG:", 			1},
    {"GPY0_AFETX_CTRL:", 	2},
    {"GPY0_FCR_SD:", 		3},
    {"GPY0_GPS:", 			8},
    {"GPY0_BFDEV:", 		9},
    {"GPY0_STATUS:", 		15},
    {"",                0, 0}
};


gsw_register_t T_gsw_register_rmii [] =
{
    {"MII_CFG_5:", 			0xf100},
    {"PCDU_5:", 			0xf101},
    {"RTXB_CTL:5:", 		0xf120},


    {"MMI_MUX_CFG:", 			0xf130},
    {"PKT_INS:", 				0xf140},
    {"PKT_EXT_READ:", 			0xf141},
    {"PKT_EXT_CMD:", 			0xf142},
	
    {"PCDU5_TX_KVAL:", 			0xf160},
    {"PCDU5_TX_MREQ:", 			0xf161},
    {"PCDU5_TX_MBLK:", 			0xf162},
    {"PCDU5_TX_DELLEN:", 		0xf163},

    {"PCDU5_RX_KVAL:", 			0xf168},
    {"PCDU5_RX_MREQ:", 			0xf169},
    {"PCDU5_RX_MBLK:", 			0xf16a},
    {"PCDU5_RX_DELLEN:", 		0xf16b},
    {"",                0, 0}
};

gsw_register_t T_gsw_register_mdio_master [] =
{
    {"GSWIP_CFG:", 		0xf400},
    {"MMDIO_WRITE:",	0xf40A},
    {"MMDC_CFG_1:",		0xf40C},

    {"PHY_ADDR_5:",		0xf410},
    {"PHY_ADDR_2:",		0xf413},
    {"PHY_ADDR_1:",		0xf414},
    {"PHY_ADDR_0:",		0xf415},

    {"MMDIO_STAT_0:",	0xf4016},
    {"ANEG_EEE_0:",		0xf401d},
    {"MMDIO_CTRL:",		0xf408},
    {"MMDIO_READ:",		0xf409},
    {"MMDC_CFG_0:",		0xf40b},

    {"PHY_ADDR_4:",		0xf411},
    {"PHY_ADDR3:",		0xf412},

    {"MMDIO_STAT_1:",	0xf417},
    {"MMDIO_STAT_2:",	0xf418},
    {"MMDIO_STAT_3:",	0xf419},
    {"MMDIO_STAT_5:",	0xf41b},

    {"ANEG_EEE_1:",		0xf41e},
    {"ANEG_EEE_2:",		0xf41f},
    {"ANEG_EEE_3:",		0xf420},
    {"ANEG_EEE_5:",		0xf422},
    {"",                0, 0}
};




gsw_register_t T_gsw_register_mdio_slave [] =
{
    {"SMDIO_CFG:",		0xf480},
    {"SMDIO_BADR:",		0xf481},
    {"",                0, 0}
};


gsw_register_t T_gsw_register_spi_master [] =
{
    {"MSPI_CFG:",		0xf510},
    {"MSPI_OP:",		0xf511},
    {"MSPI_MANCTRL:",	0xf512},
    {"MSPI_ISR:",		0xf513},
    {"MSPI_IER:",		0xf514},
    {"MSPI_DIN01:",		0xf518},
    {"MSPI_DIN23:",		0xf519},
    {"MSPI_DIN67:",		0xf51b},
    
    {"MSPI_DOUT01:",	0xf51c},
    {"MSPI_DOUT23:",	0xf51d},
    {"MSPI_DOUT67:",	0xf51e},
    {"MSPI_DOUT45:",	0xf51f},	
    {"MSPI_DIN45:",		0xf51a},
    {"",                0, 0}
};

gsw_register_t T_gsw_register_spi_slave [] =
{
    {"SSPI_CFG:",		0xf580},
    {"",                0, 0}
};

gsw_register_t T_gsw_register_uart [] =
{
    {"UART_CFG:",		0xf680},
    {"UART_BD:",		0xf681},
    {"UART_FDIV:",		0xf682},
    {"UART_PROMPT:",	0xf683},
    {"UART_ERRCNT:",	0xf684},
    {"",                0, 0}
};



gsw_register_t T_gsw_register_gcu [] =
{
    {"ROPLL_MISC:",		0xf990},
    {"GC0_CONF:",		0xf948},
    {"GC1_CONF:",		0xf94c},
    {"SYSCLK_CONF:",	0xf950},
    {"SGMII_CONF:",		0xf954},

    {"NCO1_LSB:",		0xf958},
    {"NCO1_MSB:",		0xf95c},
    {"NCO2_LSB:",		0xf960},
    {"NCO2_MSB:",		0xf964},
    {"NCO_CTRL:",		0xf998},

    {"ROPLL_CFG0:",		0xf980},
    {"ROPLL_CFG1:",		0xf984},
    {"ROPLL_CFG2:",		0xf988},
    {"ROPLL_CFG3:",		0xf98c},

    {"",                0, 0}
};


gsw_register_t T_gsw_register_rcu [] =
{
    {"RESET_STATUS:",		0xfa00},
    {"RST_REQ:",			0xfa01},
    {"MAN_ID:",				0xfa10},
    {"PNUM_ID:",			0xfa11},
    {"GPIO_DRIVE0_CFG:",	0xfa70},
    {"GPIO_DRIVE1_CFG:",	0xfa71},
    {"GPIO_SLEW_CFG:",		0xfa72},
    {"GPIO2_DRIVE0_CFG:",	0xfa74},
    {"GPIO2_DRIVE1_CFG:",	0xfa75},
    {"GPIO2_SLEW_CFG:",		0xfa76},
    {"RGMII_SLEW_CFG:",		0xfa78},
    {"PS0:",				0xfa80},
    {"PS1:",				0xfa81},
    {"",                0, 0}
};

gsw_register_t T_gsw_register_gpio [] =
{
    {"GPIO_ALTSEL0:",	0xf383},
    {"GPIO_ALTSEL1:",	0xf384},
    {"GPIO_PUDSEL:",	0xf386},
    
	{"GPIO2_ALTSEL0:",	0xf393},
    {"GPIO2_ALTSEL1:",	0xf394},
    {"GPIO2_PUDSEL:",	0xf396},

    {"GPIO_OUT:",		0xf380},
    {"GPIO_IN:",		0xf381},
    {"GPIO_DIR:",		0xf382},
    {"GPIO_OD:",		0xf385},
    {"GPIO_PUDEN:",		0xf387},
	
    {"GPIO2_OUT:",		0xf390},
    {"GPIO2_IN:",		0xf391},
    {"GPIO2_DIR:",		0xf392},
    {"GPIO2_OD:",		0xf395},
    {"GPIO2_PUDEN:",	0xf397},
    {"",                0, 0}
};


gsw_register_t T_gsw_register_icu [] =
{
    {"IMO_ISR:",			0xf3c0},
    {"IMO_EINT0_IER:",		0xf3c2},
    {"IMO_EINT1_IER:",		0xf3c3},
    {"IMO_EXINT_CONF:",		0xf3c4},
    {"",                0, 0}
};


gsw_register_t T_gsw_register_gpio [] =
{
    {"LED_MD_CFG:",		0xf3e0},
    {"LED_BRT_CTRL:",	0xf3e1},
    {"LED_LSENS_CTRL:",	0xf3e2},
    {"",                0, 0}
};


u16 fapi_gsw_dump_registers (u16 if_id)
{
    plm_mdio_trace_off ();

    if (p)
    {
        u16 i;
        u16 j;

        for (i = 0; i <96;i++)
        {
            printf ("0x%02X: ", i);
            for (j = 0; j <4;j++)
            {
                p->regs[i] = fapi_gsw_mdio_dataread(if_id, j, 0, i);
                printf ("0x%04X ",p->regs[i]);
            }
            printf ("\n");         
        }
    }

    plm_mdio_trace_on ();
    return 0;
}





u16 fapi_gsw_dump_registers (u16 if_id)
{
    plm_mdio_trace_off ();

     i = 0;
    do
    {
        ret =  fapi_gsw_reg_read (if_id, p->reg);                
            printf ("0x%04X ",p->reg);
            printf ("%s",p->reg);
            printf ("0x%04X ",ret);
            fflush(stdout);
        printf ("\n");
        i++;         
    } while p->name != "");
    return 0;

    plm_mdio_trace_on ();
    return 0;
}
#endif
