/******************************************************************************

    Copyright 2021 Maxlinear

    SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only)

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.
******************************************************************************/

/**
   \file fapi_gpy_ffu.c
   This file implements the PHY FFU feature (upgrade, erase, version, ...) using GPYAPI services. 

*/

/* ============================= */
/* Includes                      */
/* ============================= */

#include "os_linux.h" 
#include "fapi_gpy_ffu.h"

/* Access to GPYAPI driver  */

#include "api_gpy.h"

#include "gpy211_common.h"
#include "gpy211_phy.h"
#include "gpy211_regs.h"


#define FFU_TIMEOUT_INIT  5000
#define FFU_TIMEOUT_PAGE  1000
#define FFU_PAGE_SIZE 	  256

/**
   FFU function implementation for updating the PHY firmware
   in flash.


   \param
      u16	            if_id           phy Interface id
      u16               port            phy port addr        
      u16               dev             phy dev addr        
	  void* 			phy_fw          phy Firmware address
	  unsigned long 	phy_fwlength    phy Frmware length

   \return
    < 0	error
*/

int fapi_gpy_ffu_flash_update (u16 if_id, u16 port, u16 dev, void* phy_fw, unsigned long phy_fwlength)
{
	int ret = 0;
    void* p_gpydev;
	
    u8 *ppage;
	unsigned long nb_pages;

	/* open gpy api */
	p_gpydev = api_gpy_open (if_id, port, dev);	
    if (p_gpydev == NULL || phy_fw == NULL)
    {
        return -1;
    }

    /* GPY device init  */
	ret = gpy2xx_init(p_gpydev);
	if (ret < 0)
	{
		return ret;
	} 

   /* Start the upgrade procedure */
   ret = gpy2xx_fw_frw_init (p_gpydev,FFU_TIMEOUT_INIT);
   if (ret < 0)
   {
      gpy2xx_fw_frw_uninit (p_gpydev);
      return ret;
   } 

	/* Calculate the number of pages
	   to be written to the flash */
	nb_pages = (phy_fwlength / FFU_PAGE_SIZE);
	if (phy_fwlength % FFU_PAGE_SIZE != 0)
	{
		nb_pages++;
	}
	ppage = (u8*)(phy_fw);

	/* Firmware Upgrade loop */
	do 
	{
		ret = gpy2xx_fw_fwr_page(p_gpydev, ppage, FFU_TIMEOUT_PAGE);
      	if (ret < 0)
      	{
        	gpy2xx_fw_frw_uninit (p_gpydev);
         	return ret;
      	} 
		ppage = ppage + FFU_PAGE_SIZE;
		nb_pages--;
	} while (nb_pages > 0);

	/* Complete the Upgrade Procedure. */
   	gpy2xx_fw_frw_uninit (p_gpydev);

	/* close gpy api */
	 api_gpy_close (if_id, port, dev);

	return ret;
}


/**
   FFU function implementation for upgrading the PHY firmware.


   \param
      u16	 if_id          phy Interface id
      u16    port           phy port addr
      u16    dev            phy dev addr
	  char*  fw_path        phy Firmware file path

   \return
    < 0	error
*/
int fapi_gpy_ffu_upgrade (u16 if_id, u16 port, u16 dev, char *fw_path)
{
    int ret;	

	unsigned char *pFW;
    unsigned long FW_size;

	ret = os_fileload (fw_path, (unsigned char **)&pFW,
						  (OS_size_t*)&FW_size);
	if (ret == OS_ERROR)
	{
	 return -2;
	}

    /* update the flash image */ 
	ret = fapi_gpy_ffu_flash_update (if_id, port, dev, pFW, FW_size);
	return ret;	
}




/**
   FFU function implementation for erasing the PHY firmware.

   \param
      u16	if_id           phy Interface id
      u16    port           phy port addr
      u16    dev            phy dev addr

   \return
    < 0	error
*/
int fapi_gpy_ffu_erase (u16 if_id, u16 port, u16 dev)
{
    int ret = 0;
    void* p_gpydev;

	/* open gpy api */
	p_gpydev = api_gpy_open (if_id, port, dev);
	if (p_gpydev == NULL)
		return -1;     

    /* erase the flash */
  	ret = gpy2xx_fw_frw_init (p_gpydev,FFU_TIMEOUT_INIT);
    gpy2xx_fw_frw_uninit (p_gpydev);

	/* close gpy api */
	 api_gpy_close (if_id, port, dev);
    
    return ret;
}
