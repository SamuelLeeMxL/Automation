/******************************************************************************

         Copyright 2016 - 2017 Intel Corporation
         Copyright 2015 - 2016 Lantiq Beteiligungs-GmbH & Co. KG
         Copyright 2012 - 2014 Lantiq Deutschland GmbH

  SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only)

******************************************************************************/

#ifndef _FAPI_GSW_MDIO_H_
#define _FAPI_GSW_MDIO_H_



#include "os.h"
#include "types.h"



/**
    Implements MDIO Register Read function Clause 22

   \param
      u16	if_id           phy Interface id
      u16   port            phy addr        
	  u16 	reg             phy register

   \return
    >=0:  register value
    -1:   access error
    -2:   parameter error
*/
s32 fapi_gsw_mdio_c22_read (u16 if_id, u16 port, u16 reg);



/**
    Implements SMDIO Register Write function Clause 22


   \param
      u16	if_id           phy Interface id
      u16   port            phy addr        
	  u16 	reg             phy register
	  u16 	val             phy value to write

   \return
    >=0:  register value
    -1:   access error
    -2:   parameter error
*/
s32 fapi_gsw_mdio_c22_write (u16 if_id, u16 port,  u16 reg, u16 val);


/**
    Implements GSW Register Read Access.


   \param
      u16	if_id           GSW Interface id
	  u16 	gsw_addr        GSW Register Offset Address 

   \return
   	u16 	val             GSW Register Value
    >=0:  register value
    -1:   access error
    -2:   parameter error
*/
u16 fapi_gsw_reg_read (u16 if_id, u16 gsw_addr);


/**
    Implements GSW Register Write Access.


   \param
      u16	if_id           GSW Interface id
	  u16 	gsw_addr        GSW Register Offset Address 
	  u16 	val             GSW Register Value to write

   \return
   	u16 	val             GSW Register Value
    >=0:  register value
    -1:   access error
    -2:   parameter error
*/
u16 fapi_gsw_reg_write (u16 if_id, u16 gsw_addr, u16 val);




u16 fapi_gsw_mdio_dataread(u16 if_id,u16 port, u16 dev, u16 reg);
u16 fapi_gsw_mdio_datawrite(u16 if_id,u16 port, u16 dev, u16 reg, u16 val);

u16 fapi_gsw_mmd_dataread(u16 if_id,u16 port, u16 dev, u16 reg);



typedef struct {
	u16	regs [96];
} gsw_mdio_t;

u16 fapi_gsw_mdio_get_registers (u16 if_id,  u16 port, gsw_mdio_t *p); 

#endif /* _FAPI_GSW_MDIO_H_ */
