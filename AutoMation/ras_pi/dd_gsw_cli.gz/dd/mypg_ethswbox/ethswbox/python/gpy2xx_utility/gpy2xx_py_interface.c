/******************************************************************************

         Copyright 2016 - 2017 Intel Corporation
         Copyright 2015 - 2016 Lantiq Beteiligungs-GmbH & Co. KG
         Copyright 2012 - 2014 Lantiq Deutschland GmbH

  SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only)

******************************************************************************/

#include <Python.h> 

#include <windows_stub.h>
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <gpy211.h>
#include <gpy211_macsec.h>
#include "gpy211_utility.h"
/*
#include "gpy211_utility_main.h"
#include "gpy211_utility_common.h"
#include "gpy211_utility_cmdprocessor.h"
*/
//#include <gpy211_gmac.h>

#include "gpy211_utility_gpy2xx.h"


int phyid(int phy_id)
{
	phy.phy_addr = phy_id;
	return 0;
}

int cmd(int num, int counter, char **param_list)
{
	cmdProcessor(num, counter, param_list, (FILE *)NULL);
}

int run(char *lpBuffer)
{
	int i = 0, j = 0, k = 0, c = 0;   

	char lpBuffer2[CMD_LINE_BUFFER_SIZE];
	char temp_buffer[TEMP_BUFFRE_SIZE];
	unsigned int check_space = 1;

	unsigned int num = 0;
	int counter = 0;
	char *param_list[MAX_PARAM];
	char *param_list1[MAX_PARAM];


	memcpy(temp_buffer, lpBuffer, 15);
	memcpy(lpBuffer2, lpBuffer, 1000);

	for (k = 0; k < 15; k++) {
		if (temp_buffer[k] != ' ' && temp_buffer[k] != 0 && temp_buffer[k] != '\n') {
			check_space = 0;
		}
	}

	if (temp_buffer[0] != '\n' || check_space == 0) {
		num = split_buffer(lpBuffer, param_list, MAX_PARAM);
		counter = split_buffer(lpBuffer2, param_list1, MAX_PARAM);
	}


	if ((temp_buffer[0] == 'r' || temp_buffer[0] == 'w') && temp_buffer[1] == ' ') {
		printf("r/w are uart commands, cannot use directly with mdio interface.\r\n");
		return 0;
	} else if (temp_buffer[0] == '\n' || check_space == 1) {
		return 0;
	} else {
		cmdProcessor(num, counter, param_list, (FILE *)NULL);
	}

	return 1;
}