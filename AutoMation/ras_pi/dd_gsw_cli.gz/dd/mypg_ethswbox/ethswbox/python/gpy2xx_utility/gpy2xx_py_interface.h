int phyid(int phy_id);
int cmd(int num, int counter, char **param_list);
int run(char *lpBuffer);
