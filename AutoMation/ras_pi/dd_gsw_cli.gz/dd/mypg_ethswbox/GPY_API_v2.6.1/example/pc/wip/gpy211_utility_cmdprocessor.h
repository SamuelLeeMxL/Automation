/******************************************************************************

         Copyright 2016 - 2017 Intel Corporation
         Copyright 2015 - 2016 Lantiq Beteiligungs-GmbH & Co. KG
         Copyright 2012 - 2014 Lantiq Deutschland GmbH

  SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only)

******************************************************************************/

#ifndef _UTILITY_CMDPROCESSOR_H_
#define _UTILITY_CMDPROCESSOR_H_

int cmdProcessor(int num, int counter, char **param_list, FILE *fp);

#endif /* _UTILITY_CMDPROCESSOR_H_ */

