/******************************************************************************

         Copyright 2016 - 2017 Intel Corporation
         Copyright 2015 - 2016 Lantiq Beteiligungs-GmbH & Co. KG
         Copyright 2012 - 2014 Lantiq Deutschland GmbH

  SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only)

******************************************************************************/

#ifndef _UTILITY_COMMON_H_
#define _UTILITY_COMMON_H_

u32 swap_uint32(u32 val);
int xisupper(char c);
int xisalpha(char c);
int xisspace(char c);
int xisdigit(char c);
int xgetBase(const char *sPtr);
unsigned long xstrtoul(char *sPtr);
void printMAC_Address(unsigned char *pMAC);
int convert_mac_adr_str(char *mac_adr_str, unsigned char *mac_adr_ptr);
int copy_key_to_dst(char *key_adr_str, u8 size, char *key_adr_ptr);
void remove_leading_whitespace(char **p, int *len);
int split_buffer(char *buffer, char *array[], int max_param_num);
unsigned int t_olower(u32 ch);
unsigned int xstrncasecmp(const char *s1, const char *s2, unsigned int n);
unsigned int str_to_hex(unsigned char *str);
unsigned int hex2int(char c);
int print_sys_time(u32 sec, u32 nsec);



#endif /* _UTILITY_COMMON_H_ */

