/******************************************************************************

         Copyright 2016 - 2017 Intel Corporation
         Copyright 2015 - 2016 Lantiq Beteiligungs-GmbH & Co. KG
         Copyright 2012 - 2014 Lantiq Deutschland GmbH

  SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only)

******************************************************************************/

#ifndef _UTILITY_GPY2XX_H_
#define _UTILITY_GPY2XX_H_

extern struct gpy211_device phyphy; // DISABLED
extern struct gpy211_device* p_gpyapi_phy; 

char *findArgParam(int argc, char *argv[], char *name);
int scanParamArg(int argc, char *argv[], char *name, int size, void *param);
int scanMAC_Arg(int argc, char *argv[], char *name, unsigned char *param);
int scanKey_Arg(int argc, char *argv[], char *name, u8 size, char *param);

#if FCON_MSEC_TEST
void e160_free_rx_sc(struct e160_macsec_rx_sc *rx_sc);
#endif

 
void convert_sci_to_mac_addr(sci_t sci, u8 *mac_addr);
int scan_advert(int argc, char *argv[], char *name, u64 *param);
int print_advert(char *buf, unsigned int size, u64 param);
int gpy2xx_msec_main(int argc, char *argv[]);

int gpy211_main(int argc, char *argv[]);

#endif /* _UTILITY_GPY2XX_H_ */

