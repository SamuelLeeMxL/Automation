/******************************************************************************

         Copyright 2016 - 2017 Intel Corporation
         Copyright 2015 - 2016 Lantiq Beteiligungs-GmbH & Co. KG
         Copyright 2012 - 2014 Lantiq Deutschland GmbH

  SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only)

******************************************************************************/

#include <windows_stub.h>
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <gpy211.h>
//#include <gpy211_gmac.h>
#include <gpy211_macsec.h>
#include "gpy211_utility.h"

#include "gpy211_utility_pg31.h"
#include "gpy211_utility_uart.h"
#include "gpy211_utility_gpy2xx.h"

#if P31G_READ_REGS
void print_p31g_std()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tSTD Registers\n");
	base = 0x0;

	for (i = 0; i < 16; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, gpy2xx_read( p_gpyapi_phy, addr));
	}
}

void print_p31g_phy()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tPHY Registers\n");
	base = 0x10;

	for (i = 0; i < 16; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, gpy2xx_read( p_gpyapi_phy, addr));
	}
}

void print_p31g_pma()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tPMA Registers\n");
	base = 0x0;

	for (i = 0; i < 9; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, gpy2xx_read_mmd( p_gpyapi_phy, 0x1, addr));
	}

	base = 0xB;

	for (i = 0; i < 1; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, gpy2xx_read_mmd( p_gpyapi_phy, 0x1, addr));
	}

	base = 0xE;

	for (i = 0; i < 2; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, gpy2xx_read_mmd( p_gpyapi_phy, 0x1, addr));
	}

	base = 0x15;

	for (i = 0; i < 1; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, gpy2xx_read_mmd( p_gpyapi_phy, 0x1, addr));
	}

	base = 0x81;

	for (i = 0; i < 19; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, gpy2xx_read_mmd( p_gpyapi_phy, 0x1, addr));
	}

	base = 0x708;

	for (i = 0; i < 1; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, gpy2xx_read_mmd( p_gpyapi_phy, 0x1, addr));
	}
}

void print_p31g_pcs()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tPCS Registers\n");
	base = 0x0;

	for (i = 0; i < 9; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, gpy2xx_read_mmd( p_gpyapi_phy, 0x3, addr));
	}

	base = 0xE;

	for (i = 0; i < 2; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, gpy2xx_read_mmd( p_gpyapi_phy, 0x3, addr));
	}

	base = 0x14;

	for (i = 0; i < 3; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, gpy2xx_read_mmd( p_gpyapi_phy, 0x3, addr));
	}

	base = 0x20;

	for (i = 0; i < 2; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, gpy2xx_read_mmd( p_gpyapi_phy, 0x3, addr));
	}

	base = 0x708;

	for (i = 0; i < 1; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, gpy2xx_read_mmd( p_gpyapi_phy, 0x3, addr));
	}
}

void print_p31g_aneg()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tANEG Registers\n");
	base = 0x0;

	for (i = 0; i < 7; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, gpy2xx_read_mmd( p_gpyapi_phy, 0x7, addr));
	}

	base = 0xE;

	for (i = 0; i < 3; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, gpy2xx_read_mmd( p_gpyapi_phy, 0x7, addr));
	}

	base = 0x13;

	for (i = 0; i < 1; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, gpy2xx_read_mmd( p_gpyapi_phy, 0x7, addr));
	}

	base = 0x16;

	for (i = 0; i < 6; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, gpy2xx_read_mmd( p_gpyapi_phy, 0x7, addr));
	}

	base = 0x20;

	for (i = 0; i < 2; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, gpy2xx_read_mmd( p_gpyapi_phy, 0x7, addr));
	}

	base = 0x3C;

	for (i = 0; i < 5; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, gpy2xx_read_mmd( p_gpyapi_phy, 0x7, addr));
	}
}

void print_p31g_vspec1()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tMMD Vspec-1 Registers\n");
	base = 0x0;

	for (i = 0; i < 14; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, gpy2xx_read_mmd( p_gpyapi_phy, 0x1e, addr));
	}
}

void print_p31g_vspec2()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tMMD Vspec-2 Registers\n");
	base = 0xE06;

	for (i = 0; i < 9; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, gpy2xx_read_mmd( p_gpyapi_phy, 0x1f, addr));
	}
}

void print_p31g_sgmii()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tSGMII PHY\n");
	base = 0xD000;

	for (i = 0; i < 11; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}

	base = 0xD100;

	for (i = 0; i < 3; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}

	base = 0xD111;

	for (i = 0; i < 2; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}

	printf("\n\tSGMII MACRO\n");
	base = 0xD200;

	for (i = 0; i < 2; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}

	base = 0xD20F;

	for (i = 0; i < 2; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}

	printf("\n\tSGMII TBI\n");
	base = 0xD300;

	for (i = 0; i < 17; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}

	printf("\n\tSGMII PCS\n");
	base = 0xD400;

	for (i = 0; i < 7; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_p31g_uart()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tUART Registers\n");
	base = 0xF680;

	for (i = 0; i < 5; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_p31g_mspi()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tSPI Master Registers\n");
	base = 0xF510;

	for (i = 0; i < 16; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_p31g_smdio()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tMDIO Slave Registers\n");
	base = 0xF480;

	for (i = 0; i < 2; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_p31g_mmdio()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tMDIO Master Registers\n");
	addr = 0xF400;
	pc_uart_dataread(addr, &value);
	printf("\taddr = 0x%x, value = 0x%x\n", addr, value);

	base = 0xF408;

	for (i = 0; i < 3; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}

	addr = 0xF40C;
	pc_uart_dataread(addr, &value);
	printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
}

void print_p31g_led()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tLED Registers\n");
	base = 0xF3E0;

	for (i = 0; i < 3; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_p31g_icu()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tICU Registers\n");
	base = 0xF3C0;

	for (i = 0; i < 12; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_p31g_gpio()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tGPIO Registers\n");
	base = 0xF380;

	for (i = 0; i < 23; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_p31g_sbuf()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tShared Buffer Registers\n");
	base = 0xE080;

	for (i = 0; i < 3; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_p31g_pm()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tPacket Manager Registers\n");
	base = 0xE000;

	for (i = 0; i < 109; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_p31g_foxvil()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tFXVL Config Registers\n");
	base = 0xB000;

	for (i = 0; i < 2; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_p31g_dcpm()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tDCPM-FCSI Registers\n");
	base = 0xA620;

	for (i = 0; i < 4; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_p31g_crcu()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tConfig Reset Control Unit Registers\n");
	base = 0xA501;

	for (i = 0; i < 5; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_p31g_srcu()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tSticky Reset Control Unit Registers\n");
	base = 0xA500;

	for (i = 0; i < 1; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_p31g_cgu()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tClock Generation Unit Registers\n");
	base = 0xA400;

	for (i = 0; i < 15; i++) {
		addr = base + (i * 4);
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_p31g_pmu()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tPower Management Unit Registers\n");
	base = 0xA300;

	for (i = 0; i < 21; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_p31g_chipid()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tChip ID Registers\n");
	base = 0xA220;

	for (i = 0; i < 29; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_p31g_top()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tChip ID Registers\n");
	base = 0xA200;

	for (i = 0; i < 2; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_p31g_pvt()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tPVT Module Registers\n");
	base = 0xA100;

	for (i = 0; i < 5; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_p31g_xofsci()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tXO-FSCI Interface Registers\n");
	base = 0xA020;

	for (i = 0; i < 4; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_p31g_gphy()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tGPHY Shell Registers\n");
	base = 0x9000;

	for (i = 0; i < 4; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_p31g_ssc()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tCDB SSC Registers\n");
	base = 0x8080;

	for (i = 0; i < 2; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_p31g_cdb()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tCDB Registers\n");
	base = 0x8040;

	for (i = 0; i < 4; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_p31g_cdb_fsci()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tCDB FCSI-Interface Registers\n");
	base = 0x8020;

	for (i = 0; i < 15; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void 	print_p31g_mfsci()
{
	u32 i, base = 0, addr = 0, value = 0;

	printf("\n\tMaster FSCI Registers\n");
	base = 0x8000;

	for (i = 0; i < 4; i++) {
		addr = base + i;
		pc_uart_dataread(addr, &value);
		printf("\taddr = 0x%x, value = 0x%x\n", addr, value);
	}
}

void print_p31g_regs()
{
	printf("\nSGMII_Registers\n");
	print_p31g_sgmii();
	printf("\nTop Level PDI Registers\n");
	/*
		print_p31g_mfsci();
		print_p31g_cdb_fsci();
		print_p31g_cdb();
		print_p31g_ssc();
		print_p31g_gphy();
		print_p31g_xofsci();
		print_p31g_pvt();
		print_p31g_top();
		print_p31g_chipid();
		print_p31g_pmu();
		print_p31g_cgu();
		print_p31g_srcu();
		print_p31g_crcu();
		print_p31g_dcpm();
		print_p31g_foxvil();
		print_p31g_pm();
		print_p31g_sbuf();
		print_p31g_gpio();
		print_p31g_icu();
		print_p31g_led();
		print_p31g_mmdio();
		print_p31g_smdio();
		print_p31g_mspi();
		print_p31g_uart();
	*/
	print_p31g_gphy();
	print_p31g_top();
	print_p31g_cgu();
	print_p31g_srcu();
	print_p31g_crcu();
	print_p31g_gpio();
	print_p31g_icu();
	print_p31g_led();
	print_p31g_mmdio();
	print_p31g_smdio();
	print_p31g_mspi();
	print_p31g_uart();
	printf("\nPHY MDIO\n");
	print_p31g_std();
	print_p31g_phy();
	printf("\nPHY MMD\n");
	print_p31g_pma();
	print_p31g_pcs();
	print_p31g_aneg();
	print_p31g_vspec1();
	print_p31g_vspec2();
}
#endif
