#!/usr/bin/perl -w
use Fcntl;
use Getopt::Std;
use lib '../scripts';
use npf_format;

%options=();

my $header =
"/****************************************************************************

                               Copyright 2010
                          Lantiq Deutschland GmbH
                   Am Campeon 3; 85579 Neubiberg, Germany

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

*****************************************************************************/
#include \"ifx_types.h\"
#include \"INPUTNAME\"
#include \"ltq_linux_ioctl_ll_fkt.h\"
\n";
my @inputFile = ();
my $inputFileLen1 = 0;
my $inputFileLen2 = 0;

my $devName = undef;
my %tableContent = ();
my %ioctlTableContent = ();
my %moduleConfig = ();
my $nextFktTableName = "IFX_NULL";
my $magicCode = "";
my $numFktTableEntries = 0;
my $numBlackListEntries = 0;
my @blackList = ();

sub PrintHelp {
   print "Usage: $0 <options>\n";
   print "Generate low level switch api function call table source code file\n";
   print "out of ioctl switch api header file.\n";
   print "Usage:\n";
   print "   -i <file>     Main input files\n";
   print "   -n <file>     Device specific input file\n";
   print "   -o <file>     Write output to file.\n";
   print "   -p <file>     Low level include file\n";
   print "   -k <files>    Read a list of keywords from a given file.\n";
   print "                 Use defaults if this file is not given.\n";
   print "   -m <module>   Module name. E.g. ETHSW, TAPI\n";
   print "   -b <file>     Blacklist of ioctl where no low-level function should\n";
   print "                 be provided.\n";
   print "   -c <file>     Config file about which function is enabled over which\n";
   print "                 INCLUDE macro\n";
   print "   -h            Printout help and exit\n\n";
   exit 0;
}

sub strip_tailing_spaces {
   foreach(@inputFile) {
      $_ =~ s/\t/   /g;
      $_ =~ s/ +\n/\n/g;
   }
}

sub readInputFile {
   sysopen(IN1, $options{i}, O_RDONLY) || die "$options{i} could not be opened!\n";
   #copy whole config spec into memory
   while (<IN1>) {
      $inputFile[$inputFileLen1] = $_;
      $inputFileLen1++;
   }
   close (IN1);

   sysopen(IN2, $options{n}, O_RDONLY) || die "$options{n} could not be opened!\n";
   #copy whole config spec into memory
   while (<IN2>) {
      $inputFile[$inputFileLen1 + $inputFileLen2] = $_;
      $inputFileLen2++;
   }
   close (IN2);
}

sub readModuleConfigFile {
   sysopen(IN, $options{c}, O_RDONLY) || die "$options{c} could not be opened!\n";

   while (<IN>) {
      s/[\n\r]*//g;
      # module config macro(0) ; IOCTL name(1)
      my @tmp = split /[,;]/, $_;

      if (defined $tmp[0] && defined $tmp[1]) {
         $moduleConfig{$tmp[1]} = $tmp[0];
      }
   }

   close (IN);
}

sub removePathFromFileName {
   my $filname = $_[0];
   $filname =~ s/\\/\//g;
   my @tmp = split /\//, $filname;
   return $tmp[@tmp - 1];
}

sub remove_ifdef_zero {
   my $found = 0;

   for (my $i = 0; $i < @inputFile; $i++) {
      my $line = $inputFile[$i];

      if ($line =~ /#if 0/) {
         $found = 1;
      }

      if ($found == 1) {
         $inputFile[$i] = "";
      }

      if ($line =~ /#endif/) {
         $found = 0;
      }
   }
}

#subroutine to look for the ioctl defines, adapt spaces and index number
sub GenerateFktTableContent {
   #arguments
   my $startline = $_[0];
   my $stopline = $_[1];

   #init and reset previous values for a new run
   %tableContent = ();
   %ioctlTableContent = ();
   $numFktTableEntries = 0;
   $numBlackListEntries = 0;

   for (my $i = $startline; $i < $stopline; $i++) {
      my $fileLine = $inputFile[$i];
      if ($fileLine =~ /#define/) {
         if ($fileLine =~ /_IO/) {
            # if line contains backspace at the end -> merge with next line
            if ($fileLine =~ /\\/) {
               $fileLine =~ s/[\ \n\r\\]*$//g;

               $inputFile[$i] .= $inputFile[$i + 1];
               $inputFile[$i + 1] = "";
            }

            #ioctl define found, remove tabs and all spaces and ensure the their is a space after the comma and the brackets
            $inputFile[$i] =~ s/,/, /g;
            $inputFile[$i] =~ s/\t/ /g;
            $inputFile[$i] =~ s/\(/\( /g;
            $inputFile[$i] =~ s/ +/ /g;

            #define(0) IOCTLNAME(1)      _IOWR( (2)  IFX_MAGIC,(3)    NUMBER, (4)   STRUCT)(5)
            my @line = split / /, $inputFile[$i];

            #search for this IOCTL command in the blacklist. If found, leave it out
            my $blackListFound = 0;

            foreach $blEntry (@blackList)
            {
               if (($line[1] =~ $blEntry) && ($blEntry =~ $line[1])) {
                  $blackListFound = 1;
                  last;
               }
            }

            if ($blackListFound == 1) {
               $numBlackListEntries += 1;
               next;
            }

            #IOCTL command bits
            my $nNrBits = $line[4];
            $nNrBits =~ s/[,\)\ \r\n]*//g;

            #IOCTL Type
            $nextFktTableName = $line[3];
            $nextFktTableName =~ s/,//;
            $magicCode = $nextFktTableName;
            $nextFktTableName =~ s/_MAGIC//;

            #Add IOCTL name to a separate table
            $ioctlTableContent{$nNrBits} = $line[1];

            my $ifxDevName = lc $devName;
            my $my_fkt = lc $line[1];
            $my_fkt =~ s/ethsw/$ifxDevName/g;
            $my_fkt = convert2NPF($my_fkt, $ifxDevName);

            die "ERROR: Duplicate Command IOCTL Number $nNrBits\n" if defined ($tableContent{$nNrBits});

            $tableContent{$nNrBits} = "   /* Command: $line[1] ; Index: $nNrBits */\n";
            if (defined $moduleConfig{$line[1]}) {
               #module config macro set for this specific IOCTL. Therefore set the macro accordingly
               $tableContent{$nNrBits} .= "   (IFX_ll_fkt) IFX_ETHSW_SW_FKT( $moduleConfig{$line[1]} , $my_fkt),";
            } else {
               #no config macro set for this IOCTL. Place the regular function pointer
               $tableContent{$nNrBits} .= "   (IFX_ll_fkt) $my_fkt,";
            }

            $numFktTableEntries += 1;
         }
      }
   }
}

sub generateOutput {
   sub printFktTable {
      my $tableName = $_[0];
      my $i = 0;
      my $j = $numFktTableEntries;

      die "ERROR: More functions given than size of table\n" if ($j < keys(%tableContent));

      #printout the function pointer table
      print OUT "const IFX_ll_fkt $tableName [] =\n{\n";

      my $nNrBits = 0;
      do {
         my $nNrBitString = sprintf("0x%02X", $nNrBits);
         my $text = {};

         if (defined $tableContent{$nNrBitString}) {
            #low level function found
            $text = "$tableContent{$nNrBitString}\n";
            $j -= 1;
         }
         else {
            $text = "   /* $nNrBitString */\n   (IFX_ll_fkt) IFX_NULL,\n";
         }

         if ($j == 0) {
            #last line search, remove the "," at the end of the line for the structure element
            $text =~ s/, \/\*/ \/\*/;
         }

         print OUT $text;
         $nNrBits +=1;

         die "ERROR: Number of IOCTLs not correctly identified!" if ($nNrBits > @inputFile);

      }while ($j > 0);

      print OUT "};\n\n";
   }

   sub printIoctlTable {
      my $tableName = $_[0];
      my $i = 0;
      my $j = $numFktTableEntries;

      die "ERROR: More functions given than size of table\n" if ($j < keys(%ioctlTableContent));

      #printout the function pointer table
      print OUT "IFX_uint32_t $tableName [] =\n{\n";

      my $nNrBits = 0;
      do {
         my $nNrBitString = sprintf("0x%02X", $nNrBits);
         my $text = {};

         if (defined $ioctlTableContent{$nNrBitString}) {
            #low level function found
            $text = "   (IFX_uint32_t) $ioctlTableContent{$nNrBitString}, /* $nNrBitString */\n";
            $j -= 1;
         }
         else {
            $text = "   (IFX_uint32_t) 0, /* $nNrBitString */\n";
         }

         if ($j == 0) {
            #last line search, remove the "," at the end of the line for the structure element
            $text =~ s/,//;
         }

         print OUT $text;
         $nNrBits +=1;
      }while ($j > 0);

      print OUT "};\n\n";
   }

   #place the filename the the filename define in the header and print out to file
   if (defined $options{o}) {
      $outputfile = $options{o};
   } else {
      $outputfile = "STDOUT_PRINT_H";
   }

   $outputfile =~ s/\./_/g;
   $outputfile = uc $outputfile;
   my $input = removePathFromFileName($options{p});
   my $output = removePathFromFileName($options{o});

   $header =~ s/INPUTNAME/$input/g;
   $header =~ s/ETHSW/$devName/g;

   print OUT "$header";

   #search for the different ETHSW group definition and print them to OUT. Ignore the device specific groups

   #find beginning of the ioctl description
   GenerateFktTableContent(0, $inputFileLen1);
   my $tableName1 = sprintf("%s_%s_fkt_tbl", lc $nextFktTableName, $devName);
   my $ptrTableName1 = sprintf("%s_%s_fkt_ptr_tbl", lc $nextFktTableName, $devName);
   my $ioctlTableName1 = sprintf("%s_%s_ioctl_tbl", lc $nextFktTableName, $devName);


   #printout the macro to define the function pointer
   print OUT "#ifdef IFX_ETHSW_SW_FKT\n";
   print OUT "#undef IFX_ETHSW_SW_FKT\n";
   print OUT "#endif /* IFX_ETHSW_SW_FKT */\n\n";
   print OUT "#define IFX_ETHSW_SW_FKT(x, y) x? (IFX_ll_fkt)y : IFX_NULL\n\n";

   if (defined $options{c}) {
      #printout defaults if not macro definition is not given
      my %value_tmp = ();
      foreach my $key (sort keys %moduleConfig) {
         if (not defined $value_tmp{$moduleConfig{$key}}) {
            $value_tmp{$moduleConfig{$key}} = 1;
            print OUT "#ifdef $moduleConfig{$key}\n";
            print OUT "   #undef $moduleConfig{$key}\n";
            print OUT "   #define $moduleConfig{$key} 1\n";
            print OUT "#else\n";
            print OUT "   #define $moduleConfig{$key} 0\n";
            print OUT "#endif\n";
         }
      }
      print OUT "\n";
   }

   #printout the function pointer table
   printFktTable($ptrTableName1);

   #Increment the 'nNumFkts' counter because we added one element for the zero index
   $numFktTableEntries += 1 + $numBlackListEntries;

   #printout the low level table
   print OUT "const IFX_ETHSW_lowLevelFkts_t $tableName1 =\n{\n";
   print OUT "   IFX_NULL , /* pNext */\n";
   print OUT "   (IFX_uint16_t) $magicCode , /* nType */\n";
   print OUT "   $numFktTableEntries , /* nNumFkts */\n";
   print OUT "   $ptrTableName1 /* pFkts */\n";
   print OUT "};\n\n";
   my $oldNextFktTableName = $nextFktTableName;
   GenerateFktTableContent($inputFileLen1, $inputFileLen1 + $inputFileLen2);

   my $tableName2 = sprintf("%s_fkt_tbl", lc $nextFktTableName);
   my $ptrTableName2 = sprintf("%s_fkt_ptr_tbl", lc $nextFktTableName);
   my $ioctlTableName2 = sprintf("%s_ioctl_tbl", lc $nextFktTableName);

   #printout the function pointer table
   printFktTable($ptrTableName2);

   #Increment the 'nNumFkts' counter because we added one element for the zero index
   $numFktTableEntries += 1 + $numBlackListEntries;

   #printout the low level table
   print OUT "const IFX_ETHSW_lowLevelFkts_t $tableName2 =\n{\n";
   print OUT "   & $tableName1 , /* pNext */\n";
   print OUT "   (IFX_uint16_t) $magicCode , /* nType */\n";
   print OUT "   $numFktTableEntries , /* nNumFkts */\n";
   print OUT "   $ptrTableName2 /* pFkts */\n";
   print OUT "};\n\n";
}

########### main ###########

# parse command line options
getopts("b:c:dhi:k:m:n:o:p:", \%options) or die "invalid option\n";

if (defined $options{h}) {
   die PrintHelp;
}

if ((not defined $options{i}) or (not defined $options{n})) {
   print STDERR "ERROR: No input files given!\n\n";
   die PrintHelp;
}

if (defined $options{c}) {
   print "read module config file\n";
   readModuleConfigFile;
}

if (not defined $options{n}) {
   print STDERR "ERROR: No output file name given!\n\n";
   die PrintHelp;
}

if (not defined $options{p}) {
   print STDERR "ERROR: No include file name given!\n\n";
   die PrintHelp;
}

if (not defined $options{m}) {
   print STDERR "ERROR: No module name given!\n\n";
   die PrintHelp;
}
$devName = uc($options{m});

if (defined $options{k}) {
   print "read NPF file\n";
   readNPFFile $options{k};
}

if (defined $options{b}) {
   print "read black list\n";
   @blackList = readinput $options{b};
}

print "read input file\n";
readInputFile;
print "remove unused file parts\n";
remove_ifdef_zero;
sysopen(OUT, $options{o}, O_WRONLY | O_CREAT | O_TRUNC) || die "$options{o} could not be opened!\n";
print "generate output file\n";
generateOutput;
close (OUT);
