#!/bin/sh
#changing 'VR9' to 'GSWIP' in all variable-, MACRO-, file- and function- names
find ../ -name "*.[ch]" | grep -v gphy | xargs perl -p -i -e 'if (!(/defined/) && !(/ifdef/)) { s/([a-zA-Z0-9_]*)[Vv][Rr]9([a-zA-Z0-9_]*)/$1GSWIP$2/g; }'

#changing GPHY usage of 'VR9' variable-, MACRO-, file- and function- names
find ../ -name "*.[ch]" | grep gphy | xargs perl -p -i -e 's/VR9_REG_ACCESS/GSWIP_REG_ACCESS/g'

#changing 'VR9' to 'GSWIP' in all file names
find ../ -name "Makefile*" | xargs perl -p -i -e 'if (!(/gphy/) && !(/CONFIG_VR9/) && !(/DVR9/)) { s/([a-zA-Z0-9_]*)[Vv][Rr]9([a-zA-Z0-9_]*)/$1GSWIP$2/g; }'

for i in `find ../ -name *[Vv][Rr]9* | grep -v gphy`
do
   mv $i `echo $i | sed 's/[Vv][Rr]9/GSWIP/g'`
done

#update header file links
H_DIRS="../../../drivers_config/files-2.6.32.11/include/switch_api/ ../../../drivers_config/files/include/switch_api/"
for i in $H_DIRS
do
   cd $i
   rm -f *.h
   ln -s ../../../../switch_api_drv/switch_ifx_ethsw_api/include/*.h .
   cd - >& /dev/null
done

#update source code files
C_DIRS="../../../drivers_config/files/drivers/net/ifxmips_switch_api/ ../../../drivers_config/files-2.6.32.11/drivers/net/ifxmips_switch_api/"
for i in $H_DIRS
do
   cd $i
   rm -f *.c
   ln -s ../../../../../switch_api_drv/switch_ifx_ethsw_api/src/*.c .
   cd - >& /dev/null
done
