#!/usr/bin/perl -w
use Fcntl;
use Getopt::Std;
use lib '../scripts';
use npf_format;

%options=();

my $header =
"/****************************************************************************

                               Copyright 2010
                          Lantiq Deutschland GmbH
                   Am Campeon 3; 85579 Neubiberg, Germany

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

*****************************************************************************/
#ifndef FILEDEFINE
#define FILEDEFINE

#include \"INPUTNAME1\"
#include \"INPUTNAME2\"

/* Group definitions for Doxygen */
/** \\defgroup ETHSW_LL Ethernet Switch Application Kernel Interface
    This chapter describes the entire interface to access and
    configure the services of the switch module in OS kernel space. */\n/*@\{*/\n";
my $help = 0;
my @list = ();
my @inputFile = ();
my $inputFileLen1 = 0;
my $inputFileLen2 = 0;
my @fkt = ();
my @fktType = ();
my $fktTypeLen = 0;
my @fktTypeShortDescr = ();
my $devName = undef;
my @fktTypeList = ();
my @blackList = ();
my $fktTypeListLen = 0;
my $ftkTypeMaxLen = 0;


sub PrintHelp {
   print "Usage: $0 <options>\n";
   print "Generate low level switch api header file out of ";
   print "ioctl switch api header file.\n\n";
   print "Usage:\n";
   print "   -i <file>     Main input files\n";
   print "   -n <file>     Device specific input file\n";
   print "   -o <file>     Write output to file.\n";
   print "   -m <module>   Module name. E.g. ETHSW, TAPI\n";
   print "   -f            Printout the function pointer declaration & table\n";
   print "   -h            Printout help and exit\n\n";
   print "   -k <files>    Read a list of keywords from a given file.\n";
   print "                 Use defaults if this file is not given.\n";
   print "   -b <file>     Blacklist of ioctl where no low-level function should\n";
   print "                 be provided.\n";
   exit 0;
}

my @cached_output = "";

sub cached_print_output {
   my $size = $#cached_output + 1;
   $cached_output[$size] = $_[0];
}

sub cached_strip_tailing_spaces {
   foreach(@cached_output) {
      $_ =~ s/ +\n/\n/g;
   }
}

sub readInputFile {
   sysopen(IN1, $options{i}, O_RDONLY) || die "$options{i} could not be opened!\n";
   #copy whole config spec into memory
   while (<IN1>) {
      $inputFile[$inputFileLen1] = $_;
      $inputFileLen1++;
   }
   close (IN1);

   sysopen(IN2, $options{n}, O_RDONLY) || die "$options{n} could not be opened!\n";
   #copy whole config spec into memory
   while (<IN2>) {
      $inputFile[$inputFileLen1 + $inputFileLen2] = $_;
      $inputFileLen2++;
   }
   close (IN2);
}

sub cached_flush_output {
   if (defined $options{o}) {
      sysopen(OUT, $options{o}, O_WRONLY | O_CREAT | O_TRUNC) || die "$options{o} could not be opened or created!\n";

      foreach(@cached_output) {
         print OUT "$_";
      }

      close (OUT);
   } else {
      foreach(@cached_output) {
         print "$_";
      }
   }
}

sub remove_sample_code {
   my $code_found = 0;

   for (my $i = 0; $i < @inputFile; $i++) {
      my $line = $inputFile[$i];

      if ($line =~ /\\code/) {
         $code_found = 1;
      }

      if ($code_found == 1) {
         $inputFile[$i] = "";
      }

      if ($line =~ /\\endcode/) {
         $code_found = 0;
      }
   }
}

sub remove_ifdef_zero {
   my $found = 0;

   for (my $i = 0; $i < @inputFile; $i++) {
      my $line = $inputFile[$i];

      if ($line =~ /#if 0/) {
         $found = 1;
      }

      if ($found == 1) {
         $inputFile[$i] = "";
      }

      if ($line =~ /#endif/) {
         $found = 0;
      }
   }
}

#replace all group definition by subgroup definitions
sub group2subgroup_definitions {
   foreach(@inputFile) {
      $_ =~ s/_IOCTL_/_LL_/g;
      if (($_ =~ /addtogroup/) || ($_ =~ /defgroup/) || ($_ =~ /@/)) {
         #rename all low-level groups to be added to the ETHSW_LL group
         $_ =~ s/ETHSW/$devName/g;
      }

   }
}

#search for the different ETHSW group definition and print them to OUT. Ignore the device specific groups
sub printout_subgroups {
   my $InGroupDefinition = 0;
   my @group_history = ();
   my @group_unsorted = ();
   my $group_unsorted_num = 0;

   foreach(@inputFile) {
      if (($_ =~ /defgroup/) && ($_ =~ /_LL_/)) {
         #get the group name and check by comparing with the history if it is already printed out
         my @names = split / /, $_;
         my $history_found = 0;

         foreach(@group_history) {
            if ($_ =~ $names[2]) {
               $history_found = 1;
               last;
            }
         }

         if ($history_found == 0) {
            #New group definition found
            push(@group_history, $names[2]);

            $InGroupDefinition = 1;
            $group_unsorted[$group_unsorted_num] = "";
            $group_unsorted[$group_unsorted_num] .= "$_";
         }
      }
      elsif ($InGroupDefinition == 1) {
         #additional lines of the definition group
         $group_unsorted[$group_unsorted_num] .= "$_";
         if ($_ =~ /\*\//) {
            # end of comment found
            $InGroupDefinition = 0;
            $group_unsorted_num++;
         }
      }
   }
   my @group_sorted = sort @group_unsorted;

   #now printout the sorted group list
   foreach (@group_sorted) {
      cached_print_output "$_";
   }
}

#subroutine to search for the next ioctl declaration area inside the file based on a given start line index
sub findIoctlLine {
   #arguments
   my $cnt = $_[0];

   for (my $i = $cnt; $i < @inputFile; $i++) {
      if ($inputFile[$i] =~ /IOCTL Command Definitions/) {
         return $i;
      }
   }
   die "ERROR: No IOCTL command definition found!\n";
}

#subroutine to look for the ioctl defines, adapt spaces and index number
sub PrintoutDefines {
   #arguments
   my $startline = $_[0];
   my $stopline = $_[1];
   #print "PrintoutDefines($startline, $stopline)\n";

   my @fkt_descr_unsorted = ();
   my $fkt_descr_unsorted_num = 0;
   my @fkt_name_unsorted = ();

   my $MyCommentStart = 0;
   for (my $i = $startline; $i < $stopline; $i++) {
      if ($inputFile[$i] =~ /addtogroup/) {
         cached_print_output "$inputFile[$i]";
         $fkt_descr_unsorted_num = 0;
         @fkt_name_unsorted = ();
         @fkt_descr_unsorted = ();
      }
      elsif ($inputFile[$i] =~ /@/) {
         #end of group reached
         #now sort the list of functionsnames and then printout the whole function description in sorted order
         my @fkt_name_sorted = sort @fkt_name_unsorted;

         for (my $j = 0; $j < @fkt_name_sorted; $j++) {
            for (my $k = 0; $k < @fkt_name_unsorted; $k++) {
               if ($fkt_name_unsorted[$k] eq $fkt_name_sorted[$j]) {
                  cached_print_output "$fkt_descr_unsorted[$k]";
                  last;
               }
            }
         }

         cached_print_output "$inputFile[$i]";
      }
      elsif ($inputFile[$i] =~ /\/\*\*/) {
         # remember the line where the first comment is placed. This will be also printed out for the function pointer
         # declaration inside the function pointer table declaration
         $MyCommentStart = $i + 1;
      }

      if ($inputFile[$i] =~ /#define/) {
         if ($inputFile[$i] =~ /_IO/) {
            # if line contains backspace at the end -> merge with next line
            if ($inputFile[$i] =~ /\\/) {
               $inputFile[$i] =~ s/\\//g;
               $inputFile[$i] =~ s/\n//g;

               $inputFile[$i] .= $inputFile[$i + 1];
               $inputFile[$i + 1] = "";
            }

            #ioctl define found, remove tabs and all spaces and ensure the their is a space after the comma

            $inputFile[$i] =~ s/,/, /g;
            $inputFile[$i] =~ s/\t/ /g;
            $inputFile[$i] =~ s/  +/ /g;

            #define(0)   IOCTLNAME(1)         _IOWR(IFX_MAGIC(2),    NUMBER(3),    STRUCT(4))
            my @line = split / /, $inputFile[$i];
            my $structure = "void";
            if (@line > 4) {
               $structure = $line[4];
               $structure =~ s/\)//g;
               $structure =~ s/;//g;
               $structure =~ s/\n//g;
            }

            #search for this IOCTL command in the blacklist. If found, leave it out
            my $blackListFound = 0;

            foreach $blEntry (@blackList)
            {
               if (($line[1] =~ $blEntry) && ($blEntry =~ $line[1])) {
                  $blackListFound = 1;
                  last;
               }
            }
            if ($blackListFound == 1) { next;}

            my $my_fkttype = lc $line[1];

            {
               $my_fkttype =~ s/ifx_//;
               my $myFkttypeRight = substr($my_fkttype, index($my_fkttype, "_"));
               my $myFkttypeLeft = substr($my_fkttype, 0, index($my_fkttype, "_"));

               $my_fkttype = sprintf("ifx_%s_fkt%s", $myFkttypeLeft, $myFkttypeRight);
               $my_fkttype = convert2NPF($my_fkttype, $devName);
            }

            my $ifxDevName = lc $devName;
            my $my_fkt = lc $line[1];
            $my_fkt =~ s/ethsw/$ifxDevName/g;
            $my_fkt = convert2NPF($my_fkt, $ifxDevName);

            $fktType[$fktTypeLen] = $my_fkttype;
            $fktTypeShortDescr[$fktTypeLen] = "$line[1] low-level function pointer.";
            $fkt[$fktTypeLen] = $my_fkt;
            $fktTypeLen++;
            #get the maximum funtion name length. This helps to later indent the function pointer table correctly
            if ($ftkTypeMaxLen < length($my_fkttype)) {
               $ftkTypeMaxLen = length($my_fkttype);
            }

            my $fkt_typedef = undef;
            my $fkt_def = undef;
            #example: typedef int (*ifx_fkt_ethsw_cap_get_t) (void *pDevCtx, IFX_ETHSW_CAP_t *pPar);
            #example: int (*ifx_tantoslite_ethsw_cap_get) (void *pDevCtx, IFX_ETHSW_CAP_t *pPar);
            if ($structure =~ /void/) {
               $fkt_typedef = sprintf("typedef IFX_return_t (*%s_t)(IFX_void_t *pDevCtx);", $my_fkttype);
               $fkt_def = sprintf("IFX_return_t %s(IFX_void_t *pDevCtx);\n\n", $my_fkt);
            }
            else {
               $fkt_typedef = sprintf("typedef IFX_return_t (*%s_t)\n   (IFX_void_t *pDevCtx, %s *pPar);", $my_fkttype, $structure);
               $fkt_def = sprintf("IFX_return_t %s(IFX_void_t *pDevCtx, %s *pPar);\n\n", $my_fkt, $structure);
            }

            #add this type definition to the list of type definitions
            $fktTypeList[$fktTypeListLen] = $fkt_typedef;
            $fktTypeListLen++;

            #find beginning and end of the description
            my $begin_descr = 0;
            my $end_descr = 0;

            for (my $j = $i; $j >= 0; $j--) {
               if ($inputFile[$j] =~ /\/\*\*/) {
                  #beginning found
                  $begin_descr = $j;
                  last;
               }
               if ($inputFile[$j] =~ /\*\//) {
                  #end found
                  $end_descr = $j;
               }
            }

            #now modify the parameter description inside the description range
            if (not($structure =~ /void/)) {
               my $param = sprintf("param %s*", $structure);
               my $paramFound = 0;
               for (my $j = $begin_descr; $j <= $end_descr; $j++) {
                  if ($inputFile[$j] =~ /$param/) {
                     $inputFile[$j] =~ s/$param/param pPar/g;
                     $paramFound = 1;
                  }
               }
               if ($paramFound == 0) {
                  die "ERROR: \"$structure\" not given in parameter description in function \"$my_fkt\"!\n";
               }
            }

            #replace the orignal description by: "Low level API for the \ref XXX command"
            for (my $j = $begin_descr; $j <= $end_descr; $j++) {
               if ($inputFile[$j] =~ /\/\*\*/) {
                  #replace the complete first line to ensure that it does contain any comment text
                  $inputFile[$j] = "/**\n   This is the switch API low-level function for \n   the \\ref $line[1] command.\n\n";
                  $inputFile[$j] .= "   \\param pDevCtx This parameter is a pointer to the device context\n";
                  $inputFile[$j] .= "   which contains all information related to this special instance of the device.\n";
               }
               elsif ($inputFile[$j] =~ /\\param/) {
                  if ($structure =~ /void/) {
                     $inputFile[$j] = '';
                  }
                  last;
               }
               else {
                  $inputFile[$j] = '';
               }
            }

            for (my $j = $begin_descr; $j <= $end_descr; $j++) {
               $fkt_descr_unsorted[$fkt_descr_unsorted_num] .= "$inputFile[$j]";
            }
            $fkt_descr_unsorted[$fkt_descr_unsorted_num] .= "$fkt_def";
            $fkt_name_unsorted[$fkt_descr_unsorted_num] .= "$fkt_def";
            $fkt_descr_unsorted_num++;
         }
      }
   }
}

sub generateHeader {

   #place the filename the the filename define in the header and print out to file
   if (defined $options{o}) {
      $outputfile = $options{o};
   } else {
      $outputfile = "STDOUT_PRINT_H";
   }

   $header =~ s/ETHSW/$devName/g;
   $outputfile =~ s/\./_/g;
   $outputfile =~ s/\//_/g;
   $outputfile = uc $outputfile;
   $header =~ s/FILEDEFINE/_$outputfile/g;
   my $tmp = $options{i};
   $tmp =~ s/[^\/]*\///g;
   $header =~ s/INPUTNAME1/$tmp/g;
   $tmp = $options{n};
   $tmp =~ s/[^\/]*\///g;
   $header =~ s/INPUTNAME2/$tmp/g;

   cached_print_output "$header";

   #search for the different ETHSW group definition and print them to OUT. Ignore the device specific groups
   printout_subgroups;

   cached_print_output "/*@}*/\n\n/* ------------------------------------------------------------------------- */
/*                       Function Declaration                                */
/* ------------------------------------------------------------------------- */\n\n";

   #find beginning of the ioctl description
   my $idx = findIoctlLine(0);
   PrintoutDefines($idx, $inputFileLen1);
   $idx = findIoctlLine($inputFileLen1);
   PrintoutDefines($idx, $inputFileLen1 + $inputFileLen2);
}

sub generateFktPtr {
   cached_print_output "/*@}*/\n\n/* ------------------------------------------------------------------------- */
/*                 Global Function Pointer Table Declaration                 */
/* ------------------------------------------------------------------------- */\n\n";

   #printout the type defintion of the function pointer. In future this printout might be moved to a different output file
   for (my $i = 0; $i < $fktTypeListLen; $i++) {
      cached_print_output "$fktTypeList[$i]\n";
   }

   #printout the function pointer table
   cached_print_output "\n/* Global function pointer table. */\n";
   cached_print_output "typedef struct\n{\n";

   for (my $i = 0; $i < $fktTypeLen; $i++) {
      my $my_insertspace = $ftkTypeMaxLen - length($fktType[$i]);
      my $tmp = sprintf("   %s_t", $fktType[$i]);

      for (my $j = 0; $j < $my_insertspace; $j++) {
         $tmp .= " ";
      }
      my $MyDescr = $fktTypeShortDescr[$i];
      $MyDescr =~ s/\n//g;
      $MyDescr =~ s/^\s+//; #remove leading whitespaces
      cached_print_output "   /* $MyDescr */\n";
      cached_print_output "$tmp $fktType[$i];\n";
   }
   my $structName = "IFX_ETHSW_LL_FKT_t";
   $structName =~ s/ETHSW/$devName/;
   cached_print_output "}$structName;\n\n";
}

sub generateHeaderTrailer {
   cached_print_output sprintf("#endif /* _%s */\n", $outputfile);
}

########### main ###########

# parse command line options
getopts("b:fhi:k:m:n:o:", \%options) or die "invalid option\n";

if (defined $options{h}) {
   die PrintHelp;
}

if ((not defined $options{i}) or (not defined $options{n})) {
   print STDERR "ERROR: No input files given!\n\n";
   die PrintHelp;
}

if (not defined $options{m}) {
   print STDERR "ERROR: No module name given!\n\n";
   die PrintHelp;
}
$devName = uc($options{m});

readInputFile;

if (defined $options{k}) {
   readNPFFile $options{k};
}

if (defined $options{b}) {
   @blackList = readinput $options{b};
}

#remove the sample code from the doxygen comments
remove_sample_code;
#remove precompiler '#if 0' parts
remove_ifdef_zero;

#find the subgroup definition inside the inputFile
#replace all group definition by subgroup definitions
group2subgroup_definitions;

generateHeader;
if (defined $options{f}) {
   generateFktPtr;
}
generateHeaderTrailer;

cached_strip_tailing_spaces;
cached_flush_output;
