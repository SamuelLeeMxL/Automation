/****************************************************************************

                               Copyright 2010
                          Lantiq Deutschland GmbH
                   Am Campeon 3; 85579 Neubiberg, Germany

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

*****************************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <ctype.h>
#include "ifx_cli_lib.h"
#include "ifx_ethsw.h"
#include "ifx_ethsw_PSB6970.h"

#ifdef SWITCHAPI_TANTOS_SUPPORT

int ifx_psb6970_qos_mfc_add(int argc, char *argv[], int fd, int numPar)
{
   IFX_PSB6970_QoS_MfcCfg_t mfcCfg;
   int cnt = 0;

   memset(&mfcCfg, 0, sizeof(IFX_PSB6970_QoS_MfcCfg_t));

   cnt += scanParamArg(argc, argv, "sFilterMatchField.nPortSrc", 16, &mfcCfg.sFilterMatchField.nPortSrc);
   cnt += scanParamArg(argc, argv, "sFilterMatchField.nPortDst", 16, &mfcCfg.sFilterMatchField.nPortDst);
   cnt += scanParamArg(argc, argv, "sFilterMatchField.nPortSrcRange", 16, &mfcCfg.sFilterMatchField.nPortSrcRange);
   cnt += scanParamArg(argc, argv, "sFilterMatchField.nProtocol", 8, &mfcCfg.sFilterMatchField.nProtocol);
   cnt += scanParamArg(argc, argv, "sFilterMatchField.nEtherType", 16, &mfcCfg.sFilterMatchField.nEtherType);
   cnt += scanParamArg(argc, argv, "sFilterMatchField.eFieldSelection", 32, &mfcCfg.sFilterMatchField.eFieldSelection);
   cnt += scanParamArg(argc, argv, "sFilterInfo.nTrafficClass", 8, &mfcCfg.sFilterInfo.nTrafficClass);
   cnt += scanParamArg(argc, argv, "sFilterInfo.ePortForward", 32, &mfcCfg.sFilterInfo.ePortForward);

   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_PSB6970_QOS_MFC_ADD, &mfcCfg)) {
      printf("ioctl returned with ERROR!\n");
      return (-3);
   }

   return 0;
}

int ifx_psb6970_qos_mfc_entry_read(int argc, char *argv[], int fd, int numPar)
{
   IFX_PSB6970_QoS_MfcEntryRead_t qos_MfcEntryRead;

   printf("Field PortSrc PortDst PortSrcRange PortDstRange Protocol EtherType TrafficClass PortForward\n");
   printf("===== ======= ======= ============ ============ ======== ========= ============ ===========\n");

   memset(&qos_MfcEntryRead, 0x00, sizeof(qos_MfcEntryRead));
   qos_MfcEntryRead.bInitial = IFX_TRUE;

   for (;;) {
      if (cli_ioctl( fd, IFX_PSB6970_QOS_MFC_ENTRY_READ, &qos_MfcEntryRead )!= IFX_SUCCESS) {
         return (-2);
      }

      if (qos_MfcEntryRead.bLast == IFX_TRUE)
         break;

      switch (qos_MfcEntryRead.sFilter.sFilterMatchField.eFieldSelection)
      {
         case IFX_PSB6970_QOS_MF_ETHERTYPE:
            printf("%5d %7s %7s %12s %12s %8s %9xH%12d %11d\n",
               qos_MfcEntryRead.sFilter.sFilterMatchField.eFieldSelection,
               "", "", "", "", "",
               qos_MfcEntryRead.sFilter.sFilterMatchField.nEtherType,
               qos_MfcEntryRead.sFilter.sFilterInfo.nTrafficClass,
               qos_MfcEntryRead.sFilter.sFilterInfo.ePortForward);
            break;
         case IFX_PSB6970_QOS_MF_PROTOCOL:
            printf("%5d %7s %7s %12s %12s %8d %9s %12s %11d\n",
               qos_MfcEntryRead.sFilter.sFilterMatchField.eFieldSelection,
               "", "", "", "",
               qos_MfcEntryRead.sFilter.sFilterMatchField.nProtocol,
               "", "",
               qos_MfcEntryRead.sFilter.sFilterInfo.ePortForward);
            break;
         case IFX_PSB6970_QOS_MF_SRCPORT:
            printf("%5d %7d %7s %12d %12s %8s %9s %12d %11d\n",
               qos_MfcEntryRead.sFilter.sFilterMatchField.eFieldSelection,
               qos_MfcEntryRead.sFilter.sFilterMatchField.nPortSrc,
               "",
               qos_MfcEntryRead.sFilter.sFilterMatchField.nPortSrcRange,
               "", "", "",
               qos_MfcEntryRead.sFilter.sFilterInfo.nTrafficClass,
               qos_MfcEntryRead.sFilter.sFilterInfo.ePortForward);
            break;
         case IFX_PSB6970_QOS_MF_DSTPORT:
            printf("%5d %7s %7d %12s %12d %8s %9s %12d %11d\n",
               qos_MfcEntryRead.sFilter.sFilterMatchField.eFieldSelection,
               "",
               qos_MfcEntryRead.sFilter.sFilterMatchField.nPortDst,
               "",
               qos_MfcEntryRead.sFilter.sFilterMatchField.nPortDstRange,
               "", "",
               qos_MfcEntryRead.sFilter.sFilterInfo.nTrafficClass,
               qos_MfcEntryRead.sFilter.sFilterInfo.ePortForward);
            break;
      }

      memset(&qos_MfcEntryRead, 0x00, sizeof(qos_MfcEntryRead));
   }

   return 0;
}

int ifx_psb6970_register_set(int argc, char *argv[], int fd, int numPar) {
   IFX_PSB6970_register_t param;
   IFX_uint32_t nSetBits = 0, nClearBits = 0;
   int bitmask_used = 0;

   memset(&param, 0, sizeof(IFX_PSB6970_register_t));

   if (scanParamArg(argc, argv, "nRegAddr", 32, &param.nRegAddr) == 0)
      return (-2);

   if (scanParamArg(argc, argv, "nSetBits", 32, &nSetBits) != 0)
      bitmask_used = 1;

   if (scanParamArg(argc, argv, "nClearBits", 32, &nClearBits) != 0)
      bitmask_used = 1;

   if (bitmask_used == 0) {
      /* Scan 'nData' and write the hardware register. */
      if (scanParamArg(argc, argv, "nData", 32, &param.nData) == 0)
         return (-3);
   } else {
      /* Read the register, set 'nSetBits', clear 'nCleartBits' and
         write hardware register. */
      if (cli_ioctl(fd, IFX_PSB6970_REGISTER_GET, &param) != 0)
         return (-4);

      param.nData = param.nData & ~nClearBits;
      param.nData = param.nData | nSetBits;
   }

   return cli_ioctl(fd, IFX_PSB6970_REGISTER_SET, &param);
}

#endif /* SWITCHAPI_TANTOS_SUPPORT */
