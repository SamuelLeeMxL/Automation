/****************************************************************************

                               Copyright 2010
                          Lantiq Deutschland GmbH
                   Am Campeon 3; 85579 Neubiberg, Germany

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

*****************************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <ctype.h>
#include "ifx_cli_lib.h"
//#include "ifx_ethsw.h"
//#include "ifx_ethsw_flow.h"

#ifdef SWITCHAPI_GSWIP_SUPPORT

#define NUM_TC 16

int ifx_flow_pce_rule_read(int argc, char *argv[], int fd, int numPar)
{
   IFX_FLOW_PCE_rule_t pce_rule;
   int cnt;

   memset(&pce_rule, 0x00, sizeof(pce_rule));

   cnt = scanParamArg(argc, argv, "pattern.nIndex", 32, &pce_rule.pattern.nIndex);

   if (cnt == 0)
      return (-2);

   if(cli_ioctl(fd, IFX_FLOW_PCE_RULE_READ, &pce_rule) != 0)
      return (-3);

   printf("\tpattern.bEnable                   %s\n", (pce_rule.pattern.bEnable > 0)?"TRUE":"FALSE");
   printf("\tpattern.bPortIdEnable             %s\n", (pce_rule.pattern.bPortIdEnable > 0)?"TRUE":"FALSE");
   printf("\tpattern.nPortId                   %d\n", pce_rule.pattern.nPortId);
   printf("\tpattern.bDSCP_Enable              %s\n", (pce_rule.pattern.bDSCP_Enable > 0)?"TRUE":"FALSE");
   printf("\tpattern.nDSCP                     0x%x\n", pce_rule.pattern.nDSCP);
   printf("\tpattern.bPCP_Enable               %s\n", (pce_rule.pattern.bPCP_Enable > 0)?"TRUE":"FALSE");
   printf("\tpattern.nPCP                      0x%x\n", pce_rule.pattern.nPCP);
#ifdef SWAPI_ETC_CHIP  
	printf("\tpattern.bSTAG_PCP_DEI_Enable          %s\n", (pce_rule.pattern.bSTAG_PCP_DEI_Enable > 0)?"TRUE":"FALSE");
	printf("\tpattern.nSTAG_PCP_DEI                 0x%x\n", pce_rule.pattern.nSTAG_PCP_DEI);
#endif   /* SWAPI_ETC_CHIP */
   printf("\tpattern.bPktLngEnable             %s\n", (pce_rule.pattern.bPktLngEnable > 0)?"TRUE":"FALSE");
   printf("\tpattern.nPktLng                   %d\n", pce_rule.pattern.nPktLng);
   printf("\tpattern.nPktLngRange              0x%x\n", pce_rule.pattern.nPktLngRange);
   printf("\tpattern.bMAC_DstEnable            %s\n", (pce_rule.pattern.bMAC_DstEnable > 0)?"TRUE":"FALSE");
   printf("\tpattern.nMAC_Dst[6]               ");
   printMAC_Address(pce_rule.pattern.nMAC_Dst);
   printf("\n\tpattern.nMAC_DstMask              0x%x\n", pce_rule.pattern.nMAC_DstMask);
   printf("\tpattern.bMAC_SrcEnable            %s\n", (pce_rule.pattern.bMAC_SrcEnable > 0)?"TRUE":"FALSE");
   printf("\tpattern.nMAC_Src[6]               ");
   printMAC_Address(pce_rule.pattern.nMAC_Src);
   printf("\n\tpattern.nMAC_SrcMask              0x%x\n", pce_rule.pattern.nMAC_SrcMask);
   printf("\tpattern.bAppDataMSB_Enable        %s\n", (pce_rule.pattern.bAppDataMSB_Enable > 0)?"TRUE":"FALSE");
   printf("\tpattern.nAppDataMSB               0x%x\n", pce_rule.pattern.nAppDataMSB);
   printf("\tpattern.bAppMaskRangeMSB_Select   %s\n", (pce_rule.pattern.bAppMaskRangeMSB_Select > 0)?"TRUE":"FALSE");
   printf("\tpattern.nAppMaskRangeMSB          0x%x\n", pce_rule.pattern.nAppMaskRangeMSB);
   printf("\tpattern.bAppDataLSB_Enable        %s\n", (pce_rule.pattern.bAppDataLSB_Enable > 0)?"TRUE":"FALSE");
   printf("\tpattern.nAppDataLSB               0x%x\n", pce_rule.pattern.nAppDataLSB);
	printf("\tpattern.bAppMaskRangeLSB_Select   %s\n", (pce_rule.pattern.bAppMaskRangeLSB_Select > 0)?"TRUE":"FALSE");
	printf("\tpattern.nAppMaskRangeLSB          0x%x\n", pce_rule.pattern.nAppMaskRangeLSB);
	printf("\tpattern.eDstIP_Select             %d\n", pce_rule.pattern.eDstIP_Select);
   if (pce_rule.pattern.eDstIP_Select == IFX_FLOW_PCE_IP_V4) {
      printf("\tpattern.nDstIP.nIPv4              ");
      printIPv4_Address(pce_rule.pattern.nDstIP.nIPv4);
      printf("\n");
   } else if (pce_rule.pattern.eDstIP_Select == IFX_FLOW_PCE_IP_V6) {
      printf("\tpattern.nDstIP.nIPv6              ");
      printIPv6_Address(pce_rule.pattern.nDstIP.nIPv6);
      printf("\n");
   }
	printf("\tpattern.nDstIP_Mask               0x%x\n", pce_rule.pattern.nDstIP_Mask);
	printf("\tpattern.eSrcIP_Select             %d\n", pce_rule.pattern.eSrcIP_Select);

   if (pce_rule.pattern.eSrcIP_Select == IFX_FLOW_PCE_IP_V4) {
      printf("\tpattern.nSrcIP.nIPv4              ");
      printIPv4_Address(pce_rule.pattern.nSrcIP.nIPv4);
      printf("\n");
   } else if (pce_rule.pattern.eSrcIP_Select == IFX_FLOW_PCE_IP_V6) {
      printf("\tpattern.nSrcIP.nIPv6              ");
      printIPv6_Address(pce_rule.pattern.nSrcIP.nIPv6);
			printf("\n");
   }
	printf("\tpattern.nSrcIP_Mask               0x%x\n", pce_rule.pattern.nSrcIP_Mask);
	printf("\tpattern.bEtherTypeEnable          %s\n", (pce_rule.pattern.bEtherTypeEnable > 0)?"TRUE":"FALSE");
	printf("\tpattern.nEtherType                0x%04x\n", pce_rule.pattern.nEtherType);
	printf("\tpattern.nEtherTypeMask            0x%x\n", pce_rule.pattern.nEtherTypeMask);
	printf("\tpattern.bProtocolEnable           %s\n", (pce_rule.pattern.bProtocolEnable > 0)?"TRUE":"FALSE");
	printf("\tpattern.nProtocol                 0x%x\n", pce_rule.pattern.nProtocol);
	printf("\tpattern.nProtocolMask             0x%x\n", pce_rule.pattern.nProtocolMask);
	printf("\tpattern.bSessionIdEnable          %s\n", (pce_rule.pattern.bSessionIdEnable > 0)?"TRUE":"FALSE");
	printf("\tpattern.nSessionId                0x%x\n", pce_rule.pattern.nSessionId);
	printf("\tpattern.bVid                      %s\n", (pce_rule.pattern.bVid > 0)?"TRUE":"FALSE");
	printf("\tpattern.nVid                      0x%x\n", pce_rule.pattern.nVid);
#ifdef SWAPI_ETC_CHIP 
	printf("\tpattern.bSLAN_Vid                 %s\n", (pce_rule.pattern.bSLAN_Vid > 0)?"TRUE":"FALSE");
	printf("\tpattern.nSLAN_Vid                 0x%x\n", pce_rule.pattern.nSLAN_Vid);
#endif   /* SWAPI_ETC_CHIP */
	printf("\taction.eTrafficClassAction        %d\n", pce_rule.action.eTrafficClassAction);
	printf("\taction.nTrafficClassAlternate     0x%x\n", pce_rule.action.nTrafficClassAlternate);
	printf("\taction.eSnoopingTypeAction        %d\n", pce_rule.action.eSnoopingTypeAction);
	printf("\taction.eLearningAction            %d\n", pce_rule.action.eLearningAction);
	printf("\taction.eIrqAction                 %d\n", pce_rule.action.eIrqAction);
	printf("\taction.eCrossStateAction          %d\n", pce_rule.action.eCrossStateAction);
	printf("\taction.eCritFrameAction           %d\n", pce_rule.action.eCritFrameAction);
	printf("\taction.ePortMapAction             %d\n", pce_rule.action.ePortMapAction);
	printf("\taction.nForwardPortMap            0x%x\n", pce_rule.action.nForwardPortMap);
	printf("\taction.bRemarkAction              %s\n", (pce_rule.action.bRemarkAction > 0)?"TRUE":"FALSE");
	printf("\taction.bRemarkPCP                 %s\n", (pce_rule.action.bRemarkPCP > 0)?"TRUE":"FALSE");
#ifdef SWAPI_ETC_CHIP    	
	printf("\taction.bRemarkSTAG_PCP                 %s\n", (pce_rule.action.bRemarkSTAG_PCP > 0)?"TRUE":"FALSE");
	printf("\taction.bRemarkSTAG_DEI                 %s\n", (pce_rule.action.bRemarkSTAG_DEI > 0)?"TRUE":"FALSE");
#endif /* SWAPI_ETC_CHIP */
	printf("\taction.bRemarkDSCP                %s\n", (pce_rule.action.bRemarkDSCP > 0)?"TRUE":"FALSE");
	printf("\taction.bRemarkClass               %s\n", (pce_rule.action.bRemarkClass > 0)?"TRUE":"FALSE");
	printf("\taction.eMeterAction               %d\n", pce_rule.action.eMeterAction);
	printf("\taction.nMeterId                   %d\n", pce_rule.action.nMeterId);
	printf("\taction.bRMON_Action               %s\n", (pce_rule.action.bRMON_Action > 0)?"TRUE":"FALSE");
	printf("\taction.nRMON_Id                   %d\n", pce_rule.action.nRMON_Id);
	printf("\taction.eVLAN_Action               %d\n", pce_rule.action.eVLAN_Action);
	printf("\taction.nVLAN_Id                   %d\n", pce_rule.action.nVLAN_Id);
#ifdef SWAPI_ETC_CHIP 
	printf("\taction.nFId                  			%d\n", pce_rule.action.nFId);
	printf("\taction.eSVLAN_Action               %d\n", pce_rule.action.eSVLAN_Action);
	printf("\taction.nSVLAN_Id                   %d\n", pce_rule.action.nSVLAN_Id);
	printf("\taction.bPortBitMapMuxControl                %s\n", (pce_rule.action.bPortBitMapMuxControl > 0)?"TRUE":"FALSE");
	printf("\taction.bCVLAN_Ignore_Control                %s\n", (pce_rule.action.bCVLAN_Ignore_Control > 0)?"TRUE":"FALSE");
	printf("\taction.bPortLinkSelection                %s\n", (pce_rule.action.bPortLinkSelection > 0)?"TRUE":"FALSE");
	printf("\taction.bPortTrunkAction                %s\n", (pce_rule.action.bPortTrunkAction > 0)?"TRUE":"FALSE");
#endif  /* SWAPI_ETC_CHIP */
	printf("\taction.eVLAN_CrossAction          %d\n", pce_rule.action.eVLAN_CrossAction);
	printf("\taction.bFlowID_Action             %s\n", (pce_rule.action.bFlowID_Action > 0)?"TRUE":"FALSE");
	printf("\taction.nFlowID                    %d\n", pce_rule.action.nFlowID);

   return IFX_SUCCESS;
}

int ifx_flow_pce_rule_write(int argc, char *argv[], int fd, int numPar)
{
   IFX_FLOW_PCE_rule_t pce_rule;
   int cnt = 0;

   memset(&pce_rule, 0, sizeof(pce_rule));

   cnt += scanParamArg(argc, argv, "pattern.nIndex", 32, &pce_rule.pattern.nIndex);
   cnt += scanParamArg(argc, argv, "pattern.bEnable", 32, &pce_rule.pattern.bEnable);
   cnt += scanParamArg(argc, argv, "pattern.bPortIdEnable", 32, &pce_rule.pattern.bPortIdEnable);
   cnt += scanParamArg(argc, argv, "pattern.nPortId", 8, &pce_rule.pattern.nPortId);
   cnt += scanParamArg(argc, argv, "pattern.bDSCP_Enable", 32, &pce_rule.pattern.bDSCP_Enable);
   cnt += scanParamArg(argc, argv, "pattern.nDSCP", 8, &pce_rule.pattern.nDSCP);
   cnt += scanParamArg(argc, argv, "pattern.bPCP_Enable", 32, &pce_rule.pattern.bPCP_Enable);
   cnt += scanParamArg(argc, argv, "pattern.nPCP", 8, &pce_rule.pattern.nPCP);
#ifdef SWAPI_ETC_CHIP   
	cnt += scanParamArg(argc, argv, "pattern.bSTAG_PCP_DEI_Enable", 32, &pce_rule.pattern.bSTAG_PCP_DEI_Enable);
	cnt += scanParamArg(argc, argv, "pattern.nSTAG_PCP_DEI", 8, &pce_rule.pattern.nSTAG_PCP_DEI);
#endif   /* SWAPI_ETC_CHIP */
   cnt += scanParamArg(argc, argv, "pattern.bPktLngEnable", 32, &pce_rule.pattern.bPktLngEnable);
   cnt += scanParamArg(argc, argv, "pattern.nPktLng", 16, &pce_rule.pattern.nPktLng);
   cnt += scanParamArg(argc, argv, "pattern.nPktLngRange", 16, &pce_rule.pattern.nPktLngRange);
   cnt += scanParamArg(argc, argv, "pattern.bMAC_DstEnable", 32, &pce_rule.pattern.bMAC_DstEnable);
   cnt += scanMAC_Arg(argc, argv, "pattern.nMAC_Dst", pce_rule.pattern.nMAC_Dst);
   cnt += scanParamArg(argc, argv, "pattern.nMAC_DstMask", 16, &pce_rule.pattern.nMAC_DstMask);
   cnt += scanParamArg(argc, argv, "pattern.bMAC_SrcEnable", 32, &pce_rule.pattern.bMAC_SrcEnable);
   cnt += scanMAC_Arg(argc, argv, "pattern.nMAC_Src", pce_rule.pattern.nMAC_Src);
   cnt += scanParamArg(argc, argv, "pattern.nMAC_SrcMask", 16, &pce_rule.pattern.nMAC_SrcMask);
   cnt += scanParamArg(argc, argv, "pattern.bAppDataMSB_Enable", 32, &pce_rule.pattern.bAppDataMSB_Enable);
   cnt += scanParamArg(argc, argv, "pattern.nAppDataMSB", 16, &pce_rule.pattern.nAppDataMSB);
   cnt += scanParamArg(argc, argv, "pattern.bAppMaskRangeMSB_Select", 32, &pce_rule.pattern.bAppMaskRangeMSB_Select);
   cnt += scanParamArg(argc, argv, "pattern.nAppMaskRangeMSB", 16, &pce_rule.pattern.nAppMaskRangeMSB);
   cnt += scanParamArg(argc, argv, "pattern.bAppDataLSB_Enable", 32, &pce_rule.pattern.bAppDataLSB_Enable);
   cnt += scanParamArg(argc, argv, "pattern.nAppDataLSB", 16, &pce_rule.pattern.nAppDataLSB);
   cnt += scanParamArg(argc, argv, "pattern.bAppMaskRangeLSB_Select", 32, &pce_rule.pattern.bAppMaskRangeLSB_Select);
   cnt += scanParamArg(argc, argv, "pattern.nAppMaskRangeLSB", 16, &pce_rule.pattern.nAppMaskRangeLSB);
   cnt += scanParamArg(argc, argv, "pattern.eDstIP_Select", 32, &pce_rule.pattern.eDstIP_Select);
   if (pce_rule.pattern.eDstIP_Select == IFX_FLOW_PCE_IP_V4)
      cnt += scanIPv4_Arg(argc, argv, "pattern.nDstIP", &pce_rule.pattern.nDstIP.nIPv4);
   else if (pce_rule.pattern.eDstIP_Select == IFX_FLOW_PCE_IP_V6)
      cnt += scanIPv6_Arg(argc, argv, "pattern.nDstIP", pce_rule.pattern.nDstIP.nIPv6);
   cnt += scanParamArg(argc, argv, "pattern.nDstIP_Mask", 32, &pce_rule.pattern.nDstIP_Mask);
   cnt += scanParamArg(argc, argv, "pattern.eSrcIP_Select", 32, &pce_rule.pattern.eSrcIP_Select);
   if (pce_rule.pattern.eSrcIP_Select == IFX_FLOW_PCE_IP_V4)
      cnt += scanIPv4_Arg(argc, argv, "pattern.nSrcIP", &pce_rule.pattern.nSrcIP.nIPv4);
   else if (pce_rule.pattern.eSrcIP_Select == IFX_FLOW_PCE_IP_V6)
      cnt += scanIPv6_Arg(argc, argv, "pattern.nSrcIP", pce_rule.pattern.nSrcIP.nIPv6);
   cnt += scanParamArg(argc, argv, "pattern.nSrcIP_Mask", 32, &pce_rule.pattern.nSrcIP_Mask);
   cnt += scanParamArg(argc, argv, "pattern.bEtherTypeEnable", 32, &pce_rule.pattern.bEtherTypeEnable);
   cnt += scanParamArg(argc, argv, "pattern.nEtherType", 16, &pce_rule.pattern.nEtherType);
   cnt += scanParamArg(argc, argv, "pattern.nEtherTypeMask", 16, &pce_rule.pattern.nEtherTypeMask);
   cnt += scanParamArg(argc, argv, "pattern.bProtocolEnable", 32, &pce_rule.pattern.bProtocolEnable);
   cnt += scanParamArg(argc, argv, "pattern.nProtocol", 8, &pce_rule.pattern.nProtocol);
   cnt += scanParamArg(argc, argv, "pattern.nProtocolMask", 8, &pce_rule.pattern.nProtocolMask);
   cnt += scanParamArg(argc, argv, "pattern.bSessionIdEnable", 32, &pce_rule.pattern.bSessionIdEnable);
   cnt += scanParamArg(argc, argv, "pattern.nSessionId", 16, &pce_rule.pattern.nSessionId);
   cnt += scanParamArg(argc, argv, "pattern.bVid", 32, &pce_rule.pattern.bVid);
   cnt += scanParamArg(argc, argv, "pattern.nVid", 16, &pce_rule.pattern.nVid);
#ifdef SWAPI_ETC_CHIP 
	cnt += scanParamArg(argc, argv, "pattern.bSLAN_Vid", 32, &pce_rule.pattern.bSLAN_Vid);
	cnt += scanParamArg(argc, argv, "pattern.nSLAN_Vid", 16, &pce_rule.pattern.nSLAN_Vid);
#endif   /* SWAPI_ETC_CHIP */
   cnt += scanParamArg(argc, argv, "action.eTrafficClassAction", 32, &pce_rule.action.eTrafficClassAction);
   cnt += scanParamArg(argc, argv, "action.nTrafficClassAlternate", 8, &pce_rule.action.nTrafficClassAlternate);
   cnt += scanParamArg(argc, argv, "action.eSnoopingTypeAction", 32, &pce_rule.action.eSnoopingTypeAction);
   cnt += scanParamArg(argc, argv, "action.eLearningAction", 32, &pce_rule.action.eLearningAction);
   cnt += scanParamArg(argc, argv, "action.eIrqAction", 32, &pce_rule.action.eIrqAction);
   cnt += scanParamArg(argc, argv, "action.eCrossStateAction", 32, &pce_rule.action.eCrossStateAction);
   cnt += scanParamArg(argc, argv, "action.eCritFrameAction", 32, &pce_rule.action.eCritFrameAction);
   cnt += scanParamArg(argc, argv, "action.ePortMapAction", 32, &pce_rule.action.ePortMapAction);
   cnt += scanParamArg(argc, argv, "action.nForwardPortMap", 32, &pce_rule.action.nForwardPortMap);
   cnt += scanParamArg(argc, argv, "action.bRemarkAction", 32, &pce_rule.action.bRemarkAction);
   cnt += scanParamArg(argc, argv, "action.bRemarkPCP", 32, &pce_rule.action.bRemarkPCP);
#ifdef SWAPI_ETC_CHIP    
	cnt += scanParamArg(argc, argv, "action.bRemarkSTAG_PCP", 32, &pce_rule.action.bRemarkSTAG_PCP);
	cnt += scanParamArg(argc, argv, "action.bRemarkSTAG_DEI", 32, &pce_rule.action.bRemarkSTAG_DEI);
#endif   /* SWAPI_ETC_CHIP */
   cnt += scanParamArg(argc, argv, "action.bRemarkDSCP", 32, &pce_rule.action.bRemarkDSCP);
   cnt += scanParamArg(argc, argv, "action.bRemarkClass", 32, &pce_rule.action.bRemarkClass);
   cnt += scanParamArg(argc, argv, "action.eMeterAction", 32, &pce_rule.action.eMeterAction);
   cnt += scanParamArg(argc, argv, "action.nMeterId", 8, &pce_rule.action.nMeterId);
   cnt += scanParamArg(argc, argv, "action.bRMON_Action", 32, &pce_rule.action.bRMON_Action);
   cnt += scanParamArg(argc, argv, "action.nRMON_Id", 8, &pce_rule.action.nRMON_Id);
   cnt += scanParamArg(argc, argv, "action.eVLAN_Action", 32, &pce_rule.action.eVLAN_Action);
   cnt += scanParamArg(argc, argv, "action.nVLAN_Id", 16, &pce_rule.action.nVLAN_Id);
#ifdef SWAPI_ETC_CHIP  
	cnt += scanParamArg(argc, argv, "action.eSVLAN_Action", 32, &pce_rule.action.eSVLAN_Action);
	cnt += scanParamArg(argc, argv, "action.nSVLAN_Id", 16, &pce_rule.action.nSVLAN_Id);
#endif   /* SWAPI_ETC_CHIP */
   cnt += scanParamArg(argc, argv, "action.eVLAN_CrossAction", 32, &pce_rule.action.eVLAN_CrossAction);
   cnt += scanParamArg(argc, argv, "action.bFlowID_Action", 32, &pce_rule.action.bFlowID_Action);
   cnt += scanParamArg(argc, argv, "action.nFlowID", 16, &pce_rule.action.nFlowID);
#ifdef SWAPI_ETC_CHIP 
	cnt += scanParamArg(argc, argv, "action.nFId", 8, &pce_rule.action.nFId);
	cnt += scanParamArg(argc, argv, "action.bPortBitMapMuxControl", 32, &pce_rule.action.bPortBitMapMuxControl);
	cnt += scanParamArg(argc, argv, "action.bCVLAN_Ignore_Control", 32, &pce_rule.action.bCVLAN_Ignore_Control);
	cnt += scanParamArg(argc, argv, "action.bPortLinkSelection", 32, &pce_rule.action.bPortLinkSelection);
	cnt += scanParamArg(argc, argv, "action.bPortTrunkAction", 32, &pce_rule.action.bPortTrunkAction);
#endif /* SWAPI_ETC_CHIP */
   
   if (cnt != numPar) return (-2);
   if (cnt == 0) return (-3);
   return cli_ioctl(fd, IFX_FLOW_PCE_RULE_WRITE, &pce_rule);
}

int ifx_flow_rmon_extend_get(int argc, char *argv[], int fd, int numPar)
{
   IFX_FLOW_RMON_extendGet_t param;
   int cnt, i;
   memset(&param, 0, sizeof(IFX_FLOW_RMON_extendGet_t));

   cnt = scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   if (cnt != 1)
      return (-2);

   if (cli_ioctl(fd, IFX_FLOW_RMON_EXTEND_GET, &param)) {
      printf("ioctl returned with ERROR!\n");
      return (-3);
   }

   for (i = 0; i < IFX_FLOW_RMON_EXTEND_NUM; i++) {
      printf("RMON Counter [%d] = %d\n", i, param.nTrafficFlowCnt[i]);
   }

   return IFX_SUCCESS;
}

int ifx_flow_rmon_extend_set(int argc, char *argv[], int fd, int numPar)
{
   return IFX_ERROR;
}

int ifx_flow_timestamp_timer_get(int argc, char *argv[], int fd, int numPar)
{
	IFX_FLOW_TIMESTAMP_Timer_t param;
	memset(&param, 0, sizeof(IFX_FLOW_TIMESTAMP_Timer_t));
   
	if (cli_ioctl(fd, IFX_FLOW_TIMESTAMP_TIMER_GET, &param)) {
		printf("ioctl returned with ERROR!\n");
		return (-3);
	}
	printHex32Value("nSec", param.nSec, 0);
	printHex32Value("nNanoSec", param.nNanoSec, 0);
	printHex32Value("nFractionalNanoSec", param.nFractionalNanoSec, 0);
	return IFX_SUCCESS;
}

int ifx_flow_timestamp_timer_set(int argc, char *argv[], int fd, int numPar)
{
	IFX_FLOW_TIMESTAMP_Timer_t param;
	int cnt=0;
	memset(&param, 0, sizeof(IFX_FLOW_TIMESTAMP_Timer_t));
	if (cli_ioctl(fd, IFX_FLOW_TIMESTAMP_TIMER_GET, &param)) {
		printf("ioctl returned with ERROR!\n");
		return (-3);
	}
	cnt += scanParamArg(argc, argv, "nSec", 32, &param.nSec);
	cnt += scanParamArg(argc, argv, "nNanoSec", 32, &param.nNanoSec);
	cnt += scanParamArg(argc, argv, "nFractionalNanoSec", 32, &param.nFractionalNanoSec);
	if (cnt != numPar)
		return (-2);
	if (cli_ioctl(fd, IFX_FLOW_TIMESTAMP_TIMER_SET, &param)) {
		printf("ioctl returned with ERROR!\n");
		return (-3);
	}
	return IFX_SUCCESS;
}

int ifx_flow_timestamp_port_read(int argc, char *argv[], int fd, int numPar)
{
	IFX_FLOW_TIMESTAMP_PortRead_t param;
	int cnt, i;
	memset(&param, 0, sizeof(IFX_FLOW_TIMESTAMP_PortRead_t));
	cnt = scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
	if (cnt != numPar)
		return (-2);
	if (cli_ioctl(fd, IFX_FLOW_TIMESTAMP_PORT_READ, &param)) {
		printf("ioctl returned with ERROR!\n");
		return (-3);
	}
	printHex32Value("nPortId", param.nPortId, 0);
	printHex32Value("nIngressSec", param.nIngressSec, 0);
	printHex32Value("nIngressNanoSec", param.nIngressNanoSec, 0);
	printHex32Value("nEgressSec", param.nEgressSec, 0);
	printHex32Value("nEgressNanoSec", param.nEgressNanoSec, 0);
	return IFX_SUCCESS;
}
int ifx_flow_boot_get(int argc, char *argv[], int fd, int numPar)
{
   return IFX_ERROR;
}

int ifx_flow_boot_set(int argc, char *argv[], int fd, int numPar)
{
   return IFX_ERROR;
}

int ifx_flow_rmon_extend_clear(int argc, char *argv[], int fd, int numPar)
{
   return IFX_ERROR;
}

int ifx_flow_register_set(int argc, char *argv[], int fd, int numPar) {
   IFX_FLOW_register_t param;
   u16 nSetBits = 0, nClearBits = 0;
   int bitmask_used = 0;

   memset(&param, 0, sizeof(IFX_FLOW_register_t));

   if (scanParamArg(argc, argv, "nRegAddr", 16, &param.nRegAddr) == 0)
      return (-2);

   if (scanParamArg(argc, argv, "nSetBits", 16, &nSetBits) != 0)
      bitmask_used = 1;

   if (scanParamArg(argc, argv, "nClearBits", 16, &nClearBits) != 0)
      bitmask_used = 1;

   if (bitmask_used == 0) {
      /* Scan 'nData' and write the hardware register. */
      if (scanParamArg(argc, argv, "nData", 16, &param.nData) == 0)
         return (-3);
   } else {
      /* Read the register, set 'nSetBits', clear 'nCleartBits' and
         write hardware register. */
      if (cli_ioctl(fd, IFX_FLOW_REGISTER_GET, &param) != 0)
         return (-4);

      param.nData = param.nData & ~nClearBits;
      param.nData = param.nData | nSetBits;
   }

   return cli_ioctl(fd, IFX_FLOW_REGISTER_SET, &param);
}

int ifx_ethsw_qos_queue_port_get(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_QoS_queuePort_t queuePortParam;
   int tc;

	if (findStringParam(argc, argv, "listunused")) {
		/* printout the unused Queues of the whole switch.
		   First read out the capability retreaving the total amount of queues.
		   Then read the queue assignment of all traffic classes of all ports.
		   Then printout the list of all unused queues. */
		IFX_ETHSW_cap_t capParam;
		int numQueues, numPorts, port, i;
		char *ptrQueues;

		memset(&capParam, 0, sizeof(IFX_ETHSW_cap_t));
		capParam.nCapType = IFX_ETHSW_CAP_TYPE_PRIORITY_QUEUE;
		if (cli_ioctl(fd, IFX_ETHSW_CAP_GET, &capParam) != 0) {
			printf("ioctl returned with ERROR!\n");
			return (-1);
		}
		numQueues = capParam.nCap;

		memset(&capParam, 0, sizeof(IFX_ETHSW_cap_t));
		capParam.nCapType = IFX_ETHSW_CAP_TYPE_PORT;
		if (cli_ioctl(fd, IFX_ETHSW_CAP_GET, &capParam) != 0) {
			printf("ioctl returned with ERROR!\n");
			return (-1);
		}
		numPorts = capParam.nCap;

		/* allocate temporary buffer which will be freed later again */
		ptrQueues = malloc(numQueues);
		if (ptrQueues == NULL) {
			printf("Could not allocate memory!\n");
			return (-1);
		}

		memset(ptrQueues, 0, numQueues);

		for (port = 0; port < numPorts; port++) {
			for (tc = 0; tc < NUM_TC; tc++) {
				memset(&queuePortParam, 0, sizeof(IFX_ETHSW_QoS_queuePort_t));
				queuePortParam.nPortId = port;
				queuePortParam.nTrafficClassId = tc;

				if (cli_ioctl(fd, IFX_ETHSW_QOS_QUEUE_PORT_GET, &queuePortParam) != 0) {
					printf("ioctl returned with ERROR!\n");
					/* free temporary buffer */
					free(ptrQueues);
					return (-1);
				}

				if (queuePortParam.nQueueId < numQueues) {
					/* mark the queue as used */
					ptrQueues[queuePortParam.nQueueId] = 1;
				}
			}
		}

		printf("\nList of unused Egress Traffic Class Queue Indices:\n"
				 "--------------------------------------------------\n");

		for (i = 0; i < numQueues; i++) {
			if (ptrQueues[i] == 0) {
				printf("Queue %2d unused\n", i);
			}
		}

		printf("\n");

		/* free temporary buffer */
		free(ptrQueues);
		return 0;
	}

	memset(&queuePortParam, 0, sizeof(IFX_ETHSW_QoS_queuePort_t));

   if(scanParamArg(argc, argv, "nPortId", 8, &queuePortParam.nPortId)) {
		if (scanParamArg(argc, argv, "nTrafficClassId", 8, &queuePortParam.nTrafficClassId)) {
			if (cli_ioctl(fd, IFX_ETHSW_QOS_QUEUE_PORT_GET, &queuePortParam) != 0) {
				printf("ioctl returned with ERROR!\n");
				return (-1);
			}

			printf("Returned values:\n----------------\n");
			printHex32Value("nPortId", queuePortParam.nPortId, 8);
			printHex32Value("nTrafficClassId", queuePortParam.nTrafficClassId, 0);
			printHex32Value("nQueueId", queuePortParam.nQueueId, 0);
		} else {
			/* printout all queues of that port */
			printf("\n Port | Traffic Class | Egress Queue\n");
			printf("---------------------------------------\n");

			for (tc = 0; tc < NUM_TC; tc++) {
				queuePortParam.nTrafficClassId = tc;

				if (cli_ioctl(fd, IFX_ETHSW_QOS_QUEUE_PORT_GET, &queuePortParam) != 0) {
					printf("ioctl returned with ERROR!\n");
					return (-1);
				}

				printf(" %4d | %13d | %12d\n",
						 queuePortParam.nPortId,
						 queuePortParam.nTrafficClassId,
						 queuePortParam.nQueueId);
			}
			printf("---------------------------------------\n");
		}
	}
   return 0;
}

#endif /* SWITCHAPI_GSWIP_SUPPORT */
