/****************************************************************************

                               Copyright 2010
                          Lantiq Deutschland GmbH
                   Am Campeon 3; 85579 Neubiberg, Germany

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

*****************************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <ctype.h>
//#include "ifx_ethsw.h"
//#include "ifx_ethsw_PSB6970.h"
//#include "ifx_ethsw_flow.h"
#include "ifx_cli_lib.h"

int ifx_ethsw_8021x_eapol_rule_set(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_8021X_EAPOL_Rule_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_8021X_EAPOL_Rule_t));

   if(cli_ioctl(fd, IFX_ETHSW_8021X_EAPOL_RULE_GET, &param) != 0)
      return (-4);

   cnt += scanParamArg(argc, argv, "eForwardPort", 32, &param.eForwardPort);
   cnt += scanParamArg(argc, argv, "nForwardPortId", 8, &param.nForwardPortId);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_8021X_EAPOL_RULE_SET, &param);
}

int ifx_ethsw_8021x_port_cfg_set(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_8021X_portCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_8021X_portCfg_t));

   cnt += scanParamArg(argc, argv, "nPortId", 32, &param.nPortId);
   if (cnt != 1)
      return (-3);

   if(cli_ioctl(fd, IFX_ETHSW_8021X_PORT_CFG_GET, &param) != 0)
      return (-4);

   cnt += scanParamArg(argc, argv, "eState", 32, &param.eState);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_8021X_PORT_CFG_SET, &param);
}

int ifx_ethsw_cfg_set(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_cfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_cfg_t));

   if(cli_ioctl(fd, IFX_ETHSW_CFG_GET, &param) != 0)
      return (-4);

   cnt += scanParamArg(argc, argv, "eMAC_TableAgeTimer", 32, &param.eMAC_TableAgeTimer);
   cnt += scanParamArg(argc, argv, "bVLAN_Aware", 32, &param.bVLAN_Aware);
   cnt += scanParamArg(argc, argv, "nMaxPacketLen", 16, &param.nMaxPacketLen);
   cnt += scanParamArg(argc, argv, "bLearningLimitAction", 32, &param.bLearningLimitAction);
   cnt += scanParamArg(argc, argv, "bPauseMAC_ModeSrc", 32, &param.bPauseMAC_ModeSrc);
   cnt += scanMAC_Arg(argc, argv, "nPauseMAC_Src", param.nPauseMAC_Src);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_CFG_SET, &param);
}

int ifx_ethsw_cpu_port_cfg_set(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_CPU_PortCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_CPU_PortCfg_t));

   cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   if (cnt != 1)
      return (-3);

   if(cli_ioctl(fd, IFX_ETHSW_CPU_PORT_CFG_GET, &param) != 0)
      return (-4);

   cnt += scanParamArg(argc, argv, "bCPU_PortValid", 32, &param.bCPU_PortValid);
   cnt += scanParamArg(argc, argv, "bSpecialTagIngress", 32, &param.bSpecialTagIngress);
   cnt += scanParamArg(argc, argv, "bSpecialTagEgress", 32, &param.bSpecialTagEgress);
   cnt += scanParamArg(argc, argv, "bFcsCheck", 32, &param.bFcsCheck);
   cnt += scanParamArg(argc, argv, "bFcsGenerate", 32, &param.bFcsGenerate);
   cnt += scanParamArg(argc, argv, "bSpecialTagEthType", 32, &param.bSpecialTagEthType);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_CPU_PORT_CFG_SET, &param);
}

int ifx_ethsw_disable(int argc, char *argv[], int fd, int numPar) {
   return cli_ioctl(fd, IFX_ETHSW_DISABLE, 0);
}

int ifx_ethsw_enable(int argc, char *argv[], int fd, int numPar) {
   return cli_ioctl(fd, IFX_ETHSW_ENABLE, 0);
}

int ifx_ethsw_hw_init(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_HW_Init_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_HW_Init_t));

   cnt += scanParamArg(argc, argv, "eInitMode", 32, &param.eInitMode);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_HW_INIT, &param);
}

int ifx_ethsw_mac_table_clear(int argc, char *argv[], int fd, int numPar) {
   return cli_ioctl(fd, IFX_ETHSW_MAC_TABLE_CLEAR, 0);
}

int ifx_ethsw_mac_table_entry_add(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_MAC_tableAdd_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_MAC_tableAdd_t));

   cnt += scanParamArg(argc, argv, "nFId", 32, &param.nFId);
   cnt += scanParamArg(argc, argv, "nPortId", 32, &param.nPortId);
   cnt += scanParamArg(argc, argv, "nAgeTimer", 32, &param.nAgeTimer);
   cnt += scanParamArg(argc, argv, "bStaticEntry", 32, &param.bStaticEntry);
   cnt += scanParamArg(argc, argv, "nTrafficClass", 8, &param.nTrafficClass);
   cnt += scanMAC_Arg(argc, argv, "nMAC", param.nMAC);
#ifdef SWAPI_ETC_CHIP 
	cnt += scanParamArg(argc, argv, "nSVLAN_Id", 16, &param.nSVLAN_Id);
#endif  /* SWAPI_ETC_CHIP */  
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_MAC_TABLE_ENTRY_ADD, &param);
}

int ifx_ethsw_mac_table_entry_remove(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_MAC_tableRemove_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_MAC_tableRemove_t));

   cnt += scanParamArg(argc, argv, "nFId", 32, &param.nFId);
   cnt += scanMAC_Arg(argc, argv, "nMAC", param.nMAC);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_MAC_TABLE_ENTRY_REMOVE, &param);
}

int ifx_ethsw_mdio_cfg_set(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_MDIO_cfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_MDIO_cfg_t));

   if(cli_ioctl(fd, IFX_ETHSW_MDIO_CFG_GET, &param) != 0)
      return (-4);

   cnt += scanParamArg(argc, argv, "nMDIO_Speed", 32, &param.nMDIO_Speed);
   cnt += scanParamArg(argc, argv, "bMDIO_Enable", 32, &param.bMDIO_Enable);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_MDIO_CFG_SET, &param);
}

int ifx_ethsw_mdio_data_write(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_MDIO_data_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_MDIO_data_t));

   cnt += scanParamArg(argc, argv, "nAddressDev", 8, &param.nAddressDev);
   cnt += scanParamArg(argc, argv, "nAddressReg", 8, &param.nAddressReg);
   cnt += scanParamArg(argc, argv, "nData", 16, &param.nData);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_MDIO_DATA_WRITE, &param);
}

int ifx_ethsw_mmd_data_write(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_MMD_data_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_MMD_data_t));

   cnt += scanParamArg(argc, argv, "nAddressDev", 8, &param.nAddressDev);
   cnt += scanParamArg(argc, argv, "nAddressReg", 32, &param.nAddressReg);
   cnt += scanParamArg(argc, argv, "nData", 16, &param.nData);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_MMD_DATA_WRITE, &param);
}

int ifx_ethsw_monitor_port_cfg_set(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_monitorPortCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_monitorPortCfg_t));

   cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   if (cnt != 1)
      return (-3);

   if(cli_ioctl(fd, IFX_ETHSW_MONITOR_PORT_CFG_GET, &param) != 0)
      return (-4);

   cnt += scanParamArg(argc, argv, "bMonitorPort", 32, &param.bMonitorPort);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_MONITOR_PORT_CFG_SET, &param);
}

int ifx_ethsw_multicast_router_port_add(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_multicastRouter_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_multicastRouter_t));

   cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_MULTICAST_ROUTER_PORT_ADD, &param);
}

int ifx_ethsw_multicast_router_port_remove(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_multicastRouter_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_multicastRouter_t));

   cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_MULTICAST_ROUTER_PORT_REMOVE, &param);
}

int ifx_ethsw_multicast_snoop_cfg_set(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_multicastSnoopCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_multicastSnoopCfg_t));

   if(cli_ioctl(fd, IFX_ETHSW_MULTICAST_SNOOP_CFG_GET, &param) != 0)
      return (-4);

   cnt += scanParamArg(argc, argv, "eIGMP_Mode", 32, &param.eIGMP_Mode);
   cnt += scanParamArg(argc, argv, "bIGMPv3", 32, &param.bIGMPv3);
   cnt += scanParamArg(argc, argv, "bCrossVLAN", 32, &param.bCrossVLAN);
   cnt += scanParamArg(argc, argv, "eForwardPort", 32, &param.eForwardPort);
   cnt += scanParamArg(argc, argv, "nForwardPortId", 8, &param.nForwardPortId);
   cnt += scanParamArg(argc, argv, "nClassOfService", 8, &param.nClassOfService);
   cnt += scanParamArg(argc, argv, "nRobust", 8, &param.nRobust);
   cnt += scanParamArg(argc, argv, "nQueryInterval", 8, &param.nQueryInterval);
   cnt += scanParamArg(argc, argv, "eSuppressionAggregation", 32, &param.eSuppressionAggregation);
   cnt += scanParamArg(argc, argv, "bFastLeave", 32, &param.bFastLeave);
   cnt += scanParamArg(argc, argv, "bLearningRouter", 32, &param.bLearningRouter);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_MULTICAST_SNOOP_CFG_SET, &param);
}

int ifx_ethsw_port_cfg_set(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_portCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_portCfg_t));

   cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   if (cnt != 1)
      return (-3);

   if(cli_ioctl(fd, IFX_ETHSW_PORT_CFG_GET, &param) != 0)
      return (-4);

   cnt += scanParamArg(argc, argv, "eEnable", 32, &param.eEnable);
   cnt += scanParamArg(argc, argv, "bUnicastUnknownDrop", 32, &param.bUnicastUnknownDrop);
   cnt += scanParamArg(argc, argv, "bMulticastUnknownDrop", 32, &param.bMulticastUnknownDrop);
   cnt += scanParamArg(argc, argv, "bReservedPacketDrop", 32, &param.bReservedPacketDrop);
   cnt += scanParamArg(argc, argv, "bBroadcastDrop", 32, &param.bBroadcastDrop);
   cnt += scanParamArg(argc, argv, "bAging", 32, &param.bAging);
   cnt += scanParamArg(argc, argv, "bLearning", 32, &param.bLearning);
   cnt += scanParamArg(argc, argv, "bLearningMAC_PortLock", 32, &param.bLearningMAC_PortLock);
   cnt += scanParamArg(argc, argv, "nLearningLimit", 16, &param.nLearningLimit);
   cnt += scanParamArg(argc, argv, "bMAC_SpoofingDetection", 32, &param.bMAC_SpoofingDetection);
   cnt += scanParamArg(argc, argv, "eFlowCtrl", 32, &param.eFlowCtrl);
   cnt += scanParamArg(argc, argv, "ePortMonitor", 32, &param.ePortMonitor);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_PORT_CFG_SET, &param);
}

int ifx_ethsw_port_link_cfg_set(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_portLinkCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_portLinkCfg_t));

   cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   if (cnt != 1)
      return (-3);

   if(cli_ioctl(fd, IFX_ETHSW_PORT_LINK_CFG_GET, &param) != 0)
      return (-4);

   cnt += scanParamArg(argc, argv, "bDuplexForce", 32, &param.bDuplexForce);
   cnt += scanParamArg(argc, argv, "eDuplex", 32, &param.eDuplex);
   cnt += scanParamArg(argc, argv, "bSpeedForce", 32, &param.bSpeedForce);
   cnt += scanParamArg(argc, argv, "eSpeed", 32, &param.eSpeed);
   cnt += scanParamArg(argc, argv, "bLinkForce", 32, &param.bLinkForce);
   cnt += scanParamArg(argc, argv, "eLink", 32, &param.eLink);
   cnt += scanParamArg(argc, argv, "eMII_Mode", 32, &param.eMII_Mode);
   cnt += scanParamArg(argc, argv, "eMII_Type", 32, &param.eMII_Type);
   cnt += scanParamArg(argc, argv, "eClkMode", 32, &param.eClkMode);
   cnt += scanParamArg(argc, argv, "bLPI", 32, &param.bLPI);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_PORT_LINK_CFG_SET, &param);
}

int ifx_ethsw_port_redirect_set(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_portRedirectCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_portRedirectCfg_t));

   cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   if (cnt != 1)
      return (-3);

   if(cli_ioctl(fd, IFX_ETHSW_PORT_REDIRECT_GET, &param) != 0)
      return (-4);

   cnt += scanParamArg(argc, argv, "bRedirectEgress", 32, &param.bRedirectEgress);
   cnt += scanParamArg(argc, argv, "bRedirectIngress", 32, &param.bRedirectIngress);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_PORT_REDIRECT_SET, &param);
}

int ifx_ethsw_port_rgmii_clk_cfg_set(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_portRGMII_ClkCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_portRGMII_ClkCfg_t));

   cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   if (cnt != 1)
      return (-3);

   if(cli_ioctl(fd, IFX_ETHSW_PORT_RGMII_CLK_CFG_GET, &param) != 0)
      return (-4);

   cnt += scanParamArg(argc, argv, "nDelayRx", 8, &param.nDelayRx);
   cnt += scanParamArg(argc, argv, "nDelayTx", 8, &param.nDelayTx);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_PORT_RGMII_CLK_CFG_SET, &param);
}

int ifx_ethsw_qos_meter_cfg_set(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_QoS_meterCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_QoS_meterCfg_t));

   cnt += scanParamArg(argc, argv, "nMeterId", 32, &param.nMeterId);
   if (cnt != 1)
      return (-3);

   if(cli_ioctl(fd, IFX_ETHSW_QOS_METER_CFG_GET, &param) != 0)
      return (-4);

   cnt += scanParamArg(argc, argv, "bEnable", 32, &param.bEnable);
   cnt += scanParamArg(argc, argv, "nCbs", 32, &param.nCbs);
   cnt += scanParamArg(argc, argv, "nEbs", 32, &param.nEbs);
   cnt += scanParamArg(argc, argv, "nRate", 32, &param.nRate);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_QOS_METER_CFG_SET, &param);
}

int ifx_ethsw_qos_meter_port_assign(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_QoS_meterPort_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_QoS_meterPort_t));

   cnt += scanParamArg(argc, argv, "nMeterId", 32, &param.nMeterId);
   cnt += scanParamArg(argc, argv, "eDir", 32, &param.eDir);
   cnt += scanParamArg(argc, argv, "nPortIngressId", 32, &param.nPortIngressId);
   cnt += scanParamArg(argc, argv, "nPortEgressId", 32, &param.nPortEgressId);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_QOS_METER_PORT_ASSIGN, &param);
}

int ifx_ethsw_qos_meter_port_deassign(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_QoS_meterPort_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_QoS_meterPort_t));

   cnt += scanParamArg(argc, argv, "nMeterId", 32, &param.nMeterId);
   cnt += scanParamArg(argc, argv, "eDir", 32, &param.eDir);
   cnt += scanParamArg(argc, argv, "nPortIngressId", 32, &param.nPortIngressId);
   cnt += scanParamArg(argc, argv, "nPortEgressId", 32, &param.nPortEgressId);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_QOS_METER_PORT_DEASSIGN, &param);
}

int ifx_ethsw_qos_port_cfg_set(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_QoS_portCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_QoS_portCfg_t));

   cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   if (cnt != 1)
      return (-3);

   if(cli_ioctl(fd, IFX_ETHSW_QOS_PORT_CFG_GET, &param) != 0)
      return (-4);

   cnt += scanParamArg(argc, argv, "eClassMode", 32, &param.eClassMode);
   cnt += scanParamArg(argc, argv, "nTrafficClass", 8, &param.nTrafficClass);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_QOS_PORT_CFG_SET, &param);
}

int ifx_ethsw_qos_port_remarking_cfg_set(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_QoS_portRemarkingCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_QoS_portRemarkingCfg_t));

   cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   if (cnt != 1)
      return (-3);

   if(cli_ioctl(fd, IFX_ETHSW_QOS_PORT_REMARKING_CFG_GET, &param) != 0)
      return (-4);

   cnt += scanParamArg(argc, argv, "eDSCP_IngressRemarkingEnable", 32, &param.eDSCP_IngressRemarkingEnable);
   cnt += scanParamArg(argc, argv, "bDSCP_EgressRemarkingEnable", 32, &param.bDSCP_EgressRemarkingEnable);
   cnt += scanParamArg(argc, argv, "bPCP_IngressRemarkingEnable", 32, &param.bPCP_IngressRemarkingEnable);
   cnt += scanParamArg(argc, argv, "bPCP_EgressRemarkingEnable", 32, &param.bPCP_EgressRemarkingEnable);
#ifdef SWAPI_ETC_CHIP 
	cnt += scanParamArg(argc, argv, "bSTAG_PCP_IngressRemarkingEnable", 32, &param.bSTAG_PCP_IngressRemarkingEnable);
	cnt += scanParamArg(argc, argv, "bSTAG_DEI_IngressRemarkingEnable", 32, &param.bSTAG_DEI_IngressRemarkingEnable);
	cnt += scanParamArg(argc, argv, "bSTAG_PCP_DEI_EgressRemarkingEnable", 32, &param.bSTAG_PCP_DEI_EgressRemarkingEnable);
#endif /* SWAPI_ETC_CHIP */
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_QOS_PORT_REMARKING_CFG_SET, &param);
}

#ifdef SWITCHAPI_GSWIP_SUPPORT

int ifx_ethsw_qos_queue_port_set(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_QoS_queuePort_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_QoS_queuePort_t));

   cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   cnt += scanParamArg(argc, argv, "nTrafficClassId", 8, &param.nTrafficClassId);
   if (cnt != 2)
      return (-3);

   if(cli_ioctl(fd, IFX_ETHSW_QOS_QUEUE_PORT_GET, &param) != 0)
      return (-4);

   cnt += scanParamArg(argc, argv, "nQueueId", 8, &param.nQueueId);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_QOS_QUEUE_PORT_SET, &param);
}

#endif /* SWITCHAPI_GSWIP_SUPPORT */

int ifx_ethsw_qos_scheduler_cfg_set(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_QoS_schedulerCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_QoS_schedulerCfg_t));

   cnt += scanParamArg(argc, argv, "nQueueId", 8, &param.nQueueId);
   if (cnt != 1)
      return (-3);

   if(cli_ioctl(fd, IFX_ETHSW_QOS_SCHEDULER_CFG_GET, &param) != 0)
      return (-4);

   cnt += scanParamArg(argc, argv, "eType", 32, &param.eType);
   cnt += scanParamArg(argc, argv, "nWeight", 32, &param.nWeight);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_QOS_SCHEDULER_CFG_SET, &param);
}

int ifx_ethsw_qos_shaper_cfg_set(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_QoS_ShaperCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_QoS_ShaperCfg_t));

   cnt += scanParamArg(argc, argv, "nRateShaperId", 32, &param.nRateShaperId);
   if (cnt != 1)
      return (-3);

   if(cli_ioctl(fd, IFX_ETHSW_QOS_SHAPER_CFG_GET, &param) != 0)
      return (-4);

   cnt += scanParamArg(argc, argv, "bEnable", 32, &param.bEnable);
   cnt += scanParamArg(argc, argv, "nCbs", 32, &param.nCbs);
   cnt += scanParamArg(argc, argv, "nRate", 32, &param.nRate);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_QOS_SHAPER_CFG_SET, &param);
}

int ifx_ethsw_qos_shaper_queue_assign(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_QoS_ShaperQueue_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_QoS_ShaperQueue_t));

   cnt += scanParamArg(argc, argv, "nRateShaperId", 8, &param.nRateShaperId);
   cnt += scanParamArg(argc, argv, "nQueueId", 8, &param.nQueueId);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_QOS_SHAPER_QUEUE_ASSIGN, &param);
}

int ifx_ethsw_qos_shaper_queue_deassign(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_QoS_ShaperQueue_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_QoS_ShaperQueue_t));

   cnt += scanParamArg(argc, argv, "nRateShaperId", 8, &param.nRateShaperId);
   cnt += scanParamArg(argc, argv, "nQueueId", 8, &param.nQueueId);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_QOS_SHAPER_QUEUE_DEASSIGN, &param);
}

int ifx_ethsw_qos_storm_cfg_set(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_QoS_stormCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_QoS_stormCfg_t));

   cnt += scanParamArg(argc, argv, "nMeterId", 32, &param.nMeterId);
   cnt += scanParamArg(argc, argv, "bBroadcast", 32, &param.bBroadcast);
   cnt += scanParamArg(argc, argv, "bMulticast", 32, &param.bMulticast);
   cnt += scanParamArg(argc, argv, "bUnknownUnicast", 32, &param.bUnknownUnicast);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_QOS_STORM_CFG_SET, &param);
}

int ifx_ethsw_qos_wred_cfg_set(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_QoS_WRED_Cfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_QoS_WRED_Cfg_t));

   if(cli_ioctl(fd, IFX_ETHSW_QOS_WRED_CFG_GET, &param) != 0)
      return (-4);

   cnt += scanParamArg(argc, argv, "eProfile", 32, &param.eProfile);
   cnt += scanParamArg(argc, argv, "nRed_Min", 32, &param.nRed_Min);
   cnt += scanParamArg(argc, argv, "nRed_Max", 32, &param.nRed_Max);
   cnt += scanParamArg(argc, argv, "nYellow_Min", 32, &param.nYellow_Min);
   cnt += scanParamArg(argc, argv, "nYellow_Max", 32, &param.nYellow_Max);
   cnt += scanParamArg(argc, argv, "nGreen_Min", 32, &param.nGreen_Min);
   cnt += scanParamArg(argc, argv, "nGreen_Max", 32, &param.nGreen_Max);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_QOS_WRED_CFG_SET, &param);
}

int ifx_ethsw_qos_wred_queue_cfg_set(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_QoS_WRED_QueueCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_QoS_WRED_QueueCfg_t));

   cnt += scanParamArg(argc, argv, "nQueueId", 32, &param.nQueueId);
   if (cnt != 1)
      return (-3);

   if(cli_ioctl(fd, IFX_ETHSW_QOS_WRED_QUEUE_CFG_GET, &param) != 0)
      return (-4);

   cnt += scanParamArg(argc, argv, "nRed_Min", 32, &param.nRed_Min);
   cnt += scanParamArg(argc, argv, "nRed_Max", 32, &param.nRed_Max);
   cnt += scanParamArg(argc, argv, "nYellow_Min", 32, &param.nYellow_Min);
   cnt += scanParamArg(argc, argv, "nYellow_Max", 32, &param.nYellow_Max);
   cnt += scanParamArg(argc, argv, "nGreen_Min", 32, &param.nGreen_Min);
   cnt += scanParamArg(argc, argv, "nGreen_Max", 32, &param.nGreen_Max);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_QOS_WRED_QUEUE_CFG_SET, &param);
}

int ifx_ethsw_rmon_clear(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_RMON_clear_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_RMON_clear_t));

   cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_RMON_CLEAR, &param);
}

int ifx_ethsw_stp_bpdu_rule_set(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_STP_BPDU_Rule_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_STP_BPDU_Rule_t));

   if(cli_ioctl(fd, IFX_ETHSW_STP_BPDU_RULE_GET, &param) != 0)
      return (-4);

   cnt += scanParamArg(argc, argv, "eForwardPort", 32, &param.eForwardPort);
   cnt += scanParamArg(argc, argv, "nForwardPortId", 8, &param.nForwardPortId);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_STP_BPDU_RULE_SET, &param);
}

int ifx_ethsw_stp_port_cfg_set(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_STP_portCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_STP_portCfg_t));

   cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   if (cnt != 1)
      return (-3);

   if(cli_ioctl(fd, IFX_ETHSW_STP_PORT_CFG_GET, &param) != 0)
      return (-4);

   cnt += scanParamArg(argc, argv, "ePortState", 32, &param.ePortState);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_STP_PORT_CFG_SET, &param);
}

int ifx_ethsw_vlan_id_create(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_VLAN_IdCreate_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_VLAN_IdCreate_t));

   cnt += scanParamArg(argc, argv, "nVId", 16, &param.nVId);
   cnt += scanParamArg(argc, argv, "nFId", 32, &param.nFId);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_VLAN_ID_CREATE, &param);
}

int ifx_ethsw_vlan_id_delete(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_VLAN_IdDelete_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_VLAN_IdDelete_t));

   cnt += scanParamArg(argc, argv, "nVId", 16, &param.nVId);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_VLAN_ID_DELETE, &param);
}

int ifx_ethsw_vlan_port_cfg_set(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_VLAN_portCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_VLAN_portCfg_t));

   cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   if (cnt != 1)
      return (-3);

   if(cli_ioctl(fd, IFX_ETHSW_VLAN_PORT_CFG_GET, &param) != 0)
      return (-4);

   cnt += scanParamArg(argc, argv, "nPortVId", 16, &param.nPortVId);
   cnt += scanParamArg(argc, argv, "bVLAN_UnknownDrop", 32, &param.bVLAN_UnknownDrop);
   cnt += scanParamArg(argc, argv, "bVLAN_ReAssign", 32, &param.bVLAN_ReAssign);
   cnt += scanParamArg(argc, argv, "eVLAN_MemberViolation", 32, &param.eVLAN_MemberViolation);
   cnt += scanParamArg(argc, argv, "eAdmitMode", 32, &param.eAdmitMode);
   cnt += scanParamArg(argc, argv, "bTVM", 32, &param.bTVM);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_VLAN_PORT_CFG_SET, &param);
}

int ifx_ethsw_vlan_port_member_add(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_VLAN_portMemberAdd_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_VLAN_portMemberAdd_t));

   cnt += scanParamArg(argc, argv, "nVId", 16, &param.nVId);
   cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   cnt += scanParamArg(argc, argv, "bVLAN_TagEgress", 32, &param.bVLAN_TagEgress);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_VLAN_PORT_MEMBER_ADD, &param);
}

int ifx_ethsw_vlan_port_member_remove(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_VLAN_portMemberRemove_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_VLAN_portMemberRemove_t));

   cnt += scanParamArg(argc, argv, "nVId", 16, &param.nVId);
   cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_VLAN_PORT_MEMBER_REMOVE, &param);
}

int ifx_ethsw_vlan_reserved_add(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_VLAN_reserved_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_VLAN_reserved_t));

   cnt += scanParamArg(argc, argv, "nVId", 16, &param.nVId);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_VLAN_RESERVED_ADD, &param);
}

int ifx_ethsw_vlan_reserved_remove(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_VLAN_reserved_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_VLAN_reserved_t));

   cnt += scanParamArg(argc, argv, "nVId", 16, &param.nVId);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_VLAN_RESERVED_REMOVE, &param);
}

int ifx_ethsw_wol_cfg_set(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_WoL_Cfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_WoL_Cfg_t));

   if(cli_ioctl(fd, IFX_ETHSW_WOL_CFG_GET, &param) != 0)
      return (-4);

   cnt += scanMAC_Arg(argc, argv, "nWolMAC", param.nWolMAC);
   cnt += scanMAC_Arg(argc, argv, "nWolPassword", param.nWolPassword);
   cnt += scanParamArg(argc, argv, "bWolPasswordEnable", 32, &param.bWolPasswordEnable);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_WOL_CFG_SET, &param);
}

int ifx_ethsw_wol_port_cfg_set(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_WoL_PortCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_WoL_PortCfg_t));

   cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   if (cnt != 1)
      return (-3);

   if(cli_ioctl(fd, IFX_ETHSW_WOL_PORT_CFG_GET, &param) != 0)
      return (-4);

   cnt += scanParamArg(argc, argv, "bWakeOnLAN_Enable", 32, &param.bWakeOnLAN_Enable);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_ETHSW_WOL_PORT_CFG_SET, &param);
}

#ifdef SWITCHAPI_GSWIP_SUPPORT

int ifx_flow_irq_mask_set(int argc, char *argv[], int fd, int numPar) {
   IFX_FLOW_irq_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_FLOW_irq_t));

   cnt += scanParamArg(argc, argv, "nPortId", 32, &param.nPortId);
   cnt += scanParamArg(argc, argv, "eIrqSrc", 32, &param.eIrqSrc);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_FLOW_IRQ_MASK_SET, &param);
}

int ifx_flow_irq_status_clear(int argc, char *argv[], int fd, int numPar) {
   IFX_FLOW_irq_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_FLOW_irq_t));

   cnt += scanParamArg(argc, argv, "nPortId", 32, &param.nPortId);
   cnt += scanParamArg(argc, argv, "eIrqSrc", 32, &param.eIrqSrc);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_FLOW_IRQ_STATUS_CLEAR, &param);
}

int ifx_flow_pce_rule_delete(int argc, char *argv[], int fd, int numPar) {
   IFX_FLOW_PCE_ruleDelete_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_FLOW_PCE_ruleDelete_t));

   cnt += scanParamArg(argc, argv, "nIndex", 32, &param.nIndex);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_FLOW_PCE_RULE_DELETE, &param);
}

int ifx_flow_reset(int argc, char *argv[], int fd, int numPar) {
   IFX_FLOW_reset_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_FLOW_reset_t));

   cnt += scanParamArg(argc, argv, "eReset", 32, &param.eReset);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_FLOW_RESET, &param);
}

#endif /* SWITCHAPI_GSWIP_SUPPORT */

#ifdef SWITCHAPI_TANTOS_SUPPORT

int ifx_psb6970_power_management_set(int argc, char *argv[], int fd, int numPar) {
   IFX_PSB6970_powerManagement_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_PSB6970_powerManagement_t));

   cnt += scanParamArg(argc, argv, "bEnable", 32, &param.bEnable);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_PSB6970_POWER_MANAGEMENT_SET, &param);
}

int ifx_psb6970_qos_mfc_del(int argc, char *argv[], int fd, int numPar) {
   IFX_PSB6970_QoS_MfcMatchField_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_PSB6970_QoS_MfcMatchField_t));

   cnt += scanParamArg(argc, argv, "nPortSrc", 16, &param.nPortSrc);
   cnt += scanParamArg(argc, argv, "nPortDst", 16, &param.nPortDst);
   cnt += scanParamArg(argc, argv, "nPortSrcRange", 16, &param.nPortSrcRange);
   cnt += scanParamArg(argc, argv, "nPortDstRange", 16, &param.nPortDstRange);
   cnt += scanParamArg(argc, argv, "nProtocol", 8, &param.nProtocol);
   cnt += scanParamArg(argc, argv, "nEtherType", 16, &param.nEtherType);
   cnt += scanParamArg(argc, argv, "eFieldSelection", 32, &param.eFieldSelection);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_PSB6970_QOS_MFC_DEL, &param);
}

int ifx_psb6970_qos_mfc_port_cfg_set(int argc, char *argv[], int fd, int numPar) {
   IFX_PSB6970_QoS_MfcPortCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_PSB6970_QoS_MfcPortCfg_t));

   cnt += scanParamArg(argc, argv, "nPort", 32, &param.nPort);
   if (cnt != 1)
      return (-3);

   if(cli_ioctl(fd, IFX_PSB6970_QOS_MFC_PORT_CFG_GET, &param) != 0)
      return (-4);

   cnt += scanParamArg(argc, argv, "bPriorityPort", 32, &param.bPriorityPort);
   cnt += scanParamArg(argc, argv, "bPriorityEtherType", 32, &param.bPriorityEtherType);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_PSB6970_QOS_MFC_PORT_CFG_SET, &param);
}

int ifx_psb6970_qos_port_policer_set(int argc, char *argv[], int fd, int numPar) {
   IFX_PSB6970_QoS_portPolicerCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_PSB6970_QoS_portPolicerCfg_t));

   cnt += scanParamArg(argc, argv, "nPort", 32, &param.nPort);
   if (cnt != 1)
      return (-3);

   if(cli_ioctl(fd, IFX_PSB6970_QOS_PORT_POLICER_GET, &param) != 0)
      return (-4);

   cnt += scanParamArg(argc, argv, "nRate", 32, &param.nRate);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_PSB6970_QOS_PORT_POLICER_SET, &param);
}

int ifx_psb6970_qos_port_shaper_cfg_set(int argc, char *argv[], int fd, int numPar) {
   IFX_PSB6970_QoS_portShaperCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_PSB6970_QoS_portShaperCfg_t));

   cnt += scanParamArg(argc, argv, "nPort", 32, &param.nPort);
   cnt += scanParamArg(argc, argv, "eWFQ_Type", 32, &param.eWFQ_Type);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_PSB6970_QOS_PORT_SHAPER_CFG_SET, &param);
}

int ifx_psb6970_qos_port_shaper_strict_set(int argc, char *argv[], int fd, int numPar) {
   IFX_PSB6970_QoS_portShaperStrictCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_PSB6970_QoS_portShaperStrictCfg_t));

   cnt += scanParamArg(argc, argv, "nPort", 32, &param.nPort);
   cnt += scanParamArg(argc, argv, "nTrafficClass", 8, &param.nTrafficClass);
   cnt += scanParamArg(argc, argv, "nRate", 32, &param.nRate);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_PSB6970_QOS_PORT_SHAPER_STRICT_SET, &param);
}

int ifx_psb6970_qos_port_shaper_wfq_set(int argc, char *argv[], int fd, int numPar) {
   IFX_PSB6970_QoS_portShaperWFQ_Cfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_PSB6970_QoS_portShaperWFQ_Cfg_t));

   cnt += scanParamArg(argc, argv, "nPort", 32, &param.nPort);
   cnt += scanParamArg(argc, argv, "nTrafficClass", 8, &param.nTrafficClass);
   cnt += scanParamArg(argc, argv, "nRate", 32, &param.nRate);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_PSB6970_QOS_PORT_SHAPER_WFQ_SET, &param);
}

int ifx_psb6970_qos_storm_set(int argc, char *argv[], int fd, int numPar) {
   IFX_PSB6970_QoS_stormCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_PSB6970_QoS_stormCfg_t));

   if(cli_ioctl(fd, IFX_PSB6970_QOS_STORM_GET, &param) != 0)
      return (-4);

   cnt += scanParamArg(argc, argv, "bBroadcast", 32, &param.bBroadcast);
   cnt += scanParamArg(argc, argv, "bMulticast", 32, &param.bMulticast);
   cnt += scanParamArg(argc, argv, "bUnicast", 32, &param.bUnicast);
   cnt += scanParamArg(argc, argv, "nThreshold10M", 32, &param.nThreshold10M);
   cnt += scanParamArg(argc, argv, "nThreshold100M", 32, &param.nThreshold100M);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_PSB6970_QOS_STORM_SET, &param);
}

int ifx_psb6970_reset(int argc, char *argv[], int fd, int numPar) {
   IFX_PSB6970_reset_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_PSB6970_reset_t));

   cnt += scanParamArg(argc, argv, "eReset", 32, &param.eReset);
   if (cnt != numPar)
      return (-2);

   return cli_ioctl(fd, IFX_PSB6970_RESET, &param);
}

#endif /* SWITCHAPI_TANTOS_SUPPORT */

int ifx_ethsw_8021x_eapol_rule_get(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_8021X_EAPOL_Rule_t param;
   memset(&param, 0, sizeof(IFX_ETHSW_8021X_EAPOL_Rule_t));

   if (cli_ioctl(fd, IFX_ETHSW_8021X_EAPOL_RULE_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("eForwardPort", param.eForwardPort, 0);
   printHex32Value("nForwardPortId", param.nForwardPortId, 0);
   return 0;
}

int ifx_ethsw_8021x_port_cfg_get(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_8021X_portCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_8021X_portCfg_t));

   cnt += scanParamArg(argc, argv, "nPortId", 32, &param.nPortId);
   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_ETHSW_8021X_PORT_CFG_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nPortId", param.nPortId, 32);
   printHex32Value("eState", param.eState, 0);
   return 0;
}

int ifx_ethsw_cfg_get(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_cfg_t param;
   memset(&param, 0, sizeof(IFX_ETHSW_cfg_t));

   if (cli_ioctl(fd, IFX_ETHSW_CFG_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("eMAC_TableAgeTimer", param.eMAC_TableAgeTimer, 0);
   printf("\t%40s:\t%s\n", "bVLAN_Aware", (param.bVLAN_Aware > 0)?"TRUE":"FALSE");
   printHex32Value("nMaxPacketLen", param.nMaxPacketLen, 0);
   printf("\t%40s:\t%s\n", "bLearningLimitAction", (param.bLearningLimitAction > 0)?"TRUE":"FALSE");
   printf("\t%40s:\t%s\n", "bPauseMAC_ModeSrc", (param.bPauseMAC_ModeSrc > 0)?"TRUE":"FALSE");
   printf("\t%40s:\t", "nPauseMAC_Src");
   printMAC_Address(param.nPauseMAC_Src);
   printf("\n");
   return 0;
}

int ifx_ethsw_cpu_port_cfg_get(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_CPU_PortCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_CPU_PortCfg_t));

   cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_ETHSW_CPU_PORT_CFG_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nPortId", param.nPortId, 8);
   printf("\t%40s:\t%s\n", "bCPU_PortValid", (param.bCPU_PortValid > 0)?"TRUE":"FALSE");
   printf("\t%40s:\t%s\n", "bSpecialTagIngress", (param.bSpecialTagIngress > 0)?"TRUE":"FALSE");
   printf("\t%40s:\t%s\n", "bSpecialTagEgress", (param.bSpecialTagEgress > 0)?"TRUE":"FALSE");
   printf("\t%40s:\t%s\n", "bFcsCheck", (param.bFcsCheck > 0)?"TRUE":"FALSE");
   printf("\t%40s:\t%s\n", "bFcsGenerate", (param.bFcsGenerate > 0)?"TRUE":"FALSE");
   printHex32Value("bSpecialTagEthType", param.bSpecialTagEthType, 0);
   return 0;
}

int ifx_ethsw_mac_table_entry_query(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_MAC_tableQuery_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_MAC_tableQuery_t));

   cnt += scanMAC_Arg(argc, argv, "nMAC", param.nMAC);
   cnt += scanParamArg(argc, argv, "nFId", 32, &param.nFId);
   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_ETHSW_MAC_TABLE_ENTRY_QUERY, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printf("\t%40s:\t", "nMAC");
   printMAC_Address(param.nMAC);
   printf("\n");
   printHex32Value("nFId", param.nFId, 0);
   printf("\t%40s:\t%s\n", "bFound", (param.bFound > 0)?"TRUE":"FALSE");
   printHex32Value("nPortId", param.nPortId, 32);
   printHex32Value("nAgeTimer", param.nAgeTimer, 0);
#ifdef SWAPI_ETC_CHIP 
	printHex32Value("nSVLAN_Id", param.nSVLAN_Id, 0);
#endif /* SWAPI_ETC_CHIP */
   printf("\t%40s:\t%s\n", "bStaticEntry", (param.bStaticEntry > 0)?"TRUE":"FALSE");
   return 0;
}

int ifx_ethsw_mdio_cfg_get(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_MDIO_cfg_t param;
   memset(&param, 0, sizeof(IFX_ETHSW_MDIO_cfg_t));

   if (cli_ioctl(fd, IFX_ETHSW_MDIO_CFG_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nMDIO_Speed", param.nMDIO_Speed, 0);
   printf("\t%40s:\t%s\n", "bMDIO_Enable", (param.bMDIO_Enable > 0)?"TRUE":"FALSE");
   return 0;
}

int ifx_ethsw_mdio_data_read(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_MDIO_data_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_MDIO_data_t));

   cnt += scanParamArg(argc, argv, "nAddressDev", 8, &param.nAddressDev);
   cnt += scanParamArg(argc, argv, "nAddressReg", 8, &param.nAddressReg);
   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_ETHSW_MDIO_DATA_READ, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nAddressDev", param.nAddressDev, 0);
   printHex32Value("nAddressReg", param.nAddressReg, 0);
   printHex32Value("nData", param.nData, 0);
   return 0;
}

int ifx_ethsw_mmd_data_read(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_MMD_data_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_MMD_data_t));

   cnt += scanParamArg(argc, argv, "nAddressDev", 8, &param.nAddressDev);
   cnt += scanParamArg(argc, argv, "nAddressReg", 32, &param.nAddressReg);
   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_ETHSW_MMD_DATA_READ, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nAddressDev", param.nAddressDev, 0);
   printHex32Value("nAddressReg", param.nAddressReg, 0);
   printHex32Value("nData", param.nData, 0);
   return 0;
}

int ifx_ethsw_monitor_port_cfg_get(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_monitorPortCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_monitorPortCfg_t));

   cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_ETHSW_MONITOR_PORT_CFG_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nPortId", param.nPortId, 8);
   printf("\t%40s:\t%s\n", "bMonitorPort", (param.bMonitorPort > 0)?"TRUE":"FALSE");
   return 0;
}

int ifx_ethsw_multicast_snoop_cfg_get(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_multicastSnoopCfg_t param;
   memset(&param, 0, sizeof(IFX_ETHSW_multicastSnoopCfg_t));

   if (cli_ioctl(fd, IFX_ETHSW_MULTICAST_SNOOP_CFG_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("eIGMP_Mode", param.eIGMP_Mode, 0);
   printf("\t%40s:\t%s\n", "bIGMPv3", (param.bIGMPv3 > 0)?"TRUE":"FALSE");
   printf("\t%40s:\t%s\n", "bCrossVLAN", (param.bCrossVLAN > 0)?"TRUE":"FALSE");
   printHex32Value("eForwardPort", param.eForwardPort, 0);
   printHex32Value("nForwardPortId", param.nForwardPortId, 0);
   printHex32Value("nClassOfService", param.nClassOfService, 0);
   printHex32Value("nRobust", param.nRobust, 0);
   printHex32Value("nQueryInterval", param.nQueryInterval, 0);
   printHex32Value("eSuppressionAggregation", param.eSuppressionAggregation, 0);
   printf("\t%40s:\t%s\n", "bFastLeave", (param.bFastLeave > 0)?"TRUE":"FALSE");
   printf("\t%40s:\t%s\n", "bLearningRouter", (param.bLearningRouter > 0)?"TRUE":"FALSE");
   return 0;
}

int ifx_ethsw_port_cfg_get(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_portCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_portCfg_t));

   cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_ETHSW_PORT_CFG_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nPortId", param.nPortId, 8);
   printHex32Value("eEnable", param.eEnable, 0);
   printf("\t%40s:\t%s\n", "bUnicastUnknownDrop", (param.bUnicastUnknownDrop > 0)?"TRUE":"FALSE");
   printf("\t%40s:\t%s\n", "bMulticastUnknownDrop", (param.bMulticastUnknownDrop > 0)?"TRUE":"FALSE");
   printf("\t%40s:\t%s\n", "bReservedPacketDrop", (param.bReservedPacketDrop > 0)?"TRUE":"FALSE");
   printf("\t%40s:\t%s\n", "bBroadcastDrop", (param.bBroadcastDrop > 0)?"TRUE":"FALSE");
   printf("\t%40s:\t%s\n", "bAging", (param.bAging > 0)?"TRUE":"FALSE");
	printf("\t%40s:\t%s\n", "bLearning", (param.bLearning > 0)?"TRUE":"FALSE");
   printf("\t%40s:\t%s\n", "bLearningMAC_PortLock", (param.bLearningMAC_PortLock > 0)?"TRUE":"FALSE");
	printf("\t%40s:\t%s\n", "bMAC_SpoofingDetection", (param.bMAC_SpoofingDetection > 0)?"TRUE":"FALSE");
   printHex32Value("nLearningLimit", param.nLearningLimit, 0);
   printHex32Value("eFlowCtrl", param.eFlowCtrl, 0);
   printHex32Value("ePortMonitor", param.ePortMonitor, 0);
   return 0;
}

int ifx_ethsw_port_link_cfg_get(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_portLinkCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_portLinkCfg_t));

   cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_ETHSW_PORT_LINK_CFG_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nPortId", param.nPortId, 8);
   printf("\t%40s:\t%s\n", "bDuplexForce", (param.bDuplexForce > 0)?"TRUE":"FALSE");
   printHex32Value("eDuplex", param.eDuplex, 0);
   printf("\t%40s:\t%s\n", "bSpeedForce", (param.bSpeedForce > 0)?"TRUE":"FALSE");
   printHex32Value("eSpeed", param.eSpeed, 0);
   printf("\t%40s:\t%s\n", "bLinkForce", (param.bLinkForce > 0)?"TRUE":"FALSE");
   printHex32Value("eLink", param.eLink, 0);
   printHex32Value("eMII_Mode", param.eMII_Mode, 0);
   printHex32Value("eMII_Type", param.eMII_Type, 0);
   printHex32Value("eClkMode", param.eClkMode, 0);
   printf("\t%40s:\t%s\n", "bLPI", (param.bLPI > 0)?"TRUE":"FALSE");
   return 0;
}

int ifx_ethsw_port_phy_addr_get(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_portPHY_Addr_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_portPHY_Addr_t));

   cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_ETHSW_PORT_PHY_ADDR_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nPortId", param.nPortId, 8);
   printHex32Value("nAddressDev", param.nAddressDev, 0);
   return 0;
}

int ifx_ethsw_port_phy_query(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_portPHY_Query_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_portPHY_Query_t));

   cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_ETHSW_PORT_PHY_QUERY, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nPortId", param.nPortId, 8);
   printf("\t%40s:\t%s\n", "bPHY_Present", (param.bPHY_Present > 0)?"TRUE":"FALSE");
   return 0;
}

int ifx_ethsw_port_redirect_get(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_portRedirectCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_portRedirectCfg_t));

   cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_ETHSW_PORT_REDIRECT_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nPortId", param.nPortId, 8);
   printf("\t%40s:\t%s\n", "bRedirectEgress", (param.bRedirectEgress > 0)?"TRUE":"FALSE");
   printf("\t%40s:\t%s\n", "bRedirectIngress", (param.bRedirectIngress > 0)?"TRUE":"FALSE");
   return 0;
}

int ifx_ethsw_port_rgmii_clk_cfg_get(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_portRGMII_ClkCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_portRGMII_ClkCfg_t));

   cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_ETHSW_PORT_RGMII_CLK_CFG_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nPortId", param.nPortId, 8);
   printHex32Value("nDelayRx", param.nDelayRx, 0);
   printHex32Value("nDelayTx", param.nDelayTx, 0);
   return 0;
}

int ifx_ethsw_qos_meter_cfg_get(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_QoS_meterCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_QoS_meterCfg_t));

   cnt += scanParamArg(argc, argv, "nMeterId", 32, &param.nMeterId);
   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_ETHSW_QOS_METER_CFG_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printf("\t%40s:\t%s\n", "bEnable", (param.bEnable > 0)?"TRUE":"FALSE");
   printHex32Value("nMeterId", param.nMeterId, 0);
   printHex32Value("nCbs", param.nCbs, 0);
   printHex32Value("nEbs", param.nEbs, 0);
   printHex32Value("nRate", param.nRate, 0);
   return 0;
}

int ifx_ethsw_qos_port_cfg_get(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_QoS_portCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_QoS_portCfg_t));

   cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_ETHSW_QOS_PORT_CFG_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nPortId", param.nPortId, 8);
   printHex32Value("eClassMode", param.eClassMode, 0);
   printHex32Value("nTrafficClass", param.nTrafficClass, 0);
   return 0;
}

int ifx_ethsw_qos_port_remarking_cfg_get(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_QoS_portRemarkingCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_QoS_portRemarkingCfg_t));

   cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_ETHSW_QOS_PORT_REMARKING_CFG_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nPortId", param.nPortId, 8);
   printHex32Value("eDSCP_IngressRemarkingEnable", param.eDSCP_IngressRemarkingEnable, 0);
   printf("\t%40s:\t%s\n", "bDSCP_EgressRemarkingEnable", (param.bDSCP_EgressRemarkingEnable > 0)?"TRUE":"FALSE");
   printf("\t%40s:\t%s\n", "bPCP_IngressRemarkingEnable", (param.bPCP_IngressRemarkingEnable > 0)?"TRUE":"FALSE");
   printf("\t%40s:\t%s\n", "bPCP_EgressRemarkingEnable", (param.bPCP_EgressRemarkingEnable > 0)?"TRUE":"FALSE");
#ifdef SWAPI_ETC_CHIP    	
	printf("\t%40s:\t%s\n", "bSTAG_PCP_IngressRemarkingEnable", (param.bSTAG_PCP_IngressRemarkingEnable > 0)?"TRUE":"FALSE");
	printf("\t%40s:\t%s\n", "bSTAG_DEI_IngressRemarkingEnable", (param.bSTAG_DEI_IngressRemarkingEnable > 0)?"TRUE":"FALSE");
	printf("\t%40s:\t%s\n", "bSTAG_PCP_DEI_EgressRemarkingEnable", (param.bSTAG_PCP_DEI_EgressRemarkingEnable > 0)?"TRUE":"FALSE");
#endif   /* SWAPI_ETC_CHIP */
   return 0;
}

int ifx_ethsw_qos_scheduler_cfg_get(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_QoS_schedulerCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_QoS_schedulerCfg_t));

   cnt += scanParamArg(argc, argv, "nQueueId", 8, &param.nQueueId);
   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_ETHSW_QOS_SCHEDULER_CFG_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nQueueId", param.nQueueId, 0);
   printHex32Value("eType", param.eType, 0);
   printHex32Value("nWeight", param.nWeight, 0);
   return 0;
}

int ifx_ethsw_qos_shaper_cfg_get(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_QoS_ShaperCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_QoS_ShaperCfg_t));

   cnt += scanParamArg(argc, argv, "nRateShaperId", 32, &param.nRateShaperId);
   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_ETHSW_QOS_SHAPER_CFG_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nRateShaperId", param.nRateShaperId, 0);
   printf("\t%40s:\t%s\n", "bEnable", (param.bEnable > 0)?"TRUE":"FALSE");
   printHex32Value("nCbs", param.nCbs, 0);
   printHex32Value("nRate", param.nRate, 0);
   return 0;
}

int ifx_ethsw_qos_shaper_queue_get(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_QoS_ShaperQueueGet_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_QoS_ShaperQueueGet_t));

   cnt += scanParamArg(argc, argv, "nQueueId", 8, &param.nQueueId);
   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_ETHSW_QOS_SHAPER_QUEUE_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nQueueId", param.nQueueId, 0);
   printf("\t%40s:\t%s\n", "bAssigned", (param.bAssigned > 0)?"TRUE":"FALSE");
   printHex32Value("nRateShaperId", param.nRateShaperId, 0);
   return 0;
}

int ifx_ethsw_qos_storm_cfg_get(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_QoS_stormCfg_t param;
   memset(&param, 0, sizeof(IFX_ETHSW_QoS_stormCfg_t));

   if (cli_ioctl(fd, IFX_ETHSW_QOS_STORM_CFG_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nMeterId", param.nMeterId, 0);
   printf("\t%40s:\t%s\n", "bBroadcast", (param.bBroadcast > 0)?"TRUE":"FALSE");
   printf("\t%40s:\t%s\n", "bMulticast", (param.bMulticast > 0)?"TRUE":"FALSE");
   printf("\t%40s:\t%s\n", "bUnknownUnicast", (param.bUnknownUnicast > 0)?"TRUE":"FALSE");
   return 0;
}

int ifx_ethsw_qos_wred_cfg_get(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_QoS_WRED_Cfg_t param;
   memset(&param, 0, sizeof(IFX_ETHSW_QoS_WRED_Cfg_t));

   if (cli_ioctl(fd, IFX_ETHSW_QOS_WRED_CFG_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("eProfile", param.eProfile, 0);
   printHex32Value("nRed_Min", param.nRed_Min, 0);
   printHex32Value("nRed_Max", param.nRed_Max, 0);
   printHex32Value("nYellow_Min", param.nYellow_Min, 0);
   printHex32Value("nYellow_Max", param.nYellow_Max, 0);
   printHex32Value("nGreen_Min", param.nGreen_Min, 0);
   printHex32Value("nGreen_Max", param.nGreen_Max, 0);
   return 0;
}

int ifx_ethsw_qos_wred_queue_cfg_get(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_QoS_WRED_QueueCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_QoS_WRED_QueueCfg_t));

   cnt += scanParamArg(argc, argv, "nQueueId", 32, &param.nQueueId);
   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_ETHSW_QOS_WRED_QUEUE_CFG_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nQueueId", param.nQueueId, 0);
   printHex32Value("nRed_Min", param.nRed_Min, 0);
   printHex32Value("nRed_Max", param.nRed_Max, 0);
   printHex32Value("nYellow_Min", param.nYellow_Min, 0);
   printHex32Value("nYellow_Max", param.nYellow_Max, 0);
   printHex32Value("nGreen_Min", param.nGreen_Min, 0);
   printHex32Value("nGreen_Max", param.nGreen_Max, 0);
   return 0;
}

int ifx_ethsw_rmon_get(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_RMON_cnt_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_RMON_cnt_t));

   cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_ETHSW_RMON_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nPortId", param.nPortId, 8);
   printHex32Value("nRxGoodPkts", param.nRxGoodPkts, 0);
   printHex32Value("nRxUnicastPkts", param.nRxUnicastPkts, 0);
   printHex32Value("nRxBroadcastPkts", param.nRxBroadcastPkts, 0);
   printHex32Value("nRxMulticastPkts", param.nRxMulticastPkts, 0);
   printHex32Value("nRxFCSErrorPkts", param.nRxFCSErrorPkts, 0);
   printHex32Value("nRxUnderSizeGoodPkts", param.nRxUnderSizeGoodPkts, 0);
   printHex32Value("nRxOversizeGoodPkts", param.nRxOversizeGoodPkts, 0);
   printHex32Value("nRxUnderSizeErrorPkts", param.nRxUnderSizeErrorPkts, 0);
   printHex32Value("nRxGoodPausePkts", param.nRxGoodPausePkts, 0);
   printHex32Value("nRxOversizeErrorPkts", param.nRxOversizeErrorPkts, 0);
   printHex32Value("nRxAlignErrorPkts", param.nRxAlignErrorPkts, 0);
   printHex32Value("nRxFilteredPkts", param.nRxFilteredPkts, 0);
   printHex32Value("nRx64BytePkts", param.nRx64BytePkts, 0);
   printHex32Value("nRx127BytePkts", param.nRx127BytePkts, 0);
   printHex32Value("nRx255BytePkts", param.nRx255BytePkts, 0);
   printHex32Value("nRx511BytePkts", param.nRx511BytePkts, 0);
   printHex32Value("nRx1023BytePkts", param.nRx1023BytePkts, 0);
   printHex32Value("nRxMaxBytePkts", param.nRxMaxBytePkts, 0);
   printHex32Value("nTxGoodPkts", param.nTxGoodPkts, 0);
   printHex32Value("nTxUnicastPkts", param.nTxUnicastPkts, 0);
   printHex32Value("nTxBroadcastPkts", param.nTxBroadcastPkts, 0);
   printHex32Value("nTxMulticastPkts", param.nTxMulticastPkts, 0);
   printHex32Value("nTxSingleCollCount", param.nTxSingleCollCount, 0);
   printHex32Value("nTxMultCollCount", param.nTxMultCollCount, 0);
   printHex32Value("nTxLateCollCount", param.nTxLateCollCount, 0);
   printHex32Value("nTxExcessCollCount", param.nTxExcessCollCount, 0);
   printHex32Value("nTxCollCount", param.nTxCollCount, 0);
   printHex32Value("nTxPauseCount", param.nTxPauseCount, 0);
   printHex32Value("nTx64BytePkts", param.nTx64BytePkts, 0);
   printHex32Value("nTx127BytePkts", param.nTx127BytePkts, 0);
   printHex32Value("nTx255BytePkts", param.nTx255BytePkts, 0);
   printHex32Value("nTx511BytePkts", param.nTx511BytePkts, 0);
   printHex32Value("nTx1023BytePkts", param.nTx1023BytePkts, 0);
   printHex32Value("nTxMaxBytePkts", param.nTxMaxBytePkts, 0);
   printHex32Value("nTxDroppedPkts", param.nTxDroppedPkts, 0);
   printHex32Value("nTxAcmDroppedPkts", param.nTxAcmDroppedPkts, 0);
   printHex32Value("nRxDroppedPkts", param.nRxDroppedPkts, 0);
   printf("\t%40s:\t%lu (0x%0lx)\n", "nRxGoodBytes", (unsigned long)param.nRxGoodBytes, (unsigned long)param.nRxGoodBytes);
   printf("\t%40s:\t%lu (0x%0lx)\n", "nRxBadBytes", (unsigned long)param.nRxBadBytes, (unsigned long)param.nRxBadBytes);
   printf("\t%40s:\t%lu (0x%0lx)\n", "nTxGoodBytes", (unsigned long)param.nTxGoodBytes, (unsigned long)param.nTxGoodBytes);
   return 0;
}

int ifx_ethsw_stp_bpdu_rule_get(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_STP_BPDU_Rule_t param;
   memset(&param, 0, sizeof(IFX_ETHSW_STP_BPDU_Rule_t));

   if (cli_ioctl(fd, IFX_ETHSW_STP_BPDU_RULE_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("eForwardPort", param.eForwardPort, 0);
   printHex32Value("nForwardPortId", param.nForwardPortId, 0);
   return 0;
}

int ifx_ethsw_stp_port_cfg_get(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_STP_portCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_STP_portCfg_t));

   cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_ETHSW_STP_PORT_CFG_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nPortId", param.nPortId, 8);
   printHex32Value("ePortState", param.ePortState, 0);
   return 0;
}

int ifx_ethsw_vlan_id_get(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_VLAN_IdGet_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_VLAN_IdGet_t));

   cnt += scanParamArg(argc, argv, "nVId", 16, &param.nVId);
   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_ETHSW_VLAN_ID_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nVId", param.nVId, 0);
   printHex32Value("nFId", param.nFId, 0);
   return 0;
}

int ifx_ethsw_vlan_port_cfg_get(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_VLAN_portCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_VLAN_portCfg_t));

   cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_ETHSW_VLAN_PORT_CFG_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nPortId", param.nPortId, 8);
   printHex32Value("nPortVId", param.nPortVId, 0);
   printf("\t%40s:\t%s\n", "bVLAN_UnknownDrop", (param.bVLAN_UnknownDrop > 0)?"TRUE":"FALSE");
   printf("\t%40s:\t%s\n", "bVLAN_ReAssign", (param.bVLAN_ReAssign > 0)?"TRUE":"FALSE");
   printHex32Value("eVLAN_MemberViolation", param.eVLAN_MemberViolation, 0);
   printHex32Value("eAdmitMode", param.eAdmitMode, 0);
   printf("\t%40s:\t%s\n", "bTVM", (param.bTVM > 0)?"TRUE":"FALSE");
   return 0;
}

int ifx_ethsw_wol_cfg_get(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_WoL_Cfg_t param;
   memset(&param, 0, sizeof(IFX_ETHSW_WoL_Cfg_t));

   if (cli_ioctl(fd, IFX_ETHSW_WOL_CFG_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printf("\t%40s:\t", "nWolMAC");
   printMAC_Address(param.nWolMAC);
   printf("\n");
   printf("\t%40s:\t", "nWolPassword");
   printMAC_Address(param.nWolPassword);
   printf("\n");
   printf("\t%40s:\t%s\n", "bWolPasswordEnable", (param.bWolPasswordEnable > 0)?"TRUE":"FALSE");
   return 0;
}

int ifx_ethsw_wol_port_cfg_get(int argc, char *argv[], int fd, int numPar) {
   IFX_ETHSW_WoL_PortCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_ETHSW_WoL_PortCfg_t));

   cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_ETHSW_WOL_PORT_CFG_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nPortId", param.nPortId, 8);
   printf("\t%40s:\t%s\n", "bWakeOnLAN_Enable", (param.bWakeOnLAN_Enable > 0)?"TRUE":"FALSE");
   return 0;
}

#ifdef SWITCHAPI_GSWIP_SUPPORT

int ifx_flow_irq_get(int argc, char *argv[], int fd, int numPar) {
   IFX_FLOW_irq_t param;
   memset(&param, 0, sizeof(IFX_FLOW_irq_t));

   if (cli_ioctl(fd, IFX_FLOW_IRQ_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nPortId", param.nPortId, 32);
   printHex32Value("eIrqSrc", param.eIrqSrc, 0);
   return 0;
}

int ifx_flow_irq_mask_get(int argc, char *argv[], int fd, int numPar) {
   IFX_FLOW_irq_t param;
   memset(&param, 0, sizeof(IFX_FLOW_irq_t));

   if (cli_ioctl(fd, IFX_FLOW_IRQ_MASK_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nPortId", param.nPortId, 32);
   printHex32Value("eIrqSrc", param.eIrqSrc, 0);
   return 0;
}

int ifx_flow_register_get(int argc, char *argv[], int fd, int numPar) {
   IFX_FLOW_register_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_FLOW_register_t));

   cnt += scanParamArg(argc, argv, "nRegAddr", 16, &param.nRegAddr);
   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_FLOW_REGISTER_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nRegAddr", param.nRegAddr, 0);
   printHex32Value("nData", param.nData, 0);
   return 0;
}
int ifx_ethsw_trunking_cfg_get(int argc, char *argv[], int fd, int numPar) {
	IFX_ETHSW_trunkingCfg_t param;

	memset(&param, 0, sizeof(IFX_ETHSW_trunkingCfg_t));
	if (cli_ioctl(fd, IFX_ETHSW_TRUNKING_CFG_GET, &param) != 0) {
		printf("ioctl returned with ERROR!\n");
		return (-1);
	}
	printHex32Value("bIP_Src", param.bIP_Src, 0);
	printHex32Value("bIP_Dst", param.bIP_Dst, 0);
	printHex32Value("bMAC_Src", param.bMAC_Src, 0);
	printHex32Value("bMAC_Dst", param.bMAC_Dst, 0);
	return 0;
}
int ifx_ethsw_trunking_cfg_set(int argc, char *argv[], int fd, int numPar) {
	IFX_ETHSW_trunkingCfg_t param;
	int cnt = 0;
	memset(&param, 0, sizeof(IFX_ETHSW_trunkingCfg_t));
	
	if(cli_ioctl(fd, IFX_ETHSW_TRUNKING_CFG_GET, &param) != 0)
		return (-4);
	
	cnt += scanParamArg(argc, argv, "bIP_Src", 32, &param.bIP_Src);
	cnt += scanParamArg(argc, argv, "bIP_Dst", 32, &param.bIP_Dst);
	cnt += scanParamArg(argc, argv, "bMAC_Src", 32, &param.bMAC_Src);
	cnt += scanParamArg(argc, argv, "bMAC_Dst", 32, &param.bMAC_Dst);
	
	if (cnt != numPar) 
		return (-2);
	
	return cli_ioctl(fd, IFX_ETHSW_TRUNKING_CFG_SET, &param);
}
int ifx_ethsw_trunking_port_cfg_get(int argc, char *argv[], int fd, int numPar) {
	IFX_ETHSW_trunkingPortCfg_t param;
	int cnt = 0;
	memset(&param, 0, sizeof(IFX_ETHSW_trunkingPortCfg_t));
	cnt += scanParamArg(argc, argv, "nPortId", 32, &param.nPortId);
	if (cnt != numPar)
		return (-2);
	if (cli_ioctl(fd, IFX_ETHSW_TRUNKING_PORT_CFG_GET, &param) != 0) {
		printf("ioctl returned with ERROR!\n");
		return (-1);
	}
	printf("Returned values:\n----------------\n");
	printHex32Value("nPortId", param.nPortId, 0);
	printf("\t%40s:\t%s\n", "bAggregateEnable", (param.bAggregateEnable > 0)?"TRUE":"FALSE");
	printHex32Value("nAggrPortId", param.nAggrPortId, 0);
	return 0;
}
int ifx_ethsw_trunking_port_cfg_set(int argc, char *argv[], int fd, int numPar) {
	IFX_ETHSW_trunkingPortCfg_t param;
	int cnt = 0;
	memset(&param, 0, sizeof(IFX_ETHSW_trunkingPortCfg_t));
	cnt += scanParamArg(argc, argv, "nPortId", 32, &param.nPortId);
	if (cnt != 1)
		return (-3);
	if (cli_ioctl(fd, IFX_ETHSW_TRUNKING_PORT_CFG_GET, &param) != 0) {
		printf("ioctl returned with ERROR!\n");
		return (-1);
	}
	cnt += scanParamArg(argc, argv, "bAggregateEnable", 32, &param.bAggregateEnable);
	cnt += scanParamArg(argc, argv, "nAggrPortId", 32, &param.nAggrPortId);
	if (cnt != numPar)
		return (-2);
	return cli_ioctl(fd, IFX_ETHSW_TRUNKING_PORT_CFG_SET, &param);
}

int ifx_ethsw_qos_wred_port_cfg_get(int argc, char *argv[], int fd, int numPar) {
	IFX_ETHSW_QoS_WRED_PortCfg_t param;
	int cnt = 0;
	memset(&param, 0, sizeof(IFX_ETHSW_QoS_WRED_PortCfg_t));
	
	cnt += scanParamArg(argc, argv, "nPortId", 32, &param.nPortId);
	if (cnt != numPar)
		return (-2);
	if (cli_ioctl(fd, IFX_ETHSW_QOS_WRED_PORT_CFG_GET, &param) != 0) {
		printf("ioctl returned with ERROR!\n");
		return (-1);
	}
	printHex32Value("nPortId", param.nPortId, 0);
	printHex32Value("nRed_Min", param.nRed_Min, 0);
	printHex32Value("nRed_Max", param.nRed_Max, 0);
	printHex32Value("nYellow_Min", param.nYellow_Min, 0);
	printHex32Value("nYellow_Max", param.nYellow_Max, 0);
	printHex32Value("nGreen_Min", param.nGreen_Min, 0);
	printHex32Value("nGreen_Max", param.nGreen_Max, 0);
	return 0;
}

int ifx_ethsw_qos_wred_port_cfg_set(int argc, char *argv[], int fd, int numPar) {
	IFX_ETHSW_QoS_WRED_PortCfg_t param;
	int cnt = 0;
	memset(&param, 0, sizeof(IFX_ETHSW_QoS_WRED_PortCfg_t));
	cnt += scanParamArg(argc, argv, "nPortId", 32, &param.nPortId);
	if (cnt != 1)
		return (-3);
	if(cli_ioctl(fd, IFX_ETHSW_QOS_WRED_PORT_CFG_GET, &param) != 0)
		return (-4);
	cnt += scanParamArg(argc, argv, "nRed_Min", 32, &param.nRed_Min);
	cnt += scanParamArg(argc, argv, "nRed_Max", 32, &param.nRed_Max);
	cnt += scanParamArg(argc, argv, "nYellow_Min", 32, &param.nYellow_Min);
	cnt += scanParamArg(argc, argv, "nYellow_Max", 32, &param.nYellow_Max);
	cnt += scanParamArg(argc, argv, "nGreen_Min", 32, &param.nGreen_Min);
	cnt += scanParamArg(argc, argv, "nGreen_Max", 32, &param.nGreen_Max);
	if (cnt != numPar)
		return (-2);
	return cli_ioctl(fd, IFX_ETHSW_QOS_WRED_PORT_CFG_SET, &param);
}

int ifx_ethsw_qos_flowctrl_cfg_get(int argc, char *argv[], int fd, int numPar) {
	IFX_ETHSW_QoS_FlowCtrlCfg_t param;
	memset(&param, 0, sizeof(IFX_ETHSW_QoS_FlowCtrlCfg_t));
	
	if (cli_ioctl(fd, IFX_ETHSW_QOS_FLOWCTRL_CFG_GET, &param) != 0) {
		printf("ioctl returned with ERROR!\n");
		return (-1);
	}
	printHex32Value("nFlowCtrlNonConform_Min", param.nFlowCtrlNonConform_Min, 0);
	printHex32Value("nFlowCtrlNonConform_Max", param.nFlowCtrlNonConform_Max, 0);
	printHex32Value("nFlowCtrlConform_Min", param.nFlowCtrlConform_Min, 0);
	printHex32Value("nFlowCtrlConform_Max", param.nFlowCtrlConform_Max, 0);
	return 0;
}


int ifx_ethsw_qos_flowctrl_cfg_set(int argc, char *argv[], int fd, int numPar) {
	IFX_ETHSW_QoS_FlowCtrlCfg_t param;
	int cnt = 0;
	memset(&param, 0, sizeof(IFX_ETHSW_QoS_FlowCtrlCfg_t));
	if(cli_ioctl(fd, IFX_ETHSW_QOS_FLOWCTRL_CFG_GET, &param) != 0)
		return (-4);
	cnt += scanParamArg(argc, argv, "nFlowCtrlNonConform_Min", 32, &param.nFlowCtrlNonConform_Min);
	cnt += scanParamArg(argc, argv, "nFlowCtrlNonConform_Max", 32, &param.nFlowCtrlNonConform_Max);
	cnt += scanParamArg(argc, argv, "nFlowCtrlConform_Min", 32, &param.nFlowCtrlConform_Min);
	cnt += scanParamArg(argc, argv, "nFlowCtrlConform_Max", 32, &param.nFlowCtrlConform_Max);
	if (cnt != numPar)
		return (-2);
	return cli_ioctl(fd, IFX_ETHSW_QOS_FLOWCTRL_CFG_SET, &param);
}

int ifx_ethsw_qos_flowctrl_port_cfg_get(int argc, char *argv[], int fd, int numPar) {
	IFX_ETHSW_QoS_FlowCtrlPortCfg_t param;
	int cnt = 0;
	memset(&param, 0, sizeof(IFX_ETHSW_QoS_FlowCtrlPortCfg_t));
	
	cnt += scanParamArg(argc, argv, "nPortId", 32, &param.nPortId);
	if (cnt != numPar)
		return (-2);
	if (cli_ioctl(fd, IFX_ETHSW_QOS_FLOWCTRL_PORT_CFG_GET, &param) != 0) {
		printf("ioctl returned with ERROR!\n");
		return (-1);
	}
	printHex32Value("nPortId", param.nPortId, 0);
	printHex32Value("nFlowCtrl_Min", param.nFlowCtrl_Min, 0);
	printHex32Value("nFlowCtrl_Max", param.nFlowCtrl_Max, 0);
	return 0;
}
int ifx_ethsw_qos_flowctrl_port_cfg_set(int argc, char *argv[], int fd, int numPar) {
	IFX_ETHSW_QoS_FlowCtrlPortCfg_t param;
	int cnt = 0;
	memset(&param, 0, sizeof(IFX_ETHSW_QoS_FlowCtrlPortCfg_t));
	cnt += scanParamArg(argc, argv, "nPortId", 32, &param.nPortId);
	if (cnt != 1)
		return (-2);
	if (cli_ioctl(fd, IFX_ETHSW_QOS_FLOWCTRL_PORT_CFG_GET, &param) != 0) {
		printf("ioctl returned with ERROR!\n");
		return (-1);
	}
	cnt += scanParamArg(argc, argv, "nFlowCtrl_Min", 32, &param.nFlowCtrl_Min);
	cnt += scanParamArg(argc, argv, "nFlowCtrl_Max", 32, &param.nFlowCtrl_Max);
	if (cnt != numPar)
		return (-2);
	return cli_ioctl(fd, IFX_ETHSW_QOS_FLOWCTRL_PORT_CFG_SET, &param);
}

int ifx_ethsw_qos_queue_buffer_reserve_cfg_get(int argc, char *argv[], int fd, int numPar) {
	IFX_ETHSW_QoS_QueueBufferReserveCfg_t param;
	int cnt = 0;
	memset(&param, 0, sizeof(IFX_ETHSW_QoS_QueueBufferReserveCfg_t));
	cnt += scanParamArg(argc, argv, "nQueueId", 8, &param.nQueueId);
	if (cnt != numPar)
		return (-2);
	if (cli_ioctl(fd, IFX_ETHSW_QOS_QUEUE_BUFFER_RESERVE_CFG_GET, &param) != 0) {
		printf("ioctl returned with ERROR!\n");
		return (-1);
	}
	printHex32Value("nQueueId", param.nQueueId, 0);
	printHex32Value("nBufferReserved", param.nBufferReserved, 0);
	return 0;
}

int ifx_ethsw_qos_queue_buffer_reserve_cfg_set(int argc, char *argv[], int fd, int numPar) {
	IFX_ETHSW_QoS_QueueBufferReserveCfg_t param;
	int cnt = 0;
	memset(&param, 0, sizeof(IFX_ETHSW_QoS_QueueBufferReserveCfg_t));
	
	cnt += scanParamArg(argc, argv, "nQueueId", 8, &param.nQueueId);
	if (cnt != 1)
		return (-2);
	if (cli_ioctl(fd, IFX_ETHSW_QOS_QUEUE_BUFFER_RESERVE_CFG_GET, &param) != 0) {
		printf("ioctl returned with ERROR!\n");
		return (-1);
	}
	cnt += scanParamArg(argc, argv, "nBufferReserved", 32, &param.nBufferReserved);
	if (cnt != numPar)
		return (-2);
	return cli_ioctl(fd, IFX_ETHSW_QOS_QUEUE_BUFFER_RESERVE_CFG_SET, &param);
}

#ifdef SWAPI_ETC_CHIP 
int ifx_ethsw_svlan_cfg_get(int argc, char *argv[], int fd, int numPar) {
	
	IFX_ETHSW_SVLAN_cfg_t param;
	memset(&param, 0, sizeof(IFX_ETHSW_SVLAN_cfg_t));
	if(cli_ioctl(fd, IFX_ETHSW_SVLAN_CFG_GET, &param) != 0) {
		return (-1);
	}
	printf("\tnEthertype :0x%04x\n", param.nEthertype);
	return 0;
}

int ifx_ethsw_svlan_cfg_set(int argc, char *argv[], int fd, int numPar) {
	
	IFX_ETHSW_SVLAN_cfg_t param;
	int cnt = 0;
	memset(&param, 0, sizeof(IFX_ETHSW_SVLAN_cfg_t));

	cnt += scanParamArg(argc, argv, "nEthertype", 16, &param.nEthertype);
	if (cnt != 1)
		return (-2);

	return cli_ioctl(fd, IFX_ETHSW_SVLAN_CFG_SET, &param);
}

int ifx_ethsw_svlan_port_cfg_get(int argc, char *argv[], int fd, int numPar) {
	
	IFX_ETHSW_SVLAN_portCfg_t param;
	int cnt = 0;
	memset(&param, 0, sizeof(IFX_ETHSW_SVLAN_portCfg_t));

	cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
	if (cnt != numPar)
		return (-2);

	if (cli_ioctl(fd, IFX_ETHSW_SVLAN_PORT_CFG_GET, &param) != 0) {
		printf("ioctl returned with ERROR!\n");
		return (-1);
	}

	printf("Returned values:\n----------------\n");
	printf("\t%40s:\t0x%04x\n", "nPortId", param.nPortId);
	printf("\t%40s:\t0x%04x\n", "nPortVId", param.nPortVId);
	printf("\t%40s:\t%s\n", "bSVLAN_TagSupport", (param.bSVLAN_TagSupport > 0)?"TRUE":"FALSE");
	printf("\t%40s:\t%s\n", "bSVLAN_MACbasedTag", (param.bSVLAN_MACbasedTag > 0)?"TRUE":"FALSE");
	printf("\t%40s:\t%s\n", "bVLAN_ReAssign", (param.bVLAN_ReAssign > 0)?"TRUE":"FALSE");
	printHex32Value("eVLAN_MemberViolation", param.eVLAN_MemberViolation, 0);
	printHex32Value("eAdmitMode", param.eAdmitMode, 0);
	return 0;
}

int ifx_ethsw_svlan_port_cfg_set(int argc, char *argv[], int fd, int numPar) {
	
	IFX_ETHSW_SVLAN_portCfg_t param;
	int cnt = 0;
	memset(&param, 0, sizeof(IFX_ETHSW_SVLAN_portCfg_t));

	cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
	if (cnt != 1)
		return (-2);

	if(cli_ioctl(fd, IFX_ETHSW_SVLAN_PORT_CFG_GET, &param) != 0)
		return (-4);

	cnt += scanParamArg(argc, argv, "nPortVId", 16, &param.nPortVId);
	cnt += scanParamArg(argc, argv, "bSVLAN_TagSupport", 32, &param.bSVLAN_TagSupport);
	cnt += scanParamArg(argc, argv, "bSVLAN_MACbasedTag", 32, &param.bSVLAN_MACbasedTag);
	cnt += scanParamArg(argc, argv, "bVLAN_ReAssign", 32, &param.bVLAN_ReAssign);
	cnt += scanParamArg(argc, argv, "eVLAN_MemberViolation", 32, &param.eVLAN_MemberViolation);
	cnt += scanParamArg(argc, argv, "eAdmitMode", 32, &param.eAdmitMode);
	if (cnt != numPar)
		return (-2);

   return cli_ioctl(fd, IFX_ETHSW_SVLAN_PORT_CFG_SET, &param);
	
}

int ifx_ethsw_qos_svlan_class_pcp_port_set(int argc, char *argv[], int fd, int numPar) {
	
	IFX_ETHSW_QoS_SVLAN_ClassPCP_PortCfg_t param;
	unsigned char nTrafficClass=0,nSPCP=0,nCPCP=0,nDSCP=0;
	unsigned int cnt=0,i;
	memset(&param, 0, sizeof(IFX_ETHSW_QoS_SVLAN_ClassPCP_PortCfg_t));
	
	cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
	cnt += scanParamArg(argc, argv, "nTrafficClass", 8, &nTrafficClass);
	cnt += scanParamArg(argc, argv, "nCPCP", 8, &nCPCP);
	cnt += scanParamArg(argc, argv, "nSPCP", 8, &nSPCP);
	cnt += scanParamArg(argc, argv, "nDSCP", 8, &nDSCP);

	if (cnt != numPar)
		return (-2);
	
	if (nTrafficClass >= 16) {
      printf("ERROR: Given \"nTrafficClass\" is out of range (15)\n");
      return (-3);
   }
	if(cli_ioctl(fd, IFX_ETHSW_QOS_SVLAN_CLASS_PCP_PORT_GET, &param) != 0)
		return (-2);
	param.nCPCP[nTrafficClass] = nCPCP;
	param.nSPCP[nTrafficClass] = nSPCP;
	param.nDSCP[nTrafficClass] = nDSCP;
	if (cli_ioctl(fd, IFX_ETHSW_QOS_SVLAN_CLASS_PCP_PORT_SET, &param) != 0)
		return (-5);
		
	return 0;
   
}

int ifx_ethsw_qos_svlan_class_pcp_port_get(int argc, char *argv[], int fd, int numPar) {
	IFX_ETHSW_QoS_SVLAN_ClassPCP_PortCfg_t param;
	int cnt = 0,i;
	
	memset(&param, 0, sizeof(IFX_ETHSW_QoS_SVLAN_ClassPCP_PortCfg_t));
	cnt += scanParamArg(argc, argv, "nPortId", 8, &param.nPortId);
	if (cnt != numPar)
		return (-2);
	if(cli_ioctl(fd, IFX_ETHSW_QOS_SVLAN_CLASS_PCP_PORT_GET, &param) != 0)
		return (-2);
	
	printf("\n\t nPortId = %d\n", param.nPortId);
	for (i=0; i<16; i++) {
		printf("\t nCPCP[%d] = %d", i, param.nCPCP[i]);
		printf("\t nSPCP[%d] = %d", i, param.nSPCP[i]);
		printf("\t nDSCP[%d] = %d\n", i, param.nDSCP[i]);
	}
	return 0;
}

int ifx_ethsw_qos_svlan_pcp_class_set(int argc, char *argv[], int fd, int numPar) {

	IFX_ETHSW_QoS_SVLAN_PCP_ClassCfg_t param;
	unsigned char nTrafficClass=0,nTrafficColor=0, nPCP_Remark_Enable=0, nDEI_Remark_Enable=0;
	unsigned int nPCP=0, cnt=0;
	cnt += scanParamArg(argc, argv, "nPCP", 32, &nPCP);
	cnt += scanParamArg(argc, argv, "nTrafficClass", 8, &nTrafficClass);
	cnt += scanParamArg(argc, argv, "nTrafficColor", 8, &nTrafficColor);
	cnt += scanParamArg(argc, argv, "nPCP_Remark_Enable", 8, &nPCP_Remark_Enable);
	cnt += scanParamArg(argc, argv, "nDEI_Remark_Enable", 8, &nDEI_Remark_Enable);
	if (cnt != 5) return (-2);
	if (nPCP >= 16) {
		printf("ERROR: Given \"nPCP\" is out of range (15)\n");
		return (-3);
	}
	
	memset(&param, 0x00, sizeof(param));
	if (cli_ioctl(fd, IFX_ETHSW_QOS_SVLAN_PCP_CLASS_GET, &param) != 0)
		return (-4);
		
	param.nTrafficClass[nPCP] = nTrafficClass;
	param.nTrafficColor[nPCP] = nTrafficColor;
	param.nPCP_Remark_Enable[nPCP] = nPCP_Remark_Enable;
	param.nDEI_Remark_Enable[nPCP] = nDEI_Remark_Enable;
	
	if (cli_ioctl(fd, IFX_ETHSW_QOS_SVLAN_PCP_CLASS_SET, &param) != 0)
		return (-5);

	return 0;
}

int ifx_ethsw_qos_svlan_pcp_class_get(int argc, char *argv[], int fd, int numPar) {
	IFX_ETHSW_QoS_SVLAN_PCP_ClassCfg_t param;
	int i;

	memset(&param, 0x00, sizeof(param));
	if(cli_ioctl(fd, IFX_ETHSW_QOS_SVLAN_PCP_CLASS_GET, &param) != 0)
		return (-2);
	for (i=0; i<16; i++) {
		printf("\tnTrafficClass[%d] = %d, TrafficColor[%d] = %d  ", i, param.nTrafficClass[i],i,param.nTrafficColor[i] );
		printf("PCP_Remark_Enable[%d] = %d, nDEI_Remark_Enable[%d] = %d \n", i, param.nPCP_Remark_Enable[i],i,param.nDEI_Remark_Enable[i] );
		
	}
	return 0;
}
#endif /* SWAPI_ETC_CHIP */
#endif /* SWITCHAPI_GSWIP_SUPPORT */

#ifdef SWITCHAPI_TANTOS_SUPPORT

int ifx_psb6970_power_management_get(int argc, char *argv[], int fd, int numPar) {
   IFX_PSB6970_powerManagement_t param;
   memset(&param, 0, sizeof(IFX_PSB6970_powerManagement_t));

   if (cli_ioctl(fd, IFX_PSB6970_POWER_MANAGEMENT_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned value:\n---------------\n");
   printf("\t%40s:\t%s\n", "bEnable", (param.bEnable > 0)?"TRUE":"FALSE");
   return 0;
}

int ifx_psb6970_qos_mfc_port_cfg_get(int argc, char *argv[], int fd, int numPar) {
   IFX_PSB6970_QoS_MfcPortCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_PSB6970_QoS_MfcPortCfg_t));

   cnt += scanParamArg(argc, argv, "nPort", 32, &param.nPort);
   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_PSB6970_QOS_MFC_PORT_CFG_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nPort", param.nPort, 0);
   printf("\t%40s:\t%s\n", "bPriorityPort", (param.bPriorityPort > 0)?"TRUE":"FALSE");
   printf("\t%40s:\t%s\n", "bPriorityEtherType", (param.bPriorityEtherType > 0)?"TRUE":"FALSE");
   return 0;
}

int ifx_psb6970_qos_port_policer_get(int argc, char *argv[], int fd, int numPar) {
   IFX_PSB6970_QoS_portPolicerCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_PSB6970_QoS_portPolicerCfg_t));

   cnt += scanParamArg(argc, argv, "nPort", 32, &param.nPort);
   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_PSB6970_QOS_PORT_POLICER_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nPort", param.nPort, 0);
   printHex32Value("nRate", param.nRate, 0);
   return 0;
}

int ifx_psb6970_qos_port_shaper_cfg_get(int argc, char *argv[], int fd, int numPar) {
   IFX_PSB6970_QoS_portShaperCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_PSB6970_QoS_portShaperCfg_t));

   cnt += scanParamArg(argc, argv, "nPort", 32, &param.nPort);
   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_PSB6970_QOS_PORT_SHAPER_CFG_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nPort", param.nPort, 0);
   printHex32Value("eWFQ_Type", param.eWFQ_Type, 0);
   return 0;
}

int ifx_psb6970_qos_port_shaper_strict_get(int argc, char *argv[], int fd, int numPar) {
   IFX_PSB6970_QoS_portShaperStrictCfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_PSB6970_QoS_portShaperStrictCfg_t));

   cnt += scanParamArg(argc, argv, "nPort", 32, &param.nPort);
   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_PSB6970_QOS_PORT_SHAPER_STRICT_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nPort", param.nPort, 0);
   printHex32Value("nTrafficClass", param.nTrafficClass, 0);
   printHex32Value("nRate", param.nRate, 0);
   return 0;
}

int ifx_psb6970_qos_port_shaper_wfq_get(int argc, char *argv[], int fd, int numPar) {
   IFX_PSB6970_QoS_portShaperWFQ_Cfg_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_PSB6970_QoS_portShaperWFQ_Cfg_t));

   cnt += scanParamArg(argc, argv, "nPort", 32, &param.nPort);
   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_PSB6970_QOS_PORT_SHAPER_WFQ_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nPort", param.nPort, 0);
   printHex32Value("nTrafficClass", param.nTrafficClass, 0);
   printHex32Value("nRate", param.nRate, 0);
   return 0;
}

int ifx_psb6970_qos_storm_get(int argc, char *argv[], int fd, int numPar) {
   IFX_PSB6970_QoS_stormCfg_t param;
   memset(&param, 0, sizeof(IFX_PSB6970_QoS_stormCfg_t));

   if (cli_ioctl(fd, IFX_PSB6970_QOS_STORM_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printf("\t%40s:\t%s\n", "bBroadcast", (param.bBroadcast > 0)?"TRUE":"FALSE");
   printf("\t%40s:\t%s\n", "bMulticast", (param.bMulticast > 0)?"TRUE":"FALSE");
   printf("\t%40s:\t%s\n", "bUnicast", (param.bUnicast > 0)?"TRUE":"FALSE");
   printHex32Value("nThreshold10M", param.nThreshold10M, 0);
   printHex32Value("nThreshold100M", param.nThreshold100M, 0);
   return 0;
}

int ifx_psb6970_register_get(int argc, char *argv[], int fd, int numPar) {
   IFX_PSB6970_register_t param;
   int cnt = 0;
   memset(&param, 0, sizeof(IFX_PSB6970_register_t));

   cnt += scanParamArg(argc, argv, "nRegAddr", 32, &param.nRegAddr);
   if (cnt != numPar)
      return (-2);

   if (cli_ioctl(fd, IFX_PSB6970_REGISTER_GET, &param) != 0) {
      printf("ioctl returned with ERROR!\n");
      return (-1);
   }

   printf("Returned values:\n----------------\n");
   printHex32Value("nRegAddr", param.nRegAddr, 0);
   printHex32Value("nData", param.nData, 0);
   return 0;
}

#endif /* SWITCHAPI_TANTOS_SUPPORT */

