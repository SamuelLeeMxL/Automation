#!/usr/bin/perl -w
use Fcntl;
use Getopt::Std;

%options=();
my @inputFile = ();
my @outputFile = ();
my @structures = ();
my @enumerators = ();
my @ioctls = ();

sub PrintHelp {
   print "Usage: $0 <options>
Reads API Header file and extracts IOCTL commands, type definitions and comments
and generates a XML database out of it.

Usage:
   -i <file>     Main input files
   -o <file>     Write output to file.\n";
   exit 0;
}

sub readInputFile {
   sysopen(IN, $options{i}, O_RDONLY) || die "$options{i} could not be opened!\n";
   #copy whole config spec into memory
   while (<IN>) {
      s/[\r\n]//g;
      push @inputFile, $_;
   }
   close (IN);
}

sub writeOutputFile {
   sysopen(OUT, $options{o}, O_WRONLY | O_CREAT | O_TRUNC) || die "$options{o} could not be opened!\n";

   print OUT "<?xml version=\"1.0\" ?>\n<top>\n";

   foreach (@enumerators) { print OUT "$_"; }
   foreach (@structures) { print OUT "$_"; }
   foreach (@ioctls) { print OUT "$_"; }

   print OUT "</top>\n";
   close(OUT);
}

sub stripDownString {
   my ($line) = @_;

   $line =~ s/^[\ \t]*//g;
   $line =~ s/[\ \t]+/\ /g;
   $line =~ s/[\ \t\r\n]*$//g;
   return $line;
}

sub findEnumerators {
   my $insideEnum = 0;
   my $insideDescr = 0;

   my @enumValues = ();
   my $descr = "";

   foreach my $line (@inputFile) {
      if ($line =~ /typedef[\ \t]+enum/) {
         #enumerator found
         $insideEnum = 1;
      }

      if (($line =~ /\{/) && ($insideEnum == 1)) {
         $insideEnum = 2;
         if ($line =~ /\{[\t\ ]*$/) {
            #no following data in the line
            next;
         }
      }

      if (($line =~ /\}[\ \t]*([a-zA-Z0-9_]+)[\ \t]*;/) && ($insideEnum == 2)) {
         $insideEnum = 0;
         my $tmp = "\t<enum>\n\t\t<name>$1</name>\n";

         foreach my $tmp2 (@enumValues) { $tmp .= $tmp2; }
         @enumValues = ();

         $tmp .= "\t</enum>\n";

         push @enumerators, $tmp;

         #print "enum: \"$1\" found\n";
         next;
      }

      if ($insideEnum == 2) {
         #inside a enumerator where to find enum values and descriptions

         ######################################################################
         #description handling
         if ($insideDescr == 1) {
            #still inside description
            $descr .= $line;
         }

         if ($line =~ /[\ \t]*\/\*+\ *(.*)/) {
            #inside description
            $insideDescr = 1;
            $descr = "<descr><param>$1";
         }

         if (($insideDescr == 1) && ($descr =~ /\*\//)) {
            #end of description found
            $descr =~ s/\*\///g;
            #remove doxygen tags
            $descr =~ s/\\([a-z]+)//g;

            $descr = stripDownString $descr;
            $descr =~ s/<descr>/\t\t\t<descr>\n/g;
            $descr =~ s/<param>/\t\t\t\t<param>/g;
            $descr .= "</param>\n\t\t\t</descr>\n";
            $insideDescr = 0;
            next;
         }
         ######################################################################

         if ($insideDescr == 0) {
            #line must contain a enumerator value
            if ($line =~ /^[\ \t]*([a-zA-Z0-9_]+)[\ \t]*=*[\ \t]*([0-9]*)/) {
               my $tmp = "\t\t<elem>\n\t\t\t<name>$1</name>\n";

               if (defined ($2)) {
                  $tmp .= "\t\t\t<value>$2</value>\n";
               }
               $tmp .= $descr;
               $tmp .= "\t\t</elem>\n";
               push @enumValues, $tmp;
            }
         }
      }
   }

   @enumerators = sort @enumerators;
}

sub findStructures {
   my $insideStruct = 0;
   my $insideDescr = 0;

   my @structValues = ();
   my $descr = "";

   foreach my $line (@inputFile) {
      if ($line =~ /typedef[\ \t]+struct/) {
         #structure found
         $insideStruct = 1;
      }

      if (($line =~ /\{/) && ($insideStruct == 1)) {
         $insideStruct = 2;
      }

      if (($line =~ /\}[\ \t]*([a-zA-Z0-9_]+)[\ \t]*;/) && ($insideStruct == 2)) {
         $insideStruct = 0;
         my $tmp2 = "\t<struct>\n\t\t<name>$1</name>\n";
         foreach my $tmp3 (@structValues) { $tmp2 .= $tmp3; }
         @structValues = ();
         $tmp2 .= "\t</struct>\n";
         push @structures, $tmp2;
         next;
      }

      if ($insideStruct == 2) {
         #inside a structure where to find struct elements and descriptions

         ######################################################################
         #description handling
         if ($insideDescr == 1) {
            #still inside description
            $descr .= $line;
         }

         if ($line =~ /[\ \t]*\/\*+\ *(.*)/) {
            #inside description
            $insideDescr = 1;
            $descr = "<descr><param>$1";
         }

         if (($insideDescr == 1) && ($descr =~ /\*\//)) {
            my $remarks = "";
            #end of description found
            $descr =~ s/\*\///g;
            #remove '\remarks' doxygen tags and all following text/description
            #move the 'remarks' text into a separate XML tag
            if ($descr =~ /\\remarks[\ \t*](.*)/){
               $remarks = $1;
               $descr =~ s/\\remarks.*//g;
               $remarks = "\t\t\t\t<remarks>$remarks</remarks>\n";
            }

            #remove any doxygen tags
            $descr =~ s/\\[a-z]+//g;

            $descr = stripDownString $descr;
            $descr =~ s/<descr>/\t\t\t<descr>\n/g;
            $descr =~ s/<param>/\t\t\t\t<param>/g;
            $descr .= "</param>\n";
            #append possible remarks
            $descr .= $remarks;
            $descr .= "\t\t\t</descr>\n";
            $insideDescr = 0;
            next;
         }
         ######################################################################

         if ($insideDescr == 0) {
            #line must contain a structure element
            if ($line =~ /^[\ \t]*([a-zA-Z0-9_]+)[\ \t]*[\ \t]*([a-zA-Z0-9_]+)/) {
               my $typeName = $1;
               my $elemName = $2;
               my $tmp = "\t\t<elem>\n\t\t\t<name>$elemName</name>\n";
               $tmp .= "\t\t\t<type>$typeName</type>\n";
               if ($line =~ /\[([a-zA-Z0-9_]+)\]/) {
                  #structure element is an array of a parameter type
                  $tmp .= "\t\t\t<amount>$1</amount>\n";
               }
               $tmp .= $descr;
               $tmp .= "\t\t</elem>\n";
               push @structValues, $tmp;
            }
         }
      }
   }

   @structures = sort @structures;
}

sub findIoctl {
   for (my $i = 0; $i < @inputFile; $i++) {
      my $line = $inputFile[$i];

      if ($line =~ /^[\ \t]*\#define[\ \t]*[a-zA-Z0-9_]+[\ \t]*_IO[WR_BAD]*.*/) {
         my $tmp = undef;

         if ($line =~ /^[\ \t]*\#define[\ \t]*([a-zA-Z0-9_]+)[\ \t]*_IO([WR_BAD]+)\(([a-zA-Z0-9_]+)[\ \t]*,[\ \t]([a-zA-Z0-9_]+),[\ \t]*([a-zA-Z0-9_]+)[\ \t]*\)/) {
            #$1 IOCTL name
            #$2 operator
            #$3 Magic numerator
            #$4 command offset
            #$5 command argument
            $tmp = "<ioctl>\n\t<name>$1</name>\n";
            $tmp .= "\t<type>$2</type>\n";
            $tmp .= "\t<magic>$3</magic>\n";
            $tmp .= "\t<offset>$4</offset>\n";
            $tmp .= "\t<arg>$5</arg>\n";
         }
         elsif ($line =~ /^[\ \t]*\#define[\ \t]*([a-zA-Z0-9_]+)[\ \t]*_IO[\ \t]*\(([a-zA-Z0-9_]+)[\ \t]*,[\ \t]*([a-zA-Z0-9_]+)[\ \t]*\)/) {
            #$1 IOCTL name
            #$2 Magic numerator
            #$3 command offset
            $tmp = "<ioctl>\n\t<name>$1</name>\n";
            $tmp .= "\t<type>None</type>\n";
            $tmp .= "\t<magic>$2</magic>\n";
            $tmp .= "\t<offset>$3</offset>\n";
         } else { $i +=1; die "ERROR: file \"$options{i}:$i\" contains unsupported IOCTL command!\n"; }

         ######################################################################
         #now find the IOCTL description.
         my $descr = "";

         #find the beginning of the comment before
         my $j = $i;
         for (; $j >= 0; $j--) {
            my $line2 = $inputFile[$j];

            if ($line2 =~ /\/\*\**(.*)/) {
               #beginning found
               my $tmp2 = $1;
               $tmp2 =~ s/\\ref //g;
               $tmp2 = stripDownString $tmp2;
               if (length($tmp2)) {
                  $descr .= "\t\t<param>$tmp2</param>\n";
               }
               last;
            }
         }

         for (my $k = $j + 1; $k < $i; $k++) {
            my $line2 = $inputFile[$k];
               if ($line2 =~ /\\param/) {
                  last;
               }
               $line2 =~ s/\\ref //g;
               $line2 = stripDownString $line2;
               if (length($line2)) {
                  $descr .= "\t\t<param>$line2</param>\n";
               }
         }

         $tmp .= "\t<descr>\n$descr\t</descr>\n";
         ######################################################################
         $tmp .= "</ioctl>\n";
         push @ioctls, $tmp;
      }
   }

   @ioctls = sort @ioctls;
}

########### main ###########

# parse command line options
getopts("i:o:", \%options) or die "invalid option\n";

if (defined $options{h}) {
   die PrintHelp;
}

if (not defined $options{i}) {
   print STDERR "ERROR: No input files given!\n\n";
   die PrintHelp;
}

if (not defined $options{o}) {
   print STDERR "ERROR: No output files given!\n\n";
   die PrintHelp;
}

readInputFile;

findEnumerators;
findStructures;
findIoctl;

writeOutputFile;
