#!/usr/bin/perl -w

my $cmd_name = "";
my $parameter_list = "";
my $parameteridx = 0;
my $linenumber = 0;
my %cmd_namelist = ();
my %paramlist = ();

while (<STDIN>) {
   $linenumber++;
   $_ =~ s/[\r\n]//g;

   if ($_ =~ /case ([a-zA-Z0-9_]*):/) {
      $cmd_name = $1;
      $parameter_list = "";
      $parameteridx = 0;

      die "Line $linenumber: Command \"$cmd_name\" previously found in line $cmd_namelist{$cmd_name}\n" if defined($cmd_namelist{$cmd_name});
      $cmd_namelist{$cmd_name} = $linenumber;
   }
   elsif ($_ =~ /([a-zA-Z0-9_\.]+)\ *=\ *cmd_arg\[([0-9]+)\]\;/) {
      die "Line $linenumber: Parameter Index is not correct!\n" if ($parameteridx != $2);
      $parameter_list .= $1 . " ";
      $parameteridx++;
   }
   elsif ($_ =~ /break;/) {
      $parameter_list =~ s/[\ \t]$//g;
      $paramlist{$cmd_name} = $parameter_list;
   }
   elsif (length($_) <= 1) {
   } else {
      die "Line $linenumber: Unknown line \"$_\"\n";
   }
}

foreach my $cmd (sort keys %paramlist) {
   print "\$parameterlist\{\"$cmd\"\} = \"$paramlist{$cmd}\";\n"
}
