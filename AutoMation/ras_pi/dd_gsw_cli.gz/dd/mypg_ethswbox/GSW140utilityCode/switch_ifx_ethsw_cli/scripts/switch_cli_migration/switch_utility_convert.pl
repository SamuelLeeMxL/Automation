#!/usr/bin/perl -w
use Fcntl;
use Getopt::Std;

my @file_content = ();
my %parameterlist = ();
my %commandlist = ();

my $fileLineNumber = 0;
my $fileContentChanged = 0;

###################  switch_utility parameter list  #####################

$parameterlist{"IFX_ETHSW_8021X_EAPOL_RULE_GET"} = "eForwardPort nForwardPortId";
$parameterlist{"IFX_ETHSW_8021X_EAPOL_RULE_SET"} = "eForwardPort";
$parameterlist{"IFX_ETHSW_8021X_PORT_CFG_GET"} = "nPortId";
$parameterlist{"IFX_ETHSW_8021X_PORT_CFG_SET"} = "nPortId eState";
$parameterlist{"IFX_ETHSW_CAP_GET"} = "nCapType";
$parameterlist{"IFX_ETHSW_CFG_GET"} = "eMAC_TableAgeTimer bVLAN_Aware nMaxPacketLen bLearningLimitAction bPauseMAC_ModeSrc nPauseMAC_Src";
$parameterlist{"IFX_ETHSW_CFG_SET"} = "eMAC_TableAgeTimer bVLAN_Aware nMaxPacketLen bPauseMAC_ModeSrc nPauseMAC_Src";
$parameterlist{"IFX_ETHSW_CPU_PORT_CFG_GET"} = "nPortId";
$parameterlist{"IFX_ETHSW_CPU_PORT_CFG_SET"} = "nPortId bFcsCheck bFcsGenerate bSpecialTagEgress bSpecialTagIngress bCPU_PortValid";
$parameterlist{"IFX_ETHSW_CPU_PORT_EXTEND_CFG_GET"} = "eHeaderAdd bHeaderRemove ePauseCtrl bFcsRemove nWAN_Ports";
$parameterlist{"IFX_ETHSW_CPU_PORT_EXTEND_CFG_SET"} = "eHeaderAdd bHeaderRemove sHeader.nMAC_Src sHeader.nMAC_Dst sHeader.nEthertype sHeader.nVLAN_Prio sHeader.nVLAN_CFI sHeader.nVLAN_ID ePauseCtrl bFcsRemove nWAN_Ports";
$parameterlist{"IFX_ETHSW_DISABLE"} = "";
$parameterlist{"IFX_ETHSW_ENABLE"} = "";
$parameterlist{"IFX_ETHSW_HW_INIT"} = "eInitMode";
$parameterlist{"IFX_ETHSW_MAC_TABLE_CLEAR"} = "";
$parameterlist{"IFX_ETHSW_MAC_TABLE_ENTRY_ADD"} = "nFId nPortId nAgeTimer bStaticEntry";
$parameterlist{"IFX_ETHSW_MAC_TABLE_ENTRY_REMOVE"} = "nFId";
$parameterlist{"IFX_ETHSW_MDIO_CFG_GET"} = "nMDIO_Speed bMDIO_Enable";
$parameterlist{"IFX_ETHSW_MDIO_CFG_SET"} = "bMDIO_Enable nMDIO_Speed";
$parameterlist{"IFX_ETHSW_MDIO_DATA_READ"} = "nAddressDev nAddressReg";
$parameterlist{"IFX_ETHSW_MDIO_DATA_WRITE"} = "nAddressDev nAddressReg nData";
$parameterlist{"IFX_ETHSW_MONITOR_PORT_CFG_GET"} = "nPortId";
$parameterlist{"IFX_ETHSW_MONITOR_PORT_CFG_SET"} = "nPortId bMonitorPort";
$parameterlist{"IFX_ETHSW_MULTICAST_ROUTER_PORT_ADD"} = "nPortId";
$parameterlist{"IFX_ETHSW_MULTICAST_ROUTER_PORT_READ"} = "bInitial nPortId";
$parameterlist{"IFX_ETHSW_MULTICAST_ROUTER_PORT_REMOVE"} = "nPortId";
$parameterlist{"IFX_ETHSW_MULTICAST_SNOOP_CFG_GET"} = "eIGMP_Mode bIGMPv3 bCrossVLAN eForwardPort nForwardPortId nClassOfService nRobust nQueryInterval eSuppressionAggregation bFastLeave bLearningRouter";
$parameterlist{"IFX_ETHSW_MULTICAST_SNOOP_CFG_SET"} = "eIGMP_Mode bIGMPv3 bCrossVLAN eForwardPort nForwardPortId nClassOfService nRobust nQueryInterval eSuppressionAggregation bFastLeave bLearningRouter";
$parameterlist{"IFX_ETHSW_MULTICAST_TABLE_ENTRY_ADD"} = "nPortId eIPVersion uIP_Gda uIP_Gsa eModeMember";
$parameterlist{"IFX_ETHSW_MULTICAST_TABLE_ENTRY_READ"} = "nPortId";
$parameterlist{"IFX_ETHSW_MULTICAST_TABLE_ENTRY_REMOVE"} = "nPortId eIPVersion uIP_Gda uIP_Gsa eModeMember";
$parameterlist{"IFX_ETHSW_PORT_CFG_GET"} = "nPortId";
$parameterlist{"IFX_ETHSW_PORT_CFG_SET"} = "nPortId eEnable bUnicastUnknownDrop bMulticastUnknownDrop bReservedPacketDrop bBroadcastDrop bAging bLearningMAC_PortLock nLearningLimit ePortMonitor eFlowCtrl";
$parameterlist{"IFX_ETHSW_PORT_LINK_CFG_GET"} = "nPortId";
$parameterlist{"IFX_ETHSW_PORT_LINK_CFG_SET"} = "nPortId bDuplexForce eDuplex bSpeedForce eSpeed bLinkForce eLink eMII_Mode eMII_Type eClkMode";
$parameterlist{"IFX_ETHSW_PORT_PHY_ADDR_GET"} = "nPortId";
$parameterlist{"IFX_ETHSW_PORT_PHY_QUERY"} = "nPortId";
$parameterlist{"IFX_ETHSW_PORT_REDIRECT_GET"} = "nPortId";
$parameterlist{"IFX_ETHSW_PORT_REDIRECT_SET"} = "nPortId bRedirectEgress bRedirectIngress";
$parameterlist{"IFX_ETHSW_PORT_RGMII_CLK_CFG_GET"} = "nPortId";
$parameterlist{"IFX_ETHSW_PORT_RGMII_CLK_CFG_SET"} = "nPortId nDelayRx nDelayTx";
$parameterlist{"IFX_ETHSW_QOS_DSCP_CLASS_GET"} = "";
$parameterlist{"IFX_ETHSW_QOS_DSCP_CLASS_SET"} = "nDSCP nTrafficClass";
$parameterlist{"IFX_ETHSW_QOS_CLASS_DSCP_GET"} = "";
$parameterlist{"IFX_ETHSW_QOS_CLASS_DSCP_SET"} = "nTrafficClass nDSCP";
$parameterlist{"IFX_ETHSW_QOS_METER_CFG_GET"} = "nMeterId";
$parameterlist{"IFX_ETHSW_QOS_METER_CFG_SET"} = "bEnable nMeterId nCbs nEbs nRate";
$parameterlist{"IFX_ETHSW_QOS_METER_PORT_ASSIGN"} = "nMeterId eDir nPortIngressId nPortEgressId";
$parameterlist{"IFX_ETHSW_QOS_METER_PORT_DEASSIGN"} = "nMeterId eDir nPortIngressId nPortEgressId";
$parameterlist{"IFX_ETHSW_QOS_METER_PORT_GET"} = "";
$parameterlist{"IFX_ETHSW_QOS_PCP_CLASS_GET"} = "";
$parameterlist{"IFX_ETHSW_QOS_PCP_CLASS_SET"} = "nPCP nTrafficClass";
$parameterlist{"IFX_ETHSW_QOS_CLASS_PCP_GET"} = "";
$parameterlist{"IFX_ETHSW_QOS_CLASS_PCP_SET"} = "nTrafficClass nPCP";
$parameterlist{"IFX_ETHSW_QOS_PORT_CFG_GET"} = "nPortId";
$parameterlist{"IFX_ETHSW_QOS_PORT_CFG_SET"} = "nPortId eClassMode nTrafficClass";
$parameterlist{"IFX_ETHSW_QOS_PORT_REMARKING_CFG_GET"} = "nPortId";
$parameterlist{"IFX_ETHSW_QOS_PORT_REMARKING_CFG_SET"} = "nPortId eDSCP_IngressRemarkingEnable bDSCP_EgressRemarkingEnable bPCP_IngressRemarkingEnable bPCP_EgressRemarkingEnable";
$parameterlist{"IFX_ETHSW_QOS_QUEUE_PORT_GET"} = "nPortId nTrafficClassId";
$parameterlist{"IFX_ETHSW_QOS_QUEUE_PORT_SET"} = "nQueueId nPortId nTrafficClassId";
$parameterlist{"IFX_ETHSW_QOS_SCHEDULER_CFG_GET"} = "nQueueId";
$parameterlist{"IFX_ETHSW_QOS_SCHEDULER_CFG_SET"} = "nQueueId eType nWeight";
$parameterlist{"IFX_ETHSW_QOS_SHAPER_CFG_GET"} = "nRateShaperId";
$parameterlist{"IFX_ETHSW_QOS_SHAPER_CFG_SET"} = "nRateShaperId bEnable nCbs nRate";
$parameterlist{"IFX_ETHSW_QOS_SHAPER_QUEUE_ASSIGN"} = "nRateShaperId nQueueId";
$parameterlist{"IFX_ETHSW_QOS_SHAPER_QUEUE_DEASSIGN"} = "nRateShaperId nQueueId";
$parameterlist{"IFX_ETHSW_QOS_STORM_CFG_GET"} = "nMeterId";
$parameterlist{"IFX_ETHSW_QOS_STORM_CFG_SET"} = "nMeterId bBroadcast bMulticast bUnknownUnicast";
$parameterlist{"IFX_ETHSW_QOS_WRED_CFG_GET"} = "eProfile nRed_Min nRed_Max nYellow_Min nYellow_Max nGreen_Min nGreen_Max ";
$parameterlist{"IFX_ETHSW_QOS_WRED_CFG_SET"} = "eProfile nRed_Min nRed_Max nYellow_Min nYellow_Max nGreen_Min nGreen_Max";
$parameterlist{"IFX_ETHSW_QOS_WRED_QUEUE_CFG_GET"} = "nQueueId";
$parameterlist{"IFX_ETHSW_QOS_WRED_QUEUE_CFG_SET"} = "nQueueId nRed_Min nRed_Max nYellow_Min nYellow_Max nGreen_Min nGreen_Max";
$parameterlist{"IFX_ETHSW_RMON_CLEAR"} = "nPortId";
$parameterlist{"IFX_ETHSW_RMON_GET"} = "nPortId";
$parameterlist{"IFX_ETHSW_STP_BPDU_RULE_GET"} = "eForwardPort nForwardPortId";
$parameterlist{"IFX_ETHSW_STP_BPDU_RULE_SET"} = "eForwardPort nForwardPortId";
$parameterlist{"IFX_ETHSW_STP_PORT_CFG_GET"} = "nPortId";
$parameterlist{"IFX_ETHSW_STP_PORT_CFG_SET"} = "nPortId ePortState";
$parameterlist{"IFX_ETHSW_VERSION_GET"} = "nId";
$parameterlist{"IFX_ETHSW_VLAN_ID_CREATE"} = "nVId nFId";
$parameterlist{"IFX_ETHSW_VLAN_ID_DELETE"} = "nVId";
$parameterlist{"IFX_ETHSW_VLAN_ID_GET"} = "nVId";
$parameterlist{"IFX_ETHSW_VLAN_PORT_CFG_GET"} = "nPortId";
$parameterlist{"IFX_ETHSW_VLAN_PORT_CFG_SET"} = "nPortId nPortVId bVLAN_UnknownDrop bVLAN_ReAssign eVLAN_MemberViolation eAdmitMode bTVM";
$parameterlist{"IFX_ETHSW_VLAN_PORT_MEMBER_ADD"} = "nVId nPortId bVLAN_TagEgress";
$parameterlist{"IFX_ETHSW_VLAN_PORT_MEMBER_REMOVE"} = "nVId nPortId";
$parameterlist{"IFX_ETHSW_VLAN_RESERVED_ADD"} = "nVId";
$parameterlist{"IFX_ETHSW_VLAN_RESERVED_REMOVE"} = "nVId";
$parameterlist{"IFX_FLOW_PCE_RULE_DELETE"} = "nIndex";
$parameterlist{"IFX_FLOW_PCE_RULE_READ"} = "pattern.nIndex";
$parameterlist{"IFX_FLOW_PCE_RULE_WRITE"} = "pattern.nIndex pattern.bEnable pattern.bPortIdEnable pattern.nPortId pattern.bDSCP_Enable pattern.nDSCP pattern.bPCP_Enable pattern.nPCP pattern.bPktLngEnable pattern.nPktLng pattern.nPktLngRange pattern.bMAC_DstEnable pattern.nMAC_Dst pattern.nMAC_DstMask pattern.bMAC_SrcEnable pattern.nMAC_Src pattern.nMAC_SrcMask pattern.bAppDataMSB_Enable pattern.nAppDataMSB pattern.bAppMaskRangeMSB_Select pattern.nAppMaskRangeMSB pattern.bAppDataLSB_Enable pattern.nAppDataLSB pattern.bAppMaskRangeLSB_Select pattern.nAppMaskRangeLSB pattern.eDstIP_Select pattern.nDstIP pattern.nDstIP_MsbMask pattern.eSrcIP_Select pattern.nSrcIP pattern.nSrcIP_MsbMask pattern.bEtherTypeEnable pattern.nEtherType pattern.nEtherTypeMask pattern.bProtocolEnable pattern.nProtocol pattern.nProtocolMask pattern.bSessionIdEnable pattern.nSessionId pattern.bVid pattern.nVid action.eTrafficClassAction action.nTrafficClassAlternate action.eSnoopingTypeAction action.eLearningAction action.eIrqAction action.eCrossStateAction action.eCritFrameAction action.eTimestampAction action.ePortMapAction action.nForwardPortMap action.bRemarkAction action.bRemarkPCP action.bRemarkDSCP action.bRemarkClass action.eMeterAction action.nMeterId action.bRMON_Action action.nRMON_Id action.eVLAN_Action action.nVLAN_Id action.eVLAN_CrossAction";
$parameterlist{"IFX_FLOW_REGISTER_GET"} = "nRegAddr";
$parameterlist{"IFX_FLOW_REGISTER_SET"} = "nRegAddr nData";
$parameterlist{"IFX_FLOW_RESET"} = "eReset";
$parameterlist{"IFX_FLOW_RMON_EXTEND_GET"} = "nPortId";
$parameterlist{"IFX_PSB6970_POWER_MANAGEMENT_GET"} = "";
$parameterlist{"IFX_PSB6970_POWER_MANAGEMENT_SET"} = "bEnable";
$parameterlist{"IFX_PSB6970_QOS_MFC_ADD"} = "sFilterMatchField.eFieldSelection sFilterMatchField.nPortSrc sFilterMatchField.nPortDst sFilterMatchField.nPortSrcRange sFilterMatchField.nPortDstRange sFilterMatchField.nProtocol sFilterMatchField.nEtherType sFilterInfo.nTrafficClass sFilterInfo.ePortForward";
$parameterlist{"IFX_PSB6970_QOS_MFC_DEL"} = "eFieldSelection nPortSrc nPortDst nPortSrcRange nPortDstRange nProtocol nEtherType";
$parameterlist{"IFX_PSB6970_QOS_MFC_ENTRY_READ"} = "";
$parameterlist{"IFX_PSB6970_QOS_MFC_PORT_CFG_GET"} = "nPort";
$parameterlist{"IFX_PSB6970_QOS_MFC_PORT_CFG_SET"} = "nPort bPriorityPort bPriorityEtherType";
$parameterlist{"IFX_PSB6970_QOS_PORT_POLICER_GET"} = "nPort";
$parameterlist{"IFX_PSB6970_QOS_PORT_POLICER_SET"} = "nPort nRate";
$parameterlist{"IFX_PSB6970_QOS_PORT_SHAPER_CFG_GET"} = "nPort";
$parameterlist{"IFX_PSB6970_QOS_PORT_SHAPER_CFG_SET"} = "nPort eWFQ_Type";
$parameterlist{"IFX_PSB6970_QOS_PORT_SHAPER_STRICT_GET"} = "nPort nTrafficClass";
$parameterlist{"IFX_PSB6970_QOS_PORT_SHAPER_STRICT_SET"} = "nPort nTrafficClass nRate";
$parameterlist{"IFX_PSB6970_QOS_PORT_SHAPER_WFQ_GET"} = "nPort nTrafficClass";
$parameterlist{"IFX_PSB6970_QOS_PORT_SHAPER_WFQ_SET"} = "nPort nTrafficClass nRate";
$parameterlist{"IFX_PSB6970_QOS_STORM_GET"} = "";
$parameterlist{"IFX_PSB6970_QOS_STORM_SET"} = "bBroadcast bMulticast bUnicast nThreshold10M nThreshold100M";
$parameterlist{"IFX_PSB6970_REGISTER_GET"} = "nRegAddr";
$parameterlist{"IFX_PSB6970_REGISTER_SET"} = "nRegAddr nData";
$parameterlist{"IFX_PSB6970_RESET"} = "eReset";

###################  end of switch_utility parameter list  #####################

$commandlist{"8021X_EAPOL_RuleGet"} = "IFX_ETHSW_8021X_EAPOL_RULE_GET";
$commandlist{"8021X_EAPOL_RuleSet"} = "IFX_ETHSW_8021X_EAPOL_RULE_SET";
$commandlist{"8021X_PortCfgGet"} = "IFX_ETHSW_8021X_PORT_CFG_GET";
$commandlist{"8021X_PortCfgSet"} = "IFX_ETHSW_8021X_PORT_CFG_SET";
$commandlist{"CPU_PortCfgGet"} = "IFX_ETHSW_CPU_PORT_CFG_GET";
$commandlist{"CPU_PortCfgSet"} = "IFX_ETHSW_CPU_PORT_CFG_SET";
$commandlist{"CPU_PortExtendCfgGet"} = "IFX_ETHSW_CPU_PORT_EXTEND_CFG_GET";
$commandlist{"CPU_PortExtendCfgSet"} = "IFX_ETHSW_CPU_PORT_EXTEND_CFG_SET";
$commandlist{"CapGet"} = "IFX_ETHSW_CAP_GET";
$commandlist{"CfgGet"} = "IFX_ETHSW_CFG_GET";
$commandlist{"CfgSet"} = "IFX_ETHSW_CFG_SET";
$commandlist{"Disable"} = "IFX_ETHSW_DISABLE";
$commandlist{"Enable"} = "IFX_ETHSW_ENABLE";
$commandlist{"HW_Init"} = "IFX_ETHSW_HW_INIT";
$commandlist{"MAC_TableClear"} = "IFX_ETHSW_MAC_TABLE_CLEAR";
$commandlist{"MAC_TableEntryAdd"} = "IFX_ETHSW_MAC_TABLE_ENTRY_ADD";
$commandlist{"MAC_TableEntryRead"} = "IFX_ETHSW_MAC_TABLE_ENTRY_READ";
$commandlist{"MAC_TableEntryRemove"} = "IFX_ETHSW_MAC_TABLE_ENTRY_REMOVE";
$commandlist{"MDIO_CfgGet"} = "IFX_ETHSW_MDIO_CFG_GET";
$commandlist{"MDIO_CfgSet"} = "IFX_ETHSW_MDIO_CFG_SET";
$commandlist{"MDIO_DataRead"} = "IFX_ETHSW_MDIO_DATA_READ";
$commandlist{"MDIO_DataWrite"} = "IFX_ETHSW_MDIO_DATA_WRITE";
$commandlist{"MonitorPortGet"} = "IFX_ETHSW_MONITOR_PORT_CFG_GET";
$commandlist{"MonitorPortSet"} = "IFX_ETHSW_MONITOR_PORT_CFG_SET";
$commandlist{"MulticastRouterPortAdd"} = "IFX_ETHSW_MULTICAST_ROUTER_PORT_ADD";
$commandlist{"MulticastRouterPortRead"} = "IFX_ETHSW_MULTICAST_ROUTER_PORT_READ";
$commandlist{"MulticastRouterPortRemove"} = "IFX_ETHSW_MULTICAST_ROUTER_PORT_REMOVE";
$commandlist{"MulticastSnoopCfgGet"} = "IFX_ETHSW_MULTICAST_SNOOP_CFG_GET";
$commandlist{"MulticastSnoopCfgSet"} = "IFX_ETHSW_MULTICAST_SNOOP_CFG_SET";
$commandlist{"MulticastTableEntryAdd"} = "IFX_ETHSW_MULTICAST_TABLE_ENTRY_ADD";
$commandlist{"MulticastTableEntryRead"} = "IFX_ETHSW_MULTICAST_TABLE_ENTRY_READ";
$commandlist{"MulticastTableEntryRemove"} = "IFX_ETHSW_MULTICAST_TABLE_ENTRY_REMOVE";
$commandlist{"PCE_RuleDelete"} = "IFX_FLOW_PCE_RULE_DELETE";
$commandlist{"PCE_RuleRead"} = "IFX_FLOW_PCE_RULE_READ";
$commandlist{"PCE_RuleWrite"} = "IFX_FLOW_PCE_RULE_WRITE";
$commandlist{"PHY_AddrGet"} = "IFX_ETHSW_PORT_PHY_ADDR_GET";
$commandlist{"PHY_Query"} = "IFX_ETHSW_PORT_PHY_QUERY";
$commandlist{"PortCfgGet"} = "IFX_ETHSW_PORT_CFG_GET";
$commandlist{"PortCfgSet"} = "IFX_ETHSW_PORT_CFG_SET";
$commandlist{"PortLinkCfgGet"} = "IFX_ETHSW_PORT_LINK_CFG_GET";
$commandlist{"PortLinkCfgSet"} = "IFX_ETHSW_PORT_LINK_CFG_SET";
$commandlist{"PortRGMII_ClkCfgGet"} = "IFX_ETHSW_PORT_RGMII_CLK_CFG_GET";
$commandlist{"PortRGMII_ClkCfgSet"} = "IFX_ETHSW_PORT_RGMII_CLK_CFG_SET";
$commandlist{"PortRedirectGet"} = "IFX_ETHSW_PORT_REDIRECT_GET";
$commandlist{"PortRedirectSet"} = "IFX_ETHSW_PORT_REDIRECT_SET";
$commandlist{"PowerManagementGet"} = "IFX_PSB6970_POWER_MANAGEMENT_GET";
$commandlist{"PowerManagementSet"} = "IFX_PSB6970_POWER_MANAGEMENT_SET";
$commandlist{"QOS_ClassDSCPGet"} = "IFX_ETHSW_QOS_CLASS_DSCP_GET";
$commandlist{"QOS_ClassDSCPSet"} = "IFX_ETHSW_QOS_CLASS_DSCP_SET";
$commandlist{"QOS_ClassPCPGet"} = "IFX_ETHSW_QOS_CLASS_PCP_GET";
$commandlist{"QOS_ClassPCPSet"} = "IFX_ETHSW_QOS_CLASS_PCP_SET";
$commandlist{"QOS_DscpClassGet"} = "IFX_ETHSW_QOS_DSCP_CLASS_GET";
$commandlist{"QOS_DscpClassSet"} = "IFX_ETHSW_QOS_DSCP_CLASS_SET";
$commandlist{"QOS_MFC_Add"} = "IFX_PSB6970_QOS_MFC_ADD";
$commandlist{"QOS_MFC_Del"} = "IFX_PSB6970_QOS_MFC_DEL";
$commandlist{"QOS_MFC_EntryRead"} = "IFX_PSB6970_QOS_MFC_ENTRY_READ";
$commandlist{"QOS_MFC_PortCfgGet"} = "IFX_PSB6970_QOS_MFC_PORT_CFG_GET";
$commandlist{"QOS_MFC_PortCfgSet"} = "IFX_PSB6970_QOS_MFC_PORT_CFG_SET";
$commandlist{"QOS_MeterCfgGet"} = "IFX_ETHSW_QOS_METER_CFG_GET";
$commandlist{"QOS_MeterCfgSet"} = "IFX_ETHSW_QOS_METER_CFG_SET";
$commandlist{"QOS_MeterPortAssign"} = "IFX_ETHSW_QOS_METER_PORT_ASSIGN";
$commandlist{"QOS_MeterPortDeassign"} = "IFX_ETHSW_QOS_METER_PORT_DEASSIGN";
$commandlist{"QOS_MeterPortGet"} = "IFX_ETHSW_QOS_METER_PORT_GET";
$commandlist{"QOS_PcpClassGet"} = "IFX_ETHSW_QOS_PCP_CLASS_GET";
$commandlist{"QOS_PcpClassSet"} = "IFX_ETHSW_QOS_PCP_CLASS_SET";
$commandlist{"QOS_PortCfgGet"} = "IFX_ETHSW_QOS_PORT_CFG_GET";
$commandlist{"QOS_PortCfgSet"} = "IFX_ETHSW_QOS_PORT_CFG_SET";
$commandlist{"QOS_PortPolicerGet"} = "IFX_PSB6970_QOS_PORT_POLICER_GET";
$commandlist{"QOS_PortPolicerSet"} = "IFX_PSB6970_QOS_PORT_POLICER_SET";
$commandlist{"QOS_PortRemarkingCfgGet"} = "IFX_ETHSW_QOS_PORT_REMARKING_CFG_GET";
$commandlist{"QOS_PortRemarkingCfgSet"} = "IFX_ETHSW_QOS_PORT_REMARKING_CFG_SET";
$commandlist{"QOS_PortShaperCfgGet"} = "IFX_PSB6970_QOS_PORT_SHAPER_CFG_GET";
$commandlist{"QOS_PortShaperCfgSet"} = "IFX_PSB6970_QOS_PORT_SHAPER_CFG_SET";
$commandlist{"QOS_PortShaperGet"} = "IFX_PSB6970_QOS_PORT_SHAPER_GET";
$commandlist{"QOS_PortShaperSet"} = "IFX_PSB6970_QOS_PORT_SHAPER_SET";
$commandlist{"QOS_PortShaperStrictGet"} = "IFX_PSB6970_QOS_PORT_SHAPER_STRICT_GET";
$commandlist{"QOS_PortShaperStrictSet"} = "IFX_PSB6970_QOS_PORT_SHAPER_STRICT_SET";
$commandlist{"QOS_PortShaperWFQGet"} = "IFX_PSB6970_QOS_PORT_SHAPER_WFQ_GET";
$commandlist{"QOS_PortShaperWFQSet"} = "IFX_PSB6970_QOS_PORT_SHAPER_WFQ_SET";
$commandlist{"QOS_QueuePortGet"} = "IFX_ETHSW_QOS_QUEUE_PORT_GET";
$commandlist{"QOS_QueuePortSet"} = "IFX_ETHSW_QOS_QUEUE_PORT_SET";
$commandlist{"QOS_SchedulerCfgGet"} = "IFX_ETHSW_QOS_SCHEDULER_CFG_GET";
$commandlist{"QOS_SchedulerCfgSet"} = "IFX_ETHSW_QOS_SCHEDULER_CFG_SET";
$commandlist{"QOS_ShaperCfgGet"} = "IFX_ETHSW_QOS_SHAPER_CFG_GET";
$commandlist{"QOS_ShaperCfgSet"} = "IFX_ETHSW_QOS_SHAPER_CFG_SET";
$commandlist{"QOS_ShaperQueueAssign"} = "IFX_ETHSW_QOS_SHAPER_QUEUE_ASSIGN";
$commandlist{"QOS_ShaperQueueDeassign"} = "IFX_ETHSW_QOS_SHAPER_QUEUE_DEASSIGN";
$commandlist{"QOS_StormAdd"} = "IFX_ETHSW_QOS_STORM_CFG_SET";
$commandlist{"QOS_StormGet"} = "IFX_ETHSW_QOS_STORM_CFG_GET";
$commandlist{"QOS_StormSet"} = "IFX_PSB6970_QOS_STORM_SET";
$commandlist{"QOS_WredCfgGet"} = "IFX_ETHSW_QOS_WRED_CFG_GET";
$commandlist{"QOS_WredCfgSet"} = "IFX_ETHSW_QOS_WRED_CFG_SET";
$commandlist{"QOS_WredQueueCfgGet"} = "IFX_ETHSW_QOS_WRED_QUEUE_CFG_GET";
$commandlist{"RGMII_CfgGet"} = "IFX_ETHSW_PORT_RGMII_CLK_CFG_GET";
$commandlist{"RGMII_CfgSet"} = "IFX_ETHSW_PORT_RGMII_CLK_CFG_SET";
$commandlist{"RMON_Clear"} = "IFX_ETHSW_RMON_CLEAR";
$commandlist{"RMON_ExtendGet"} = "IFX_FLOW_RMON_EXTEND_GET";
$commandlist{"RMON_Get"} = "IFX_ETHSW_RMON_GET";
$commandlist{"RegisterGet"} = "IFX_FLOW_REGISTER_GET";
$commandlist{"RegisterSet"} = "IFX_FLOW_REGISTER_SET";
$commandlist{"Reset"} = "IFX_FLOW_RESET";
$commandlist{"STP_BPDU_RULE_Get"} = "IFX_ETHSW_STP_BPDU_RULE_GET";
$commandlist{"STP_BPDU_RULE_Set"} = "IFX_ETHSW_STP_BPDU_RULE_SET";
$commandlist{"STP_PortCfgGet"} = "IFX_ETHSW_STP_PORT_CFG_GET";
$commandlist{"STP_PortCfgSet"} = "IFX_ETHSW_STP_PORT_CFG_SET";
$commandlist{"VLAN_IdCreate"} = "IFX_ETHSW_VLAN_ID_CREATE";
$commandlist{"VLAN_IdDelete"} = "IFX_ETHSW_VLAN_ID_DELETE";
$commandlist{"VLAN_IdGet"} = "IFX_ETHSW_VLAN_ID_GET";
$commandlist{"VLAN_PortCfgGet"} = "IFX_ETHSW_VLAN_PORT_CFG_GET";
$commandlist{"VLAN_PortCfgSet"} = "IFX_ETHSW_VLAN_PORT_CFG_SET";
$commandlist{"VLAN_PortMapTableRead"} = "IFX_ETHSW_VLAN_PORT_MEMBER_READ";
$commandlist{"VLAN_PortMemberAdd"} = "IFX_ETHSW_VLAN_PORT_MEMBER_ADD";
$commandlist{"VLAN_PortMemberRemove"} = "IFX_ETHSW_VLAN_PORT_MEMBER_REMOVE";
$commandlist{"VLAN_ReservedAdd"} = "IFX_ETHSW_VLAN_RESERVED_ADD";
$commandlist{"VLAN_ReservedRemove"} = "IFX_ETHSW_VLAN_RESERVED_REMOVE";
$commandlist{"VersionGet"} = "IFX_ETHSW_VERSION_GET";


if (!$ARGV[1]) {
print "Converts shell script from \"switch_utility\" usage to \"switch_cli\" usage.

Usage: <input_file> <output_file>

   input_file -  input shell script, containing \"switch_utility\" calls, to convert.
                 will only be read and not modified.

   output_file - output shell script containing the \"switch_cli\" calls
                 This file will be created and existing files will be overwritten.
                 No file is written or generated in case \"switch_utility\" is not found
                 in <input_file>.
";
exit;

}


#read input file content;
sysopen(IN, $ARGV[0], O_RDONLY) || die "$ARGV[0] could not be opened!\n";
while (<IN>) {
   push @file_content, $_;
}
close (IN);

#check if the file contains a "switch_utility" call
my $switch_utility_found = 0;
my $switch_utility_int_found = 0;
foreach my $line (@file_content) {
   if ($line =~ /switch_utility/) {
      $switch_utility_found = 1;
   }
   if ($line =~ /switch_utility_int/) {
      $switch_utility_int_found = 1;
   }
}
if (($switch_utility_found == 0) && ($switch_utility_int_found == 0)) {
   #script does not contain any "switch_utility" calls
   exit 0;
}

my $switch_cli_int = "";
my $switch_cli = "";

if ($switch_utility_int_found == 0) {
   #no internal switch_utility call routines found
   $switch_cli = "switch_cli ";
} else {
   #internal switch_utility call routines found
   $switch_cli_int = "switch_cli dev=0 ";
   $switch_cli = "switch_cli dev=1 ";
}

#some script switch_utility command calls use "\" and are split over multiple lines (two or more)
my $no_merging_done = 1;
while ($no_merging_done == 1) {
   $no_merging_done = 0;
   for (my $i = 0; $i < @file_content; $i++) {
      if (($file_content[$i] =~ /switch_utility/) && ($file_content[$i] =~ /\\[\ \t\r]*\n/)) {
         $file_content[$i] =~ s/\\[\ \t\r]*\n//;
         $file_content[$i] .= $file_content[$i + 1];
         $file_content[$i + 1] = "";
         $no_merging_done = 1;
      }
   }

   #rearrange array and remove empty elements
   my @tmp = ();
   foreach my $line (@file_content) {
      if (length($line) > 0) {
         push @tmp, $line;
      }
   }
   @file_content = @tmp;
}

sub cmd_convert {
   my ($line, $switch_cli_cmd) = @_;

   if ($line =~ /switch_utility[\ \\t]+(.*)/) {
      my $param = $1;
      $param =~ s/[\ \t]+/\ /g;
      $param =~ s/[\r\t]+$//g;
      my @paramList = split / /, $param;
      if (length (@paramList) == 0) {
         print "File $ARGV[0], Line $fileLineNumber: \"switch_utility\" call without parameter\n";
         return $line;
      }

      die "File $ARGV[0] , Line $fileLineNumber: switch_utility command unknown!\n" if not defined($commandlist{$paramList[0]});
      die "No \"$commandlist{$paramList[0]}\" arguments given\n" if not defined ($parameterlist{$commandlist{$paramList[0]}});

      my $newCommand = $switch_cli_cmd . $commandlist{$paramList[0]};
      my @newParamList = split / /, $parameterlist{$commandlist{$paramList[0]}};

      for (my $i = 1, my $j = 0; $i < @paramList; $i++, $j++) {
         die "File $ARGV[0] , Line $fileLineNumber: Unexpected command parameter error!\n" if not defined($paramList[$i]);
         die "File $ARGV[0] , Line $fileLineNumber: $paramList[$i] command parameter not portable\n" if not defined($newParamList[$j]);
         $newCommand .= " $newParamList[$j]=$paramList[$i]";
      }

      $line =~ s/switch_utility.*[\r\n]*//;
      $line .= $newCommand . "\n";

      return $line;
   }
}

for (my $i = 0, $fileLineNumber = 1; $i < @file_content; $i++, $fileLineNumber++) {
   if ($file_content[$i] =~ /switch_utility_int/) {
      $fileContentChanged = 1;
      $file_content[$i] = cmd_convert($file_content[$i], $switch_cli_int);
   }
   elsif ($file_content[$i] =~ /switch_utility/) {
      $fileContentChanged = 1;
      $file_content[$i] = cmd_convert($file_content[$i], $switch_cli);
   }
}

#read input file content;
if ($fileContentChanged != 0) {
   sysopen(OUT, $ARGV[1], O_WRONLY | O_CREAT | O_TRUNC) || die "$ARGV[1] could not be opened!\n";
   print OUT @file_content;
   close (OUT);
}
