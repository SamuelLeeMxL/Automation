/******************************************************************************

         Copyright 2016 - 2017 Intel Corporation
         Copyright 2015 - 2016 Lantiq Beteiligungs-GmbH & Co. KG
         Copyright 2012 - 2014 Lantiq Deutschland GmbH

  SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only)

******************************************************************************/

#ifndef __GPY211_CFG_H__
#define __GPY211_CFG_H__

#define ENABLE_CHIP_FUNC			0
#define READ_VENDOR_SPECIFIC_LINK_STATUS	1

#endif /* __GPY211_CFG_H__ */

