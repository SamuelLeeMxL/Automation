/******************************************************************************

         Copyright 2016 - 2017 Intel Corporation
         Copyright 2015 - 2016 Lantiq Beteiligungs-GmbH & Co. KG
         Copyright 2012 - 2014 Lantiq Deutschland GmbH

  SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only);

******************************************************************************/

#ifndef _UTILITY_PG31_H_
#define _UTILITY_PG31_H_

void print_p31g_std();
void print_p31g_phy();
void print_p31g_pma();
void print_p31g_pcs();
void print_p31g_aneg();
void print_p31g_vspec1();
void print_p31g_vspec2();
void print_p31g_sgmii();
void print_p31g_uart();
void print_p31g_mspi();
void print_p31g_smdio();
void print_p31g_mmdio();
void print_p31g_led();
void print_p31g_icu();
void print_p31g_gpio();
void print_p31g_sbuf();
void print_p31g_pm();
void print_p31g_foxvil();
void print_p31g_dcpm();
void print_p31g_crcu();
void print_p31g_srcu();
void print_p31g_cgu();
void print_p31g_pmu();
void print_p31g_chipid();
void print_p31g_top();
void print_p31g_pvt();
void print_p31g_xofsci();
void print_p31g_gphy();
void print_p31g_ssc();
void print_p31g_cdb();
void print_p31g_cdb_fsci();
void 	print_p31g_mfsci();
void print_p31g_regs();

#endif /* _UTILITY_PG31_H_ */

