/******************************************************************************

         Copyright 2016 - 2017 Intel Corporation
         Copyright 2015 - 2016 Lantiq Beteiligungs-GmbH & Co. KG
         Copyright 2012 - 2014 Lantiq Deutschland GmbH

  SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only)

******************************************************************************/

#ifndef _USER_MDIO_INTERFACE_H_
#define _USER_MDIO_INTERFACE_H_

int gpy211_mdio_read(void *busdata, u16 phyaddr, u32 regnum);
int gpy211_mdio_write(void *busdata, u16 phyaddr, u32 regnum, u16 data);

struct gpy211_device* gpy211_mdio_open (void);
void gpy211_mdio_close (void);
#endif /* _USER_MDIO_INTERFACE_H_ */

