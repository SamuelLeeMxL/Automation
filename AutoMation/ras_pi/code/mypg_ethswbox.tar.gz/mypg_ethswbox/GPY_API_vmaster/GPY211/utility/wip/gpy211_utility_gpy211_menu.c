/******************************************************************************

         Copyright 2016 - 2017 Intel Corporation
         Copyright 2015 - 2016 Lantiq Beteiligungs-GmbH & Co. KG
         Copyright 2012 - 2014 Lantiq Deutschland GmbH

  SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only)

******************************************************************************/

#include <windows_stub.h>
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <gpy211.h>
//#include <gpy211_gmac.h>
#include <gpy211_macsec.h>
#include "gpy211_utility.h"

#if FCON_MSEC_TEST
#include <e160_api.h>
#endif
//#include <eip160_common.h>
#include<time.h>


#include "gpy211_utility_gpy211_menu.h"



#define ARRAY_SIZE(x)	(sizeof(x) / sizeof((x)[0]))

static struct {
	const char *cmd;
	const char *brief;
	const char *desc;
} help_text[] = {
	{
		"exit",
		"Exit GPY211 utility tool",
		NULL
	},
	{
		"help",
		"Print this help page",
		NULL
	},
	{
		"en_debug",
		"Enable debugging codes",
		"en_debug <option>\n"
		"  option: 0 - disable, 1 -enable\n"
	},
	{
		"gpy2xx_init",
		"Initialize GPY211 API",
		NULL
	},
	{
		"gpy2xx_uninit",
		"Clean up GPY211 API",
		NULL
	},
	{
		"gpy2xx_get_phy_id",
		"Read PHY/Chip/Firmware/Driver version number",
		NULL
	},
	{
		"gpy2xx_soft_reset",
		"Trigger soft reset via MDIO STD_CTRL",
		NULL
	},
	{
		"gpy2xx_poll_reset",
		"Poll soft reset status",
		NULL
	},
#if defined(EN_SMDIO_RW) && EN_SMDIO_RW
	{
		"smdio_read",
		"Read internal register (may be disabled by PHY firmware)",
		"smdio_read <regaddr=?>\n"
		"  regaddr: register address\n"
	},
	{
		"smdio_write",
		"Write internal register (may be disabled by PHY firmware)",
		"smdio_write <regaddr=?> <data=?>\n"
		"  regaddr: register address\n"
		"  data:    value\n"
	},
#endif
	{
		"gpy2xx_read",
		"Read MDIO Clause 22 registers",
		"gpy2xx_read <regaddr=?>\n"
		"  regaddr: register address\n"
	},
	{
		"gpy2xx_write",
		"Write MDIO Clause 22 registers",
		"gpy2xx_write <regaddr=?> <data=?>\n"
		"  regaddr: register address\n"
		"  data:    value\n"
	},
	{
		"gpy2xx_read_mmd",
		"Read MDIO Clause 45 MMD registers",
		"gpy2xx_read_mmd <devtype=?> <regaddr=?>\n"
		"  devtype: MMD device type\n"
		"  regaddr: register address\n"
	},
	{
		"gpy2xx_write_mmd",
		"Write MDIO Clause 45 MMD registers",
		"gpy2xx_write_mmd <devtype=?> <regaddr=?> <data=?>\n"
		"  devtype: MMD device type\n"
		"  regaddr: register address\n"
		"  data:    value\n"
	},
#if defined(P31G_IND_RW) && P31G_IND_RW
	{
		"pm_ind_read",
		"PM's indirect register read",
		"pm_ind_read <regaddr=?>\n"
		"  regaddr: register address\n"
	},
	{
		"pm_ind_write",
		"PM's indirect register write",
		"pm_ind_write <regaddr=?>\n"
		"  regaddr: register address\n"
		"  data:    value\n"
	},
#endif
	{
		"gpy2xx_mbox_read16",
		"PHY's Mbox 16-bit wide register read",
		"gpy2xx_mbox_read16 <regaddr=?>\n"
		"  regaddr: register address\n"
	},
	{
		"gpy2xx_mbox_write16",
		"PHY's Mbox 16-bit wide register write",
		"gpy2xx_mbox_write16 <regaddr=?>\n"
		"  regaddr: register address\n"
		"  data:    value\n"
	},
	{
		"gpy2xx_mbox_read32",
		"PHY's Mbox 32-bit wide register read",
		"gpy2xx_mbox_read32 <regaddr=?>\n"
		"  regaddr: register address\n"
	},
	{
		"gpy2xx_mbox_write32",
		"PHY's Mbox 32-bit wide register write",
		"gpy2xx_mbox_write32 <regaddr=?>\n"
		"  regaddr: register address\n"
		"  data:    value\n"
	},
	{
		"gpy2xx_config_advert",
		"Advertise auto-negotiation parameters",
		"gpy2xx_config_advert <advertising=?>\n"
		"  advertising: 10baseT_Half|10baseT_Full|100baseT_Half|100baseT_Full\n"
		"               1000baseT_Half|1000baseT_Full|2500baseT_Full|2500baseT_FR\n"
		"               Autoneg|Pause|Asym_Pause\n"
	},
	{
		"gpy2xx_setup_forced",
		"Configures/forces speed/duplex",
		"gpy2xx_setup_forced <speed=?> <duplex=?> <pause=?> <asym_pause=?>\n"
		"  speed:      10/100/1000/2500\n"
		"  duplex:     full/half\n"
		"  pause:      true/false\n"
		"  asym_pause: true/false\n"
	},
	{
		"gpy2xx_restart_aneg",
		"Enable and restart auto-negotiation",
		NULL
	},
	{
		"gpy2xx_config_aneg",
		"Restart auto-negotiation or force link",
		"gpy2xx_config_aneg <autoneg=?> [advertising=?] [<speed=?> <duplex=?> <pause=?> <asym_pause=?>]\n"
		"  autoneg:     true/false\n"
		"  advertising: 10baseT_Half|10baseT_Full|100baseT_Half|100baseT_Full\n"
		"               1000baseT_Half|1000baseT_Full|2500baseT_Full|2500baseT_FR\n"
		"               Autoneg|Pause|Asym_Pause\n"
		"  speed:       10/100/1000/2500\n"
		"  duplex:      full/half\n"
		"  pause:       true/false\n"
		"  asym_pause:  true/false\n"
	},
	{
		"gpy2xx_aneg_done",
		"Get auto-negotiation status",
		NULL
	},
	{
		"gpy2xx_update_link",
		"Get link status (up/down)",
		NULL
	},
	{
		"gpy2xx_read_status",
		"Get link status (detail)",
		NULL
	},
	{
		"gpy2xx_read_fw_info",
		"Get FW info (detail)",
		NULL
	},
	{
		"gpy2xx_gpio_cfg",
		"Configure GPIO pin",
		"For internal use.\n"
		"gpy2xx_gpio_cfg <pinid=?> <gpioflags=?>\n"
		"  pinid:     16-bit pin ID\n"
		"  gpioflags: GPIO configuration flags\n"
	},
	{
		"gpy2xx_gpio_get",
		"Get GPIO pin configuration",
		"For internal use.\n"
		"gpy2xx_gpio_get <pinid=?>\n"
		"  pinid:     16-bit pin ID\n"
	},
	{
		"gpy2xx_gpio_output",
		"Configure GPIO pin output value (low/high)",
		"For internal use.\n"
		"gpy2xx_gpio_output <pinid=?> <gpioflags=?>\n"
		"  pinid:     16-bit pin ID\n"
		"  gpioflags: 0 - low, 2 - high\n"
	},
	{
		"gpy2xx_gpio_input",
		"Get GPIO pin input value (low/high)",
		"For internal use.\n"
		"gpy2xx_gpio_input <pinid=?>\n"
		"  pinid:     16-bit pin ID\n"
	},
	{
		"gpy2xx_led_br_cfg",
		"Configure LED brightness",
		"For internal use.\n"
		"gpy2xx_led_br_cfg <brightmode=?> <brightlvlmin=?> <brightlvlmax=?> <swedgedetect=?> <sensingperiod=?> <dischargeslots=?>\n"
		"  brightmode: 0 - constant level at max brightness\n"
		"              1 - constant level given by brightlvlmax\n"
		"              2 - 2 level switch between brightlvlmin and brightlvlmax\n"
		"              3 - 16 level switch mode\n"
	},
	{
		"gpy2xx_led_br_get",
		"Get LED brightness configuration",
		"For internal use.\n"
	},
#if defined(EN_LED_TOP_CFG) && EN_LED_TOP_CFG
	{
		"gpy2xx_led_top_cfg",
		"LED general configuration",
		"For internal use.\n"
		"gpy2xx_led_top_cfg <complexscan=?> <complexblink=?> <inversescan=?> <fastblinkfreq=?> <slowblinkfreq=?>\n"
		"  complexscan:  in which state the 'inverse complex SCAN' is activated, refer to below state table\n"
		"  complexblink: in which state the 'complex blinking' is activated, refer to below state table\n"
		"  inversescan:  in which state the 'complex SCAN' is activated, refer to below state table\n"
		"  fastblinkfreq:the slow-blinking frequency, refer to below frequency table\n"
		"  slowblinkfreq:the fast-blinking frequency, refer to below frequency table\n"
		"state table\n"
		"	0 - disable\n"
		"	1 - Link is UP\n"
		"	2 - Device is in power down\n"
		"	3 - Device is in EEE mode\n"
		"	4 - ANEG is running\n"
		"	5 - ABIST is running\n"
		"	6 - CDIAG is running\n"
		"	7 - TEST mode is running\n"
		"frequency table\n"
		"	0 - 2 Hz blinking frequency\n"
		"	1 - 4 Hz blinking frequency\n"
		"	2 - 8 Hz blinking frequency\n"
		"	3 - 16 Hz blinking frequency\n"
	},
	{
		"gpy2xx_led_top_get",
		"Get LED general configuration",
		"For internal use.\n"
	},
#endif
	{
		"gpy2xx_led_if_cfg",
		"Configure LED",
		"gpy2xx_led_if_cfg <ledid=?> <colormode=?> <slowblinksrc=?> <fastblinksrc=?> <constantlyon=?> <pulseflags=?>\n"
		"  ledid:        0~3\n"
		"  colormode:    internal use\n"
		"  slowblinksrc: event to trigger slow blink, refer to below trigger table\n"
		"  fastblinksrc: event to trigger fast blink, refer to below trigger table\n"
		"  constantlyon: event to trigger constant on, refer to below trigger table\n"
		"  pulseflags:   pulse on LED trigger by combination of following events\n"
		"                1 - transmit activity\n"
		"                2 - receive activity\n"
		"                4 - collision\n"
		"Trigger Table\n"
		"   0 - disable\n"
		"   1 - 10Mbps\n"
		"   2 - 100Mbps\n"
		"   4 - 1000Mbps\n"
		"   8 - 2500Mbps link\n"
	},
	{
		"gpy2xx_led_if_get",
		"Get LED configuration",
		"gpy2xx_led_if_get <ledid=?>\n"
		"  ledid:        0~3\n"
	},
#if EN_SUPPORT_TOP_INT
	{
		"gpy2xx_topin_cfg",
		"Configure external interrupt",
		"For internal use."
	},
	{
		"gpy2xx_topin_get",
		"Get external interrupt configuration",
		"For internal use.\n"
	},
	{
		"gpy2xx_topin_clr",
		"Clear external interrupt events",
		"For internal use.\n"
	},
#endif
	{
		"gpy2xx_extin_mask",
		"Enable/disable external interrupt event",
		"gpy2xx_extin_mask <imask_istat=?>\n"
		"  imask_istat: 0x0001 - link state change\n"
		"               0x0002 - link speed change\n"
		"               0x0004 - duplex mode change\n"
		"               0x0008 - MDI/MDIX crossover change\n"
		"               0x0010 - MDI polarity change\n"
		"               0x0020 - link's auto-downspeed change\n"
		"               0x0100 - SyncE lost of reference clock\n"
		"               0x0200 - mailbox transaction complete\n"
		"               0x0400 - auto-negotiation complete\n"
		"               0x0800 - auto-negotiation error\n"
		"               0x1000 - next page transmitted\n"
		"               0x2000 - next page received\n"
		"               0x4000 - master/slave resolution error\n"
		"               0x8000 - wake-on-lan event\n"
	},
	{
		"gpy2xx_extin_get",
		"Get external interrupt event mask",
		NULL
	},
#if defined(EN_GMAC_DEBUG_ACCESS) && EN_GMAC_DEBUG_ACCESS
	{
		"gpy2xx_extin_clr",
		"Clear external interrupt event",
		"gpy2xx_extin_clr <imask_istat=?>\n"
		"  imask_istat: 0x0001 - link state change\n"
		"               0x0002 - link speed change\n"
		"               0x0004 - duplex mode change\n"
		"               0x0008 - MDI/MDIX crossover change\n"
		"               0x0020 - MDI polarity change\n"
		"               0x0040 - link's auto-downspeed change\n"
		"               0x0100 - SyncE lost of reference clock\n"
		"               0x0200 - mailbox transaction complete\n"
		"               0x0400 - auto-negotiation complete\n"
		"               0x0800 - auto-negotiation error\n"
		"               0x1000 - next page transmitted\n"
		"               0x2000 - next page received\n"
		"               0x4000 - master/slave resolution error\n"
		"               0x8000 - wake-on-lan event\n"
	},
#endif
	{
		"gpy2xx_test_mode_cfg",
		"Set test mode",
		"gpy2xx_test_mode_cfg <testtxmode=?>\n"
		"  testtxmode: 0 - normal operation\n"
		"              1 - Test Mode 1 (Transmit Waveform Test)\n"
		"              2 - Test Mode 2 (Transmit Jitter Test in MASTER Mode)\n"
		"              3 - Test Mode 3 (Transmit Jitter Test in SLAVE Mode)\n"
		"              4 - Test Mode 4 (Transmitter Distortion Test)\n"
	},
	{
		"gpy2xx_cdiag_start",
		"Start cable diagnostic",
		"Check with firwmare developer for more detail.\n"
	},
	{
		"gpy2xx_cdiag_read",
		"Read cable diagnostic result",
		"Check with firwmare developer for more detail.\n"
	},
	{
		"gpy2xx_abist_start",
		"Start analog self-test (ABIST)",
		"Check with firwmare developer for more detail.\n"
	},
	{
		"gpy2xx_abist_read",
		"Read analog self-test (ABIST) result",
		"Check with firwmare developer for more detail.\n"
	},
	{
		"gpy2xx_loopback_cfg",
		"Configure near/far end loopback",
		"gpy2xx_loopback_cfg <loopbackmode=?>\n"
		"  loopbackmode: 0 - disable test loop\n"
		"                1 - GMII near end test loop\n"
		"                2 - PCS far end test loop\n"
		"                3 - DEC (Digital Echo Canceler) test loop\n"
		"                4 - MDI (RJ45 near end) test loop\n"
		"                5 - far end test loop\n"
		"                8 - GMII near end test loop - LB=1\n"
	},
	{
		"gpy2xx_errcnt_cfg",
		"Configure errors/events to be counted",
		"gpy2xx_errcnt_cfg <errcountmode=?>\n"
		"  errcountmode: 0 - receive errors\n"
		"                1 - receive frames\n"
		"                2 - ESD errors\n"
		"                3 - SSD errors\n"
		"                4 - transmit errors\n"
		"                5 - transmit frames\n"
		"                6 - collision events\n"
		"                8 - link down events\n"
		"                9 - auto-downspeed events\n"
	},
	{
		"gpy2xx_errcnt_read",
		"Read error/event counter",
		NULL
	},
	{
		"gpy2xx_pcs_status_read",
		"Get PCS status",
		NULL
	},
	{
		"gpy2xx_ptp_adjfreq",
		"Adjust frequency of hardware clock",
		"gpy2xx_ptp_adjfreq <pbbTime=?>\n"
		"  pbbTime: value\n"
	},
	{
		"gpy2xx_ptp_adjtime",
		"Adjust the system timestamp",
		"gpy2xx_ptp_adjtime <deltaTime=?>\n"
		"  deltaTime: 	value\n"
	},
	{
		"gpy2xx_ptp_settime",
		"Initialize the system timestamp",
		"gpy2xx_ptp_settime <initSec=?> <initNsec=?>\n"
		"  initSec: value\n"
		"  initNsec:value\n"
	},
	{
		"gpy2xx_ptp_set_tsctrl",
		"Configures the timestamp control, second/sub-second increment value",
		"gpy2xx_ptp_set_tsctrl <enAllPkts=?> <enEvntMsg=?> <enMstrMsg=?> <snapType=?> <tsStatMode=?> <subNsecIncr=?> <subSecIncr=?>\n"
		"  enAllPkts: 	dis/en\n"
		"  enEvntMsg:  	dis/en\n"
		"  enMstrMsg: 	dis/en\n"
		"  snapType: 	value\n"
		"  tsStatMode: 	dis/en\n"
		"  subNsecIncr:	value\n"
		"  subSecIncr: 	value\n"
	},
	{
		"gpy2xx_ptp_set_ppsctrl",
		"Configures the timestamp PPS control params",
		"gpy2xx_ptp_set_ppsctrl <ppsCtrlLow=?> <targetSec=?> <targetNsc=?> <ppsInterval=?> <ppsWidth=?>\n"
		"  ppsCtrlLow: 	value\n"
		"  targetSec:  	value\n"
		"  targetNsc: 	value\n"
		"  ppsInterval:	value\n"
		"  ppsWidth: 	value\n"
	},
	{
		"gpy2xx_ptp_set_ptoctrl",
		"Configures the timestamp PTO control params",
		"gpy2xx_ptp_set_ptoctrl <ptoCtrlLow=?> <srcPortID=?> <logmLvlLow=?> <logmLvlHi=?>\n"
		"  ptoCtrlLow: 	value\n"
		"  srcPortID:  	value\n"
		"  logmLvlLow: 	value\n"
		"  logmLvlHi:	value\n"
	},
	{
		"gpy2xx_ptp_gettime",
		"Provides the system timestamp",
		NULL
	},
	{
		"gpy2xx_ptp_enable",
		"Enable and configure PTP (1588) function",
		"gpy2xx_ptp_enable <enPhyTxTs=?> <enPhyRxTs=?> <enTxOstCor=?> <txPtpOffset=?> <txPtpProto=?> <txOstCorTime=?>\n"
		"  enPhyTxTs: 	 value\n"
		"  enPhyRxTs: 	 value\n"
		"  enTxOstCor: 	 value\n"
		"  txPtpOffset:  value\n"
		"  txPtpProto: 	 value\n"
		"  txOstCorTime: value\n"
	},
	{
		"gpy2xx_ptp_disable",
		"Disable and configure PTP (1588) function",
		NULL
	},
	{
		"gpy2xx_ptp_getcfg",
		"Get PTP (1588) configuration",
		NULL
	},
	{
		"gpy2xx_ptp_fifostat",
		"Get timestamp FIFO status",
		NULL
	},
	{
		"gpy2xx_ptp_resetfifo",
		"Resets the timestamp FIFO status",
		NULL
	},
#if defined(EN_GMAC_DEBUG_ACCESS) && EN_GMAC_DEBUG_ACCESS
	{
		"gpy2xx_ptp_txtsstat",
		"Get Tx timestamp status",
		NULL
	},
#endif
	{
		"gpy2xx_ptp_getrxts",
		"Get RX packet timestamp status and CRC",
		NULL
	},
	{
		"gpy2xx_ptp_aux_cfg",
		"Configure PTP Auxiliary timestamp function",
		"gpy2xx_ptp_aux_cfg <enAux=?> <auxTrigPort=?>\n"
		"  enAux:    	0 - disable,   1 - enable\n"
		"  auxTrigPort: 0 - OUT_TIMER, 1 - GPC0, 2 - GPC1, 3 - GPC2\n"
	},
	{
		"gpy2xx_ptp_gettxts",
		"Get TX packet timestamp and CRC status and CRC",
		NULL
	},
	{
		"gpy2xx_ptp_getauxts",
		"Get Auxiliary timestamp",
		NULL
	},
	{
		"gpy2xx_ptp_auxfifostat",
		"Get auxiliary timestamp FIFO status",
		NULL
	},
	{
		"gpy2xx_ptp_resetauxfifo",
		"Reset auxiliary timestamp FIFO status",
		NULL
	},
	{
		"gpy2xx_synce_cfg",
		"Configure SyncE function",
		"gpy2xx_synce_cfg <enSyncE=?> <syncEClk=?> <MasterMode=?> <DataRate=?> <PGCSel=?>\n"
		"  enSyncE:    0 - disable,    1 - enable\n"
		"  syncEClk:   0 - CLK_PSTN,   1 - CLK_EEC1, 2 - CLK_EEC2\n"
		"  MasterMode: 0 - slave mode, 1 - master mode\n"
		"  DataRate:   0 - 1G,	 1 - 2.5G\n"
		"  PGCSel:     1 - GPC1, 2 - GPC2\n",
	},
	{
		"gpy2xx_synce_get",
		"Get SyncE configuration",
		NULL
	},
	{
		"gpy2xx_wol_cfg",
		"Configure Wake-On-Lan function",
		"gpy2xx_wol_cfg <woloptions=?> <wolmac=?> <wolpassword=?>\n"
		"  woloptions:  combination of following flags\n"
		"               0x20 - wake up when receiving magic packet\n"
		"               0x40 - password enabled\n"
		"  wolmac:      6-byte MAC address of magic packet\n"
		"  wolpassword: 6-byte password\n"
	},
	{
		"gpy2xx_wol_get",
		"Get Wake-On-Lan configuration",
		NULL
	},
	{
		"gpy2xx_ads_cfg",
		"Configure Auto-Down-Speed",
		"gpy2xx_ads_cfg [<advertise_enable=?>] [<NBaseT_ds_enable=?>] [<downshift_cnt_thr=?>] [<force_reset=?>] [<rst_cntdown_timer=?>]\n"
		"advertise_enable:  0 Disable / 1 Enable\n"
		"NBaseT_ds_enable:  0 Disable / 1 Enable\n"
		"downshift_cnt_thr: value (5bits)\n"
		"force_reset:       0/1\n"
		"rst_cntdown_timer: value (8bits)\n"
	},
	{
		"gpy2xx_ads_get",
		"Get Auto-Down-Speed",
		NULL
	},
	{
		"gpy2xx_ulp_cfg",
		"Configure Ultra Low Power",
		"gpy2xx_ulp_cfg [<ulp_enable=?>] [<ulp_sta_block=?>]\n"
		"ulp_enable:  0 Disable / 1 Enable\n"
		"ulp_sta_block:  0 Disable / 1 Enable\n"
	},
	{
		"gpy2xx_ulp_cfg",
		"Get Ultra Low Power",
		NULL
	},
	{
		"gpy2xx_ads_detected",
		"Get auto-downspeed event",
		NULL
	},
	{
		"gpy2xx_sgmii_restart_aneg",
		"Restart SGMII auto-negotiation",
		NULL
	},
	{
		"gpy2xx_sgmii_config_aneg",
		"Configure SGMII auto-negotiation",
		"gpy2xx_sgmii_config_aneg <linkcfg_dir=?> [<aneg_mode=?>] [<eee_enable=?>] [<autoneg=?>] [<speed=?>] [fixed2G5=?] [<duplex=?>]\n"
		"  linkcfg_dir: 0 - SGMII_LINKCFG_TPI / 1 - SGMII_LINKCFG_SGMII\n"
		"  aneg_mode:   1 - SGMII_ANEG_1000BX\n"
		"               2 - SGMII_ANEG_CISCO_PHY\n"
		"               3 - SGMII_ANEG_CISCO_MAC\n"
		"  eee_enable:  0 - disable / 1 - enable\n"
		"  autoneg:     0 - disable / 1 - enable\n"
		"  speed:       10/100/1000/2500\n"
		"  fixed2G5:    0 - TPI speed / 1 - force 2.5G\n"
		"  duplex:      DUPLEX_FULL/DUPLEX_HALF\n"
	},
	{
		"gpy2xx_sgmii_aneg_done",
		"Check SGMII auto-negotiation status",
		NULL
	},
	{
		"gpy2xx_sgmii_read_status",
		"Get SGMII link status (detail)",
		NULL
	},
	{
		"gpy2xx_sgmii_opmode",
		"Configure SGMII operation mode",
		"gpy211_sgmii_opmode <opMode=?>\n"
		"  opMode: 0 - normal oeration\n"
		"		   1 - power down\n"
		"		   2 - loopback\n"
		"		   3 - reset\n"
	},
	{
		"gpy2xx_pvt_get",
		"Get SENSOR temparature",
		NULL
	},
#if defined(EN_GMAC_DEBUG_ACCESS) && EN_GMAC_DEBUG_ACCESS
	{
		"gpy2xx_gmacx_pm_hw_reset",
		"Set PM lavel HW reset",
		NULL
	},
#endif
	{
		"gpy2xx_gmacx_pm_pdi_cfg",
		"Set PM PDI configuration",
		"gpy2xx_gmacx_pm_pdi_cfg <bpMac=?> <bpMsec=?> [dropCrc=?] [dropPerr=?] [dropSfail=?] [dropClass=?] [cust3gEn=?] [sgmiiLb=?]\n"
		"  bpMac:      dis/en\n"
		"  bpMsec:     dis/en\n"
		"  dropCrc:    dis/en\n"
		"  dropPerr:   dis/en\n"
		"  dropSfail:  dis/en\n"
		"  dropClass:  dis/en\n"
		"  cust3gEn:   dis/en\n"
		"  sgmiiLb:    dis/en\n"
	},
	{
		"gpy2xx_gmacx_pm_pdi_get",
		"Get PM PDI configuration",
		NULL
	},
	{
		"gpy2xx_gmacf_pm_cfg",
		"Set PM GMAC-Full configuration",
		"gpy2xx_gmacf_pm_cfg <crcPad=?> [txErr=?] [bigEndian=?]\n"
		"  crcPad:     0 - Insert both CRC and Paddding\n"
		"			   1 - Insert CRC only but no Paddding\n"
		"			   2 - Do not insert CRC or Paddding\n"
		"			   3 - Replace CRC but no Paddding\n"
		"  txErr:      dis/en\n"
		"  bigEndian:  dis/en\n"
		"  pcStrip:    dis/en\n"
		"  crcStrip:   dis/en\n"
	},
	{
		"gpy2xx_gmacf_pm_get",
		"Get PM GMAC-Full configuration",
		NULL
	},
	{
		"gpy2xx_gmacl_pm_cfg",
		"Set PM GMAC-Lite configuration",
		"gpy2xx_gmacl_pm_cfg <crcPad=?> [txErr=?] [bigEndian=?]\n"
		"  crcPad:     0 - Insert both CRC and Paddding\n"
		"			   1 - Insert CRC only but no Paddding\n"
		"			   2 - Do not insert CRC or Paddding\n"
		"			   3 - Replace CRC but no Paddding\n"
		"  txErr:      dis/en\n"
		"  bigEndian:  dis/en\n"
		"  pcStrip:    dis/en\n"
		"  crcStrip:   dis/en\n"
	},
	{
		"gpy2xx_gmacl_pm_get",
		"Get PM GMAC-Lite configuration",
		NULL
	},
#if defined(EN_GMAC_DEBUG_ACCESS) && EN_GMAC_DEBUG_ACCESS
	{
		"gpy2xx_gmacf_lpi_cfg",
		"Set PM GMAC-Full LPI configuration",
		"gpy2xx_gmacf_lpi_cfg <lpintEn=?> <lpiEn=?> <linkUp=?> [txautoEn=?] [timerEn=?] [clkStop=?] [ticTime=0196] [twTime=?] [lsTime=?] [entryTime=?]\n"
		"  lpintEn:    dis/en\n"
		"  lpiEn:      dis/en\n"
		"  linkUp:     dis/en\n"
		"  txautoEn:   dis/en\n"
		"  timerEn:    dis/en\n"
		"  clkStop:    dis/en\n"
		"  ticTime:    value\n"
		"  twTime:     value\n"
		"  lsTime:     value\n"
		"  entryTime:  value\n"
	},
	{
		"gpy2xx_gmacf_lpi_get",
		"Get PM GMAC-Full LPI configuration",
		NULL
	},
	{
		"gpy2xx_gmacl_lpi_cfg",
		"Set PM GMAC-Lite LPI configuration",
		"gpy2xx_gmacl_lpi_cfg <lpintEn=?> <lpiEn=?> <linkUp=?> [txautoEn=?] [timerEn=?] [clkStop=?] [ticTime=0196] [twTime=?] [lsTime=?] [entryTime=?]\n"
		"  lpintEn:    dis/en\n"
		"  lpiEn:      dis/en\n"
		"  linkUp:     dis/en\n"
		"  txautoEn:   dis/en\n"
		"  timerEn:    dis/en\n"
		"  clkStop:    dis/en\n"
		"  ticTime:    value\n"
		"  twTime:     value\n"
		"  lsTime:     value\n"
		"  entryTime:  value\n"
	},
	{
		"gpy2xx_gmacl_lpi_get",
		"Get PM GMAC-Lite LPI configuration",
		NULL
	},
	{
		"gpy2xx_gmacf_lpi_stat_get",
		"Get GMAC-Full LPI status",
		NULL
	},
	{
		"gpy2xx_gmacl_lpi_stat_get",
		"Get GMAC-Lite LPI status",
		NULL
	},
	{
		"gpy2xx_gmacf_lpi_imask_cfg",
		"Set GMAC-Full's LPI interrupt mask",
		"gpy2xx_gmacf_lpi_imask_cfg <rxUsc=?> <rxTrc=?> <txUsc=?> <txTrc=?>\n"
		"  rxUsc:  dis/en\n"
		"  rxTrc:  dis/en\n"
		"  txUsc:  dis/en\n"
		"  txTrc:  dis/en\n"
	},
	{
		"gpy2xx_gmacf_lpi_imask_get",
		"Get GMAC-Full's LPI interrupt mask",
		NULL
	},
	{
		"gpy2xx_gmacf_lpi_istat_get",
		"Get GMAC-Full's LPI interrupt status",
		NULL
	},
	{
		"gpy2xx_gmacf_lpi_count_get",
		"Get GMAC-Full's LPI counters",
		NULL
	},
#endif
	{
		"gpy2xx_gmacx_bm_cfg",
		"Set PM's Buffer configuration",
		"gpy2xx_gmacx_bm_cfg [sb0Start=?] [sb0End=?] [sb0Pthresh=?] [sb1Start=?] [sb1End=?] [sb1Pthresh=?]\n"
		"  sb0Start:   value\n"
		"  sb0End:     value\n"
		"  sb0Pthresh: value\n"
		"  sb1Start:   value\n"
		"  sb1End:	   value\n"
		"  sb1Pthresh: value\n"
	},
	{
		"gpy2xx_gmacx_bm_status_get",
		"Get PMs buffer status",
		NULL
	},
	{
		"gpy2xx_gmacx_bm_get",
		"Get PM's Buffer configuration",
		NULL
	},
	{
		"gpy2xx_gmacl_pause_cfg",
		"Set GMAC-Lite's Pause configuration",
		"gpy2xx_gmacl_pause_cfg <fcBusy=?> <gmaclFc=?> <txfcEn=?> <pauseTime=?> <pauseMac=?> [plThresh=?] [zqPause=?] [paThresh=?] [pdThresh=?]\n"
		"  fcBusy:   dis/en\n"
		"  gmaclFc:  dis/en\n"
		"  txfcEn:   dis/en\n"
		"  plThresh: 0 - PT-4 slot times\n"
		"			 1 - PT-28 slot times\n"
		"			 2 - PT-36 slot times\n"
		"			 3 - PT-144 slot times\n"
		"			 4 - PT-256 slot times\n"
		"			 5 - PT-512 slot times\n"
		"  zqPause:	 dis/en\n"
		"  pauseTime:value\n"
		"  pauseMac: value\n"
		"  paThresh: value\n"
		"  pdThresh: value\n"
	},
	{
		"gpy2xx_gmacl_pause_get",
		"Get GMAC-Lite's Pause configuration",
		NULL
	},
    {
		"gpy2xx_pm_freg_tune",
		"Tune the frequency of MACs within GPY in USXGMII Mode",
		"gpy2xx_pm_freg_tune <ppm=?>\n"
		"  ppm: 0 - MACs operate at frequency+000ppm\n"
		"		1 - MACs operate at frequency+100ppm\n"
		"		2 - MACs operate at frequency+300ppm\n"
	},
#if defined(EN_GMAC_DEBUG_ACCESS) && EN_GMAC_DEBUG_ACCESS
	{
		"gpy2xx_gmacf_pkt_filter_cfg",
		"Set GMAC-Full's packet filter control info",
		"gpy2xx_gmacf_pkt_filter_cfg <prEn=?> [passAmc=?] [blockBc=?] [passCtrl=?] [safltrEn=?] [rxAll=?]\n"
		"  prEn:       dis/en\n"
		"  passAmc:    dis/en\n"
		"  blockBc:    dis/en\n"
		"  passCtrl:   0 - Block all control packets\n"
		"			   1 - Forwards all control packets except Pause packets even if they fail the Address filter\n"
		"			   2 - Forwards all control packets even if they fail the Address filter\n"
		"			   3 - Forwards the control packets that pass the Address filter\n"
		"  safltrEn:   dis/en\n"
		"  rxAll:      dis/en\n"
	},
	{
		"gpy2xx_gmacf_pkt_filter_get",
		"Get GMAC-Full's packet filter control info",
		NULL
	},
	{
		"gpy2xx_gmacl_pkt_filter_cfg",
		"Set GMAC-Lite's packet filter control info",
		"gpy2xx_gmacl_pkt_filter_cfg <prEn=?> [passAmc=?] [blockBc=?] [passCtrl=?] [safltrEn=?] [rxAll=?]\n"
		"  prEn:       dis/en\n"
		"  passAmc:    dis/en\n"
		"  blockBc:    dis/en\n"
		"  passCtrl:   0 - Block all control packets\n"
		"			   1 - Forwards all control packets except Pause packets even if they fail the Address filter\n"
		"			   2 - Forwards all control packets even if they fail the Address filter\n"
		"			   3 - Forwards the control packets that pass the Address filter\n"
		"  safltrEn:   dis/en\n"
		"  rxAll:      dis/en\n"
	},
	{
		"gpy2xx_gmacl_pkt_filter_get",
		"Get GMAC-Lite's packet filter control info",
		NULL
	},
	{
		"gpy2xx_gmacf_debug_info_get",
		"Get GMAC-Full's debug info",
		NULL
	},
	{
		"gpy2xx_gmacl_pkt_cfg",
		"Set GMAC-Lite's packet config info",
		"gpy2xx_gmacl_pkt_cfg <pcStrip=?> <crcStrip=?> [jumboEn=?] [jabberDis=?] [wdogDis=?] [sup2kp=?] [macIpg=?]\n"
		"  jumboEn:    dis/en\n"
		"  jabberDis:  dis/en\n"
		"  wdogDis:    dis/en\n"
		"  pcStrip:    dis/en\n"
		"  crcStrip:   dis/en\n"
		"  sup2kp:     dis/en\n"
		"  macIpg:     0 - 12 Bytes\n"
		"  	           1 - 11 Bytes\n"
		"  	           2 - 10 Bytes\n"
		"  	           3 - 09 Bytes\n"
		"  	           4 - 08 Bytes\n"
		"			   5 - 07 Bytes\n"
		"			   6 - 06 Bytes\n"
		"			   7 - 05 Bytes\n"
	},
	{
		"gpy2xx_gmacl_pkt_get",
		"Get GMAC-Lite's packet config info",
		NULL
	},
	{
		"gpy2xx_gmacf_cfg",
		"Set GMAC-Full's basic config info",
		"gpy2xx_gmacf_cfg [reEn=?] [teEn=?] [preambLen=<enum>] [lbmEn=?] [fdupEn=?] [macSpeed=<enum>] [rcWrite1=?]\n"
		"  reEn:       dis/en\n"
		"  teEn:       dis/en\n"
		"  preambLen:  0 - 7 bytes of preamble\n"
		"			   1 - 5 bytes of preamble\n"
		"			   2 - 3 bytes of preamble\n"
		"  lbmEn:      dis/en\n"
		"  fdupEn:     dis/en\n"
		"  macSpeed:   0 - 1G\n"
		"			   1 - 2.5G\n"
		"			   2 - 10M\n"
		"			   3 - 100MG\n"
		"  rcWrite1:   dis/en\n"
	},
	{
		"gpy2xx_gmacf_get",
		"Get GMAC-Full's basic config info",
		NULL
	},
	{
		"gpy2xx_gmacl_cfg",
		"Set GMAC-Lite's basic config info",
		"gpy2xx_gmacl_cfg [reEn=?] [teEn=?] [preambLen=<enum>] [lbmEn=?] [fdupEn=?] [macSpeed=<enum>] [rcWrite1=?]\n"
		"  reEn:       dis/en\n"
		"  teEn:       dis/en\n"
		"  preambLen:  0 - 7 bytes of preamble\n"
		"			   1 - 5 bytes of preamble\n"
		"			   2 - 3 bytes of preamble\n"
		"  lbmEn:      dis/en\n"
		"  fdupEn:     dis/en\n"
		"  macSpeed:   0 - 1G\n"
		"			   1 - 2.5G\n"
		"			   2 - 10M\n"
		"			   3 - 100MG\n"
		"  rcWrite1:   dis/en\n"
	},
	{
		"gpy2xx_gmacl_get",
		"Get GMAC-Lite's basic config info",
		NULL
	},
#endif
	{
		"gpy2xx_gmacf_pkt_cfg",
		"Set GMAC-Full's packet config info",
		"gpy2xx_gmacf_pkt_cfg <pcStrip=?> <crcStrip=?> [jumboEn=?] [jabberDis=?] [wdogDis=?] [sup2kp=?] [macIpg=?]\n"
		"  jumboEn:    dis/en\n"
		"  jabberDis:  dis/en\n"
		"  wdogDis:    dis/en\n"
		"  pcStrip:    dis/en\n"
		"  crcStrip:   dis/en\n"
		"  sup2kp:     dis/en\n"
		"  macIpg:     0 - 12 Bytes\n"
		"  	           1 - 11 Bytes\n"
		"  	           2 - 10 Bytes\n"
		"  	           3 - 09 Bytes\n"
		"  	           4 - 08 Bytes\n"
		"  	           5 - 07 Bytes\n"
		"  	           6 - 06 Bytes\n"
		"  	           7 - 05 Bytes\n"
	},
	{
		"gpy2xx_gmacf_pkt_get",
		"Get GMAC-Full's packet config info",
		NULL
	},
	{
		"gpy2xx_gmacf_count_ctrl_cfg",
		"Set GMAC-Full's Rx/Tx counters control info",
		"gpy2xx_gmacf_count_ctrl_cfg <rstCnt=?> <stopRoll=?> <conRead=?> <frzCnt=?> <pstCnt=?> <psthFull=?> <cntbcDrop=?>\n"
		"  rstCnt:     dis/en\n"
		"  stopRoll:   dis/en\n"
		"  conRead:    dis/en\n"
		"  frzCnt:     dis/en\n"
		"  pstCnt:     dis/en\n"
		"  psthFull:   dis/en\n"
		"  cntbcDrop:  dis/en\n"
	},
	{
		"gpy2xx_gmacf_count_ctrl_get",
		"Get GMAC-Full's counters control info",
		NULL
	},
	{
		"gpy2xx_gmacf_count_get",
		"Get GMAC-Full's Rx/Tx counters",
		NULL
	},
#if defined(EN_GMAC_DEBUG_ACCESS) && EN_GMAC_DEBUG_ACCESS
	{
		"gpy2xx_gmacf_count_imask_cfg",
		"Set GMAC-Full's counters interrupt mask",
		"gpy2xx_gmacf_count_imask_cfg <txGb=?> <txUflow=?> <txGood=?> <txOsize=?> <rxGb=?> <rxCrc=?> <rxUsize=?> <rxOsize=?>\n"
		"  txGb:     dis/en\n"
		"  txUflow:  dis/en\n"
		"  txGood:   dis/en\n"
		"  txOsize:  dis/en\n"
		"  rxGb:     dis/en\n"
		"  rxCrc:    dis/en\n"
		"  rxUsize:  dis/en\n"
		"  rxOsize:  dis/en\n"
	},
	{
		"gpy2xx_gmacf_count_imask_get",
		"Get GMAC-Full's counters interrupt mask",
		NULL
	},
	{
		"gpy2xx_gmacf_count_istat_get",
		"Get GMAC-Full's counters interrupt status",
		NULL
	},
#endif
	{
		"gpy2xx_msec_init_ing_dev",
		"Init macsec ING device",
		NULL
	},
	{
		"gpy2xx_msec_init_egr_dev",
		"Init macsec EGR device",
		NULL
	},

	{
		"gpy2xx_msec_config_ing_tr",
		"Configure ingress transform record",
		"gpy2xx_msec_config_ing_tr [sa_index=?] [ca_type=?] [sn_type=?] [key=?] [sci=?] [seq_num=?] [rep_window=?] [salt=?] [short_sci=?]\n"
		"  sa_index:   value\n"
		"  ca_type:    value\n"
		"  sn_type:    value\n"
		"  key:        value\n"
		"  sci:        value\n"
		"  seq_num     value\n"
		"  salt:       value\n"
		"  short_sci:  value\n"
		"  rep_window: value\n",
	},
	{
		"gpy2xx_msec_config_egr_tr",
		"Configure egress transform record",
		"gpy2xx_msec_config_egr_tr [sa_index=?] [ca_type=?] [an=?] [sn_type=?] [key=?] [sci=?] [seq_num=?] [salt=?] [short_sci=?] [next_sa_ind=?] [sa_expirq=?] [sa_indvalid=?] [flow_index=?] [sa_indupen=?]\n"
		"  sa_index:    value\n"
		"  ca_type:     value\n"
		"  an:          value\n"
		"  sn_type:     value\n"
		"  key:         value\n"
		"  sci:         value\n"
		"  seq_num:        value\n"
		"  salt:        value\n"
		"  short_sci:    value\n"
		"  next_sa_ind:   value\n"
		"  sa_expirq: value\n"
		"  sa_indvalid:  value\n"
		"  flow_index:  value\n"
		"  sa_indupen:  value\n",
	},
	{
		"gpy2xx_msec_update_egr_sa_cw",
		"Update egress SA control word",
		"gpy2xx_msec_update_egr_sa_cw [sa_index=?] [ca_type=?] [sn_type=?] [next_sa_ind=?] [sa_expirq=?] [sa_indvalid=?] [flow_index=?] [sa_indupen=?]\n"
		"  sa_index:    value\n"
		"  ca_type:     value\n"
		"  sn_type:     value\n"
		"  next_sa_ind: value\n"
		"  sa_expirq:   value\n"
		"  sa_indvalid: value\n"
		"  flow_index:  value\n"
		"  sa_indupen:  value\n",
	},
	{
		"gpy2xx_msec_get_ing_tr",
		"Get ingress transform record",
		"gpy2xx_msec_get_ing_tr sa_index=0\n"
		"  sa_index:  value\n",
	},
	{
		"gpy2xx_msec_get_egr_tr",
		"Get egress transform record",
		"gpy2xx_msec_get_egr_tr sa_index=0\n"
		"  sa_index:  value\n",
	},
	{
		"gpy2xx_msec_get_ing_pn",
		"Get ingress current SN from transform record",
		"gpy2xx_msec_get_ing_pn sa_index=0\n"
		"  sa_index:  value\n",
	},
	{
		"gpy2xx_msec_get_egr_pn",
		"Get egress current SN from transform record",
		"gpy2xx_msec_get_egr_pn sa_index=0\n"
		"  sa_index:  value\n",
	},
	{
		"gpy2xx_msec_config_ing_sam_rule",
		"Configure ingress SA match rule parameters",
		"gpy2xx_msec_config_ing_sam_rule [rule_index=?] [sa_mac=?] [da_mac=?] [eth_type=?] [vlan_id=?] [misc=?] [sci=?] [mask=?] [flow_index=?]\n"
		"  rule_index:value\n"
		"  sa_mac:    value\n"
		"  da_mac:    value\n"
		"  eth_type:  value\n"
		"  vlan_id:   value\n"
		"  misc:      value\n"
		"  sci:       value\n"
		"  mask:      value\n"
		"  flow_index:value\n",
	},
	{
		"gpy2xx_msec_config_egr_sam_rule",
		"Configure egress SA match rule parameters",
		"gpy2xx_msec_config_egr_sam_rule [rule_index=?] [sa_mac=?] [da_mac=?] [eth_type=?] [vlan_id=?] [misc=?] [sci=?] [mask=?] [flow_index=?]\n"
		"  rule_index:value\n"
		"  sa_mac:    value\n"
		"  da_mac:    value\n"
		"  eth_type:  value\n"
		"  vlan_id:   value\n"
		"  misc:      value\n"
		"  sci:       value\n"
		"  mask:      value\n"
		"  flow_index:value\n",
	},
	{
		"gpy2xx_msec_get_ing_sam_rule",
		"Get ingress SA match rule parameters",
		"gpy2xx_msec_get_ing_sam_rule [rule_index=?]\n"
		"  rule_index: value\n",
	},
	{
		"gpy2xx_msec_get_egr_sam_rule",
		"Get egress SA match rule parameters",
		"gpy2xx_msec_get_egr_sam_rule [rule_index=?]\n"
		"  rule_index: value\n",
	},
	{
		"gpy2xx_msec_config_ing_sam_fca",
		"Configure ingress SA matching rule's flow control action parameters",
		"gpy2xx_msec_config_ing_sam_fca [flow_index=?] [flow_type=?] [dest_port=?] [drop_nonres=?] [crypt_auth=?] [drop_act=?] [sa_index=?] [rep_protect=?] [sa_inuse=?] [validate_level=?] [conf_offset=?]\n"
		"  flow_index: 	 value\n"
		"  flow_type:    value\n"
		"  dest_port:    value\n"
		"  drop_nonres:  value\n"
		"  crypt_auth:   value\n"
		"  drop_act:   	 value\n"
		"  sa_index:     value\n"
		"  rep_protect:  value\n"
		"  sa_inuse:     value\n"
		"  validate_level:value\n"
		"  conf_offset:  value\n",
	},
	{
		"gpy2xx_msec_config_egr_sam_fca",
		"Configure egress SA matching rule's flow control action parameters",
		"gpy2xx_msec_config_egr_sam_fca [flow_index=?] [flow_type=?] [dest_port=?] [drop_nonres=?] [crypt_auth=?] [drop_act=?] [sa_index=?] [frame_protect=?] [sa_inuse=?] [include_sci=?] [use_es=?] [use_scb=?] [tag_bpsize=?] [sa_indup=?] [conf_offset=?] [conf_protect=?]\n"
		"  flow_index:	 value\n"
		"  flow_type:	 value\n"
		"  dest_port:	 value\n"
		"  drop_nonres:  value\n"
		"  crypt_auth:	 value\n"
		"  drop_act:	 value\n"
		"  sa_index:	 value\n"
		"  frame_protect:value\n"
		"  sa_inuse:	 value\n"
		"  include_sci:  value\n"
		"  use_es:		 value\n"
		"  use_scb: 	 value\n"
		"  tag_bpsize:	 value\n"
		"  sa_indup:	 value\n"
		"  conf_offset:  value\n"
		"  conf_protect: value\n",
	},
	{
		"gpy2xx_msec_get_ing_sam_fca",
		"Get ingress SA matching rule's flow control action parameters",
		"gpy2xx_msec_get_ing_sam_fca [flow_index=?]\n"
		"  flow_index: 	value\n",
	},
	{
		"gpy2xx_msec_get_egr_sam_fca",
		"Get ingress SA matching rule's flow control action parameters",
		"gpy2xx_msec_get_egr_sam_fca [flow_index=?]\n"
		"  flow_index: 	value\n",
	},
	{
		"gpy2xx_msec_clear_ing_tr",
		"Clears ingress transform record",
		"gpy2xx_msec_clear_ing_tr [sa_index=?]\n"
		"  sa_index:  value\n",
	},
	{
		"gpy2xx_msec_clear_egr_tr",
		"Clears egress transform record",
		"gpy2xx_msec_clear_egr_tr [sa_index=?]\n"
		"  sa_index:  value\n",
	},
	{
		"gpy2xx_msec_clear_ing_sam_rule",
		"Clears ingress SAM rule parameters",
		"gpy2xx_msec_clear_ing_sam_rule [rule_index=?]\n"
		"  rule_index:  value\n",
	},
	{
		"gpy2xx_msec_clear_egr_sam_rule",
		"Clears egress SAM rule parameters",
		"gpy2xx_msec_clear_egr_sam_rule [rule_index=?]\n"
		"  rule_index:  value\n",
	},
	{
		"gpy2xx_msec_clear_ing_sam_fca",
		"Clears ingress SAM flow control parameters",
		"gpy2xx_msec_clear_ing_sam_fca [flow_index=?]\n"
		"  flow_index:  value\n",
	},
	{
		"gpy2xx_msec_clear_egr_sam_fca",
		"Clears egress SAM flow control parameters",
		"gpy2xx_msec_clear_egr_sam_fca [flow_index=?]\n"
		"  flow_index:  value\n",
	},
	{
		"gpy2xx_msec_config_ing_vlan_parse",
		"Configure ingress SA match VLAN control parameters",
		"gpy2xx_msec_config_ing_vlan_parse [qinq_en=?] [stag_en=?] [qtag_en=?]\n"
		"  qinq_en: value\n"
		"  stag_en: value\n"
		"  qtag_en: value\n",
	},
	{
		"gpy2xx_msec_config_egr_vlan_parse",
		"Configure egress SA match VLAN control parameters",
		"gpy2xx_msec_config_egr_vlan_parse [qinq_en=?] [stag_en=?] [qtag_en=?]\n"
		"  qinq_en: value\n"
		"  stag_en: value\n"
		"  qtag_en: value\n",
	},
	{
		"gpy2xx_msec_config_ing_sam_eex",
		"Configure ingress SA match entry enable flags",
		"gpy2xx_msec_config_ing_sam_eex [eex_type=?] [eex_word0=?]\n"
		"  eex_type:  value\n"
		"  eex_word0: value\n",
	},
	{
		"gpy2xx_msec_config_egr_sam_eex",
		"Configure egress SA match entry enable flags",
		"gpy2xx_msec_config_egr_sam_eex [eex_type=?] [eex_word0=?]\n"
		"  eex_type:  value\n"
		"  eex_word0: value\n",
	},
	{
		"gpy2xx_msec_get_ing_sam_eef",
		"Get ingress SA match entry enable flags",
		"gpy2xx_msec_get_ing_sam_eef [word_num=?]\n"
		"  word_num: value\n",
	},
	{
		"gpy2xx_msec_get_egr_sam_eef",
		"Get egress SA match entry enable flags",
		"gpy2xx_msec_get_egr_sam_eef [word_num=?]\n"
		"  word_num: value\n",
	},
	{
		"gpy2xx_msec_config_ing_sam_eec",
		"Configure ingress SA match entry enable clear",
		"gpy2xx_msec_config_ing_sam_eec [sam_ind_set=?] [set_single=?] [set_all=?] [sam_ind_clr=?] [clr_single=?] [clr_all=?]\n"
		"  sam_ind_set: value\n"
		"  set_single:  value\n"
		"  set_all:     value\n"
		"  sam_ind_clr: value\n"
		"  clr_single:  value\n"
		"  clr_all:     value\n",
	},
	{
		"gpy2xx_msec_config_egr_sam_eec",
		"Configure egress SA match entry enable clear",
		"gpy2xx_msec_config_egr_sam_eec [sam_ind_set=?] [set_single=?] [set_all=?] [sam_ind_clr=?] [clr_single=?] [clr_all=?]\n"
		"  sam_ind_set: value\n"
		"  set_single:  value\n"
		"  set_all:     value\n"
		"  sam_ind_clr: value\n"
		"  clr_single:  value\n"
		"  clr_all:     value\n",
	},
	{
		"gpy2xx_msec_config_ing_cc_rule",
		"Configure ingress consistency check match parameters",
		"gpy2xx_msec_config_ing_cc_rule [icc_index=?] [eth_type=?] [misc=?] \n"
		"  icc_index:   value\n"
		"  eth_type: 	value\n"
		"  misc:        value\n"
	},
	{
		"gpy2xx_msec_get_ing_cc_rule",
		"Configure ingress consistency check match parameters",
		"gpy2xx_msec_get_ing_cc_rule [icc_index=?]\n"
		"  icc_index:	value\n",
	},
	{
		"gpy2xx_msec_config_ing_cc_eef",
		"Configure ingress consistency check entry enable flags",
		"gpy2xx_msec_config_ing_cc_eef [eec_word0=?]\n"
		"  eec_word0:	value\n",
	},
	{
		"gpy2xx_msec_get_ing_cc_eef",
		"Get ingress consistency check entry enable flags",
		"gpy2xx_msec_get_ing_cc_eef \n"
	},
	{
		"gpy2xx_msec_config_ing_cc_eec",
		"Configure ingress CC match entry enable clear",
		"gpy2xx_msec_config_ing_cc_eec [icc_ind_set=?] [set_single=?] [set_all=?] [icc_ind_clr=?] [clr_single=?] [clr_all=?]\n"
		"  icc_ind_set:value\n"
		"  set_single: value\n"
		"  set_all:    value\n"
		"  icc_ind_clr:value\n"
		"  clr_single: value\n"
		"  clr_all:    value\n",
	},
	{
		"gpy2xx_msec_config_ing_cc_ctrl",
		"Configure ingress consistency check control",
		"gpy2xx_msec_config_ing_cc_ctrl [nm_act=?] [nm_ctrl_act=?] [etype_max_len=?]\n"
		"  nm_act:        value\n"
		"  nm_ctrl_act:   value\n"
		"  etype_max_len: value\n",
	},
	{
		"gpy2xx_msec_get_ing_sa_stats",
		"Get ingress SA statistics",
		"gpy2xx_msec_get_ing_sa_stats [rule_index=?]\n"
		"  rule_index:  value\n",
	},
	{
		"gpy2xx_msec_get_egr_sa_stats",
		"Get egress SA statistics",
		"gpy2xx_msec_get_egr_sa_stats [rule_index=?]\n"
		"  rule_index:  value\n",
	},
	{
		"gpy2xx_msec_get_ing_global_stats",
		"Get ingress global statistics",
		NULL
	},
	{
		"gpy2xx_msec_get_egr_global_stats",
		"Get egress global statistics",
		NULL
	},
#if defined(EN_MSEC_DEBUG_ACCESS) && EN_MSEC_DEBUG_ACCESS
	{
		"gpy2xx_msec_get_ing_debug_stats",
		"Get ingress debug statistics",
		NULL
	},
	{
		"gpy2xx_msec_get_egr_debug_stats",
		"Get egress debug statistics",
		NULL
	},
#endif
	{
		"gpy2xx_msec_config_ing_count_ctrl",
		"Configure ingress count control",
		"gpy2xx_msec_config_ing_count_ctrl [rst_all=?] [ctr_saturate=?] [ctr_conr=?] [rst_summary=?]\n"
		"  rst_all:       value\n"
		"  ctr_saturate:  value\n"
		"  ctr_conr:      value\n"
		"  rst_summary:   value\n",
	},
	{
		"gpy2xx_msec_config_egr_count_ctrl",
		"Configure egress count controls",
		"gpy2xx_msec_config_egr_count_ctrl [rst_all=?] [ctr_saturate=?] [ctr_conr=?] [rst_summary=?]\n"
		"  rst_all:       value\n"
		"  ctr_saturate:  value\n"
		"  ctr_conr:      value\n"
		"  rst_summary:   value\n",
	},
	{
		"gpy2xx_msec_config_ing_count_incen",
		"Configure ingress counter increment enables",
		"gpy2xx_msec_config_ing_count_incen [sa_inc=?] [vlan_inc=?] [global_inc=?]\n"
		"  sa_inc:        value\n"
		"  vlan_inc:      value\n"
		"  global_inc: 	  value\n",
	},
	{
		"gpy2xx_msec_config_egr_count_incen",
		"Configure egress counter increment enables",
		"gpy2xx_msec_config_egr_count_incen [sa_inc=?] [vlan_inc=?] [global_inc=?]\n"
		"  sa_inc:        value\n"
		"  vlan_inc:	  value\n"
		"  global_inc: 	  value\n",
	},
	{
		"gpy2xx_msec_config_ing_count_secfail",
		"Configure ingress secfail event trigger enables",
		"gpy2xx_msec_config_ing_count_secfail [misc_secfail=?] [global_secfail=?]\n"
		"  misc_secfail:    value\n"
		"  global_secfail:	value\n",
	},
	{
		"gpy2xx_msec_config_egr_count_secfail",
		"Configure egress secfail event trigger enables",
		"gpy2xx_msec_config_egr_count_secfail [misc_secfail=?] [global_secfail=?]\n"
		"  misc_secfail:    value\n"
		"  global_secfail:	value\n",
	},
	{
		"gpy2xx_msec_config_ing_count_thresh",
		"Configure ingress counter packet and octet thresholds",
		"gpy2xx_msec_config_ing_count_thresh [frame_thr=?] [octet_thr=?]\n"
		"  frame_thr:	 value\n"
		"  octet_thr:	 value\n",
	},
	{
		"gpy2xx_msec_get_ing_count_thresh",
		"Get ingress counter packet and octet thresholds",
		NULL
	},
	{
		"gpy2xx_msec_config_egr_count_thresh",
		"Configure egress counter packet and octet thresholds",
		"gpy2xx_msec_config_egr_count_thresh [frame_thr=?] [octet_thr=?]\n"
		"  frame_thr:	 value\n"
		"  octet_thr:	 value\n",
	},
	{
		"gpy2xx_msec_get_egr_count_thresh",
		"GEt egress counter packet and octet thresholds",
		NULL
	},
	{
		"gpy2xx_msec_config_ing_misc_ctrl",
		"Configure ingress misc control",
		"gpy2xx_msec_config_ing_misc_ctrl [mc_latency=?] [static_bp=?] [nm_macsec=?] [validate_frames=?] [sectag_avlan=?]\n"
		"  mc_latency:       value\n"
		"  static_bp         value\n"
		"  nm_macsec:        value\n"
		"  validate_frames:  value\n"
		"  sectag_avlan:     value\n",
	},
	{
		"gpy2xx_msec_config_egr_misc_ctrl",
		"Configure egress misc control",
		"gpy2xx_msec_config_egr_misc_ctrl [mc_latency=?] [static_bp=?] [nm_macsec=?] [validate_frames=?] [sectag_avlan=?]\n"
		"  mc_latency:       value\n"
		"  static_bp         value\n"
		"  nm_macsec:        value\n"
		"  validate_frames:  value\n"
		"  sectag_avlan:     value\n",
	},
	{
		"gpy2xx_msec_config_ing_sa_nm_ctrl",
		"Configure ingress no-match classifier control",
		"gpy2xx_msec_config_ing_sa_nm_ctrl [comp_etype=?] [check_ver=?] [check_kay=?] [check_ce=?] [check_sc=?] [check_sl=?] [check_pn=?] [msec_eth=?]\n"
		"  comp_etype:      dis/en\n"
		"  check_ver        dis/en\n"
		"  check_kay:       dis/en\n"
		"  check_ce:  		dis/en\n"
		"  check_sc:     	dis/en\n"
		"  check_sl:     	dis/en\n"
		"  check_pn:     	dis/en\n"
		"  msec_eth:        value\n",
	},
	{
		"gpy2xx_msec_config_egr_sa_nm_ctrl",
		"Configure egress no-match classifier control",
		"gpy2xx_msec_config_egr_sa_nm_ctrl [comp_etype=?] [check_ver=?] [check_kay=?] [check_ce=?] [check_sc=?] [check_sl=?] [check_pn=?] [msec_eth=?]\n"
		"  comp_etype:		dis/en\n"
		"  check_ver 		dis/en\n"
		"  check_kay:		dis/en\n"
		"  check_ce: 		dis/en\n"
		"  check_sc: 		dis/en\n"
		"  check_sl: 		dis/en\n"
		"  check_pn: 		dis/en\n"
		"  msec_eth: 		value\n",
	},
	{
		"gpy2xx_msec_config_ing_sa_nm_ncp",
		"Configure ingress SA non-match flow control action for non-control packet",
		"gpy2xx_msec_config_ing_sa_nm_ncp [pkt_type=?] [flow_type=?] [dest_port=?] [drop_nonres=?] [drop_action=?]\n"
		"  pkt_type:       value\n"
		"  flow_type       value\n"
		"  dest_port:      value\n"
		"  drop_nonres:    value\n"
		"  drop_action:    value\n",
	},
	{
		"gpy2xx_msec_config_egr_sa_nm_ncp",
		"Configure egress SA non-match flow control action for non-control packet",
		"gpy2xx_msec_config_egr_sa_nm_ncp [pkt_type=?] [flow_type=?] [dest_port=?] [drop_action=?]\n"
		"  pkt_type:       value\n"
		"  flow_type       value\n"
		"  dest_port:      value\n"
		"  drop_action:    value\n",
	},
	{
		"gpy2xx_msec_config_ing_sa_nm_cp",
		"Configure ingress SA non-match flow control action for control packet",
		"gpy2xx_msec_config_ing_sa_nm_cp [pkt_type=?] [flow_type=?] [dest_port=?] [drop_nonres=?] [drop_action=?]\n"
		"  pkt_type:       value\n"
		"  flow_type       value\n"
		"  dest_port:      value\n"
		"  drop_nonres:    value\n"
		"  drop_action:    value\n",
	},
	{
		"gpy2xx_msec_config_egr_sa_nm_cp",
		"Configure egress SA non-match flow control action for control packet",
		"gpy2xx_msec_config_egr_sa_nm_cp [pkt_type=?] [flow_type=?] [dest_port=?] [drop_action=?]\n"
		"  pkt_type:       value\n"
		"  flow_type       value\n"
		"  dest_port:      value\n"
		"  drop_action:    value\n",
	},
	{
		"gpy2xx_msec_clear_ing_stats_summ",
		"Configure ingress SA expired/pn-thr/psa summary",
		"gpy2xx_msec_clear_ing_stats_summ [psa_summ0=?] [glb_summ=?]\n"
		"  psa_summ0:       value\n"
		"  glb_summ:        value\n",
	},
	{
		"gpy2xx_msec_clear_egr_stats_summ",
		"Configure egress SA expired/pn-thr/psa summary",
		"gpy2xx_msec_clear_egr_stats_summ [psa_summ0=?] [glb_summ=?]\n"
		"  psa_summ0:       value\n"
		"  glb_summ:        value\n",
	},
	{
		"gpy2xx_msec_get_ing_stats_summ",
		"Get ingress SA expired/pn-thr/psa summary",
		NULL
	},
	{
		"gpy2xx_msec_get_egr_stats_summ",
		"Get egress SA expired/pn-thr/psa summary",
		NULL
	},
	{
		"gpy2xx_msec_clear_ing_psa_stats_summ",
		"Clears ingress per-SA statistics summary",
		"gpy2xx_msec_clear_ing_psa_stats_summ [psa_type=?] [rule_index=?] [psa_summ0=?]\n"
		"  psa_type:         value\n"
		"  rule_index:       value\n"
		"  psa_summ0:        value\n",
	},
	{
		"gpy2xx_msec_get_ing_psa_stats_summ",
		"Get ingress per-SA statistics summary",
		"gpy2xx_msec_get_ing_psa_stats_summ [psa_type=?] [rule_index=?]\n"
		"  psa_type:         value\n"
		"  rule_index:       value\n",
	},
	{
		"gpy2xx_msec_clear_egr_psa_stats_summ",
		"Clears egress per-SA statistics summary",
		"gpy2xx_msec_clear_egr_psa_stats_summ [psa_type=?] [rule_index=?] [psa_summ0=?]\n"
		"  psa_type:         value\n"
		"  rule_index:       value\n"
		"  psa_summ0:        value\n",
	},
	{
		"gpy2xx_msec_get_egr_psa_stats_summ",
		"Get egress per-SA statistics summary",
		"gpy2xx_msec_get_egr_psa_stats_summ [psa_type=?] [rule_index=?]\n"
		"  psa_type:         value\n"
		"  rule_index:       value\n",
	},
	{
		"gpy2xx_msec_config_ing_cp_rule",
		"Configure ingress control packet classification rule",
		"gpy2xx_msec_config_ing_cp_rule [cpc_index=?] [entry_type=?] [da_mac=?] [da_end=?] [eth_type=?] [cpm_mode=?] [cpm_en=?]\n"
		"  cpc_index:       value\n"
		"  entry_type:      value\n"
		"  da_mac:          value\n"
		"  da_end:          value\n"
		"  eth_type:        value\n"
		"  cpm_mode:        value\n"
		"  cpm_en:          value\n",
	},
	{
		"gpy2xx_msec_config_egr_cp_rule",
		"Configure engress control packet classification rule",
		"gpy2xx_msec_config_egr_cp_rule [cpc_index=?] [entry_type=?] [da_mac=?] [da_end=?] [eth_type=?] [cpm_mode=?] [cpm_en=?]\n"
		"  cpc_index:       value\n"
		"  entry_type:      value\n"
		"  da_mac:          value\n"
		"  da_end:          value\n"
		"  eth_type:        value\n"
		"  cpm_mode:        value\n"
		"  cpm_en:          value\n",
	},
	{
		"gpy2xx_msec_clear_sa_pn_thr_summ",
		"Clear OPP's SA PN threshold summary flags",
		"gpy2xx_msec_clear_sa_pn_thr_summ [pnthr_summ0=?]\n"
		"  pnthr_summ0:     value\n",
	},
	{
		"gpy2xx_msec_get_sa_pn_thr_summ",
		"Get OPP's SA PN threshold summary flags",
		NULL
	},
	{
		"gpy2xx_msec_clear_egr_sa_exp_summ",
		"Clear SA expired summary flags",
		"gpy2xx_msec_clear_egr_sa_exp_summ [saexp_summ0=?]\n"
		"  saexp_summ0:     value\n",
	},
	{
		"gpy2xx_msec_get_egr_sa_exp_summ",
		"Gets SA expired summary flags",
		NULL
	},
	{
		"gpy2xx_msec_clear_ing_cc_int_stat",
		"Clear crypto-cores's context, HW / SW interrupt status",
		"gpy2xx_msec_clear_ing_cc_int_stat [ctx_stat=?] [int_stat=?]\n"
		"  ctx_stat:     value\n"
		"  int_stat:     value\n",
	},
	{
		"gpy2xx_msec_get_ing_cc_int_stat",
		"Get crypto-cores's context, HW / SW interrupt status",
		NULL
	},
	{
		"gpy2xx_msec_clear_egr_cc_int_stat",
		"Clear crypto-cores's context, HW / SW interrupt status",
		"gpy2xx_msec_clear_egr_cc_int_stat [ctx_stat=?] [int_stat=?]\n"
		"  ctx_stat:     value\n"
		"  int_stat:     value\n",
	},
	{
		"gpy2xx_msec_get_egr_cc_int_stat",
		"Get crypto-cores's context, HW / SW interrupt status",
		NULL
	},
	{
		"gpy2xx_msec_config_ing_sn_thresh",
		"Configures the ingress sequence number threshold",
		"gpy2xx_msec_config_ing_sn_thresh [sn_type=?] [sn_thr=?]\n"
		"  sn_type:    	value\n"
		"  sn_thr:     	value\n",
	},
	{
		"gpy2xx_msec_get_ing_sn_thresh",
		"Gets the ingress Sequence Number threshold",
		"gpy2xx_msec_get_ing_sn_thresh [sn_type=?]\n"
		"sn_type:    1 - SN_32_BIT / 2 - SN_64_BIT",
	},
	{
		"gpy2xx_msec_config_egr_sn_thresh",
		"Configures the egress sequence number threshold",
		"gpy2xx_msec_config_egr_sn_thresh [sn_type=?] [sn_thr=?]\n"
		"  sn_type:    	value\n"
		"  sn_thr:     	value\n",
	},
	{
		"gpy2xx_msec_get_egr_sn_thresh",
		"Gets the ingress squence number threshold",
		"gpy2xx_msec_get_egr_sn_thresh [sn_type=?]\n"
		"sn_type:	 1 - SN_32_BIT / 2 - SN_64_BIT",

	},
	{
		"gpy2xx_msec_config_ing_aic_csr",
		"Configures the ingress interrupt  controll and status options",
		"gpy2xx_msec_config_ing_aic_csr [enable_ctrl=?] [ack=?] [enable_set=?] [enable_clr=?]\n"
		"  enable_ctrl:		value\n"
		"  ack:    			value\n"
		"  enable_set:    	value\n"
		"  enable_clr:     	value\n",
	},
	{
		"gpy2xx_msec_get_ing_aic_csr",
		"Gets the ingress interrupt  controll and status options",
		NULL
	},
	{
		"gpy2xx_msec_config_egr_aic_csr",
		"Configures the egress interrupt  controll and status options",
		"gpy2xx_msec_config_egr_aic_csr [enable_ctrl=?] [ack=?] [enable_set=?] [enable_clr=?]\n"
		"  enable_ctrl:		value\n"
		"  ack:    			value\n"
		"  enable_set:    	value\n"
		"  enable_clr:     	value\n",
	},
	{
		"gpy2xx_msec_get_egr_aic_csr",
		"Gets the egress interrupt  controll and status options",
		NULL
	},
	{
		"gpy2xx_msec_get_ing_cap",
		"Gets the ingress HW capabilities",
		NULL
	},
	{
		"gpy2xx_msec_get_egr_cap",
		"Gets the egress HW capabilities",
		NULL
	},
	{
		"gpy2xx_usxgmii_reach_cfg",
		"Configures the USXGMII reach customer setting according to master slice (slice 0)",
		"gpy2xx_usxgmii_reach_cfg trace_len=? [tx_eq_main=?] [tx_eq_pre=?] [tx_eq_post=?] [tx_vboost_en=?] [tx_vboost_lvl=?] [tx_iboost_lvl=?] [rx_eq_att_lvl=?] [rx_eq_vga1_gain=?] [rx_eq_vga2_gain=?] [rx_eq_ctle_boost=?] [rx_eq_ctle_pole=?] [rx_eq_dfe_tap1=?] [rx_afe_adapt_en=?] [rx_dfe_adapt_en=?]\n"
		"trace_len:         0-short, 1-medium, 2-long, 3-custom\n"
		"tx_eq_main:        0x00 - 0x3F\n"
		"tx_eq_pre:         0x00 - 0x3F\n"
		"tx_eq_post:        0x00 - 0x3F\n"
		"tx_vboost_en:      0 - disable, 1 - enable\n"
		"tx_vboost_lvl:     0x00 - 0x07\n"
		"tx_iboost_lvl:     0x00 - 0x07\n"
		"rx_eq_att_lvl:     0x00 - 0x07\n"
		"rx_eq_vga1_gain:   0x00 - 0x0F\n"
		"rx_eq_vga2_gain:   0x00 - 0x0F\n"
		"rx_eq_ctle_boost:  0x00 - 0x1F\n"
		"rx_eq_ctle_pole:   0x00 - 0x07\n"
		"rx_eq_dfe_tap1:    0x00 - 0xFF\n"
		"rx_afe_adapt_en:	0 - disable, 1 - enable\n"
		"rx_dfe_adapt_en:	0 - disable, 1 - enable\n",
	},
	{
		"gpy2xx_usxgmii_reach_get",
		"Get the USXGMII reach setting",
		NULL
	},

	{
		"gpy2xx_usxgmii_loopback_cfg",
		"Configures the USXGMII serial and parrallel loop back",
		"gpy2xx_usxgmii_loopback_cfg [mode=?]\n"
		"Loopback Mode\n"
		"enum mode\n"
		"	USXGMII_LOOPBACK_DISABLE = 0,\n"
		"	USXGMII_LOOPBACK_TX2RX   = 1,\n"
		"	USXGMII_LOOPBACK_RX2TX   = 2,\n",
	},

	{
		"gpy2xx_usxgmii_loopback_get",
		"Get the USXGMII reach loop back setting",
		NULL
	},

	{
		"gpy2xx_usxgmii_tx_bert_cfg",
		"Configures TX bert",
		"gpy2xx_usxgmii_tx_bert_cfg  [mode=?] [nval_sel=?]\n"
		"tx bert mode configuration\n"
		"enum mode\n"
		"	BERT_SQUAREWAVE_TX = 0\n"
		"	BERT_PSEUDO_RANDOM_TX = 1\n"
		"	BERT_PRBS31_TX = 2\n"
		"	BERT_PRBS9_TX = 3\n"
		"	BERT_TX_MODE_DISABLE = 4\n"
		"Square Wave Control When square wave test pattern generation is enabled\n"
		"enum nval_sel\n"
		"	BERT_TX_NVAL_SEL_4 = 0\n"
		"	BERT_TX_NVAL_SEL_5 = 1\n"
		"	BERT_TX_NVAL_SEL_6 = 2\n"
		"	BERT_TX_NVAL_SEL_7 = 3\n"
		"	BERT_TX_NVAL_SEL_8 = 4\n"
		"	BERT_TX_NVAL_SEL_9 = 5\n"
		"	BERT_TX_NVAL_SEL_10 = 6\n"
		"	BERT_TX_NVAL_SEL_11 = 7\n"
		"	BERT_TX_NVAL_SEL_UNSUPPORTED = 8\n",
	},

	{
		"gpy2xx_usxgmii_rx_bert_cfg",
		"Configures RX bert",
		"gpy2xx_usxgmii_rx_bert_cfg  [mode=?]\n"
		"rx bert mode configuration\n"
		"enum mode\n"
		"	BERT_PSEUDO_RANDOM_RX = 0\n"
		"	BERT_PRBS31_RX = 1\n"
		"	BERT_PRBS9_RX = 2\n"
		"	BERT_RX_MODE_DISABLE = 3\n",
	},

	{
		"gpy2xx_usxgmii_get_tx_bert_config",
		"Get TX bert configuration setting",
		NULL
	},

	{
		"gpy2xx_usxgmii_rx_bert_get",
		"Get RX bert configuration setting",
		NULL
	},

	{
		"gpy2xx_usxgmii_mii_linksts",
		"Get Port mii linkstatus (port 0 to 3 link status based on the phy address)",
		NULL
	},

	{
		"gpy2xx_usxgmii_aneg_sts",
		"Get Port ANEG status (port 0 to 3 ANEG status based on the phy address)",
		NULL
	},

	{
		"gpy2xx_usxgmii_pcs_pma_linksts",
		"Get PMA and PCS link status",
		NULL
	},

	{
		"gpy2xx_usxgmii_vr_reset",
		"Trigger VR reset",
		NULL
	},

	{
		"gpy2xx_usxgmii_vr_reset_sts",
		"Get VR reset complete status",
		NULL
	},

	{
		"gpy2xx_usxgmii_aneg_rst",
		"Configures ANEG for Port 0 to 3 (based on phy address)",
		"gpy2xx_usxgmii_aneg_rst  [usxgmii_aneg_disable=?] [usxgmii_force_linkspeed_enable=?] [usxgmii_force_linkspeed=?]  [usxgmii_force_duplex=?] [usxgmii_restart_aneg=?]\n"
		"ANEG configuration\n"
		"aneg enable/disable for port 0 to 3 based on phy addr\n"
		"Valid 1 - disabled / 0 - enabled\n"
		"	usxgmii_aneg_disable\n"
		"restart aneg for port 0 to 3 based on phy addr\n"
		"	usxgmii_restart_aneg\n"
		"force link enable for port 0 to 3 based on phy addr\n"
		"Valid 0 - disabled / 1 - enabled\n"
		"	usxgmii_force_linkspeed\n"
		"force link speed for port 0 to 3 based on phy addr\n"
		"	usxgmii_force_linkspeed\n"
		"		SPEED_10	10\n"
		"		SPEED_100	100\n"
		"		SPEED_1000	1000\n"
		"		SPEED_2500	2500\n"
		"		SPEED_UNKNOWN	-1\n"
		"force duplex for port 0 to 3 based on phy addr\n"
		"Valid 0 - Half duplex / 1 - Full duplex\n"
		"	usxgmii_force_duplex\n",
	},

	{
		"gpy2xx_usxgmii_alignmentmarker_get",
		"Get AM_COUNT",
		NULL
	},

	{
		"gpy2xx_usxgmii_alignmentmarker_set",
		"Configures AM count",
		"gpy2xx_usxgmii_alignmentmarker_set [usxgmii_am_count=?]\n"
		"AM Count\n"
		"Valid 0x00 - 0x7FFF\n"
		"	usxgmii_am_count\n",
	},

};


















void gpy211_menu(const char *cmd)
{
	unsigned int len, max_len;
	unsigned int i;

	if (cmd == NULL) {
		printf("\n\n\n\tGPY211 Utility Tool Version   : %s", TOOL_VERSION);
		printf("\n\t*************************************\n\n");

		max_len = 0;

		for (i = 0; i < ARRAY_SIZE(help_text); i++) {
			len = strlen(help_text[i].cmd);

			if (max_len < len)
				max_len = len;
		}

		for (i = 0; i < ARRAY_SIZE(help_text); i++) {
			printf("\t %-*s : %s\n", max_len, help_text[i].cmd, help_text[i].brief);
		}

		printf("\n\nIMPORTANT NOTE:\n");
		printf("\nFor hex decimal input param please add 0x before the hex decimal number or just give decimal number");
		printf("\nPrefix hex decimal value with 0x or GPY211 command execution will lead to wrong setting or malfunction\n");
		printf("\n");
	} else {
		for (i = 0; i < ARRAY_SIZE(help_text) && strcasecmp(cmd, help_text[i].cmd) != 0; i++);

		if (i >= ARRAY_SIZE(help_text))
			return;

		if (help_text[i].desc == NULL) {
			printf("%s does not have parameter.\n", help_text[i].cmd);
		} else {
			printf("%s", help_text[i].desc);
		}
	}
}
