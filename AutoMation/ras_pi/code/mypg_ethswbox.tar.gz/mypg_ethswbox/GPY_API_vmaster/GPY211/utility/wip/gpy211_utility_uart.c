/******************************************************************************

         Copyright 2016 - 2017 Intel Corporation
         Copyright 2015 - 2016 Lantiq Beteiligungs-GmbH & Co. KG
         Copyright 2012 - 2014 Lantiq Deutschland GmbH

  SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only)

******************************************************************************/

#include <windows_stub.h>
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <gpy211.h>
//#include <gpy211_gmac.h>
#include <gpy211_macsec.h>
#include "gpy211_utility.h"

#if FCON_MSEC_TEST
#include <e160_api.h>
#endif
//#include <eip160_common.h>
#include<time.h>






int pc_uart_dataread(u32 Offset, u32 *value)
{
    /* mdio read */
	return 1;
}

int pc_uart_datawrite(u32 Offset, u32 value)
{
    /* mdio write */
	return 1;
}
