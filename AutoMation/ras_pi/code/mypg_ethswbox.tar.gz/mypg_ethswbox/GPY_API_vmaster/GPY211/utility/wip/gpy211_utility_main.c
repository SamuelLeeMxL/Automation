/******************************************************************************

         Copyright 2016 - 2017 Intel Corporation
         Copyright 2015 - 2016 Lantiq Beteiligungs-GmbH & Co. KG
         Copyright 2012 - 2014 Lantiq Deutschland GmbH

  SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only)

******************************************************************************/

#include <windows_stub.h>
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <gpy211.h>
//#include <gpy211_gmac.h>
#include <gpy211_macsec.h>
#include "gpy211_utility.h"

#include "gpy211_utility_main.h"
#include "gpy211_utility_common.h"
#include "gpy211_utility_cmdprocessor.h"
#include "gpy211_utility_gpy2xx.h"

#include "gpy211_utility_system.h"
#include "user_mdio_interface.h"


#define ARRAY_SIZE(x)	(sizeof(x) / sizeof((x)[0]))

/*variable to enable/disable debug prints*/
unsigned char debugenable = 0;


char *param_list1[MAX_PARAM];
static volatile sig_atomic_t sig_cap = 1;
static void SignalHandler(int signal)
{
	if (signal == SIGINT) {
		sig_cap = 1;
	}
}



int main_GPY211_UTILITY(int argc, char **argv)
{
	int i = 0, j = 0, k = 0, c = 0;   

	char lpBuffer[CMD_LINE_BUFFER_SIZE];
	char lpBuffer2[CMD_LINE_BUFFER_SIZE];

	char temp_buffer[TEMP_BUFFRE_SIZE];
	char phyaddr[TEMP_BUFFRE_SIZE] = {0};	//PHY addres of P31G device

	char system_buffer[SYS_BUFFER_SIZE];

	unsigned int num = 0;
	char *param_list[MAX_PARAM];
	int counter = 0;

	unsigned int check_space = 0;
#if 0  /* TO DO*/   
	HANDLE Output = GetStdHandle(STD_OUTPUT_HANDLE);
	HANDLE hConsole = GetStdHandle(STD_INPUT_HANDLE);
#endif    
#if 0  /* TO DO*/   
	COORD Coordinates = {500, 5000};
#endif    
	DWORD dwPreviousMode = 0;


#if 0
	for (i = 1; i < argc; i++) {
		 if (strcmp(argv[i], "-a") == 0
			   || strcmp(argv[i], "--phyaddr") == 0
			   || strcmp(argv[i], "/a") == 0
			   || strcmp(argv[i], "/phyaddr") == 0) {
			if (i + 1 >= argc)
				break;
    printf ("***** argv[1] = %s ******\n", argv[1]);
			strncpy(phyaddr, argv[i + 1], ARRAY_SIZE(phyaddr) - 1);
			i++;
		}  else if (strcmp(argv[i], "-h") == 0
			   || strcmp(argv[i], "--help") == 0
			   || strcmp(argv[i], "/h") == 0
			   || strcmp(argv[i], "/help") == 0) {
			char *p1, *p2;

			for (p1 = p2 = argv[0]; *p1 != 0; p1++) {
				if (*p1 == '/' || *p1 == '\\')
					p2 = p1 + 1;
			}

			printf("Usage:\n");
			printf("  %s [-a <phy addres>][--help]\n", p2);
			return 0;
		}
	}
#endif
    if (argc > 1)
    {
	    strncpy(phyaddr, argv[1], ARRAY_SIZE(phyaddr) - 1);
    }
    else
    {
        phyaddr[0] = '0';
        phyaddr[1] = '\0';
    }

#if 0
	GetConsoleMode(hConsole, &dwPreviousMode);
	DWORD dwNewMode = (dwPreviousMode | ENABLE_QUICK_EDIT_MODE | ENABLE_EXTENDED_FLAGS);
	SetConsoleMode(hConsole, dwNewMode);
	system("mode con cols=140 lines=55");
	SetConsoleScreenBufferSize(Output, Coordinates);
#endif


	for (c = 0; c < 1 ; c++) {
		system("cls");
		printf("\n\n####################################################################");
		printf("\n###############  SWITCH UTILITY TOOL (Version: %s.55)  #############", TOOL_VERSION);
		printf("\n####################################################################\n\n");
		system("color 9e");
		Sleep(30);
		system("color 9a");
		Sleep(30);
		system("color 9b");
		Sleep(30);
		system("color 9c");
		Sleep(30);
		system("color 9d");
		Sleep(30);
		system("color 9e");
		Sleep(30);
		system("color 94");
		Sleep(30);
		system("color 9f");
		Sleep(70);
	}

	memset(system_buffer, 0, 100);

	if (phyaddr[0] != '\0') {

		phyphy.phy_addr = xstrtoul(phyaddr);        
	}

	printf("TITLE Switch Utility Tool Running    [ phy addr = %d ]", phyphy.phy_addr);




#if 0
	HANDLE Handle_Of_Thread_1 = 0;
	Handle_Of_Thread_1 = CreateThread(NULL, 0, check_uart_hang, 0, 0, NULL);

	if (Handle_Of_Thread_1 == NULL)
		printf("\nWarning : Error creating check_uart_hang thread\n");

#endif

	i = 0;


	printf("\n\n####################################################################");
	printf("\n######################  GPY211 UTILITY SHELL  ######################");
	printf("\n####################################################################\n\n");

    int ret;
    p_gpyapi_phy =  gpy211_mdio_open ();

	while (1) {

#if 0        
		if (sig_cap == 1) {
			signal(SIGINT, SignalHandler);
			sig_cap = 0;
		}
#endif

		printf("\n\nShell : ");
		memset(lpBuffer, 0, 1000);
		memset(temp_buffer, 0, 15);

        /* get the command with readline */
        system_readl_test (lpBuffer, sizeof(lpBuffer));

		memcpy(temp_buffer, lpBuffer, 15);
		memcpy(lpBuffer2, lpBuffer, 1000);

		num = 0;

		check_space = 1;

		for (k = 0; k < 15; k++) {
			if (temp_buffer[k] != ' ' && temp_buffer[k] != 0 && temp_buffer[k] != '\n') {
				check_space = 0;
			}
		}

		if (temp_buffer[0] != '\n' || check_space == 0) {
			num = split_buffer(lpBuffer, param_list, MAX_PARAM);
			counter = split_buffer(lpBuffer2, param_list1, MAX_PARAM);
		}


		if ((temp_buffer[0] == 'r' || temp_buffer[0] == 'w') && temp_buffer[1] == ' ') {

            /* nothing */

		} else if (temp_buffer[0] == '\n' || check_space == 1) {
			continue;
		} else if (xstrncasecmp(param_list[0], "exit", 4) == 0) {

            gpy211_mdio_close ();
			return 0;
		} else {
#if LOGM_IN_FILE
			char filename[] = "raw_dump.txt";
			mdio_fp = fopen(filename, "a");
			cmdProcessor(num, counter, param_list, (FILE *)mdio_fp);
#else

#if 0
            for (i = 0; i<num;i++)
            {
                printf ("####num = %d counter =%d param_list[%d] = %s\n", num, counter, i, param_list[i]);
            }
#endif                
			cmdProcessor(num, counter, param_list, (FILE *)NULL);
#endif
#if 0
			if (system_restart == 1) {
				system_restart = 0;
			}
#endif
#if LOGM_IN_FILE
			fclose(mdio_fp);
#endif
		}
	}/* End of while (1) loop */
}
