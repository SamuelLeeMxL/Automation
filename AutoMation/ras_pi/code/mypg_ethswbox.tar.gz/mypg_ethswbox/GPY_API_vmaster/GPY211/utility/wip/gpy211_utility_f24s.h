/******************************************************************************

         Copyright 2016 - 2017 Intel Corporation
         Copyright 2015 - 2016 Lantiq Beteiligungs-GmbH & Co. KG
         Copyright 2012 - 2014 Lantiq Deutschland GmbH

  SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only)

******************************************************************************/

#ifndef _UTILITY_FS24S_H_
#define _UTILITY_FS24S_H_

void print_f24s_top();
void print_f24s_rcu();
void print_f24s_cgu();
void print_f24s_gphy();
void print_f24s_uart();
void print_f24s_sspi();
void print_f24s_mspi();
void print_f24s_smdio();
void print_f24s_mmdio();
void print_f24s_led();
void print_f24s_icu();
void print_f24s_gpio();
void print_f24s_rgmii();
void print_f24s_sgmii();
void print_f24s_regs();


#endif /* _UTILITY_FS24S_H_ */

