/******************************************************************************
  Copyright 2020 MaxLinear, Inc.

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

******************************************************************************/
README FILE (Under Construction)


0/ Preriquisite: snap , Cmake, readline, ncurses 
---------------------------------
    sudo apt update
    sudo apt install snapd
    sudo reboot

    sudo snap install cmake --classic
    sudo apt-get install libreadline-dev
    sudo apt-get install libncurses5-dev libncursesw5-dev 

1/ Untar the SW package:
-----------------------
pi@rpi4:~/test $ tar xvfz ../mypg_ethswbox-0.0.2.tar.gz
 
pi@rpi4:~/test/mypg_ethswbox/ethswbox $ ls -l
total 44
-rw-r--r--  1 pi pi   633 Jun 23 11:25 ChangeLog.txt
-rw-r--r--  1 pi pi  3422 Jun 23 11:25 CMakeLists.txt
-rw-r--r--  1 pi pi 19457 Jun 23 11:25 LICENSE
drwxr-xr-x  2 pi pi  4096 Jun 23 11:25 python
-rw-r--r--  1 pi pi   299 Jun 23 11:25 README.txt
-rwxr-xr-x  1 pi pi    56 Jun 23 11:25 set_build.sh
drwxr-xr-x 10 pi pi  4096 Jun 23 11:25 src


2/ configure the toolbox:
------------------------ 
pi@rpi4:~/test/mypg_ethswbox/ethswbox $ . set_build.sh 
-- The C compiler identification is GNU 8.3.0
-- Detecting C compiler ABI info
-- Detecting C compiler ABI info - done
-- Check for working C compiler: /usr/bin/cc - skipped
-- Detecting C compile features
-- Detecting C compile features - done
-- Configuring done
-- Generating done
-- Build files have been written to: /home/pi/test/mypg_ethswbox/ethswbox/build

2.1/ Modify in "src/conf/conf_if.h" the GPIO pins assigment matching the RPI4 pins connected to the DUT 

/* Definition PHY interface:
   RPI4 GPIO MDIO BITBANG  */
   
#define RPI4B_GPIO_MDIO_CLK_PIN  23
#define RPI4B_GPIO_MDIO_DATA_PIN 24



3/ Build the toolbox:
--------------------
pi@rpi4:~/test/mypg_ethswbox/ethswbox/build $ make
[  4%] Building C object CMakeFiles/fapi_mdio.dir/src/fapi/mdio/fapi_mdio.c.o
[  9%] Linking C static library libfapi_mdio.a
[  9%] Built target fapi_mdio
[ 14%] Building C object CMakeFiles/os.dir/src/os/os_linux.c.o
[ 19%] Linking C static library libos.a
[ 19%] Built target os
[ 23%] Building C object CMakeFiles/api_gpy.dir/src/api/api_gpy.c.o
[ 28%] Building C object CMakeFiles/api_gpy.dir/src/api/gpy/src/api/phy/gpy211_phy.c.o
[ 33%] Building C object CMakeFiles/api_gpy.dir/src/api/gpy/src/api/phy/gpy211_chip.c.o
[ 38%] Linking C static library libapi_gpy.a
[ 38%] Built target api_gpy
[ 42%] Building C object CMakeFiles/phy_mdio.dir/src/phy/mdio/lib/bcm2835.c.o
[ 47%] Building C object CMakeFiles/phy_mdio.dir/src/phy/mdio/lib/mdio.c.o
[ 52%] Linking C static library libphy_mdio.a
[ 52%] Built target phy_mdio
[ 57%] Building C object CMakeFiles/cli.dir/src/cli/cmds/cmds.c.o
[ 61%] Building C object CMakeFiles/cli.dir/src/cli/cmds/cmds_apps.c.o
[ 66%] Building C object CMakeFiles/cli.dir/src/cli/cmds/cmds_fapi.c.o
[ 71%] Linking C static library libcli.a
[ 71%] Built target cli
[ 76%] Building C object CMakeFiles/apps.dir/src/apps/apps_tools_gpy.c.o
[ 80%] Linking C static library libapps.a
[ 80%] Built target apps
[ 85%] Building C object CMakeFiles/fapi_ffu.dir/src/fapi/ffu/fapi_gpy_ffu.c.o
[ 90%] Linking C static library libfapi_ffu.a
[ 90%] Built target fapi_ffu
[ 95%] Building C object CMakeFiles/ethswbox.dir/src/cli/ethswbox.c.o
[100%] Linking C executable ethswbox
[100%] Built target ethswbox
pi@rpi4:~/test/mypg_ethswbox/ethswbox/build $


4/ Create symbolic links for ethswbox application (only once after new build folder):
------------------------------------------------------------------------------------
pi@rpi4:~/test/mypg_ethswbox/ethswbox/build $ ./ethswbox 
Ethernet SW Toolbox version 0.0.2 ... Updating symbolic links!
pi@rpi4:~/test/mypg_ethswbox/ethswbox/build $


5/ Check available commands (type "./" and TAB completion):
---------------------------------------------------------- 
pi@rpi4:~/test/mypg_ethswbox/ethswbox/build $ ./
apps-tools-gpy-recover-lbb-uart  ethswbox                         fapi-ffu-upgrade                 fapi-mdio-c22-write              fapi-mdio-c45-write              
CMakeFiles/                      fapi-ffu-erase                   fapi-mdio-c22-read               fapi-mdio-c45-read               
pi@rpi4:~/test/mypg_ethswbox/ethswbox/build $ ./



5/ Command Help (issue command without parameters for example (type "./" and TAB completion to select the command):
------------------------------------------------------------------------------------------------------------------
pi@rpi4:~/test/mypg_ethswbox/ethswbox/build $ ./fapi-mdio-c22-read
  Usage: fapi-mdio-c22-read ifid port reg
   ifid: Interface Id
   port: PHY port address
    reg: PHY register to read
  (hexadecimal value prefixed with 0x)
pi@rpi4:~/test/mypg_ethswbox/ethswbox/build $ 

6/ Example valid commands (type "./" and TAB completion to select the command):
------------------------------------------------------------------------------
pi@rpi4:~/test/mypg_ethswbox/ethswbox/build $ ./fapi-mdio-c22-read 99 0 0x1e
 read: port=0 reg=0x1e value=0x645
pi@rpi4:~/test/mypg_ethswbox/ethswbox/build $

pi@rpi4:~/test/mypg_ethswbox/ethswbox/build $ ./fapi-mdio-c22-read 99 0 30
 read: port=0 reg=0x1e value=0x645
pi@rpi4:~/test/mypg_ethswbox/ethswbox/build $ 

7/ pctool ( the parameter is PHY address)
-----------------------------------------
pi@rpi4:~/aa_pctool/mypg_ethswbox/ethswbox/build $ ./pctool 1


####################################################################
###############  SWITCH UTILITY TOOL (Version: 0.0.2.55)  #############
####################################################################

TITLE Switch Utility Tool Running    [ phy addr = 1 ]

####################################################################
######################  GPY211 UTILITY SHELL  ######################
####################################################################

 gpy211_mdio_open: phyphy.phy_addr = 1
 gpy211_mdio_open: p_phy->phy_addr = 1


Shell : help



        GPY211 Utility Tool Version   : 0.0.2
        *************************************

         exit                                 : Exit GPY211 utility tool
         help                                 : Print this help page
         en_debug                             : Enable debugging codes
         gpy2xx_init                          : Initialize GPY211 API
         gpy2xx_uninit                        : Clean up GPY211 API
         gpy2xx_get_phy_id                    : Read PHY/Chip/Firmware/Driver version number
         gpy2xx_soft_reset                    : Trigger soft reset via MDIO STD_CTRL
         gpy2xx_poll_reset                    : Poll soft reset status
         gpy2xx_read                          : Read MDIO Clause 22 registers
         gpy2xx_write                         : Write MDIO Clause 22 registers
         gpy2xx_read_mmd                      : Read MDIO Clause 45 MMD registers
         gpy2xx_write_mmd                     : Write MDIO Clause 45 MMD registers
         gpy2xx_mbox_read16                   : PHY's Mbox 16-bit wide register read
         gpy2xx_mbox_write16                  : PHY's Mbox 16-bit wide register write
         gpy2xx_mbox_read32                   : PHY's Mbox 32-bit wide register read
         gpy2xx_mbox_write32                  : PHY's Mbox 32-bit wide register write
         gpy2xx_config_advert                 : Advertise auto-negotiation parameters
         gpy2xx_setup_forced                  : Configures/forces speed/duplex
         gpy2xx_restart_aneg                  : Enable and restart auto-negotiation
         gpy2xx_config_aneg                   : Restart auto-negotiation or force link
         gpy2xx_aneg_done                     : Get auto-negotiation status
         gpy2xx_update_link                   : Get link status (up/down)
         gpy2xx_read_status                   : Get link status (detail)
         gpy2xx_read_fw_info                  : Get FW info (detail)
         gpy2xx_gpio_cfg                      : Configure GPIO pin
         gpy2xx_gpio_get                      : Get GPIO pin configuration
         gpy2xx_gpio_output                   : Configure GPIO pin output value (low/high)
         gpy2xx_gpio_input                    : Get GPIO pin input value (low/high)
         gpy2xx_led_br_cfg                    : Configure LED brightness
         gpy2xx_led_br_get                    : Get LED brightness configuration
         gpy2xx_led_if_cfg                    : Configure LED
         gpy2xx_led_if_get                    : Get LED configuration
         gpy2xx_extin_mask                    : Enable/disable external interrupt event
         gpy2xx_extin_get                     : Get external interrupt event mask
         gpy2xx_test_mode_cfg                 : Set test mode
         gpy2xx_cdiag_start                   : Start cable diagnostic
         gpy2xx_cdiag_read                    : Read cable diagnostic result
         gpy2xx_abist_start                   : Start analog self-test (ABIST)
         gpy2xx_abist_read                    : Read analog self-test (ABIST) result
         gpy2xx_loopback_cfg                  : Configure near/far end loopback
         gpy2xx_errcnt_cfg                    : Configure errors/events to be counted
         gpy2xx_errcnt_read                   : Read error/event counter
         gpy2xx_pcs_status_read               : Get PCS status
         gpy2xx_ptp_adjfreq                   : Adjust frequency of hardware clock
         gpy2xx_ptp_adjtime                   : Adjust the system timestamp
         gpy2xx_ptp_settime                   : Initialize the system timestamp
         gpy2xx_ptp_set_tsctrl                : Configures the timestamp control, second/sub-second increment value
         gpy2xx_ptp_set_ppsctrl               : Configures the timestamp PPS control params
         gpy2xx_ptp_set_ptoctrl               : Configures the timestamp PTO control params
         gpy2xx_ptp_gettime                   : Provides the system timestamp
         gpy2xx_ptp_enable                    : Enable and configure PTP (1588) function
         gpy2xx_ptp_disable                   : Disable and configure PTP (1588) function
         gpy2xx_ptp_getcfg                    : Get PTP (1588) configuration
         gpy2xx_ptp_fifostat                  : Get timestamp FIFO status
         gpy2xx_ptp_resetfifo                 : Resets the timestamp FIFO status
         gpy2xx_ptp_getrxts                   : Get RX packet timestamp status and CRC
         gpy2xx_ptp_aux_cfg                   : Configure PTP Auxiliary timestamp function
         gpy2xx_ptp_gettxts                   : Get TX packet timestamp and CRC status and CRC
         gpy2xx_ptp_getauxts                  : Get Auxiliary timestamp
         gpy2xx_ptp_auxfifostat               : Get auxiliary timestamp FIFO status
         gpy2xx_ptp_resetauxfifo              : Reset auxiliary timestamp FIFO status
         gpy2xx_synce_cfg                     : Configure SyncE function
         gpy2xx_synce_get                     : Get SyncE configuration
         gpy2xx_wol_cfg                       : Configure Wake-On-Lan function
         gpy2xx_wol_get                       : Get Wake-On-Lan configuration
         gpy2xx_ads_cfg                       : Configure Auto-Down-Speed
         gpy2xx_ads_get                       : Get Auto-Down-Speed
         gpy2xx_ulp_cfg                       : Configure Ultra Low Power
         gpy2xx_ulp_cfg                       : Get Ultra Low Power
         gpy2xx_ads_detected                  : Get auto-downspeed event
         gpy2xx_sgmii_restart_aneg            : Restart SGMII auto-negotiation
         gpy2xx_sgmii_config_aneg             : Configure SGMII auto-negotiation
         gpy2xx_sgmii_aneg_done               : Check SGMII auto-negotiation status
         gpy2xx_sgmii_read_status             : Get SGMII link status (detail)
         gpy2xx_sgmii_opmode                  : Configure SGMII operation mode
         gpy2xx_pvt_get                       : Get SENSOR temparature
         gpy2xx_gmacx_pm_pdi_cfg              : Set PM PDI configuration
         gpy2xx_gmacx_pm_pdi_get              : Get PM PDI configuration
         gpy2xx_gmacf_pm_cfg                  : Set PM GMAC-Full configuration
         gpy2xx_gmacf_pm_get                  : Get PM GMAC-Full configuration
         gpy2xx_gmacl_pm_cfg                  : Set PM GMAC-Lite configuration
         gpy2xx_gmacl_pm_get                  : Get PM GMAC-Lite configuration
         gpy2xx_gmacx_bm_cfg                  : Set PM's Buffer configuration
         gpy2xx_gmacx_bm_status_get           : Get PMs buffer status
         gpy2xx_gmacx_bm_get                  : Get PM's Buffer configuration
         gpy2xx_gmacl_pause_cfg               : Set GMAC-Lite's Pause configuration
         gpy2xx_gmacl_pause_get               : Get GMAC-Lite's Pause configuration
         gpy2xx_pm_freg_tune                  : Tune the frequency of MACs within GPY in USXGMII Mode
         gpy2xx_gmacf_pkt_cfg                 : Set GMAC-Full's packet config info
         gpy2xx_gmacf_pkt_get                 : Get GMAC-Full's packet config info
         gpy2xx_gmacf_count_ctrl_cfg          : Set GMAC-Full's Rx/Tx counters control info
         gpy2xx_gmacf_count_ctrl_get          : Get GMAC-Full's counters control info
         gpy2xx_gmacf_count_get               : Get GMAC-Full's Rx/Tx counters
         gpy2xx_msec_init_ing_dev             : Init macsec ING device
         gpy2xx_msec_init_egr_dev             : Init macsec EGR device
         gpy2xx_msec_config_ing_tr            : Configure ingress transform record
         gpy2xx_msec_config_egr_tr            : Configure egress transform record
         gpy2xx_msec_update_egr_sa_cw         : Update egress SA control word
         gpy2xx_msec_get_ing_tr               : Get ingress transform record
         gpy2xx_msec_get_egr_tr               : Get egress transform record
         gpy2xx_msec_get_ing_pn               : Get ingress current SN from transform record
         gpy2xx_msec_get_egr_pn               : Get egress current SN from transform record
         gpy2xx_msec_config_ing_sam_rule      : Configure ingress SA match rule parameters
         gpy2xx_msec_config_egr_sam_rule      : Configure egress SA match rule parameters
         gpy2xx_msec_get_ing_sam_rule         : Get ingress SA match rule parameters
         gpy2xx_msec_get_egr_sam_rule         : Get egress SA match rule parameters
         gpy2xx_msec_config_ing_sam_fca       : Configure ingress SA matching rule's flow control action parameters
         gpy2xx_msec_config_egr_sam_fca       : Configure egress SA matching rule's flow control action parameters
         gpy2xx_msec_get_ing_sam_fca          : Get ingress SA matching rule's flow control action parameters
         gpy2xx_msec_get_egr_sam_fca          : Get ingress SA matching rule's flow control action parameters
         gpy2xx_msec_clear_ing_tr             : Clears ingress transform record
         gpy2xx_msec_clear_egr_tr             : Clears egress transform record
         gpy2xx_msec_clear_ing_sam_rule       : Clears ingress SAM rule parameters
         gpy2xx_msec_clear_egr_sam_rule       : Clears egress SAM rule parameters
         gpy2xx_msec_clear_ing_sam_fca        : Clears ingress SAM flow control parameters
         gpy2xx_msec_clear_egr_sam_fca        : Clears egress SAM flow control parameters
         gpy2xx_msec_config_ing_vlan_parse    : Configure ingress SA match VLAN control parameters
         gpy2xx_msec_config_egr_vlan_parse    : Configure egress SA match VLAN control parameters
         gpy2xx_msec_config_ing_sam_eex       : Configure ingress SA match entry enable flags
         gpy2xx_msec_config_egr_sam_eex       : Configure egress SA match entry enable flags
         gpy2xx_msec_get_ing_sam_eef          : Get ingress SA match entry enable flags
         gpy2xx_msec_get_egr_sam_eef          : Get egress SA match entry enable flags
         gpy2xx_msec_config_ing_sam_eec       : Configure ingress SA match entry enable clear
         gpy2xx_msec_config_egr_sam_eec       : Configure egress SA match entry enable clear
         gpy2xx_msec_config_ing_cc_rule       : Configure ingress consistency check match parameters
         gpy2xx_msec_get_ing_cc_rule          : Configure ingress consistency check match parameters
         gpy2xx_msec_config_ing_cc_eef        : Configure ingress consistency check entry enable flags
         gpy2xx_msec_get_ing_cc_eef           : Get ingress consistency check entry enable flags
         gpy2xx_msec_config_ing_cc_eec        : Configure ingress CC match entry enable clear
         gpy2xx_msec_config_ing_cc_ctrl       : Configure ingress consistency check control
         gpy2xx_msec_get_ing_sa_stats         : Get ingress SA statistics
         gpy2xx_msec_get_egr_sa_stats         : Get egress SA statistics
         gpy2xx_msec_get_ing_global_stats     : Get ingress global statistics
         gpy2xx_msec_get_egr_global_stats     : Get egress global statistics
         gpy2xx_msec_config_ing_count_ctrl    : Configure ingress count control
         gpy2xx_msec_config_egr_count_ctrl    : Configure egress count controls
         gpy2xx_msec_config_ing_count_incen   : Configure ingress counter increment enables
         gpy2xx_msec_config_egr_count_incen   : Configure egress counter increment enables
         gpy2xx_msec_config_ing_count_secfail : Configure ingress secfail event trigger enables
         gpy2xx_msec_config_egr_count_secfail : Configure egress secfail event trigger enables
         gpy2xx_msec_config_ing_count_thresh  : Configure ingress counter packet and octet thresholds
         gpy2xx_msec_get_ing_count_thresh     : Get ingress counter packet and octet thresholds
         gpy2xx_msec_config_egr_count_thresh  : Configure egress counter packet and octet thresholds
         gpy2xx_msec_get_egr_count_thresh     : GEt egress counter packet and octet thresholds
         gpy2xx_msec_config_ing_misc_ctrl     : Configure ingress misc control
         gpy2xx_msec_config_egr_misc_ctrl     : Configure egress misc control
         gpy2xx_msec_config_ing_sa_nm_ctrl    : Configure ingress no-match classifier control
         gpy2xx_msec_config_egr_sa_nm_ctrl    : Configure egress no-match classifier control
         gpy2xx_msec_config_ing_sa_nm_ncp     : Configure ingress SA non-match flow control action for non-control packet
         gpy2xx_msec_config_egr_sa_nm_ncp     : Configure egress SA non-match flow control action for non-control packet
         gpy2xx_msec_config_ing_sa_nm_cp      : Configure ingress SA non-match flow control action for control packet
         gpy2xx_msec_config_egr_sa_nm_cp      : Configure egress SA non-match flow control action for control packet
         gpy2xx_msec_clear_ing_stats_summ     : Configure ingress SA expired/pn-thr/psa summary
         gpy2xx_msec_clear_egr_stats_summ     : Configure egress SA expired/pn-thr/psa summary
         gpy2xx_msec_get_ing_stats_summ       : Get ingress SA expired/pn-thr/psa summary
         gpy2xx_msec_get_egr_stats_summ       : Get egress SA expired/pn-thr/psa summary
         gpy2xx_msec_clear_ing_psa_stats_summ : Clears ingress per-SA statistics summary
         gpy2xx_msec_get_ing_psa_stats_summ   : Get ingress per-SA statistics summary
         gpy2xx_msec_clear_egr_psa_stats_summ : Clears egress per-SA statistics summary
         gpy2xx_msec_get_egr_psa_stats_summ   : Get egress per-SA statistics summary
         gpy2xx_msec_config_ing_cp_rule       : Configure ingress control packet classification rule
         gpy2xx_msec_config_egr_cp_rule       : Configure engress control packet classification rule
         gpy2xx_msec_clear_sa_pn_thr_summ     : Clear OPP's SA PN threshold summary flags
         gpy2xx_msec_get_sa_pn_thr_summ       : Get OPP's SA PN threshold summary flags
         gpy2xx_msec_clear_egr_sa_exp_summ    : Clear SA expired summary flags
         gpy2xx_msec_get_egr_sa_exp_summ      : Gets SA expired summary flags
         gpy2xx_msec_clear_ing_cc_int_stat    : Clear crypto-cores's context, HW / SW interrupt status
         gpy2xx_msec_get_ing_cc_int_stat      : Get crypto-cores's context, HW / SW interrupt status
         gpy2xx_msec_clear_egr_cc_int_stat    : Clear crypto-cores's context, HW / SW interrupt status
         gpy2xx_msec_get_egr_cc_int_stat      : Get crypto-cores's context, HW / SW interrupt status
         gpy2xx_msec_config_ing_sn_thresh     : Configures the ingress sequence number threshold
         gpy2xx_msec_get_ing_sn_thresh        : Gets the ingress Sequence Number threshold
         gpy2xx_msec_config_egr_sn_thresh     : Configures the egress sequence number threshold
         gpy2xx_msec_get_egr_sn_thresh        : Gets the ingress squence number threshold
         gpy2xx_msec_config_ing_aic_csr       : Configures the ingress interrupt  controll and status options
         gpy2xx_msec_get_ing_aic_csr          : Gets the ingress interrupt  controll and status options
         gpy2xx_msec_config_egr_aic_csr       : Configures the egress interrupt  controll and status options
         gpy2xx_msec_get_egr_aic_csr          : Gets the egress interrupt  controll and status options
         gpy2xx_msec_get_ing_cap              : Gets the ingress HW capabilities
         gpy2xx_msec_get_egr_cap              : Gets the egress HW capabilities
         gpy2xx_usxgmii_reach_cfg             : Configures the USXGMII reach customer setting according to master slice (slice 0)
         gpy2xx_usxgmii_reach_get             : Get the USXGMII reach setting
         gpy2xx_usxgmii_loopback_cfg          : Configures the USXGMII serial and parrallel loop back
         gpy2xx_usxgmii_loopback_get          : Get the USXGMII reach loop back setting
         gpy2xx_usxgmii_tx_bert_cfg           : Configures TX bert
         gpy2xx_usxgmii_rx_bert_cfg           : Configures RX bert
         gpy2xx_usxgmii_get_tx_bert_config    : Get TX bert configuration setting
         gpy2xx_usxgmii_rx_bert_get           : Get RX bert configuration setting
         gpy2xx_usxgmii_mii_linksts           : Get Port mii linkstatus (port 0 to 3 link status based on the phy address)
         gpy2xx_usxgmii_aneg_sts              : Get Port ANEG status (port 0 to 3 ANEG status based on the phy address)
         gpy2xx_usxgmii_pcs_pma_linksts       : Get PMA and PCS link status
         gpy2xx_usxgmii_vr_reset              : Trigger VR reset
         gpy2xx_usxgmii_vr_reset_sts          : Get VR reset complete status
         gpy2xx_usxgmii_aneg_rst              : Configures ANEG for Port 0 to 3 (based on phy address)
         gpy2xx_usxgmii_alignmentmarker_get   : Get AM_COUNT
         gpy2xx_usxgmii_alignmentmarker_set   : Configures AM count


IMPORTANT NOTE:

For hex decimal input param please add 0x before the hex decimal number or just give decimal number
Prefix hex decimal value with 0x or GPY211 command execution will lead to wrong setting or malfunction






Shell : 



