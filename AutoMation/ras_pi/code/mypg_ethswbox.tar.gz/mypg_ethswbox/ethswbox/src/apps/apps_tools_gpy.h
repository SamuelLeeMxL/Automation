/******************************************************************************

         Copyright 2016 - 2017 Intel Corporation
         Copyright 2015 - 2016 Lantiq Beteiligungs-GmbH & Co. KG
         Copyright 2012 - 2014 Lantiq Deutschland GmbH

  SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only)

******************************************************************************/

#ifndef _APPS_TOOLS_GPY_H_
#define _APPS_TOOLS_GPY_H_


#include "os.h"
#include "types.h"

s32 apps_tools_gpy_recover_lbb_uart (u16 if_id); 


#endif /* _APPS_TOOLS_GPY_H_ */
