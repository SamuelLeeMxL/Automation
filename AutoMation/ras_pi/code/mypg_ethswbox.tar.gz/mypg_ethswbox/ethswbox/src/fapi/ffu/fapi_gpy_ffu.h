/******************************************************************************

         Copyright 2016 - 2017 Intel Corporation
         Copyright 2015 - 2016 Lantiq Beteiligungs-GmbH & Co. KG
         Copyright 2012 - 2014 Lantiq Deutschland GmbH

  SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only)

******************************************************************************/

#ifndef _FAPI_GPY_FFU_H_
#define _FAPI_GPY_FFU_H_



#include "os.h"
#include "types.h"


int fapi_gpy_ffu_flash_update (u16 if_id, u16 port, u16 dev, void* phy_fw, unsigned long phy_fwlength);
int fapi_gpy_ffu_upgrade (u16 if_id, u16 port, u16 dev, char *fw_path);
int fapi_gpy_ffu_erase (u16 if_id, u16 port, u16 dev);

#endif /* _FAPI_GPY_FFU_H_ */
