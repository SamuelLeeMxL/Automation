/******************************************************************************

         Copyright 2016 - 2017 Intel Corporation
         Copyright 2015 - 2016 Lantiq Beteiligungs-GmbH & Co. KG
         Copyright 2012 - 2014 Lantiq Deutschland GmbH

  SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only)

******************************************************************************/

#ifndef _API_GPY_H_
#define _API_GPY_H_

/* TO DO, THINK: access to   BRCM Gpio Mdio library
*/
#include "bcm2835.h"
#include "mdio.h"

#if 1 /* TEMPORARY PCTOOL intergration */
int api_gpy_read(void *mdiobus_data, u16 addr, u32 regnum);
int api_gpy_write(void *mdiobus_data, u16 addr, u32 regnum, u16 val);
#endif

void* api_gpy_open (u16 if_id, u16 port, u16 dev);
void api_gpy_close (u16 if_id, u16 port, u16 dev);

u8 api_gpy_if_clk_pin (u16 if_id);
u8 api_gpy_if_data_pin (u16 if_id);


#endif /* _API_GPY_H_ */
