/******************************************************************************

  Copyright (c) 2014 Lantiq Deutschland GmbH
  Copyright 2016, Intel Corporation.

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

******************************************************************************/

/**
   \file cmds_fapi.c
    Implements CLI commands for FAPI
        - fapi_mdio
        - fapi_ffu
*/
#include "os_linux.h"

#include "cmds.h"
#include "cmds_fapi.h"

#include "fapi_gpy_ffu.h"
#include "fapi_mdio.h"


/* ========================================================================== */
/*                           Function prototypes                              */
/* ========================================================================== */
static void cmds_fapi_help (void);




OS_boolean_t cmds_fapi (CmdArgs_t* pArgs, int *err)
{
    OS_boolean_t  api_executed; 
    int ret;
 
    if (pArgs == NULL)
    {
        *err = OS_ERROR;
        return OS_TRUE; 
    }

    ret = OS_SUCCESS;        
    api_executed = OS_TRUE;
   
   /******************************************
   *  FAPI CLI cmds                          *
   ******************************************/   
      
   if ((strcmp(pArgs->name, "cmds-fapi-help")  == 0 ) || (strcmp(pArgs->name, "cmds-fapi-?")  == 0))
   {
     cmds_fapi_help ();
   }


   /*****************************************
    * FAPI_FFU:                             *
    *   - fapi-ffu-erase                    *
    *   - fapi-ffu-upgrade                  *
    *   - fapi-ffu-version                  *
    * ***************************************/
   else if (strcmp(pArgs->name, "fapi-ffu-upgrade") == 0)
   {
      u16 ifid;
      u16 port;
      char *fw_path;

      int val;

      if (pArgs->prmc < 3)
      { 
         printf ("  Usage: fapi-ffu-update ifid addr fw_path\n");
         printf ("   ifid: Interface Id\n");
         printf ("   addr: PHY address\n");
         printf ("fw_path: FW file path\n");
         printf ("(hexadecimal value prefixed with 0x)\n");
        goto goto_end_help;
      }

      ifid    = pArgs->prmvi [0];
      port    = pArgs->prmvi [1];
      fw_path = pArgs->prmvs [2];

	  printf("FFU upgrade: port = %d file = %s\n", port, fw_path);
      ret = fapi_gpy_ffu_upgrade (ifid, port, 0,  fw_path);

	  printf(ret == 0 ? "FFU upgrade successful\n" : "FFU update failed");
   }

   else if (strcmp(pArgs->name, "fapi-ffu-erase") == 0)
   {
      u16 ifid;
      u16 port;

      if (pArgs->prmc < 2)
      { 
         printf ("  Usage: fapi-ffu-erase ifid addr\n");
         printf ("   ifid: Interface Id\n");
         printf ("   addr: PHY address\n");
         printf ("   (hexadecimal value prefixed with 0x)\n");
         goto goto_end_help;
      }

      ifid    = pArgs->prmvi [0];
      port    = pArgs->prmvi  [1];

      ret = fapi_gpy_ffu_erase (ifid, port, 0);

	  printf(ret == 0 ? "FFU erase successful\n" : "FFU erase failed");
    }



   /*****************************************
    * FAPI_MDIO:                            *
    *   - fapi-mdio-c45-read                *
    *   - fapi-mdio-c45-write               *
    *   - fapi-mdio-c22-read                *
    *   - fapi-mdio-c22-write               *
    * ***************************************/
   else if (strcmp(pArgs->name, "fapi-mdio-c45-read") == 0)
   {
      u16	if_id;           /* phy Interface id */
      u16   port;            /* phy port addr */
      u16   dev;             /* phy dev addr */
	  u16 	reg;             /* phy register*/

      if (pArgs->prmc < 4)
      { 
         printf ("  Usage: fapi-mdio-c45-read ifid port dev reg\n");
         printf ("   ifid: Interface Id\n");
         printf ("   port: PHY port address\n");
         printf ("    dev: PHY device address\n");
         printf ("    reg: PHY register to read\n");
         printf ("   (hexadecimal value prefixed with 0x)\n");
         goto goto_end_help;
      }

      if_id   = pArgs->prmvi [0];
      port    = pArgs->prmvi [1];
      dev     = pArgs->prmvi [2];
      reg     = pArgs->prmvi [3];

      ret = fapi_mdio_c45_read (if_id, port, dev,  reg);

      printf (" read: port=%d device=%d reg=0x%x value=0x%x\n", port, dev, reg, ret);
   }

   else if (strcmp(pArgs->name, "fapi-mdio-c45-write") == 0)
   {
      u16	if_id;           /* phy Interface id */
      u16   port;            /* phy port addr */
      u16   dev;             /* phy dev addr */
	  u16 	reg;             /* phy register*/
	  u16 	value;           /* value to write*/

      if (pArgs->prmc < 5)
      { 
         printf ("  Usage: fapi-mdio-c45-write ifid port dev reg value\n");
         printf ("   ifid: Interface Id\n");
         printf ("   port: PHY port address\n");
         printf ("    dev: PHY device address\n");
         printf ("    reg: PHY register to write\n");
         printf ("  value: value to write\n");
         printf ("  (hexadecimal value prefixed with 0x)\n");
         goto goto_end_help;
      }

      if_id   = pArgs->prmvi [0];
      port    = pArgs->prmvi [1];
      dev     = pArgs->prmvi [2];
      reg     = pArgs->prmvi [3];
      value   = pArgs->prmvi [4];

      ret = fapi_mdio_c45_write (if_id, port, dev,  reg, value);

      printf (" write: port=%d device=%d reg=0x%x value=0x%x ret = %d\n", port, dev, reg, value, ret);
   }

   /* C22 */ 
   else if (strcmp(pArgs->name, "fapi-mdio-c22-read") == 0)
   {
      u16	if_id;           /* phy Interface id */
      u16   port;            /* phy port addr */
	  u16 	reg;             /* phy register*/

      if (pArgs->prmc < 3)
      { 
         printf ("  Usage: fapi-mdio-c22-read ifid port reg\n");
         printf ("   ifid: Interface Id\n");
         printf ("   port: PHY port address\n");
         printf ("    reg: PHY register to read\n");
         printf ("  (hexadecimal value prefixed with 0x)\n");
         goto goto_end_help;
      }

      if_id   = pArgs->prmvi [0];
      port    = pArgs->prmvi [1];
      reg     = pArgs->prmvi [2];

      ret = fapi_mdio_c22_read (if_id, port, reg);

      printf (" read: port=%d reg=0x%x value=0x%x\n", port, reg, ret);
   }

   else if (strcmp(pArgs->name, "fapi-mdio-c22-write") == 0)
   {
      u16	if_id;           /* phy Interface id */
      u16   port;            /* phy port addr */
	  u16 	reg;             /* phy register*/
	  u16 	value;           /* value to write*/

      if (pArgs->prmc < 4)
      { 
         printf ("  Usage: fapi-mdio-c22-write ifid port dev reg value\n");
         printf ("   ifid: Interface Id\n");
         printf ("   port: PHY port address\n");
         printf ("    reg: PHY register to read\n");
         printf ("  value: value to write\n");
         printf ("  (hexadecimal value prefixed with 0x)\n");
         goto goto_end_help;
      }

      if_id   = pArgs->prmvi [0];
      port    = pArgs->prmvi [1];
      reg     = pArgs->prmvi [2];
      value   = pArgs->prmvi [3];

      ret = fapi_mdio_c22_write (if_id, port, reg, value);

      printf (" write: port=%d reg=0x%x value=0x%x ret = %d\n", port, reg, value, ret);
   }



   /***************
   *  No command  *
   ***************/
   else 
   {
      api_executed = OS_FALSE;
   }

goto_end_help:
   *err = ret;
   return api_executed;   
}


int cmds_fapi_symlink_set (void)
{  
   os_system ("ln -sf ./ethswbox fapi-ffu-erase");    
   os_system ("ln -sf ./ethswbox fapi-ffu-upgrade");

   os_system ("ln -sf ./ethswbox fapi-mdio-c45-read");
   os_system ("ln -sf ./ethswbox fapi-mdio-c45-write");

   os_system ("ln -sf ./ethswbox fapi-mdio-c22-read");
   os_system ("ln -sf ./ethswbox fapi-mdio-c22-write");

   return OS_SUCCESS;
}


static void cmds_fapi_help (void)
{
   printf ("+------------------------------------------------------------------+\n");
   printf ("|                           HELP !                                 |\n");
   printf ("|                        CMDS - FAPI                               |\n");
   printf ("|                                                                  |\n");
   printf ("+------------------------------------------------------------------+\n");
   printf ("|                                                                  |\n");
   printf ("+------------------------------------------------------------------+\n");
   printf ("\n");
}
