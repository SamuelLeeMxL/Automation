/****************************************************************************

                               Copyright 2010
                          Lantiq Deutschland GmbH
                   Am Campeon 3; 85579 Neubiberg, Germany

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

*****************************************************************************/
#ifndef _CMD_DECLARE_H
#define _CMD_DECLARE_H
int ifx_ethsw_8021x_eapol_rule_set(int, int, char **);
int ifx_ethsw_8021x_port_cfg_set(int, int, char **);
int ifx_ethsw_cfg_set(int, int, char **);
int ifx_ethsw_cpu_port_cfg_set(int, int, char **);
int ifx_ethsw_cpu_port_extend_cfg_set(int, int, char **);
int ifx_ethsw_disable(int, int, char **);
int ifx_ethsw_enable(int, int, char **);
int ifx_ethsw_hw_init(int, int, char **);
int ifx_ethsw_mac_table_clear(int, int, char **);
int ifx_ethsw_mac_table_entry_add(int, int, char **);
int ifx_ethsw_mac_table_entry_remove(int, int, char **);
int ifx_ethsw_mdio_cfg_set(int, int, char **);
int ifx_ethsw_mdio_data_write(int, int, char **);
int ifx_ethsw_mmd_data_write(int, int, char **);
int ifx_ethsw_monitor_port_cfg_set(int, int, char **);
int ifx_ethsw_multicast_router_port_add(int, int, char **);
int ifx_ethsw_multicast_router_port_remove(int, int, char **);
int ifx_ethsw_multicast_snoop_cfg_set(int, int, char **);
int ifx_ethsw_multicast_table_entry_add(int, int, char **);
int ifx_ethsw_port_cfg_set(int, int, char **);
int ifx_ethsw_port_link_cfg_set(int, int, char **);
int ifx_ethsw_port_redirect_set(int, int, char **);
int ifx_ethsw_port_rgmii_clk_cfg_set(int, int, char **);
int ifx_ethsw_qos_class_dscp_set(int, int, char **);
int ifx_ethsw_qos_dscp_class_set(int, int, char **);
int ifx_ethsw_qos_dscp_drop_precedence_cfg_set(int, int, char **);
int ifx_ethsw_qos_meter_cfg_set(int, int, char **);
int ifx_ethsw_qos_meter_port_assign(int, int, char **);
int ifx_ethsw_qos_meter_port_deassign(int, int, char **);
int ifx_ethsw_qos_pcp_class_set(int, int, char **);
int ifx_ethsw_qos_port_cfg_set(int, int, char **);
int ifx_ethsw_qos_port_remarking_cfg_set(int, int, char **);
int ifx_ethsw_qos_queue_port_set(int, int, char **);
int ifx_ethsw_qos_scheduler_cfg_set(int, int, char **);
int ifx_ethsw_qos_shaper_cfg_set(int, int, char **);
int ifx_ethsw_qos_shaper_queue_assign(int, int, char **);
int ifx_ethsw_qos_shaper_queue_deassign(int, int, char **);
int ifx_ethsw_qos_storm_cfg_set(int, int, char **);
int ifx_ethsw_qos_wred_cfg_set(int, int, char **);
int ifx_ethsw_qos_wred_queue_cfg_set(int, int, char **);
int ifx_ethsw_rmon_clear(int, int, char **);
int ifx_ethsw_stp_bpdu_rule_set(int, int, char **);
int ifx_ethsw_stp_port_cfg_set(int, int, char **);
int ifx_ethsw_vlan_id_create(int, int, char **);
int ifx_ethsw_vlan_id_delete(int, int, char **);
int ifx_ethsw_vlan_port_cfg_set(int, int, char **);
int ifx_ethsw_vlan_port_member_add(int, int, char **);
int ifx_ethsw_vlan_port_member_remove(int, int, char **);
int ifx_ethsw_vlan_reserved_add(int, int, char **);
int ifx_ethsw_vlan_reserved_remove(int, int, char **);
int ifx_ethsw_wol_cfg_set(int, int, char **);
int ifx_ethsw_wol_port_cfg_set(int, int, char **);
int ifx_flow_irq_mask_set(int, int, char **);
int ifx_flow_irq_status_clear(int, int, char **);
int ifx_flow_pce_rule_delete(int, int, char **);
int ifx_flow_pce_rule_write(int, int, char **);
int ifx_flow_register_set(int, int, char **);
int ifx_flow_reset(int, int, char **);
int ifx_psb6970_power_management_set(int, int, char **);
int ifx_psb6970_qos_mfc_add(int, int, char **);
int ifx_psb6970_qos_mfc_del(int, int, char **);
int ifx_psb6970_qos_mfc_port_cfg_set(int, int, char **);
int ifx_psb6970_qos_port_policer_set(int, int, char **);
int ifx_psb6970_qos_port_shaper_cfg_set(int, int, char **);
int ifx_psb6970_qos_port_shaper_strict_set(int, int, char **);
int ifx_psb6970_qos_port_shaper_wfq_set(int, int, char **);
int ifx_psb6970_qos_storm_set(int, int, char **);
int ifx_psb6970_register_set(int, int, char **);
int ifx_psb6970_reset(int, int, char **);
int ifx_ethsw_8021x_eapol_rule_get(int, int, char **);
int ifx_ethsw_8021x_port_cfg_get(int, int, char **);
int ifx_ethsw_cap_get(int, int, char **);
int ifx_ethsw_cfg_get(int, int, char **);
int ifx_ethsw_cpu_port_cfg_get(int, int, char **);
int ifx_ethsw_cpu_port_extend_cfg_get(int, int, char **);
int ifx_ethsw_mac_table_entry_query(int, int, char **);
int ifx_ethsw_mac_table_entry_read(int, int, char **);
int ifx_ethsw_mdio_cfg_get(int, int, char **);
int ifx_ethsw_mdio_data_read(int, int, char **);
int ifx_ethsw_mmd_data_read(int, int, char **);
int ifx_ethsw_monitor_port_cfg_get(int, int, char **);
int ifx_ethsw_multicast_router_port_read(int, int, char **);
int ifx_ethsw_multicast_snoop_cfg_get(int, int, char **);
int ifx_ethsw_multicast_table_entry_read(int, int, char **);
int ifx_ethsw_multicast_table_entry_remove(int, int, char **);
int ifx_ethsw_port_cfg_get(int, int, char **);
int ifx_ethsw_port_link_cfg_get(int, int, char **);
int ifx_ethsw_port_phy_addr_get(int, int, char **);
int ifx_ethsw_port_phy_query(int, int, char **);
int ifx_ethsw_port_redirect_get(int, int, char **);
int ifx_ethsw_port_rgmii_clk_cfg_get(int, int, char **);
int ifx_ethsw_qos_class_dscp_get(int, int, char **);
int ifx_ethsw_qos_class_pcp_get(int, int, char **);
int ifx_ethsw_qos_class_pcp_set(int, int, char **);
int ifx_ethsw_qos_dscp_class_get(int, int, char **);
int ifx_ethsw_qos_dscp_drop_precedence_cfg_get(int, int, char **);
int ifx_ethsw_qos_meter_cfg_get(int, int, char **);
int ifx_ethsw_qos_meter_port_get(int, int, char **);
int ifx_ethsw_qos_pcp_class_get(int, int, char **);
int ifx_ethsw_qos_port_cfg_get(int, int, char **);
int ifx_ethsw_qos_port_remarking_cfg_get(int, int, char **);
int ifx_ethsw_qos_queue_port_get(int, int, char **);
int ifx_ethsw_qos_scheduler_cfg_get(int, int, char **);
int ifx_ethsw_qos_shaper_cfg_get(int, int, char **);
int ifx_ethsw_qos_shaper_queue_get(int, int, char **);
int ifx_ethsw_qos_storm_cfg_get(int, int, char **);
int ifx_ethsw_qos_wred_cfg_get(int, int, char **);
int ifx_ethsw_qos_wred_queue_cfg_get(int, int, char **);
int ifx_ethsw_rmon_get(int, int, char **);
int ifx_ethsw_stp_bpdu_rule_get(int, int, char **);
int ifx_ethsw_stp_port_cfg_get(int, int, char **);
int ifx_ethsw_version_get(int, int, char **);
int ifx_ethsw_vlan_id_get(int, int, char **);
int ifx_ethsw_vlan_port_cfg_get(int, int, char **);
int ifx_ethsw_vlan_port_member_read(int, int, char **);
int ifx_ethsw_wol_cfg_get(int, int, char **);
int ifx_ethsw_wol_port_cfg_get(int, int, char **);
int ifx_flow_irq_get(int, int, char **);
int ifx_flow_irq_mask_get(int, int, char **);
int ifx_flow_pce_rule_read(int, int, char **);
int ifx_flow_register_get(int, int, char **);
int ifx_flow_rmon_extend_get(int, int, char **);
int ifx_psb6970_power_management_get(int, int, char **);
int ifx_psb6970_qos_mfc_entry_read(int, int, char **);
int ifx_psb6970_qos_mfc_port_cfg_get(int, int, char **);
int ifx_psb6970_qos_port_policer_get(int, int, char **);
int ifx_psb6970_qos_port_shaper_cfg_get(int, int, char **);
int ifx_psb6970_qos_port_shaper_strict_get(int, int, char **);
int ifx_psb6970_qos_port_shaper_wfq_get(int, int, char **);
int ifx_psb6970_qos_storm_get(int, int, char **);
int ifx_psb6970_register_get(int, int, char **);

int ifx_flow_timestamp_timer_get(int, int, char **);
int ifx_flow_timestamp_timer_set(int, int, char **);

int ifx_flow_timestamp_port_read(int, int, char **);
int ifx_ethsw_trunking_cfg_set(int, int, char **);
int ifx_ethsw_trunking_cfg_get(int, int, char **);
int ifx_ethsw_trunking_port_cfg_set(int, int, char **);
int ifx_ethsw_trunking_port_cfg_get(int, int, char **);
int ifx_ethsw_qos_wred_port_cfg_set(int, int, char **);
int ifx_ethsw_qos_wred_port_cfg_get(int, int, char **);
int ifx_ethsw_qos_flowctrl_cfg_set(int, int, char **);
int ifx_ethsw_qos_flowctrl_cfg_get(int, int, char **);
int ifx_ethsw_qos_flowctrl_port_cfg_set(int, int, char **);
int ifx_ethsw_qos_flowctrl_port_cfg_get(int, int, char **);
int ifx_ethsw_qos_queue_buffer_reserve_cfg_set(int, int, char **);
int ifx_ethsw_qos_queue_buffer_reserve_cfg_get(int, int, char **);
#ifdef SWAPI_ETC_CHIP 
int ifx_ethsw_svlan_cfg_set(int argc, char *argv[], int fd, int numPar);
int ifx_ethsw_svlan_cfg_get(int argc, char *argv[], int fd, int numPar);
int ifx_ethsw_svlan_port_cfg_set(int argc, char *argv[], int fd, int numPar);
int ifx_ethsw_svlan_port_cfg_get(int argc, char *argv[], int fd, int numPar);
int ifx_ethsw_qos_svlan_class_pcp_port_set(int argc, char *argv[], int fd, int numPar);
int ifx_ethsw_qos_svlan_class_pcp_port_get(int argc, char *argv[], int fd, int numPar);
int ifx_ethsw_qos_svlan_pcp_class_set(int argc, char *argv[], int fd, int numPar);
int ifx_ethsw_qos_svlan_pcp_class_get(int argc, char *argv[], int fd, int numPar);
#endif /* SWAPI_ETC_CHIP */
#endif /* _CMD_DECLARE_H*/
