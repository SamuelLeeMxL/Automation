/******************************************************************************

    Copyright 2021 Maxlinear

    SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only)

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.
******************************************************************************/

/**
   \file fapi_gpy_ffu.c
   This file implements the PHY FFU feature (upgrade, erase, version, ...) using GPYAPI services. 

*/

/* ============================= */
/* Includes                      */
/* ============================= */

/* Access to GPYAPI driver  */
#include "os_linux.h"
#include "conf_if.h" 
#include "fapi_mdio.h"
#include "api_gpy.h"

 

/**
    Implements MDIO Register Read function Clause 45


   \param
      u16	if_id           phy Interface id
      u16   port            phy port addr        
      u16   dev             phy dev addr        
	  u16 	reg             phy register

   \return
    >=0:  register value
    -1:   access error
    -2:   parameter error
*/

s32 fapi_mdio_c45_read (u16 if_id, u16 port, u16 dev, u16 reg)
{
    u16 val = 0;
    void* p_gpydev;
    u8 clk_pin;
    u8 data_pin;
    
    if ((port > 31) || (dev > 31) || (reg > 65535))
    {
        return -2;
    }


	/* open gpy api */
	p_gpydev = api_gpy_open (if_id, port, dev);
	if (p_gpydev == NULL)
		return -1; 

    clk_pin = api_gpy_if_clk_pin(if_id);
    data_pin = api_gpy_if_data_pin(if_id);

	val =  mdio_c45_read (clk_pin, data_pin, port, dev, reg);

	/* close gpy api */
    api_gpy_close (if_id, port, dev);

	return val;
}



/**
    Implements MDIO Register Write function Clause 45


   \param
      u16	if_id           phy Interface id
      u16   port            phy port addr        
      u16   dev             phy dev addr        
	  u16 	reg             phy register
	  u16 	val             phy value to write

   \return
    >=0:  register value
    -1:   access error
    -2:   parameter error
*/

s32 fapi_mdio_c45_write (u16 if_id, u16 port, u16 dev, u16 reg, u16 val)
{
    s32 ret = 0;
    void* p_gpydev;
    u8 clk_pin;
    u8 data_pin;
    
    if ((port > 31) || (dev > 31) || (reg > 65535))
    {
        return -2;
    }


	/* open gpy api */
	p_gpydev = api_gpy_open (if_id, port, dev);
	if (p_gpydev == NULL)
		return -1; 

    clk_pin = api_gpy_if_clk_pin(if_id);
    data_pin = api_gpy_if_data_pin(if_id);

	ret =  mdio_c45_write (clk_pin, data_pin, port, dev, reg, val);

	/* close gpy api */
    api_gpy_close (if_id, port, dev);

	return ret;
}








/**
    Implements MDIO Register Read function Clause 22


   \param
      u16	if_id           phy Interface id
      u16   port            phy addr        
	  u16 	reg             phy register

   \return
    >=0:  register value
    -1:   access error
    -2:   parameter error
*/

s32 fapi_mdio_c22_read (u16 if_id, u16 port, u16 reg)
{
    u16 val = 0;
    void* p_gpydev;
    u8 clk_pin;
    u8 data_pin;
    
    if ((port > 31) || (reg > 65535))
    {
        return -2;
    }

	/* open gpy api */
	p_gpydev = api_gpy_open (if_id, port, 0);
	if (p_gpydev == NULL)
		return -1; 

    clk_pin = api_gpy_if_clk_pin(if_id);
    data_pin = api_gpy_if_data_pin(if_id);

	val =  mdio_c22_read (clk_pin, data_pin, port, reg);

	/* close gpy api */
    api_gpy_close (if_id, port, 0);

	return val;
}



/**
    Implements MDIO Register Write function Clause 22


   \param
      u16	if_id           phy Interface id
      u16   port            phy addr        
	  u16 	reg             phy register
	  u16 	val             phy value to write

   \return
    >=0:  register value
    -1:   access error
    -2:   parameter error
*/

s32 fapi_mdio_c22_write (u16 if_id, u16 port,  u16 reg, u16 val)
{
    s32 ret = 0;
    void* p_gpydev;
    u8 clk_pin;
    u8 data_pin;
    
    if ((port > 31) || (reg > 65535))
    {
        return -2;
    }

	/* open gpy api */
	p_gpydev = api_gpy_open (if_id, port, 0);
	if (p_gpydev == NULL)
		return -1; 

    clk_pin = api_gpy_if_clk_pin(if_id);
    data_pin = api_gpy_if_data_pin(if_id);

	ret =  mdio_c22_write (clk_pin, data_pin, port,  reg, val);

	/* close gpy api */
    api_gpy_close (if_id, port, 0);

	return ret;
}
