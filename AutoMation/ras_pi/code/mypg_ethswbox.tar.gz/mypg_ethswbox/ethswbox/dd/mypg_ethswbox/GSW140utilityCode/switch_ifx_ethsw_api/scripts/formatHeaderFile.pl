#!/usr/bin/perl
use Fcntl;
use Getopt::Std;
#use Getopt::Long;

my %options=();

my $help = 0;
my @inputfile = 0;
my $inputfilelen = 0;
my $maximum_type_length = 0;
my $max_ioctl_name_length = 0;

sub PrintHelp {
   print "Usage: $0 <options>\n";
   print "Reformats the header file.\n";
   print "Usage:\n";
   print "   -i <file>     Header input files\n";
   print "   -o <file>     Header output files\n";
   print "   -c            IOCTL command index regeneration\n\n";
   print "   -h            Printout help and exit\n\n";
   exit 0;
}

sub ReadFile {
   sysopen(IN, $options{i}, O_RDONLY) || die "$options{i} could not be opened!\n";

   #copy whole config spec into memory
   while (<IN>) {
      @inputfile[$inputfilelen] = $_;
      $inputfilelen++;
   }
   close (IN);
   #remove empty spaces or tabs at the end of a line. And convert DOS to UNIX mode
   #replace TABS by 3 spaces
   for (my $i = 0; $i < $inputfilelen; $i++) {
      $inputfile[$i] =~ s/\t/\s{3}/g;
      $inputfile[$i] =~ s/\r//g;
      $inputfile[$i] =~ s/\s+\n/\n/g;
   }
}

sub WriteFile {
   sysopen(OUT, $options{o}, O_WRONLY | O_CREAT | O_TRUNC) || die "$options{o} could not be opened or created!\n";

   for ($i = 0; $i < $inputfilelen; $i++) {
      print OUT $inputfile[$i];
   }

   close (OUT);
}

#look for the ioctl defines, adapt spaces and index number
sub designIoctls {
   my $ioctl_idx = 1;
   for (my $i = 0; $i < $inputfilelen; $i++) {
      if ($inputfile[$i] =~ /#define\s+[A-Z_0-9]+\s+_IO/) {
         # if line contains backspace at the end -> merge with next line
         if ($inputfile[$i] =~ /\\/) {
            $inputfile[$i] =~ s/\\//g;
            $inputfile[$i] =~ s/\n//g;

            $inputfile[$i] .= $inputfile[$i + 1];
            $inputfile[$i + 1] = "";
         }

         #ioctl define found, remove tabs and all spaces and ensure the their is a space after the comma
         $inputfile[$i] =~ s/,/, /g;
         $inputfile[$i] =~ s/ +/ /g;
         $inputfile[$i] =~ s/ \(/\(/g;

         my @line = split / /, $inputfile[$i];

         if (defined $options{c}) {
            #generate a new IOCTL index number (following a sequential index incrementation algorithm)
            if (@line > 4) {
               #the ioctl defintion also contain the argument type
               $line[3] = sprintf("0x%02X,", $ioctl_idx);
            } else {
               #the ioctl defintion does not contain the argument type
               $line[3] = sprintf("0x%02X)\n", $ioctl_idx);
            }
         }

         $inputfile[$i] = "";
         foreach my $lineElem (@line) {
            $inputfile[$i] .= "$lineElem ";
         }
         $inputfile[$i] =~ s/\n /\n/;

         $ioctl_idx++;

         #check for the maximum ioctl name length
         if (length($line[1]) > $max_ioctl_name_length) {
            $max_ioctl_name_length = length($line[1]);
         }
      }
   }
}

sub insertIoctlSpaces {
   # insert spaces after ioctl name (define) that all '_IO' start at the same location
   for ($i = 0; $i < $inputfilelen; $i++) {
      if ($inputfile[$i] =~ /#define\s+[A-Z_0-9]+\s+_IO/) {
         my @line = split / /, $inputfile[$i];
         my $num_spaces = $max_ioctl_name_length - length($line[1]);

         if ($num_spaces > 0) {
            $line[1] .= " " foreach (1..$num_spaces);

            $inputfile[$i] = "";
            foreach my $lineElem (@line) {
               $inputfile[$i] .= "$lineElem ";
            }
            $inputfile[$i] =~ s/\n /\n/;
            #$inputfile[$i] = sprintf("%s %s %s %s %s %s", $line[0], $line[1], $insert_spaces, $line[2], $line[3], $line[4]);
         }
      }
   }
}

sub elementParameter {
   my ($run) = @_;
   my $inside_element = 0;
   my $inside_comment = 0;

   for ($i = 0; $i < $inputfilelen; $i++) {
      if ($inputfile[$i] =~ /\/\*/) {
         # beginning of comment found
         $inside_comment = 1;
      }

      if (!$inside_comment) {
         if ($inputfile[$i] =~ /@/) {
            # ignore the doxygen lines
            next;
         }
         elsif ($inputfile[$i] =~ /{/) {
            # structure / enum start found
            $inside_element += 1;
            next;
         }
         elsif ($inputfile[$i] =~ /}/) {
            # structure/enum end found
            $inside_element > 0 or
               die "ERROR: line $i contains closing brackets without opened before!\n";
            $inside_element -= 1;
            #remove the previous line in case that one is empty;
            if (length($inputfile[$i - 1]) < 3) {
               $inputfile[$i - 1] = "";
            }
         }

         if ($inside_element) {
            if (length($inputfile[$i]) > 5) {
               # parameter declaration found
               my $tmp2 = $inputfile[$i];
               $tmp2 =~ s/ +/ /g;

               my @line = split / /, $tmp2;
               my $name_length = length($line[1]);

               if ($run == 0) {
                  #add length for indent spaces (3)
                  $name_length += ($inside_element - 1) * 3;
                  # In the first run: Identify the maximum type length
                  if ($name_length > $maximum_type_length) {
                     $maximum_type_length = $name_length;
                  }
               }
               else {
                  # In the second run: Restructure the line
                  my $inserted_space = $maximum_type_length - $name_length;

                  if (($inserted_space > 0) && (@line > 2)) {
                     #insert leading spaces for all additional substructures
                     #or subunion that are given in the original structure
                     #or union
                     $line[0] = "";
                     $line[0] .= "   " foreach (2..$inside_element);

                     $inserted_space -= ($inside_element - 1) * 3;
                     if ($inserted_space > 0) {
                        $line[1] .= " " foreach (0..$inserted_space);
                     }

                     my $tmp = "  ";
                     foreach my $line2 (@line) {
                        $tmp .= $line2;
                        $tmp .= " ";
                     }
                     $tmp =~ s/\n /\n/g;
                     $inputfile[$i] = $tmp;
                  }
               }
            }
         }
      }

      if ($inside_comment != 0) {
         if ($inputfile[$i] =~ /\*\//) {
            # end of comment found
            $inside_comment = 0;
         }
      }
   }
}

#remove double empty lines
sub removeDoubleEmptyLines {
   my $last_line = -1;
   for ($i = 0; $i < $inputfilelen; $i++) {
      my $local_line = $inputfile[$i];

      $local_line =~ s/\n//g;
      $local_line =~ s/\r//g;

      if (length($local_line) < 1) {
         #empty line
         if ($i == ($last_line + 1)) {
            $inputfile[$i] = "";
         }
         $last_line = $i;
      }
   }
}
############## main ##############

getopts("chi:o:", \%options) or die "invalid option\n";

if (defined $options{h}) {
   die PrintHelp;
}

if (not defined $options{i}) {
   print STDERR "ERROR: No input file given!\n\n";
   die PrintHelp;
}

if (not defined $options{o}) {
   print STDERR "ERROR: No output file name given!\n\n";
   die PrintHelp;
}

ReadFile();
designIoctls();
# identify maximum length for structure and enum elements
elementParameter(0);
#now take the maximum identified value and adapt the file accordingly
elementParameter(1);
insertIoctlSpaces();
removeDoubleEmptyLines();
WriteFile();
