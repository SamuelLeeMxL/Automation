
#define _IOWR(x, y, z) y
#define _IOR(x, y, z) y
#define _IOW(x, y, z) y
#define _IOW_BAD(x, y, z) y

#include "stdio.h"
#include "ifx_types.h"
#include "ifx_ethsw.h"
#include "ifx_ethsw_flow.h"
#include "ifx_ethsw_PSB6970.h"
#include "ltq_linux_ioctl_ll_fkt.h"
#include "ltq_ethsw_flow_ll.h"
#include "ltq_ethsw_tantos_ll.h"

#include "fcts.c"
#include "../src/ltq_flow_core_ll_table.c"
#include "../src/ltq_tantos_core_ll_table.c"

int main(void) {
   int size = 0, i;
   size += sizeof(ifx_ethsw_FLOW_fkt_ptr_tbl);
   printf("ifx_ethsw_FLOW_fkt_ptr_tbl = %d Bytes\n", sizeof(ifx_ethsw_FLOW_fkt_ptr_tbl));
   size += sizeof(ifx_ethsw_FLOW_fkt_tbl);
   printf("ifx_ethsw_FLOW_fkt_tbl = %d Bytes\n", sizeof(ifx_ethsw_FLOW_fkt_tbl));
   size += sizeof(ifx_flow_fkt_ptr_tbl);
   printf("ifx_flow_fkt_ptr_tbl = %d Bytes\n", sizeof(ifx_flow_fkt_ptr_tbl));
   size += sizeof(ifx_flow_fkt_tbl);
   printf("ifx_flow_fkt_tbl = %d Bytes\n", sizeof(ifx_flow_fkt_tbl));
   size += sizeof(ifx_ethsw_PSB6970_fkt_ptr_tbl);
   printf("ifx_ethsw_PSB6970_fkt_ptr_tbl = %d Bytes\n", sizeof(ifx_ethsw_PSB6970_fkt_ptr_tbl));
   size += sizeof(ifx_ethsw_PSB6970_fkt_tbl);
   printf("ifx_ethsw_PSB6970_fkt_tbl = %d Bytes\n", sizeof(ifx_ethsw_PSB6970_fkt_tbl));
   size += sizeof(ifx_psb6970_fkt_ptr_tbl);
   printf("ifx_psb6970_fkt_ptr_tbl = %d Bytes\n", sizeof(ifx_psb6970_fkt_ptr_tbl));
   size += sizeof(ifx_psb6970_fkt_tbl);
   printf("ifx_psb6970_fkt_tbl = %d Bytes\n", sizeof(ifx_psb6970_fkt_tbl));
   printf("Summary = %d Bytes\n", size);

   printf("Printout table \"ifx_ethsw_FLOW_fkt_ptr_tbl\"\n");
   for (i = 0; i < sizeof(ifx_ethsw_FLOW_fkt_ptr_tbl)/sizeof(IFX_ll_fkt); i++) {
      printf("%d: 0x%08X\n", i, ifx_ethsw_FLOW_fkt_ptr_tbl[i]);
   }

   printf("\nPrintout table \"ifx_flow_fkt_ptr_tbl\"\n");
   for (i = 0; i < sizeof(ifx_flow_fkt_ptr_tbl)/sizeof(IFX_ll_fkt); i++) {
      printf("%d: 0x%08X\n", i, ifx_flow_fkt_ptr_tbl[i]);
   }

   printf("Printout table \"ifx_ethsw_PSB6970_fkt_ptr_tbl\"\n");
   for (i = 0; i < sizeof(ifx_ethsw_PSB6970_fkt_ptr_tbl)/sizeof(IFX_ll_fkt); i++) {
      printf("%d: 0x%08X\n", i, ifx_ethsw_PSB6970_fkt_ptr_tbl[i]);
   }

   printf("\nPrintout table \"ifx_psb6970_fkt_ptr_tbl\"\n");
   for (i = 0; i < sizeof(ifx_psb6970_fkt_ptr_tbl)/sizeof(IFX_ll_fkt); i++) {
      printf("%d: 0x%08X\n", i, ifx_psb6970_fkt_ptr_tbl[i]);
   }

   printf("IFX_ETHSW_MAGIC 0x%02X\n", IFX_ETHSW_MAGIC);
   printf("IFX_FLOW_MAGIC 0x%02X\n", IFX_FLOW_MAGIC);
   printf("IFX_PSB6970_MAGIC 0x%02X\n", IFX_PSB6970_MAGIC);
   printf("IFX_ETHSW_lowLevelFkts_t = %d Bytes\n", sizeof(IFX_ETHSW_lowLevelFkts_t));

   return 0;
}
