/****************************************************************************

                               Copyright 2010
                          Lantiq Deutschland GmbH
                   Am Campeon 3; 85579 Neubiberg, Germany

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

*****************************************************************************/
#ifndef _SWITCH_CLI_CONFIG_H
#define _SWITCH_CLI_CONFIG_H 

/* EMILIO: missing file.
I created it
*/

#define PACKAGE_STRING "emilio_switch_package_string"

#endif /* _SWITCH_CLI_CONFIG_H */
