/******************************************************************************

         Copyright 2016 - 2017 Intel Corporation
         Copyright 2015 - 2016 Lantiq Beteiligungs-GmbH & Co. KG
         Copyright 2012 - 2014 Lantiq Deutschland GmbH

  SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only)

******************************************************************************/

#ifndef __GPY211_VER_H__
#define __GPY211_VER_H__

#define DRV_MAJOR	2
#define DRV_MINOR	6
#define DRV_RELEASE	1	/* 0 - test version, 1 - release version */

#endif /* __GPY211_VER_H__ */

