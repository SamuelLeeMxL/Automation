#ifndef _PLM_MDIO_H
#define _PLM_MDIO_H
/******************************************************************************

  Copyright (c) 2014 Lantiq Deutschland GmbH
  Copyright 2016, Intel Corporation.

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

******************************************************************************/
/**
   \file plm_mdio.h
   
*/

#ifdef __cplusplus
   extern "C" {
#endif


#include "os.h"
#include "types.h"


int plm_mdio_open (u16 if_id);
int plm_mdio_close (u16 if_id);

s32 plm_mdio_read (u16 if_id, u16 port, u16 reg);
s32 plm_mdio_write (u16 if_id, u16 port, u16 reg, u16 val);

void plm_mdio_trace_on (void);
void plm_mdio_trace_off (void);
u16 plm_mdio_trace_get (void);

#endif /* _PLM_MDIO_H */
