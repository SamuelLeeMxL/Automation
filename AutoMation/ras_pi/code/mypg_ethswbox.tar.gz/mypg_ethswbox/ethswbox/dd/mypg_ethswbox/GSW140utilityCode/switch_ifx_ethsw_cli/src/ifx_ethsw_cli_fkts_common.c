/****************************************************************************

                               Copyright 2010
                          Lantiq Deutschland GmbH
                   Am Campeon 3; 85579 Neubiberg, Germany

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

*****************************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <ctype.h>
//#include "ifx_ethsw.h"
//#include "ifx_ethsw_PSB6970.h"
//#include "ifx_ethsw_flow.h"
#include "ifx_cli_lib.h"

int ifx_ethsw_mac_table_entry_read(int argc, char *argv[], int fd, int numPar)
{
	IFX_ETHSW_MAC_tableRead_t MAC_tableRead;

	printf("-----------------------------------------------------\n");
#ifdef SWAPI_ETC_CHIP
	printf("   MAC Address    | Port  |   Age   |  VID  | FID  | Static\n");
#else
	printf("   MAC Address    | Port  |   Age   | FID  | Static\n");
#endif /* SWAPI_ETC_CHIP */
	printf("-----------------------------------------------------\n");

	memset(&MAC_tableRead, 0x00, sizeof(MAC_tableRead));
	MAC_tableRead.bInitial = LTQ_TRUE;

	for (;;) {
		if (cli_ioctl( fd, IFX_ETHSW_MAC_TABLE_ENTRY_READ, &MAC_tableRead )!= IFX_SUCCESS) {
			return (-2);
		}

		if (MAC_tableRead.bLast == LTQ_TRUE)
			break;

		if (checkValidMAC_Address(MAC_tableRead.nMAC)) {
			if ((MAC_tableRead.nAgeTimer == 0) && (MAC_tableRead.bStaticEntry == LTQ_FALSE)) {
				/* Do nothing */
				continue;
			}
		}

		if (MAC_tableRead.bStaticEntry != LTQ_FALSE) {
			int port;
			for (port = 0; port < (sizeof(MAC_tableRead.nPortId) * 8 - 1); port++) {
				if (((MAC_tableRead.nPortId >> port) & 0x1) == 1) {
					printMAC_Address(MAC_tableRead.nMAC);
#ifdef SWAPI_ETC_CHIP
					printf(" |  %3d  |  %4d   |  %4d  | %3d  |  TRUE\n",port,MAC_tableRead.nAgeTimer,MAC_tableRead.nSVLAN_Id,MAC_tableRead.nFId);
#else
					printf(" |  %3d  |  %4d   | %3d  |  TRUE\n",port,MAC_tableRead.nAgeTimer, MAC_tableRead.nFId);
#endif /* SWAPI_ETC_CHIP */
				}
			}
		} else {
			printMAC_Address(MAC_tableRead.nMAC);
#ifdef SWAPI_ETC_CHIP
			printf(" |  %3d  |  %4d   |  %4d  | %3d  | FALSE\n", MAC_tableRead.nPortId,MAC_tableRead.nAgeTimer,MAC_tableRead.nSVLAN_Id,MAC_tableRead.nFId);
#else
			printf(" |  %3d  |  %4d   | %3d  | FALSE\n", MAC_tableRead.nPortId,MAC_tableRead.nAgeTimer,MAC_tableRead.nFId);
#endif /* SWAPI_ETC_CHIP */
		}
		memset(&MAC_tableRead, 0x00, sizeof(MAC_tableRead));
	}
	printf("-----------------------------------------------------\n");
	return 0;
}

int ifx_ethsw_multicast_router_port_read(int argc, char *argv[], int fd, int numPar)
{
	IFX_ETHSW_multicastRouterRead_t multicastRouterRead;

	memset(&multicastRouterRead, 0x00, sizeof(multicastRouterRead));
	multicastRouterRead.bInitial = LTQ_TRUE;
	for (;;) {
		if (cli_ioctl( fd, IFX_ETHSW_MULTICAST_ROUTER_PORT_READ, &multicastRouterRead )!= IFX_SUCCESS)
			return (-2);
		if (multicastRouterRead.bLast == LTQ_TRUE)
			break;
		printf("\tRouter Port : %d\n", multicastRouterRead.nPortId);
		memset(&multicastRouterRead, 0x00, sizeof(multicastRouterRead));
	}
   return 0;
}

int ifx_ethsw_qos_class_dscp_get(int argc, char *argv[], int fd, int numPar)
{
	IFX_ETHSW_QoS_ClassDSCP_Cfg_t classDSCP_Cfg;
	int i;
	memset(&classDSCP_Cfg, 0x00, sizeof(classDSCP_Cfg));
	if(cli_ioctl(fd, IFX_ETHSW_QOS_CLASS_DSCP_GET, &classDSCP_Cfg) != 0)
		return (-2);
	for (i=0; i<16; i++)
		printf("\tnDSCP[%d] = %d\n", i, classDSCP_Cfg.nDSCP[i]);
	return 0;
}

int ifx_ethsw_qos_class_dscp_set(int argc, char *argv[], int fd, int numPar)
{
   IFX_ETHSW_QoS_ClassDSCP_Cfg_t ClassDSCP_Cfg;
   unsigned int nTrafficClass, cnt;
   unsigned char nDSCP;

   cnt = scanParamArg(argc, argv, "nTrafficClass", 32, &nTrafficClass);
   cnt += scanParamArg(argc, argv, "nDSCP", 8, &nDSCP);

   if (cnt != 2) return (-2);

   if (nTrafficClass >= 16) {
      printf("ERROR: Given \"nTrafficClass\" is out of range (15)\n");
      return (-3);
   }

   memset(&ClassDSCP_Cfg, 0x00, sizeof(ClassDSCP_Cfg));

   if (cli_ioctl(fd, IFX_ETHSW_QOS_CLASS_DSCP_GET, &ClassDSCP_Cfg) != 0)
      return (-4);

   ClassDSCP_Cfg.nDSCP[nTrafficClass] = nDSCP;

   if (cli_ioctl(fd, IFX_ETHSW_QOS_CLASS_DSCP_SET, &ClassDSCP_Cfg) != 0)
      return (-5);

   return 0;
}

int ifx_ethsw_qos_class_pcp_get(int argc, char *argv[], int fd, int numPar)
{
   IFX_ETHSW_QoS_ClassPCP_Cfg_t classPCP_Cfg;
   int i;

   memset(&classPCP_Cfg, 0x00, sizeof(classPCP_Cfg));

   if (cli_ioctl(fd, IFX_ETHSW_QOS_CLASS_PCP_GET, &classPCP_Cfg) != 0)
      return (-2);

   for (i=0; i<16; i++)
      printf("\tnPCP[%d] = %d\n", i, classPCP_Cfg.nPCP[i]);

   return 0;
}

int ifx_ethsw_qos_class_pcp_set(int argc, char *argv[], int fd, int numPar)
{
   IFX_ETHSW_QoS_ClassPCP_Cfg_t classPCP_Cfg;
   unsigned int nTrafficClass, cnt;
   unsigned char nPCP;

   cnt = scanParamArg(argc, argv, "nTrafficClass", 32, &nTrafficClass);
   cnt += scanParamArg(argc, argv, "nPCP", 8, &nPCP);

   if (cnt != 2) return (-2);

   if (nTrafficClass >= 16) {
      printf("ERROR: Given \"nTrafficClass\" is out of range (15)\n");
      return (-3);
   }

   memset(&classPCP_Cfg, 0x00, sizeof(classPCP_Cfg));

   if (cli_ioctl(fd, IFX_ETHSW_QOS_CLASS_PCP_GET, &classPCP_Cfg) != 0)
      return (-4);

   classPCP_Cfg.nPCP[nTrafficClass] = nPCP;

   if (cli_ioctl(fd, IFX_ETHSW_QOS_CLASS_PCP_SET, &classPCP_Cfg) != 0)
      return (-5);

   return 0;
}

int ifx_ethsw_qos_dscp_class_get(int argc, char *argv[], int fd, int numPar)
{
   IFX_ETHSW_QoS_DSCP_ClassCfg_t DSCP_ClassCfg;
   int i;

   memset(&DSCP_ClassCfg, 0x00, sizeof(DSCP_ClassCfg));

   if(cli_ioctl(fd, IFX_ETHSW_QOS_DSCP_CLASS_GET, &DSCP_ClassCfg) != 0)
      return (-2);

   for (i=0; i<64; i++)
      printf("\tnTrafficClass[%d] = %d\n", i, DSCP_ClassCfg.nTrafficClass[i]);

   return 0;
}

int ifx_ethsw_qos_dscp_class_set(int argc, char *argv[], int fd, int numPar)
{
   IFX_ETHSW_QoS_DSCP_ClassCfg_t DSCP_ClassCfg;
   unsigned char nTrafficClass;
   unsigned int nDSCP, cnt;

   cnt = scanParamArg(argc, argv, "nTrafficClass", 8, &nTrafficClass);
   cnt += scanParamArg(argc, argv, "nDSCP", 32, &nDSCP);

   if (cnt != 2) return (-2);

   if (nDSCP >= 64) {
      printf("ERROR: Given \"nDSCP\" is out of range (63)\n");
      return (-3);
   }

   memset(&DSCP_ClassCfg, 0x00, sizeof(DSCP_ClassCfg));

   if (cli_ioctl(fd, IFX_ETHSW_QOS_DSCP_CLASS_GET, &DSCP_ClassCfg) != 0)
      return (-4);

   DSCP_ClassCfg.nTrafficClass[nDSCP] = nTrafficClass;

   if (cli_ioctl(fd, IFX_ETHSW_QOS_DSCP_CLASS_SET, &DSCP_ClassCfg) != 0)
      return (-5);

   return 0;
}

int ifx_ethsw_qos_pcp_class_get(int argc, char *argv[], int fd, int numPar)
{
   IFX_ETHSW_QoS_PCP_ClassCfg_t PCP_ClassCfg;
   int i;

   memset(&PCP_ClassCfg, 0x00, sizeof(PCP_ClassCfg));

   if(cli_ioctl(fd, IFX_ETHSW_QOS_PCP_CLASS_GET, &PCP_ClassCfg) != 0)
      return (-2);

   for (i=0; i<8; i++)
      printf("\tnTrafficClass[%d] = %d\n", i, PCP_ClassCfg.nTrafficClass[i]);

   return 0;
}

int ifx_ethsw_qos_pcp_class_set(int argc, char *argv[], int fd, int numPar)
{
   IFX_ETHSW_QoS_PCP_ClassCfg_t PCP_ClassCfg;
   unsigned char nTrafficClass;
   unsigned int nPCP, cnt;

   cnt = scanParamArg(argc, argv, "nTrafficClass", 8, &nTrafficClass);
   cnt += scanParamArg(argc, argv, "nPCP", 32, &nPCP);

   if (cnt != 2) return (-2);

   if (nPCP >= 8) {
      printf("ERROR: Given \"nPCP\" is out of range (7)\n");
      return (-3);
   }

   memset(&PCP_ClassCfg, 0x00, sizeof(PCP_ClassCfg));

   if (cli_ioctl(fd, IFX_ETHSW_QOS_PCP_CLASS_GET, &PCP_ClassCfg) != 0)
      return (-4);

   PCP_ClassCfg.nTrafficClass[nPCP] = nTrafficClass;

   if (cli_ioctl(fd, IFX_ETHSW_QOS_PCP_CLASS_SET, &PCP_ClassCfg) != 0)
      return (-5);

   return 0;
}

int ifx_ethsw_qos_dscp_drop_precedence_cfg_get(int argc, char *argv[], int fd, int numPar)
{
   IFX_ETHSW_QoS_DSCP_DropPrecedenceCfg_t DropPrecedenceCfg;
   int i;

   memset(&DropPrecedenceCfg, 0x00, sizeof(DropPrecedenceCfg));

   if(cli_ioctl(fd, IFX_ETHSW_QOS_DSCP_DROP_PRECEDENCE_CFG_GET, &DropPrecedenceCfg) != 0)
      return (-2);

   for (i = 0; i < 64; i++) {
      char *ptr;

      switch (DropPrecedenceCfg.nDSCP_DropPrecedence[i]) {
         case IFX_ETHSW_DROP_PRECEDENCE_CRITICAL:
            ptr = "CRITICAL";
            break;
         case IFX_ETHSW_DROP_PRECEDENCE_GREEN:
            ptr = "GREEN";
            break;
         case IFX_ETHSW_DROP_PRECEDENCE_YELLOW:
            ptr = "YELLOW";
            break;
         case IFX_ETHSW_DROP_PRECEDENCE_RED:
            ptr = "RED";
            break;
         default:
            ptr = "UNKNOWN";
            break;
      }
      printf("\tDSCP_DropPrecedence[%d] = %s(%d)\n",
         i, ptr, DropPrecedenceCfg.nDSCP_DropPrecedence[i]);
   }

   return 0;
}

int ifx_ethsw_qos_dscp_drop_precedence_cfg_set(int argc, char *argv[], int fd, int numPar)
{
   IFX_ETHSW_QoS_DSCP_DropPrecedenceCfg_t DropPrecedenceCfg;
   unsigned int nDSCP_DropPrecedence, nDSCP, cnt;

   cnt = scanParamArg(argc, argv, "nDSCP_DropPrecedence", 32, &nDSCP_DropPrecedence);
   cnt += scanParamArg(argc, argv, "nDSCP", 32, &nDSCP);

   if (cnt != 2) return (-2);

   if (nDSCP >= 64) {
      printf("ERROR: Given \"nDSCP\" is out of range (63)\n");
      return (-3);
   }

   memset(&DropPrecedenceCfg, 0x00, sizeof(DropPrecedenceCfg));

   if (cli_ioctl(fd, IFX_ETHSW_QOS_DSCP_DROP_PRECEDENCE_CFG_GET, &DropPrecedenceCfg) != 0)
      return (-4);

   DropPrecedenceCfg.nDSCP_DropPrecedence[nDSCP] = nDSCP_DropPrecedence;

   if (cli_ioctl(fd, IFX_ETHSW_QOS_DSCP_DROP_PRECEDENCE_CFG_SET, &DropPrecedenceCfg) != 0)
      return (-5);

   return 0;
}

int ifx_ethsw_qos_meter_port_get(int argc, char *argv[], int fd, int numPar)
{
   IFX_ETHSW_QoS_meterPortGet_t qos_meterportget;

   memset(&qos_meterportget, 0x00, sizeof(qos_meterportget));
   qos_meterportget.bInitial = LTQ_TRUE;

   for (;;) {
      if (cli_ioctl( fd, IFX_ETHSW_QOS_METER_PORT_GET, &qos_meterportget)!= IFX_SUCCESS) {
         return (-2);
      }
      if (qos_meterportget.bLast != LTQ_FALSE)
         break;

      switch (qos_meterportget.eDir) {
         case IFX_ETHSW_DIRECTION_NONE:
            printf("\tMeter Index = %2d | Direction = None\n", qos_meterportget.nMeterId);
            break;
         case IFX_ETHSW_DIRECTION_INGRESS:
            printf("\tMeter Index = %2d | Direction = Ingress | PortID = %2d\n",
               qos_meterportget.nMeterId, qos_meterportget.nPortIngressId);
            break;
         case IFX_ETHSW_DIRECTION_EGRESS:
            printf("\tMeter Index = %2d | Direction = Egress | PortID = %2d\n",
               qos_meterportget.nMeterId, qos_meterportget.nPortEgressId);
            break;
         case IFX_ETHSW_DIRECTION_BOTH:
            printf("\tMeter Index = %2d | Direction = Both | Ingress PortID = %2d | Egress PortID = %2d\n",
                  qos_meterportget.nMeterId,
                  qos_meterportget.nPortIngressId,
                  qos_meterportget.nPortEgressId);
            break;
      }

      memset(&qos_meterportget, 0x00, sizeof(qos_meterportget));
   }
   return 0;
}

int ifx_ethsw_version_get(int argc, char *argv[], int fd, int numPar)
{
   IFX_ETHSW_version_t version;
   int i;

   for (i = 0;;i++) {
      memset(&version, 0x00, sizeof(version));
      version.nId = (u16)i;

      if(cli_ioctl(fd, IFX_ETHSW_VERSION_GET, &version) != 0)
         return (-2);

      if ((strlen(version.cName) == 0) || (strlen(version.cVersion) == 0))
         break;

      printf("\tVersion ID Name: %s\n", version.cName);
      printf("\tVersion String: %s\n", version.cVersion);
   }

   return 0;
}

int ifx_ethsw_cap_get(int argc, char *argv[], int fd, int numPar)
{
   IFX_ETHSW_cap_t cap;
   IFX_ETHSW_capType_t i;

   for (i = IFX_ETHSW_CAP_TYPE_PORT; i < IFX_ETHSW_CAP_TYPE_LAST; i++) {
      memset(&cap, 0x00, sizeof(cap));
      cap.nCapType = i;
      if(cli_ioctl(fd, IFX_ETHSW_CAP_GET, &cap) != 0)
         return (-2);

      if (cap.nCap != 0) {
         printf("\t%s : %d\n", cap.cDesc, cap.nCap);
      }
   }

   return 0;
}

int ifx_ethsw_cpu_port_extend_cfg_get(int argc, char *argv[], int fd, int numPar)
{
   IFX_ETHSW_CPU_PortExtendCfg_t CPU_PortExtendCfg;
   char *peHeaderAdd;

   memset(&CPU_PortExtendCfg, 0x00, sizeof(CPU_PortExtendCfg));

   if(cli_ioctl(fd, IFX_ETHSW_CPU_PORT_EXTEND_CFG_GET, &CPU_PortExtendCfg) != 0)
      return (-2);

   switch (CPU_PortExtendCfg.eHeaderAdd) {
      case IFX_ETHSW_CPU_HEADER_NO:
         peHeaderAdd = "Add No Header";
         break;
      case IFX_ETHSW_CPU_HEADER_MAC:
         peHeaderAdd = "Add Ethernet Header";
         break;
      case IFX_ETHSW_CPU_HEADER_VLAN:
         peHeaderAdd = "Add Ethernet & VLAN Header";
         break;
      default:
         peHeaderAdd = "UNKOWN";
         break;
   }

   printf("eHeaderAdd : %s\n", peHeaderAdd);
   printf("bHeaderRemove : %s\n", (CPU_PortExtendCfg.bHeaderRemove > 0)?"TRUE":"FALSE");

   if (CPU_PortExtendCfg.eHeaderAdd != IFX_ETHSW_CPU_HEADER_NO) {
      printf("sHeader.nMAC_Src : ");
      printMAC_Address(CPU_PortExtendCfg.sHeader.nMAC_Src);
      printf("\nsHeader.nMAC_Dst : ");
      printMAC_Address(CPU_PortExtendCfg.sHeader.nMAC_Dst);
      printf("\nsHeader.nEthertype : %04X\n", CPU_PortExtendCfg.sHeader.nEthertype);
   }
   if (CPU_PortExtendCfg.eHeaderAdd == IFX_ETHSW_CPU_HEADER_VLAN) {
      printf("sHeader.nVLAN_Prio : %d\n", CPU_PortExtendCfg.sHeader.nVLAN_Prio);
      printf("sHeader.nVLAN_CFI : %d\n", CPU_PortExtendCfg.sHeader.nVLAN_CFI);
      printf("sHeader.nVLAN_ID : %d\n", CPU_PortExtendCfg.sHeader.nVLAN_ID);
   }

   printf("ePauseCtrl : %s\n",
      (CPU_PortExtendCfg.ePauseCtrl == IFX_ETHSW_CPU_PAUSE_DISPATCH)? "DISPATCH":"FORWARD");

   printf("bFcsRemove : %s\n", (CPU_PortExtendCfg.bFcsRemove > 0)?"TRUE":"FALSE");
   printf("nWAN_Ports : 0x%08X\n", CPU_PortExtendCfg.nWAN_Ports);

   return 0;
}

int ifx_ethsw_cpu_port_extend_cfg_set(int argc, char *argv[], int fd, int numPar)
{
   IFX_ETHSW_CPU_PortExtendCfg_t CPU_PortExtendCfg;
   unsigned int cnt;

   memset(&CPU_PortExtendCfg, 0x00, sizeof(CPU_PortExtendCfg));

   if(cli_ioctl(fd, IFX_ETHSW_CPU_PORT_EXTEND_CFG_GET, &CPU_PortExtendCfg) != 0)
      return (-2);

   cnt = scanParamArg(argc, argv, "eHeaderAdd", 32, &CPU_PortExtendCfg.eHeaderAdd);
   cnt += scanParamArg(argc, argv, "bHeaderRemove", 32, &CPU_PortExtendCfg.bHeaderRemove);
   cnt += scanMAC_Arg(argc, argv, "sHeader.nMAC_Src", CPU_PortExtendCfg.sHeader.nMAC_Src);
   cnt += scanMAC_Arg(argc, argv, "sHeader.nMAC_Dst", CPU_PortExtendCfg.sHeader.nMAC_Dst);
   cnt += scanParamArg(argc, argv, "sHeader.nEthertype", 16, &CPU_PortExtendCfg.sHeader.nEthertype);
   cnt += scanParamArg(argc, argv, "sHeader.nVLAN_Prio", 8, &CPU_PortExtendCfg.sHeader.nVLAN_Prio);
   cnt += scanParamArg(argc, argv, "sHeader.nVLAN_CFI", 8, &CPU_PortExtendCfg.sHeader.nVLAN_CFI);
   cnt += scanParamArg(argc, argv, "sHeader.nVLAN_ID", 16, &CPU_PortExtendCfg.sHeader.nVLAN_ID);
   cnt += scanParamArg(argc, argv, "ePauseCtrl", 32, &CPU_PortExtendCfg.ePauseCtrl);
   cnt += scanParamArg(argc, argv, "bFcsRemove", 32, &CPU_PortExtendCfg.bFcsRemove);
   cnt += scanParamArg(argc, argv, "nWAN_Ports", 32, &CPU_PortExtendCfg.nWAN_Ports);

   if (cnt != numPar) return (-3);

   if(cli_ioctl(fd, IFX_ETHSW_CPU_PORT_EXTEND_CFG_SET, &CPU_PortExtendCfg) != 0)
      return (-4);

   return 0;
}

static int multicastParamRead(int argc, char *argv[], IFX_ETHSW_multicastTable_t *param) {
   int cnt = 0;
   int ipParamCnt1 = 0;
   int ipParamCnt2 = 0;

   memset(param, 0, sizeof(IFX_ETHSW_multicastTable_t));

   cnt += scanParamArg(argc, argv, "nPortId", 8, &param->nPortId);
   cnt += scanParamArg(argc, argv, "eIPVersion", 32, &param->eIPVersion);
   cnt += scanParamArg(argc, argv, "eModeMember", 32, &param->eModeMember);

   if (param->eIPVersion == IFX_ETHSW_IP_SELECT_IPV4) {
      ipParamCnt1 = scanIPv4_Arg(argc, argv, "uIP_Gda", &param->uIP_Gda.nIPv4);
      ipParamCnt2 = scanIPv4_Arg(argc, argv, "uIP_Gsa", &param->uIP_Gsa.nIPv4);
   } else {
      ipParamCnt1 = scanIPv6_Arg(argc, argv, "uIP_Gda", param->uIP_Gda.nIPv6);
      ipParamCnt2 = scanIPv6_Arg(argc, argv, "uIP_Gsa", param->uIP_Gsa.nIPv6);
   }

   if ((param->eModeMember != IFX_ETHSW_IGMP_MEMBER_DONT_CARE) &&
      (ipParamCnt1 == 0) && (ipParamCnt2 == 0))
      return (-2);

   if (ipParamCnt1 == 0)
      return (-3);

   return 0;
}

int ifx_ethsw_multicast_table_entry_add(int argc, char *argv[], int fd, int numPar)
{
   IFX_ETHSW_multicastTable_t param;
   int retval;

   retval = multicastParamRead(argc, argv, &param);

   if (retval != 0) return retval;

   if(cli_ioctl(fd, IFX_ETHSW_MULTICAST_TABLE_ENTRY_ADD, &param) != 0)
      return IFX_ERROR;

   return 0;
}

int ifx_ethsw_multicast_table_entry_remove(int argc, char *argv[], int fd, int numPar)
{
   IFX_ETHSW_multicastTable_t param;
   int retval;

   retval = multicastParamRead(argc, argv, &param);

   if (retval != 0) return retval;

   if(cli_ioctl(fd, IFX_ETHSW_MULTICAST_TABLE_ENTRY_REMOVE, &param) != 0)
      return IFX_ERROR;

   return 0;
}

static void dump_multicast_table_entry(IFX_ETHSW_multicastTableRead_t *ptr)
{
	if (ptr->eIPVersion == IFX_ETHSW_IP_SELECT_IPV4) {
		printf("%24s", "");
		printIPv4_Address(ptr->uIP_Gda.nIPv4);
	} else
		printIPv6_Address(ptr->uIP_Gda.nIPv6);

	if (ptr->eModeMember != IFX_ETHSW_IGMP_MEMBER_DONT_CARE) {
		printf(" | ");
		if (ptr->eIPVersion == IFX_ETHSW_IP_SELECT_IPV4) {
			printf("%24s", "");
			printIPv4_Address(ptr->uIP_Gsa.nIPv4);
		} else
			printIPv6_Address(ptr->uIP_Gsa.nIPv6);

		printf(" | %s\n", (ptr->eModeMember ==IFX_ETHSW_IGMP_MEMBER_INCLUDE)? "INCLUDE":"EXCLUDE");
	} else
		printf("\n");
}

int ifx_ethsw_multicast_table_entry_read(int argc, char *argv[], int fd, int numPar)
{
   IFX_ETHSW_multicastTableRead_t multicastTableRead;

   printf("-------------------------------------------------------------------------------------------------------\n");
   printf(" Port |                                     GDA |                                     GSA | Member Mode\n");
   printf("-------------------------------------------------------------------------------------------------------\n");

   memset(&multicastTableRead, 0x00, sizeof(multicastTableRead));
   multicastTableRead.bInitial = LTQ_TRUE;

   for (;;) {
      if (cli_ioctl( fd, IFX_ETHSW_MULTICAST_TABLE_ENTRY_READ, &multicastTableRead )!= IFX_SUCCESS) {
         return (-2);
      }

      if (multicastTableRead.bLast == LTQ_TRUE)
         break;


		if (multicastTableRead.nPortId & IFX_ETHSW_PORTMAP_FLAG_GET(IFX_ETHSW_multicastTableRead_t)) {

			unsigned int i = 0, mask = 1;
			while (mask != IFX_ETHSW_PORTMAP_FLAG_GET(IFX_ETHSW_multicastTableRead_t)) {
				if (mask & multicastTableRead.nPortId) {
					printf("  %2d  | ", i);
					dump_multicast_table_entry(&multicastTableRead);
				}
	
				i++;
				mask = 1 << i;
			}
		} else {
			printf("  %2d  | ", multicastTableRead.nPortId);
			dump_multicast_table_entry(&multicastTableRead);
		}

		memset(&multicastTableRead, 0x00, sizeof(multicastTableRead));
   }

   printf("-------------------------------------------------------------------------------------------------------\n");
   return 0;
}

int ifx_ethsw_vlan_port_member_read(int argc, char *argv[], int fd, int numPar)
{
	IFX_ETHSW_VLAN_portMemberRead_t portMemberRead;

	printf("----------------------------\n");
	printf(" VLAN ID | Port | Tag Member\n");
	printf("----------------------------\n");
	memset(&portMemberRead, 0x00, sizeof(portMemberRead));
	portMemberRead.bInitial = LTQ_TRUE;
	for (;;) {
		if (cli_ioctl( fd, IFX_ETHSW_VLAN_PORT_MEMBER_READ, &portMemberRead )!= IFX_SUCCESS) {
			return (-2);
		}
		if (portMemberRead.bLast == LTQ_TRUE)
			break;
      if (portMemberRead.nVId) {
         if (portMemberRead.nPortId & IFX_ETHSW_PORTMAP_FLAG_GET(IFX_ETHSW_VLAN_portMemberRead_t)) {
				unsigned int i = 0, mask = 1;
				while (mask != IFX_ETHSW_PORTMAP_FLAG_GET(IFX_ETHSW_VLAN_portMemberRead_t)) {
					if (mask & portMemberRead.nPortId)
						printf("%8d | %4d | %s\n",
								 portMemberRead.nVId,
								 i ,
								 (portMemberRead.nTagId & mask)?"LTQ_TRUE":"LTQ_FALSE");
					i++;
					mask = 1 << i;
				}
			} else
            printf("%8d | %4d | %s\n", portMemberRead.nVId, portMemberRead.nPortId ,
               (portMemberRead.nTagId)?"LTQ_TRUE":"LTQ_FALSE");
      }
		memset(&portMemberRead, 0x00, sizeof(portMemberRead));
   }
	printf("----------------------------\n");
	return 0;
}

