/****************************************************************************

                               Copyright 2010
                          Lantiq Deutschland GmbH
                   Am Campeon 3; 85579 Neubiberg, Germany

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

*****************************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <ctype.h>
#include "ifx_cli_lib.h"
#include "ifx_ethsw_tbl.h"

 
#include "switch_cli_config.h"
 

static const IFX_ETHSW_CommandTable_t *pCmdTable = NULL;
static int bHelpText = 0;
static int cmdTableIdx = 0;

/* This function prints out a help text about how to use the program */
static int printHelp(char *prgName) {
   int i;
#ifdef SWITCHAPI_HELP_TEXT
   int HelpTextSize = sizeof(IFX_ETHSW_CommandTable_t);
#endif /* SWITCHAPI_HELP_TEXT */

   printf(PACKAGE_STRING "\n");
   printf("Usage: %s <Command> <Arg1> <Arg2> ...\n", prgName);
#ifndef CLI_DUMP_CALL
   printf("Device index parameter: dev=0\n");
#else
   printf("Parameter Dump Version\n");
#endif /* #ifdef CLI_DUMP_CALL */
   printf("Getting command help text: %s <Command> --help\n\n", prgName);
   printf("Supported Commands:\n-------------------\n");
   for (i = 0; ;i++) {
      if (cmdTable[i].Name == NULL)
         break;
      printf("\t%s\n", cmdTable[i].Name);
#ifdef SWITCHAPI_HELP_TEXT
      HelpTextSize += sizeof(IFX_ETHSW_CommandTable_t);
      HelpTextSize += strlen(HelpText[i]);
#endif /* SWITCHAPI_HELP_TEXT */
   }
#ifdef SWITCHAPI_HELP_TEXT
   printf("\n%s contains %d KBytes help text\n\n", prgName, (HelpTextSize >> 10));
#endif /* SWITCHAPI_HELP_TEXT */
   return 0;
}

/* find the command within the programm arguments and return the string to
   the global command table. */
static void findCommandName(int argc, char *argv[]){
   int i, j;
   static char * const prefix = "IFX_ETHSW_";

   /* search for all programm parameter for a command name */
   for (i = 0;i < argc; i++) {
      /* search for all supported commands */
      for (j = 0;; j++) {
         if (cmdTable[j].Name == NULL)
            /* end of table reached. non of the supported commands are found
               in any of the program parameter */
            break;

         if (strcmp(argv[i], cmdTable[j].Name) == 0) {
            pCmdTable = &cmdTable[j];
            cmdTableIdx = j;
            return;
         }

         if (0 == memcmp(cmdTable[j].Name, prefix, strlen(prefix))) {
            if (strcmp(argv[i], cmdTable[j].Name + strlen(prefix)) == 0) {
               pCmdTable = &cmdTable[j];
               cmdTableIdx = j;
               return;
            }
         }
      }
   }
}

/* search all program arguments for a help request. Return unequal zero in case
   a help request is found. Otherwise return zero */
static void findHelpText(int argc, char *argv[]){
   int i;
   /* search for all programm parameter for a command name */
   for (i = 1;i < argc; i++) {
      if (strcmp(argv[i], "help") == 0) {
         bHelpText = 1;
         return;
      }
      if (strcmp(argv[i], "--help") == 0) {
         bHelpText = 1;
         return;
      }
   }
   return;
}

int main(int argc, char *argv[]){
   command_fkt pFkt;
   int ret, fd, cnt;
   int devIdx = 0;
#ifndef CLI_DUMP_CALL
   char buffer[32];
#endif /* #ifndef CLI_DUMP_CALL */

   /* search for a SWITCH API command in the program arguments */
   findCommandName(argc, argv);

   if (pCmdTable == NULL)
      /* command not given, therefore printout help */
      return printHelp(argv[0]);

   /* check if one parameter requests help printout */
   findHelpText(argc, argv);

   /* command given and a help request -> printout help for the given command */
   if (bHelpText == 1) {
#ifdef SWITCHAPI_HELP_TEXT
      /* print out command help */
      printf("Command Description:\n--------------------\n");
      printf("%s", HelpText[cmdTableIdx]);
#ifdef SWITCHAPI_TANTOS_SUPPORT
      printf(
            "\n\nCommon Parameter:\n"
            "-----------------\n"
            "dev:\n"
            "\tDevice selection:\n"
            "\t- \"0\" for \"/dev/switch/0\" (e.g. internal switch subsystem)\n"
            "\t- \"1\" for \"/dev/switch/1\" (e.g. external attached switch device) and so on\n"
            "\tDefault is device \"0\" in case this parameter is not set.\n");
#else
      printf("\n\n");
#endif /* SWITCHAPI_TANTOS_SUPPORT */
#endif /* SWITCHAPI_HELP_TEXT */

#ifdef CLI_DUMP_CALL
      printf("\n!!!Parameter Dump Version!!!\n");
#endif /* #ifdef CLI_DUMP_CALL */
      return 0;
   }

   pFkt = pCmdTable->fkt;

   if (pFkt == NULL) {
      printf("Command not supported (%d)!\n", cmdTableIdx);
      return (-1);
   }

   /* scan for device node index */
   cnt = scanParamArg(argc, argv, "dev", 32, &devIdx);
#ifndef CLI_DUMP_CALL
   sprintf(buffer, "/dev/switch_api/%d", devIdx);
   fd = open(buffer, O_RDONLY);
   if (fd < 0) {
      printf("ERROR: Could not open dev node \"%s\"\n", buffer);
      return (-1);
   }
#else /* #ifndef CLI_DUMP_CALL */
   fd = 0;
#endif /* #ifndef CLI_DUMP_CALL */

   ret = pFkt(argc, argv, fd, argc - (2 + cnt));

#ifndef CLI_DUMP_CALL
   close(fd);
#endif /* #ifndef CLI_DUMP_CALL */

   if (ret !=0) {
      printf("Command returns with error %d\n\n", ret);
#ifdef SWITCHAPI_HELP_TEXT
      printf("Command Description:\n--------------------\n");
      printf("%s\n", HelpText[cmdTableIdx]);
#endif /* SWITCHAPI_HELP_TEXT */
#ifdef CLI_DUMP_CALL
      printf("Parameter Dump Version\n");
#endif /* #ifdef CLI_DUMP_CALL */
   }
   return ret;
}
