#!perl -w

@keyWords = ("BPDU", "EAPOL", "DSCP", "FIB", "GMII", "IP", "IPv4",
   "IPv6", "IGMP", "IGMPv1", "IGMPv2", "MLD", "HW", "LAN", "MAC", "MDIO",
   "MII", "MTU", "LED", "PCP", "PHY", "POTS", "PPPoE", "RMON", "QoS", "STP",
   "SW", "VLAN");

sub readinput {
   my $filename = $_[0];
   my @tmp = ();

   sysopen(IN, $filename, O_RDONLY) || die "$filename could not be opened!\n";

   while(<IN>) {
      s/\n+//g;
      s/\r//g;
      #remove tabs and whitespaces at the end of a line
      s/\ +$//g;
      s/\t+$//g;
      push(@tmp, $_);
   }
   close (IN);
   return @tmp;
}

sub readNPFFile {
   my $filename = $_[0];
   @keyWords = readinput $filename;
}

sub reformat2NPF {
   #print "input0: $_[0] \n";
   #print "input1: $_[1] \n";
   #return $_[0];

   my $moduleName = undef;
   my @lineSplit = split /_/, $_[0];
   $moduleName = uc($lineSplit[1]);
   #replace the module name in case a second parameter is given
   if (length($_[1]) > 0) {
      $moduleName = uc($_[1]);
   }

   #prepare Module prefix
   $lineSplit[1] = $moduleName;
   $lineSplit[2] = lcfirst $lineSplit[2];

   #two tasks have to be done inside the for loop:
   #- ensure that all key words are used correctly
   #- place a '_' between the keyword and the following word 
   #(first character upper case), in case the keyword ends with an 
   #upper case character   
   for (my $i = 2; $i < @lineSplit; $i++) {
      my $lineTag = lc $lineSplit[$i];

      foreach $keyTag (@keyWords) {
         my $tmpTag = lc $keyTag;
         if ($lineTag =~ /$tmpTag/) {
            #tag found
            $lineSplit[$i] =~ s/$tmpTag/$keyTag/i;
            #check if the word behind the keyword starts with an upper case 
            #character. In this case, insert an '_' character in between.
            if ($lineSplit[$i] =~ /$keyTag[A-Z]/) {
               $tmpTag = $keyTag."_";
               $lineSplit[$i] =~ s/$keyTag/$tmpTag/;
            }
         }
      }
   }

   my $line = $lineSplit[0];
   for (my $i = 1; $i < @lineSplit; $i++) {
      if ($lineSplit[$i] eq "t") {
         #normally this single character 't' is the last array index and 
         #specifies that we handle a typedef element. This 't' should stay 
         #unchanged and it is just added with the '_' prefix.
         $line .= "_".$lineSplit[$i];
      } elsif ($line =~ /[A-Z]$/) {
         #last character of the current string has a upper case character, 
         #therefore add the next item by usage of the '_' selector and ensure 
         #that the first following character is upper case as well.
         $line .= "_".$lineSplit[$i];
      } else {
         #last character of the current string has a lower case character, 
         #therefore add the next item without usage of any selector and ensure 
         #that the first following character is upper case as well.
         $line .= ucfirst $lineSplit[$i];
      }
   }
   return $line;
}

sub convert2NPF {
   #print "input0: $_[0] \n";
   #print "input1: $_[1] \n";
   #return $_[0];

   my $moduleName = undef;

   my @lineSplit = split /_/, lc($_[0]);
   $moduleName = uc($lineSplit[1]);
   #replace the module name in case a second parameter is given
   if (length($_[1]) > 0) {
      $moduleName = uc($_[1]);
   }

   #prepare IFX prefix
   $lineSplit[0] =~ s/ifx/IFX_/;
   $lineSplit[1] = $moduleName."_";

   for (my $i = 2; $i < @lineSplit; $i++) {
      my $lineTag = $lineSplit[$i];
      foreach $keyTag (@keyWords) {

         if (uc($lineTag) eq uc($keyTag)) {
            #tag found
            $lineSplit[$i] = $keyTag."_";
            last;
         }
      }
   }

   my $line = "";

   foreach (@lineSplit) {
      if (length($_) > 1) {
         my $ucFirstLine = ucfirst $_;
         $line .= "$ucFirstLine";
      } else {
         $line .= "_"."$_";
      }
   }

   $line =~ s/_+/_/g;
   #print "output: $line\n";
   return $line;
}

1;