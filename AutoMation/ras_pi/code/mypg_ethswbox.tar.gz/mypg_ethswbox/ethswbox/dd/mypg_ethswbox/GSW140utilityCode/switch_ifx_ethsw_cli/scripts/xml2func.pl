#!/usr/bin/perl -w
use Fcntl;
use Getopt::Std;
use XML::Parser;
use apixml;

my %structures = ();
my %structuresTypes = ();
my %structuresArrayNumbers = ();
my %ioctlsWriteParamName = ();
my %ioctlsConditional = ();
my %ioctlsReadParamName = ();
my %ioctlsReadGetParamName = ();
my %ioctlsNotGenerate = ();
my %ioctlWrite2ReadPair = ();
my $header = "/****************************************************************************

                               Copyright 2010
                          Lantiq Deutschland GmbH
                   Am Campeon 3; 85579 Neubiberg, Germany

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

*****************************************************************************/\n";

sub PrintHelp {
   print "Usage: $0 <options>
Generate LL Functions based on input XML file declaration that contains
IOCTL commands.

Usage:
   -i <file>   Main input XML file
   -c <file>   XML input file containing the GET routines with their input
               parameter. Also containing a list of not generated GET
               routines.
   -o <file>   Write output C-file.
   -h <file>   Write output H-file.\n";
   exit 0;
}

################################################################################
# API callback handler to parse the API XML file
my $currentIoctlFktName = "";
my $currentIoctlType = "";
my $currentStructName = "";
my $currentElemName = "";
my $currentElemTypes = "";
my $currentArrayNumbers = "";
my $number = "";

sub ApiXmlTagCallback {
   my ($tag, $data, %attributes) = @_;

   if ($tag =~ /struct\/name/) {$currentStructName = $data; }
   if ($tag =~ /struct\/elem\/name/) {$currentElemName .= "$data ";}
   if ($tag =~ /struct\/elem\/type/) {$currentElemTypes .= "$data ";}
   if ($tag =~ /struct\/elem\/amount/) {$number = $data;}

   if ($tag =~ /ioctl\/name/) {$currentIoctlFktName = $data;}
   if (($tag =~ /ioctl\/arg/) && ($data ne 'IFX_void_t')) { $currentElemName = $data; }
   if ($tag =~ /ioctl\/type/) {$currentIoctlType = $data;}
}

sub ApiXmlTagEndCallback {
   my ($tag) = @_;

   if ($tag =~ /struct$/) {
      $structures{$currentStructName} = $currentElemName;
      $structuresTypes{$currentStructName} = $currentElemTypes;
      $structuresArrayNumbers{$currentStructName} = $currentArrayNumbers;

      #check if the amout of element names and element types are equal
      my @tmpNames = split/\ /, $currentElemName;
      my @tmpTypes = split/\ /, $currentElemTypes;
      my @tmpArrayNumbers = split/\ /, $currentArrayNumbers;

      if (length(@tmpNames) != length(@tmpTypes)) {
         die "ERROR: structure \"$currentStructName\" does not contain equal amount of 'name' and 'type' tags\n";
      }
      if (length(@tmpNames) != length(@tmpArrayNumbers)) {
         die "ERROR: structure \"$currentStructName\" does not contain equal amount of 'name' and 'array' tags\n";
      }
      $currentElemName = "";
      $currentElemTypes = "";
      $currentArrayNumbers = "";
   }

   if ($tag =~ /struct\/elem$/) {
      if (length($number) > 0) {
         $currentArrayNumbers .= "$number ";
         $number = "";
      } else {
         #use default in case no array element amount is given
         $currentArrayNumbers .= "1 ";
      }
   }

   if ($tag =~ /ioctl$/) {
      #end of ioctl tag
      if ($currentIoctlType =~ /R/) {
         $ioctlsReadParamName{$currentIoctlFktName} = $currentElemName;
      } else {
         $ioctlsWriteParamName{$currentIoctlFktName} = $currentElemName;
      }
      $currentElemName = "";
      $currentIoctlType = "";
  }
}
################################################################################

################################################################################
# API callback handler to the API configuration file
my $generateIoctl = 0;
my $requestIoctl = 0;
my $currentIoctl = "";
my $currentIoctlParamList = "";
my $currentWrite2ReadPair = undef;
my $currentConditional = undef;

#######################

sub ConfigXmlTagCallback {
   my ($tag, $data, %attributes) = @_;

   if ($tag =~ /ioctl\/name/){ $currentIoctl = $data;}
   if ($tag =~ /ioctl\/param/){ $currentIoctlParamList .= "$data "}
   if ($tag =~ /ioctl\/pair/){ $currentWrite2ReadPair = $data;}
   if ($tag =~ /ioctl\/conditional/){ $currentConditional = $data;}

   if ($tag =~ /ioctl$/) {
      if (defined $attributes{'generate'}) {
         if ($attributes{'generate'} eq 'yes') {
            $generateIoctl = 1;
         }
      }

      if (defined $attributes{'request'}) {
         if ($attributes{'request'} eq 'yes') {
            $requestIoctl = 1;
         }
      }
   }
}

sub ConfigXmlTagEndCallback {
   my ($tag) = @_;

   if ($tag =~ /ioctl$/) {
      if ($requestIoctl == 1) {
         $ioctlsReadGetParamName{$currentIoctl} = $currentIoctlParamList;
      }

      if ($generateIoctl == 0) {
         $ioctlsNotGenerate{$currentIoctl} = 1;
      }

      if (defined $currentWrite2ReadPair) {
         $ioctlWrite2ReadPair{$currentIoctl} = $currentWrite2ReadPair;
         $currentWrite2ReadPair = undef;
      }

      if (defined $currentConditional) {
         #Conditional means to generate the C function by C pre processor directive encapsulation
         # '#ifdef $currentConditional' and '#endif /* $currentConditional */'.
         $ioctlsConditional{$currentIoctl} = $currentConditional;
         $currentConditional = undef;
      }

      $currentIoctl = "";
      $currentIoctlParamList = "";
      $generateIoctl = 0;
      $requestIoctl = 0;
   }
}
################################################################################

#provide a structure name and the parameter name of an element inside the
#structure
#The function prints out the argument scanning line in case the parameter size is "8","16","32".
#This function does not print out anything in case of arrays!
sub scanParamArg {
   my $struc = shift;
   my $Param = shift;

   sub printscanParamArg {
      my ($tmp1, $tmp2) = @_;
      print OUT "   cnt += scanParamArg(argc, argv, \"$tmp1\", $tmp2, &param.$tmp1);\n";
      return ;
   }

   my @strucElem = split /\ /, $structures{$struc};
   my @strucTypesElem = split /\ /, $structuresTypes{$struc};
   my @strucTypesArrayNumbers = split /\ /, $structuresArrayNumbers{$struc};

   for (my $i = 0; $i < @strucElem; $i++) {
      if ($strucElem[$i] eq $Param) {
         my $ParamType = $strucTypesElem[$i];

         #first find out if the parameter is a MAC address and print out the
         #parameter scanning accordingly
         if ((($strucTypesArrayNumbers[$i] eq "6") ||
              ($strucTypesArrayNumbers[$i] eq "IFX_MAC_ADDRESS_LENGTH")) &&
             ($ParamType eq "IFX_uint8_t")) {
            print OUT "   cnt += scanMAC_Arg(argc, argv, \"$Param\", param.$Param);\n";
            return;
         }

         #No MAC address parameter found -> scan regular parameter

         if ($strucTypesArrayNumbers[$i] ne "1") {
            return;
         }
         #identify the size of the parameter to scan
         if ($ParamType =~ /int8/) { return printscanParamArg($Param, "8"); }
         elsif ($ParamType =~ /int16/) { return printscanParamArg($Param, "16"); }
         else { return printscanParamArg($Param, "32"); }
      }
   }
   print "WARNING: Unknown \"$Param\" size for structure \"$struc\"\n";

   return printscanParamArg($Param, "32");

}

my $FunctionPrintConditional = undef;

# This function add a pre processor conditional directive before the next
# generated function (on demand) and add a the closing directirve behind the previous
# generated function output (on demand).
# This function should be used together with the function 'printConditionalPostFunction'.
# It is called in the perl functions to generate read-/write- C function output
sub printConditionalPreFunction {
   my $ioctlCmd = shift;

   if (defined $ioctlsConditional{$ioctlCmd}) {
      if (defined $FunctionPrintConditional) {
         if ($FunctionPrintConditional ne $ioctlsConditional{$ioctlCmd}) {
            print OUT "#endif /* $FunctionPrintConditional */\n\n";
            print OUT "#ifdef $ioctlsConditional{$ioctlCmd}\n\n";
         }
      } else {
         print OUT "#ifdef $ioctlsConditional{$ioctlCmd}\n\n";
      }
      $FunctionPrintConditional = $ioctlsConditional{$ioctlCmd};
   } elsif (defined ($FunctionPrintConditional)){
      print OUT "#endif /* $FunctionPrintConditional */\n\n";
      undef $FunctionPrintConditional;
   }
}

# This function adds the pre processor conditional directive behind the last
# generated function (ond demand).
# This function should be used together with the function 'printConditionalPreFunction'.
# It is called in the perl functions to generate read-/write- C function output
sub printConditionalPostFunction {
   my $ioctlCmd = shift;

   if (defined ($FunctionPrintConditional)){
      print OUT "#endif /* $FunctionPrintConditional */\n\n";
      undef $FunctionPrintConditional;
   }
}

#generate all functions that only write parameter to the ioctl and do not read
#any parameter
sub generateWriteFunctions {

   foreach $ioctlCmd (sort keys %ioctlsWriteParamName) {
       my @strucElem = ();

      #some ioctl command should not be generated
      if (defined $ioctlsNotGenerate{$ioctlCmd}) { next;}

      my $function = lc $ioctlCmd;

      #print conditional preprocessor directives if <conditional> flag is given
      printConditionalPreFunction $ioctlCmd;

      print OUT "int $function(int argc, char *argv[], int fd, int numPar) {\n";
      my $struc = $ioctlsWriteParamName{$ioctlCmd};
      my $ioctlVariable = "0";
      if (defined $structures{$struc}) {
         @strucElem = split /\ /, $structures{$struc};
         my @readParam = ();
         $ioctlVariable = "&param";
         print OUT "   $struc param;\n";
         if (@strucElem > 0) {
            print OUT "   int cnt = 0;\n";
         }
         print OUT "   memset(&param, 0, sizeof($struc));\n\n";

         #some write functions have a corresponding pair read function that
         #should be called first to get the original/current configuration.
         #Afterwards this configuraiton is changed by the input parameter and
         #the modified data are written back to Switch API
         if (defined $ioctlWrite2ReadPair{$ioctlCmd}) {
            #printout the read parameter for the pair read function and
            #make the corresponding IOCTL call
            my $readCmd = $ioctlWrite2ReadPair{$ioctlCmd};

            if (not defined ($ioctlsReadGetParamName{$readCmd})) {
               die "ERROR: Can't generate pair read function \"$readCmd\" for command \"$ioctlCmd\"\n";
            }

            @readParam = split /\ /, $ioctlsReadGetParamName{$readCmd};

            foreach my $elem (@readParam) {
               scanParamArg($struc, $elem);
            }

            my $readParNum = @readParam;
            if ($readParNum > 0) {
               print OUT "   if (cnt != $readParNum)\n";
               print OUT "      return (-3);\n\n";
            }

            print OUT "   if(cli_ioctl(fd, $readCmd, $ioctlVariable) != 0)\n";
            print OUT "      return (-4);\n\n";
         }

         foreach my $elem (@strucElem) {
            #scan input parameter for the write operation. Don't scan parameter
            #that where already scanned before for the read operation. It is
            #expected that the read operation does not modify these parameters
            my $printout = 1;
            foreach my $tmp (@readParam) {
               if ($tmp eq $elem) {
                  $printout = 0;
                  last;
               }
            }
            if ($printout) {
               scanParamArg($struc, $elem);
            }
         }

         if (@strucElem > 0) {
            print OUT "   if (cnt != numPar)\n";
            print OUT "      return (-2);\n\n";
         }
      }

      print OUT "   return cli_ioctl(fd, $ioctlCmd, $ioctlVariable);\n";
      print OUT "}\n\n";
   }

   #print conditional preprocessor directives if <conditional> flag is given
   printConditionalPostFunction $ioctlCmd;
}

#generate all functions that write and read parameter to and from the ioctl.
#This function also prints out all returned values
sub generateReadFunctions {
   #warning list of commands that are given by the XML parameter list but can
   #not be found in the API XML file
   my @warningList = ();

   foreach $ioctlCmd (sort keys %ioctlsReadGetParamName) {

      if (defined $ioctlsNotGenerate{$ioctlCmd}) {
         #request/get ioctl is defined in XML, but marked to not generate
         next;
      }

      if (not defined ($ioctlsReadParamName{$ioctlCmd})) {
         push @warningList, $ioctlCmd;
         next;
      }

      my $function = lc $ioctlCmd;
      my $struc = $ioctlsReadParamName{$ioctlCmd};

      my @readParam = split /\ /, $ioctlsReadGetParamName{$ioctlCmd};
      if ((not defined $structures{$struc}) ||
          (not defined $structuresTypes{$struc})) {
         die "$ioctlCmd structure not defined!\n";
      }

      my @strucElem = split /\ /, $structures{$struc};
      my @strucElemTypes = split /\ /, $structuresTypes{$struc};
      my @strucElemArrayNumbers = split /\ /, $structuresArrayNumbers{$struc};

       #print conditional preprocessor directives if <conditional> flag is given
      printConditionalPreFunction $ioctlCmd;

     print OUT "int $function(int argc, char *argv[], int fd, int numPar) {
   $struc param;\n";
      if (@readParam > 0) {
         print OUT "   int cnt = 0;\n";
      }

      print OUT "   memset(&param, 0, sizeof($struc));\n";

      if (@readParam > 0) { print OUT "\n"; }
      foreach my $elem (@readParam) {
         scanParamArg($struc, $elem);
      }

      if (@readParam > 0) {
         print OUT "   if (cnt != numPar)
      return (-2);\n";
      }

      print OUT "\n   if (cli_ioctl(fd, $ioctlCmd, &param) != 0) {\n";
      print OUT "      printf(\"ioctl returned with ERROR!\\n\");\n";
      print OUT "      return (-1);\n";
      print OUT "   }\n\n";

      if (@strucElem > 1) {
         print OUT "   printf(\"Returned values:\\n----------------\\n\");\n";
      } else {
         print OUT "   printf(\"Returned value:\\n---------------\\n\");\n";
      }

      for (my $j = 0; $j < @strucElem; $j++) {
         my $elem = $strucElem[$j];
         my $elemType = $strucElemTypes[$j];
         my $elemArrayNumbers = $strucElemArrayNumbers[$j];

         if ((($elemArrayNumbers eq "6") ||
              ($elemArrayNumbers eq "IFX_MAC_ADDRESS_LENGTH")) &&
             ($elemType eq "IFX_uint8_t")) {
            #we printout a MAC address
            print OUT "   printf(\"\\t%40s:\\t\", \"$elem\");\n";
            print OUT "   printMAC_Address(param.$elem);\n";
            print OUT "   printf(\"\\n\");\n";
         } elsif ($elemType eq 'IFX_boolean_t') {
            #special printout treatment for boolean variables
            print OUT "   printf(\"\\t%40s:\\t%s\\n\", \"$elem\", (param.$elem > 0)?\"TRUE\":\"FALSE\");\n";
         } elsif ($elemType eq 'IFX_uint64_t') {
            #prinout a dedicated 64-bit value
            print OUT "   printf(\"\\t%40s:\\t%lu (0x%0lx)\\n\", \"$elem\", (unsigned long)param.$elem, (unsigned long)param.$elem);\n";
         } else {
            #printout anything else
            my $bitmapLen = 0;
            if ($elem =~ /nPortId/) {
               #PortId parameter supports bitmaps where the MSB bit defines if the parameter
               #represents a bitmap or an index value.
               if ($elemType eq 'IFX_uint32_t') {
                  $bitmapLen = 32;
               } elsif ($elemType eq 'IFX_uint8_t') {
                  $bitmapLen = 8;
               }
            }
            print OUT "   printHex32Value(\"$elem\", param.$elem, $bitmapLen);\n";
         }
      }
      print OUT "   return 0;\n}\n\n";
   }

   #print conditional preprocessor directives if <conditional> flag is given
   printConditionalPostFunction $ioctlCmd;

   #print out the warning list
   if (@warningList) {
      print "WARNING: Following parameter list commands not found in API XML file:\n";
      foreach my $tmp (@warningList) {
         print "\t-> \"$tmp\"\n";
      }
      print "\n";
   }
}

sub generateHeaderFile {
   foreach my $func (sort keys %ioctlsWriteParamName) {
      my $lcFunc = lc $func;
      print OUT "int $lcFunc(int, int, char **);\n";
   }

   foreach my $func (sort keys %ioctlsReadParamName) {
      my $lcFunc = lc $func;
      print OUT "int $lcFunc(int, int, char **);\n";
   }
}

########### main ###########

# parse command line options
getopts("c:h:i:o:t", \%options) or die "invalid option\n";

if (not defined $options{i}) {
   print STDERR "ERROR: No input files given!\n\n";
   die PrintHelp;
}

if (not defined $options{o}) {
   print STDERR "ERROR: No output files given!\n\n";
   die PrintHelp;
}

#Parsing the API XML file
die "Can't find file \"$options{i}\"" unless -f $options{i};
parseAPIfile($options{i}, \&ApiXmlTagCallback, \&ApiXmlTagEndCallback);

if (defined $options{c}) {
   #Parsing the GET APIs and Blacklist APIs XML file
   parseAPIfile($options{c}, \&ConfigXmlTagCallback, \&ConfigXmlTagEndCallback);
}

sysopen(OUT, $options{o}, O_WRONLY | O_CREAT | O_TRUNC) || die "$options{o} could not be opened!\n";
print OUT $header;
print OUT "#include <stdio.h>\n";
print OUT "#include <string.h>\n";
print OUT "#include <stdlib.h>\n";
print OUT "#include <sys/ioctl.h>\n";
print OUT "#include <fcntl.h>\n";
print OUT "#include <unistd.h>\n";
print OUT "#include <errno.h>\n";
print OUT "#include <ctype.h>\n";
print OUT "#include \"ifx_ethsw.h\"\n";
print OUT "#include \"ifx_ethsw_PSB6970.h\"\n";
print OUT "#include \"ifx_ethsw_flow.h\"\n";
print OUT "#include \"ifx_cli_lib.h\"\n\n";

generateWriteFunctions;
generateReadFunctions;
close(OUT);

if (defined $options{h}) {
   #generate H-file
   sysopen(OUT, $options{h}, O_WRONLY | O_CREAT | O_TRUNC) || die "$options{h} could not be opened!\n";
   print OUT $header;
   print OUT "#ifndef _CMD_DECLARE_H\n";
   print OUT "#define _CMD_DECLARE_H\n";
   generateHeaderFile;
   print OUT "#endif /* _CMD_DECLARE_H*/\n";
   close OUT;
}
