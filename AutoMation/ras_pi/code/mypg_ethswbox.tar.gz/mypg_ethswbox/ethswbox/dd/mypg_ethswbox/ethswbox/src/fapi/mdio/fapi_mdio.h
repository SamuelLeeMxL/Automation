/******************************************************************************

         Copyright 2016 - 2017 Intel Corporation
         Copyright 2015 - 2016 Lantiq Beteiligungs-GmbH & Co. KG
         Copyright 2012 - 2014 Lantiq Deutschland GmbH

  SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only)

******************************************************************************/

#ifndef _FAPI_MDIO_H_
#define _FAPI_MDIO_H_



#include "os.h"
#include "types.h"
 
s32 fapi_mdio_c45_read (u16 if_id, u16 port, u16 dev, u16 reg);
s32 fapi_mdio_c45_write (u16 if_id, u16 port, u16 dev, u16 reg, u16 val);

s32 fapi_mdio_c22_read (u16 if_id, u16 port, u16 reg);
s32 fapi_mdio_c22_write (u16 if_id, u16 port,  u16 reg, u16 val);

#endif /* _FAPI_MDIO_H_ */
