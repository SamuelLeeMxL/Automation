#!/bin/sh

#switch_utility()
#{
#    echo switch_utility $@
#}

read_table_entry()
{
    #$1 table index
    #$2 offset inside the table index

    sleep 1

    #PCE_TBL_ADDR = $2
    echo switch_utility RegisterSet 0x44E $2
    switch_utility RegisterSet 0x44E $2

    #PCE_TBL_CTRL.ADDR = $1
    echo switch_utility RegisterSet 0x44F $1
    switch_utility RegisterSet 0x44F $1

    sleep 1

    echo "KeyData:"
    switch_utility RegisterGet 0x447
    switch_utility RegisterGet 0x446
    switch_utility RegisterGet 0x445
    switch_utility RegisterGet 0x444
    switch_utility RegisterGet 0x443
    switch_utility RegisterGet 0x442
    switch_utility RegisterGet 0x441
    switch_utility RegisterGet 0x440
    switch_utility RegisterGet 0x43F
    switch_utility RegisterGet 0x43E
    switch_utility RegisterGet 0x43D
    switch_utility RegisterGet 0x43C
    switch_utility RegisterGet 0x43B
    switch_utility RegisterGet 0x43A
    switch_utility RegisterGet 0x439
    switch_utility RegisterGet 0x438

    echo "Mask:"
    switch_utility RegisterGet 0x448

    echo "Value:"
    switch_utility RegisterGet 0x44D
    switch_utility RegisterGet 0x44C
    switch_utility RegisterGet 0x44B
    switch_utility RegisterGet 0x44A
    switch_utility RegisterGet 0x449

    echo "Address:"
    switch_utility RegisterGet 0x44E
 
    echo "Control:"
    switch_utility RegisterGet 0x44F
 
    echo "Stat:"
    switch_utility RegisterGet 0x450
}



vlan_aktiv()
{
    read_table_entry 0x9001 $1
}

vlan_mapping()
{
    read_table_entry 0x9002 $1
}

pppoe()
{
    read_table_entry 0x9003 $1
}

protocol()
{
    read_table_entry 0x9004 $1
}

application()
{
    read_table_entry 0x9005 $1
}

ip_dasa_msb()
{
    read_table_entry 0x9006 $1
}

ip_dasa_lsb()
{
    read_table_entry 0x9007 $1
}

ip_length()
{
    read_table_entry 0x9008 $1
}

pcp()
{
    read_table_entry 0x9009 $1
}

dscp()
{
    read_table_entry 0x900A $1
}

mac_dasa()
{
    read_table_entry 0x900C $1
}

mc_sw()
{
    read_table_entry 0x900D $1
}

mc_hw()
{
    read_table_entry 0x900E $1
}

flow()
{
    read_table_entry 0x900F $1
}

remarking()
{
    read_table_entry 0x9010 $1
}

queue()
{
    read_table_entry 0x9011 $1
}

$@

