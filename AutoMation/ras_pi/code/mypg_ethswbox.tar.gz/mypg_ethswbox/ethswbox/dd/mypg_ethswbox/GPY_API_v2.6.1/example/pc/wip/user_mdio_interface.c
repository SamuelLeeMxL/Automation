/******************************************************************************

         Copyright 2016 - 2017 Intel Corporation
         Copyright 2015 - 2016 Lantiq Beteiligungs-GmbH & Co. KG
         Copyright 2012 - 2014 Lantiq Deutschland GmbH

  SPDX-License-Identifier: (BSD-3-Clause OR GPL-2.0-only)

******************************************************************************/

#include <windows_stub.h>
#include <stdio.h>
#include <unistd.h>
#include <gpy211.h>
#include <registers/phy/std.h>
#include <registers/p31g/p31g_mdio_pdi.h>
#include "gpy211_utility.h"
 
#include <gpy211_macsec.h> 
#include "gpy211_utility_gpy2xx.h"

#include "api_gpy.h"
#include "conf_if.h"


int gpy211_mdio_read(void *busdata, u16 phyaddr, u32 regnum)
{
	u32 _mdio_data;
	u16 _reg_num, _dev_id;
	LOG_INFO("Entering func name :- %s\n", __func__);


    _mdio_data = api_gpy_read(busdata, phyaddr, regnum);

	LOG_INFO("Exiting func name :- %s\n", __func__);
	return _mdio_data;
}

int gpy211_mdio_write(void *busdata, u16 phyaddr, u32 regnum, u16 data)
{
	s16 ret = 0;

	LOG_INFO("Entering func name :- %s\n", __func__);

    ret = api_gpy_write( busdata, phyaddr, regnum, data);

	LOG_INFO("Exiting func name :- %s\n", __func__);
	return ret;
}



struct gpy211_device* gpy211_mdio_open (void)
{
 
  struct gpy211_device* p_phy;  

/* Initialize the BCM mdio library
      Open the mdio
      
   bcm2835_init (RPI4B_GPIO_MEM);
   ret = mdio_open(RPI4B_GPIO_MDIO_CLK_PIN, RPI4B_GPIO_MDIO_DATA_PIN);
*/
     p_phy = (struct gpy211_device*)api_gpy_open (0, 0, phyphy.phy_addr);	

    return p_phy; 
}


void gpy211_mdio_close (void)
{
 
 /*
   (void)mdio_close(RPI4B_GPIO_MDIO_CLK_PIN, RPI4B_GPIO_MDIO_DATA_PIN);
 */

    api_gpy_close (0, 0, phyphy.phy_addr);	

}


