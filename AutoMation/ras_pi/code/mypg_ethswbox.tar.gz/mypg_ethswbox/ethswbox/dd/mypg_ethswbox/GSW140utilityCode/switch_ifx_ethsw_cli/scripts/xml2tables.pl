#!/usr/bin/perl -w
use Fcntl;
use Getopt::Std;
use lib '../scripts';
use apixml;

my $header = "/****************************************************************************

                               Copyright 2010
                          Lantiq Deutschland GmbH
                   Am Campeon 3; 85579 Neubiberg, Germany

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

*****************************************************************************/\n";

sub PrintHelp {
   print "Usage: $0 <options>
Generate C File containing an array with help text for dedicated IOCTL commands.

Usage:
   -i <file>     Main API description XML file (input file)
   -g <file>     API input parameter XML file (input file)
   -o <file>     Write output C-file.\n";
   exit 0;
}

my @cmdTableContent = ();
my @helpTextTableContent = ();
my @ioctls = ();
my @structs = ();
my @enums = ();

#The array contains alternative IOCTL function description that are given
#by the "API imput parameter XML file" inside the <ioctl/descr> tag
my %alterIoctlDescr = ();
my %appendIoctlDescr = ();

#Some GET command carry some parameter that are needed as input parameter
#before calling the GET ioctl command. This hash array contains this input
#parameter list for all GET commands. This hash array is filled by reading
#the "API input parameter XML file"
my %GetFktParamList = ();

my $ParameterDescrIndent = 8;
#global variable for every function that the parameter header is printed out
#this variable is set before "printStruct" is started to be called in recursive
#fashion. The recursive calls will set it before printing out the first parameter
#description
my $printParameterHelpText = 0;

################################################################################

#Generate the pre compiler conditional ifdef-endif-statments. The generated
#text is the returned string
my $oldCond = undef;
sub genConditional {
   my $newCond = shift;

   my $output = "";
   my $tmp1 = "";
   my $tmp2 = "";

   if (defined ($oldCond)) {$tmp1 = $oldCond;}
   if (defined ($newCond)) {$tmp2 = $newCond;}

   if ($tmp1 ne $tmp2) {
      if (defined ($oldCond)) {
         $output .= "#endif /* " . $oldCond . "*/\n";
      }
      if (defined ($newCond)) {
         $output .= "#ifdef " . $newCond . "\n";
      }
      $oldCond = $newCond;
   }
   return $output;
}

#Generate the table containing the ioctl command string and the low level
#function pointer
sub FktTableGen {
   my $platform = undef;
   my $idx = 0;
   my $tableSize = @ioctls + 1;
   push @cmdTableContent, "const IFX_ETHSW_CommandTable_t cmdTable[] = {\n";
   foreach my $cmd (@ioctls) {
      my $cmdName = $cmd->{_name};
      my $func = lc $cmdName;


      #print out ifdef-statements for the different platforms, if required
      push @cmdTableContent, genConditional($ConditionalIoctlList{$cmdName});

      push @cmdTableContent, "   {/* $idx */ \"$cmdName\", (command_fkt)$func},\n";
      $idx++;
   }

   #printout '#endif' statement at the end if required
   push @cmdTableContent, genConditional(undef);

   push @cmdTableContent, "   {NULL, NULL}\n};\n\n";
}

#Generate the table containting the ioctl command help strings
sub HelpTextTableGen {

   sub printTabs {
      my $spaces = shift;

      while ($spaces > 0) {
         push @helpTextTableContent, "\\t";
         $spaces = $spaces - 8;
      }
   }

   #printout the description and ensure that any word is never exceeding the
   #80 character bondary of the terminal line size.
   #First parameter is the description text, the second parameter is the number
   #of character which the text should be indented.
   sub printDescr {
      my $descr = shift;
      my $numPref = shift;

      @words = split / /, $descr;

      my $lineLen = $numPref;

      foreach my $word (@words) {
         $lineLen = $lineLen + length($word) + 1;

         if ($lineLen >= 80) {
            push @helpTextTableContent, "\\n\"\n   \"";
            $lineLen = $numPref + length($word) + 1;
            printTabs($numPref);
         }
         #replace '"' by '\"' inside the string, because these characters are
         #inside a C-Code string array and therefore they should be treated
         #as special character
         $word =~ s/\"/\\\"/g;

         push @helpTextTableContent, "$word ";
      }
      push @helpTextTableContent, "\\n\"\n";
   }

   #Some variable types inside a structure are enumerators. This function
   #checks if the type is an enumerator and printouts the corresponding
   #enumerator help
   sub printEnum {
      my $enumName = shift;
      my $numPref = shift;

      my $printedEnumHelp = 0;

      foreach my $tmp (@enums) {
         if ($enumName ne $tmp->{_name}) { next;}

         $printedEnumHelp = 1;
         #enumerator found. Now printout the value and their description
         push @helpTextTableContent, "   \"";
         printTabs($numPref);
         push @helpTextTableContent, "Supported Values:\\n\"\n   \"";
         printTabs($numPref);
         push @helpTextTableContent, "-----------------\\n\"\n";

         my $tmp2 = $tmp->{_elem};
         while (defined $tmp2) {
            push @helpTextTableContent, "   \"";
            printTabs($numPref);
            push @helpTextTableContent, $tmp2->{_value},": ";
            printDescr($tmp2->{_descr}, $numPref + 3);
            push @helpTextTableContent, "   \"\\n\"\n";

            $tmp2 = $tmp2->{_elem};
         }
         last;
      }
      return $printedEnumHelp;
   }

   #This function prints out the help text for all variables inside a structure
   #It might call "printEnum" for all types to ensure that enumerator help
   #text is checked and also printed out accordingly.
   sub printStruct {
      my $variableType = shift;
      my $variableName = shift;
      my $variableDescription = shift;
      my $excludedParam = shift;

      #print "printStruct\n";
      #print "$variableType variableType\n";
      #print "$variableName variableName\n\n";

      my $bStructFound = 0;
      foreach my $tmp (@structs) {
         if ($tmp->{_name} ne $variableType) {next;}

         #structure element/type found!
         $bStructFound = 1;

         my $tmp2 = $tmp->{_elem};
         while (defined $tmp2) {
            #check if for this command we have a list of input parameter. This
            #list is given in case it is a request command and it requires some
            #input parameter.
            if (defined $excludedParam) {
               if (!($excludedParam =~ /$tmp2->{_name}/)){
                  #go to next element!
                  $tmp2 = $tmp2->{_elem};
                  next;
               }
            }
            #either this command is not in the request command list or
            #this parameter in an input parameter

            if (length($variableDescription)) {
               #printout the previously given description one time before
               #going to the next recursive level
               push @helpTextTableContent, "   \"";
               printDescr($variableDescription, 0);
               $variableDescription = "";
            }

            my $tmpName = $variableName;
            if (length($tmpName)) {
               #if there is already a valid variable name given, add a '.'
               #separator before adding the next name part
               $tmpName .= ".";
            }
            $tmpName .= $tmp2->{_name};
            printStruct($tmp2->{_type}, $tmpName, $tmp2->{_descr});

            #go to next element!
            $tmp2 = $tmp2->{_elem};
         }
         #don't run the loop a next time, because we were only searching for the
         #one and only required array element
         last;
      }

      if ($bStructFound == 0) {
         #no new structure or sub-structure found. Therefore printout what we
         #got so fare

         #printout the title in case this was not done already for this function
         if (!$printParameterHelpText) {
            push @helpTextTableContent, "   \"\\nParameter:\\n----------\\n\"\n";
            $printParameterHelpText = 1;
         }

         push @helpTextTableContent, "   \"", $variableName, " :\\n\"\n";
         push @helpTextTableContent, "   \"";
         printTabs($ParameterDescrIndent);
         printDescr($variableDescription, $ParameterDescrIndent);
         if ($variableType eq 'IFX_ETHSW_IP_t') {
            #Additional help text to be printed out in case of IPv4/v6 data type
            push @helpTextTableContent, "   \"";
            printTabs($ParameterDescrIndent);
            push @helpTextTableContent, "Supported Formats: 10.1.1.1 or f0f3:0013:e0b5: ...\"\n";
         }
         elsif (($variableName =~ /MAC/) && ($variableType eq 'IFX_uint8_t')){
            #Additional help text to be printed out in case of MAC address data type
            push @helpTextTableContent, "   \"";
            printTabs($ParameterDescrIndent);
            push @helpTextTableContent, "Supported Formats: 12:34:45:67:89:0A\"\n";
         }

         #check if element type is an enumerator
         my $printEnum = printEnum($variableType, $ParameterDescrIndent);

         if (!$printEnum) { push @helpTextTableContent, "   \"\\n\"\n";}
      }
   }

   #Generate the table containing the ioctl help string text
   my $idx = 0;
   my $tableSize = @ioctls + 1;
   my $platform = undef;
   push @helpTextTableContent, "#ifdef SWITCHAPI_HELP_TEXT\n";
   push @helpTextTableContent, "const char * const HelpText[] = {\n";
   foreach my $command (@ioctls) {
      if (defined ($platform) && ($command->{_name} !~ /$platform/)) {
         push @helpTextTableContent, "#endif\n";
         $platform = undef;
      }

      #print out ifdef-statements for the different platforms, if required
      push @helpTextTableContent, genConditional($ConditionalIoctlList{$command->{_name}});

      push @helpTextTableContent, "   /* $idx: $command->{_name} */\n";
      $idx = $idx + 1;

      if (defined ($alterIoctlDescr{$command->{_name}})) {
         #alternative IOCTL description given by API parameter file
         #therefore take it and ignove the description from the
         #standard API XML description file.
         push @helpTextTableContent, $alterIoctlDescr{$command->{_name}};
      } else {
         #No alternative IOCTL description given by API parameter file
         #therefore retrieve the description from the standard API XML
         #description file.
         push @helpTextTableContent, "   \"";
         printDescr($command->{_descr}, 0);
         if (defined($command->{_arg}) && ($command->{_arg} ne 'IFX_void_t')) {
            #reset the variable that indicates that the 'parameter' title is
            #already printed out within "printStruct"
            $printParameterHelpText = 0;
            printStruct($command->{_arg}, "", "", $GetFktParamList{$command->{_name}});
         }
         if (defined ($appendIoctlDescr{$command->{_name}})) {
            #additional IOCTL description given by API parameter file
            #therefore take it and append it to the
            #standard API XML description file description.
            push @helpTextTableContent, $appendIoctlDescr{$command->{_name}};
         }
      }
      push @helpTextTableContent, "   ,\n";
   }

   #printout '#endif' statement at the end if required
   push @helpTextTableContent, genConditional(undef);

   push @helpTextTableContent, "   NULL };\n";
   push @helpTextTableContent, "#endif /* SWITCHAPI_HELP_TEXT */\n";
}

#function runs through the help text array and removes unneeded "\n" at the end
#of every entry and combine multiple following "\n" characters.
sub CleanupHelpTextTable {
   my $tmp = "";
   my $tmp2 = undef;
   while (@helpTextTableContent) { $tmp .= shift @helpTextTableContent; }

   do {
      $tmp2 = $tmp;
      $tmp =~ s/[\ \t]*\\n\"[\ \t\n]*,/\",/g;
      $tmp =~ s/\"[\ \t\n]*\"\"/\"/g;
   } while ($tmp ne $tmp2);

   @helpTextTableContent = ();
   push @helpTextTableContent, $tmp;

}

#Printout all table content array to the output C-File
sub C_filePrintout {
   sysopen(OUT, $options{o}, O_WRONLY | O_CREAT | O_TRUNC) || die "$options{o} could not be opened!\n";
   print OUT $header;
   print OUT "#include <stdio.h>\n";
   print OUT "#include \"ifx_ethsw.h\"\n";
   print OUT "#include \"ifx_cli_lib.h\"\n";
   print OUT "#include \"ifx_ethsw_cli_fkts.h\"\n";
   print OUT "#include \"switch_cli_config.h\"\n\n";

   print OUT @cmdTableContent;

   #copy the help text table content into a skalar variable and replace the
   #leading spaces before the '\n' inside the table content. This should
   #reduce the table size by unused spaces
   my $tmp = "";
   while (@helpTextTableContent) { $tmp .= shift @helpTextTableContent; }
   $tmp =~ s/\ \\n/\\n/g;

   #printout the help text table content to the output file
   print OUT $tmp;

   close(OUT);
}

################################################################################
#Get Function Input Parameter XML File Parsing
my $GetFktXmlName = undef;
my $GetFktXmlParamList = "";
my $ConditionalIoctlList = "";
my $GetFktXmlRequestIoctl = 0;
my $alternativeDescr = undef;
my $GetFktConditional = undef;
my $DescriptionReplaceAddOption = 0;

sub GetFktXmlTagCallback {
   my ($currentTag, $data, %currentAttr) = @_;

   if ($currentTag =~ /ioctl$/) {
      if ((defined $currentAttr{'request'}) && ($currentAttr{'request'} eq 'yes')) {
         #This ioctl is a request function. Therefore take it into account
         #for parameter as request input parameter
         $GetFktXmlRequestIoctl = 1;
      }
      if (defined $currentAttr{'description'}) {
         if ($currentAttr{'description'} eq 'replace') {
            $DescriptionReplaceAddOption = 1;
         } elsif ($currentAttr{'description'} eq 'append') {
            $DescriptionReplaceAddOption = 2;
         }
      }
   }
   if ($currentTag =~ /ioctl\/name$/) { $GetFktXmlName = $data; }
   if ($currentTag =~ /ioctl\/descr$/) {
      #alternative ioctl description given in XML file
      $alternativeDescr .= "   \"$data\\n\"\n";
   }
   if ($currentTag =~ /ioctl\/param$/) {
      if ((defined $currentAttr{'write'}) && ($currentAttr{'write'} eq 'yes')) {
         if (not defined $GetFktXmlParamList) {
            $GetFktXmlParamList = $data;
         } else {
            $GetFktXmlParamList .= " $data";
         }
      }
   }

   #get the API <conditional> tag
   if ($currentTag =~ /ioctl\/conditional$/) {
      $GetFktConditional = $data;
   }
}

sub GetFktXmlTagEndCallback {
   my ($currentTag) = @_;

   if ($currentTag =~ /ioctl$/) {
      die if (not defined($GetFktXmlName));
      if (defined($alternativeDescr)) {
         if ($DescriptionReplaceAddOption == 1) {
            $alterIoctlDescr{$GetFktXmlName} = $alternativeDescr;
         } elsif ($DescriptionReplaceAddOption == 2) {
            $appendIoctlDescr{$GetFktXmlName} = $alternativeDescr;
         }
         $alternativeDescr = undef;
      }

      #store if the API is set to conditional
      if (defined ($GetFktConditional)) {
         $ConditionalIoctlList{$GetFktXmlName} = $GetFktConditional;
         $GetFktConditional = undef;
      }

      if ($GetFktXmlRequestIoctl == 1) {
         $GetFktParamList{$GetFktXmlName} = $GetFktXmlParamList;
         $GetFktXmlParamList = "";
         $GetFktXmlName = undef;
         $GetFktXmlRequestIoctl = 0;
      }
      $DescriptionReplaceAddOption = 0;
   }
}
################################################################################

################################################################################
#API XML File Parsing
my $name = "";
my $arg = "";
my $descr = "";
my $elemName = "";
my $elemType = "";
my $elemDescr = "";
my @elem = ();

sub newIoctl {
   my $self = undef;

   $self->{_name} = $name;
   $name = "";

   $self->{_arg} = $arg if (length($arg) > 0);
   $arg = "";

   $descr =~ s/ +/ /g;
   $self->{_descr} = $descr;
   $descr = "";

   return $self;
}

sub newStructElem {
   my $self = undef;

   $self->{_name} = $elemName;
   $elemName = "";

   $self->{_type} = $elemType;
   $elemType = "";

   $self->{_descr} = $elemDescr;
   $elemDescr = "";

   return $self;
}

sub newStruct {
   my $self = undef;
   $self->{_name} = $name;
   $name = "";

   while ( my $tmp = pop @elem) {
      $tmp->{_elem} = $self->{_elem};
      $self->{_elem} = $tmp;
   }

   return $self;
}

sub newEnumElem {
   my $self = undef;

   $self->{_name} = $elemName;
   $elemName = "";

   $self->{_value} = $elemType;
   $elemType = "";

   $self->{_descr} = $elemDescr;
   $elemDescr = "";

   return $self;
}

sub newEnum {
   my $self = undef;
   $self->{_name} = $name;
   $name = "";

   while (my $tmp = pop @elem) {
      $tmp->{_elem} = $self->{_elem};
      $self->{_elem} = $tmp;
   }
   return $self;
}

sub ApiXmlTagCallback {
   my ($currentTag, $data, %currentAttr) = @_;

   if ($currentTag =~ /ioctl\/name/) {$name = $data;}
   if ($currentTag =~ /ioctl\/arg/) {$arg = $data;}
   if ($currentTag =~ /ioctl\/descr\/param/) {$descr .= $data . " ";}

   if ($currentTag =~ /struct\/name/) {$name = $data;}
   if ($currentTag =~ /struct\/elem\/name/) {$elemName = $data;}
   if ($currentTag =~ /struct\/elem\/type/) {$elemType = $data;}
   if ($currentTag =~ /struct\/elem\/descr\/param/) {$elemDescr .= $data;}

   if ($currentTag =~ /enum\/name/) {$name = $data;}
   if ($currentTag =~ /enum\/elem\/name/) {$elemName = $data;}
   if ($currentTag =~ /enum\/elem\/value/) {$elemType = $data;}
   if ($currentTag =~ /enum\/elem\/descr\/param/) {$elemDescr .= $data;}
}

sub ApiXmlTagEndCallback {
   my ($currentTag) = @_;

   if ($currentTag =~ /ioctl$/) {
      my $ioctl = newIoctl();
      push @ioctls, $ioctl;
   }
   elsif ($currentTag =~ /struct\/elem$/) {
      my $structElem = newStructElem;
      push @elem, $structElem;
   }
   elsif ($currentTag =~ /struct$/) {
      my $struct = newStruct;
      push @structs, $struct;
   }
   elsif ($currentTag =~ /enum\/elem$/) {
      my $enumElem = newEnumElem;
      push @elem, $enumElem;
   }
   elsif ($currentTag =~ /enum$/) {
      my $enum = newEnum;
      push @enums, $enum;
   }
}
################################################################################

########### main ###########

# parse command line options
getopts("g:h:i:o:", \%options) or die "invalid option\n";

if (not defined $options{i}) {
   print STDERR "ERROR: No input files given!\n\n";
   die PrintHelp;
}
if (not defined $options{o}) {
   print STDERR "ERROR: No output files given!\n\n";
   die PrintHelp;
}
die "Can't find file \"$options{i}\"" unless -f $options{i};

if (defined $options{g}) {
   #Parse the file that contains a list of API parameter that are input for the
   #Get and Request calls
   parseAPIfile($options{g}, \&GetFktXmlTagCallback, \&GetFktXmlTagEndCallback);
}

parseAPIfile($options{i}, \&ApiXmlTagCallback, \&ApiXmlTagEndCallback);

HelpTextTableGen;
CleanupHelpTextTable;
FktTableGen;
C_filePrintout;
