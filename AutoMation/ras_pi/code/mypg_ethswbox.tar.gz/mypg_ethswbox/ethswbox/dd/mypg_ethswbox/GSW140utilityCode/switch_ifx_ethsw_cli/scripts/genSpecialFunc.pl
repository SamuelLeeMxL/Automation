#!/usr/bin/perl -w
use Fcntl;
use Getopt::Std;

sysopen(IN, $ARGV[0], O_RDONLY) || die "$ARGV[0] could not be opened!\n";

while (<IN>) {

   if ($_ =~ /^[\ \t]*\#define[\ \t]*([a-zA-Z0-9_]+)[\ \t]*_IO([WR_BAD]+)\(([a-zA-Z0-9_]+)[\ \t]*,[\ \t]([a-zA-Z0-9_]+),[\ \t]*([a-zA-Z0-9_]+)[\ \t]*\)/) {
      #$1 IOCTL name
      #$2 operator
      #$3 Magic numerator
      #$4 command offset
      #$5 command argument
      my $cmd = $1;
      my $operator = $2;
      if ($operator =~ /R/) {
         print "<ioctl request=\"yes\" generate=\"yes\">\n";
      } else {
         print "<ioctl request=\"no\" generate=\"yes\">\n";
      }
      print "   <name>$cmd</name>\n</ioctl>\n"
   }
}
close (IN);
