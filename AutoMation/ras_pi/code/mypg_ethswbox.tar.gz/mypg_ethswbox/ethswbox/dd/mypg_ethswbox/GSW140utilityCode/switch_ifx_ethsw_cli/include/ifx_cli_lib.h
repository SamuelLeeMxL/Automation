/****************************************************************************

                               Copyright 2010
                          Lantiq Deutschland GmbH
                   Am Campeon 3; 85579 Neubiberg, Germany

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

*****************************************************************************/
#ifndef _IFX_CLI_LIB_H
#define _IFX_CLI_LIB_H
typedef int (*command_fkt) (int argc, char *argv[], int fd, int numPar);

#ifndef EMILIO
#define SWITCHAPI_GSWIP_SUPPORT 1
#undef SWITCHAPI_TANTOS_SUPPORT
#endif

// GSW_EMILIO #include "lantiq_ethsw.h"
// GSW_EMILIO #include "lantiq_ethsw_flow.h"
typedef struct {
   char *Name;
   command_fkt fkt;
}IFX_ETHSW_CommandTable_t;

int cli_ioctl (int fd, unsigned long int request, void *par);
int scanParamArg (int argc, char *argv[], char *name, int size, void *param);
int findStringParam(int argc, char *argv[], char *name);
int scanMAC_Arg (int argc, char *argv[], char *name, unsigned char *param);
int scanIPv4_Arg (int argc, char *argv[], char *name, unsigned int *param);
int scanIPv6_Arg (int argc, char *argv[], char *name, unsigned short *param);
int checkValidMAC_Address(unsigned char *pMAC);
void printMAC_Address(unsigned char *pMAC);
int checkValidIPv6_Address(unsigned short *ip);
void printIPv6_Address(unsigned short *ip);
void printIPv4_Address(unsigned int ip);
void printHex32Value(char *name, unsigned int value, unsigned int bitmapIndicator);

command_fkt fktGet(char *name);

#endif /* _IFX_CLI_LIB_H */
