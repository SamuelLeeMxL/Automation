from pyrpio.mdio import MDIO

val = -1

mdio_bus = MDIO(clk_pin=23, data_pin=24, path='/dev/gpiochip0')
mdio_bus.open()

val = mdio_bus.read_c22_register(0, 0x1e)
print (" PHY=0, Reg=0x16 val=", hex(val))

val = mdio_bus.read_c22_register(1, 0x1e)
print (" PHY=1, Reg=0x16 val=", hex(val))

val = mdio_bus.read_c45_register(0, 0, 0x1e)
print (" PHY=0, device=0 Reg=0x16 val=", hex(val))

val = mdio_bus.read_c45_register(1, 0, 0x1e)
print (" PHY=1, device=0 Reg=0x16 val=", hex(val))


val = mdio_bus.read_c45_register(2, 0, 0x1e)
print (" PHY=2, device=0 Reg=0x16 val=", hex(val))
mdio_bus.close()
